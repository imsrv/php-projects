#### value = GMT at your locality, in seconds -------------------------#
#### ie (5hrs AHEAD) = 5X60X60 = 18000, (3.5hrs BEHIND) = -3.5X60X60 = -12600

$gmtPlusMinus = 36000;

1;	# this line must remain in all 'require' files.

