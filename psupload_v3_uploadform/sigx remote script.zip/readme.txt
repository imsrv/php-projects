Remote SigX Image Generation.


The uses of this is limitless!


Desc: 

Now you can generate your own images for SigX!
with this version of sigx.php: the image is static and non-resizable.


How to use this?


Upload sigx.php onto your server into any folder.
Edit it for proper USERNAME and IMAGE (background image).
In profile just call the [img]http://url.to/sigx.php[/img]
