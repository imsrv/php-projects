#!/usr/bin/perl
######################################################################
##  server.cgi - locate and provide information about a server      ##
######################################################################
##  This software is freeware and may be edited and redistributed.  ##
##  This may not work on all NT servers, it is a quick hack so      ##
##  beginners can try to find out more info about their server      ##
##  without having to bother the sysadmin.                          ##
######################################################################

#use strict;
use IO::Socket;
#use vars qw(%TPL);

print "Content-type: text/html\n\n";

$TPL{'OPSYS'} = getos();
$TPL{'SSOFT'} = getssoft();
$TPL{'CUDIR'} = getcudir();
$TPL{'MLLOC'} = getmail();
$TPL{'STIME'} = getstime();
$TPL{'PVERS'} = $];
display();

exit;

sub err {
  my($cause, $file, $fnct) = @_;
  chomp($cause);

  print "<pre>\n" if( $ENV{'REQUEST_METHOD'} );
  print "A CGI ERROR HAS OCCURRED\n========================\n";
  print "Error Message     :  $cause\n";   
  print "Accessing File    :  $file\n";

  exit;
}

sub getos {
  my $os = `ver`;
  if( !$os ) {
    $os = ucfirst($^O);
  }
  return $os ? $os : "<font color='red'>Unknown</font>";
}

sub getssoft {
  return $ENV{'SERVER_SOFTWARE'} ? $ENV{'SERVER_SOFTWARE'} : "<font color='red'>Unknown</font>";
}

sub getcudir {
  my $wdir = `cd`;
  $wdir =~ s/\\/\//g;

  return $wdir;
}

sub getmail {
  my $sock = IO::Socket::INET->new(PeerAddr => 'localhost', PeerPort => 25, Timeout => 20, Proto => 'tcp') || return "<font color='red'>Unknown</font>";
  return 'localhost';
}

sub getstime {
  return scalar( localtime() );
}

sub display {
  print <<__HTML__;
<html>
<head>
  <title>Server Information</title>
<body bgcolor="white" link="blue">

<div align="center">

<table border="0" cellpadding="0" cellspacing="0" width="650">
<tr bgcolor="#000000">
<td align="center">

<table cellspacing="1" cellpadding="3" border="0" width="100%">

<tr>
<td bgcolor="#7384BD" align="center" colspan="2">
<font face="Arial" size="3" color="white">
<b>Commonly Needed Information</b>
</font>
</td>
</tr>

<tr bgcolor="#dcdcdc">
<td width="30%">
<font face="Verdana, Arial" size="2"><b>
Operating System</b>
</font>
</td>
<td bgcolor="white" width="70%">
<font face="Verdana, Arial" size="2">
$TPL{'OPSYS'}
</font>
</td>
</tr>

<tr bgcolor="#dcdcdc">
<td width="30%">
<font face="Verdana, Arial" size="2"><b>
Web Server Software</b>
</font>
</td>
<td bgcolor="white" width="70%">
<font face="Verdana, Arial" size="2">
$TPL{'SSOFT'}
</font>
</td>
</tr>

<tr bgcolor="#dcdcdc">
<td width="30%">
<font face="Verdana, Arial" size="2"><b>
Current Directory</b>
</font>
</td>
<td bgcolor="white" width="70%">
<font face="Verdana, Arial" size="2">
$TPL{'CUDIR'}
</font>
</td>
</tr>

<tr bgcolor="#dcdcdc">
<td width="30%">
<font face="Verdana, Arial" size="2"><b>
SMTP Server</b>
</font>
</td>
<td bgcolor="white" width="70%">
<font face="Verdana, Arial" size="2">
$TPL{'MLLOC'}
</font>
</td>
</tr>

<tr bgcolor="#dcdcdc">
<td width="30%">
<font face="Verdana, Arial" size="2"><b>
Perl Version</b>
</font>
</td>
<td bgcolor="white" width="70%">
<font face="Verdana, Arial" size="2">
$TPL{'PVERS'}
</font>
</td>
</tr>

<tr bgcolor="#dcdcdc">
<td width="30%">
<font face="Verdana, Arial" size="2"><b>
Local Server Time</b>
</font>
</td>
<td bgcolor="white" width="70%">
<font face="Verdana,Arial" size="2">
$TPL{'STIME'}
</font>
</td>
</tr>

</table>

</td>
</tr>
</table>

<br><br>

<table width="650">
<tr>
<td>
<font face="Verdana,Arial" size="2">
<br><br>
<b>Current Directory:</b> This is the directory that the server_nt.cgi file is currently located in.  This
can be useful when setting up CGI scripts that require full paths to directories on your server.
<br><br>
<b>SMTP Server:</b> This tells you if you have an SMTP server available on the server that your site is hosted on.  You 
will most likely be able to use localhost as the hostname for any CGI scripts that require an SMTP server.  If not, you
can try your domain name, or contact your server administrator for more information on the SMTP server.
<br><br>
<b>Other Information:</b> The other information listed above can be useful for other reasons.  When you are reporting a
problem to the creator of the CGI software, it will often be helpful to the programmer to know the OS, Perl version, and
server software being used.
</font>
</td>
</tr>
</table>

</div>

</body>
</html>
__HTML__
}