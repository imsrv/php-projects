server_nt.pl installation
-------------------------

Installation of this script is pretty simple.  All you need to do is
upload it to your server in ASCII mode, then bring it up in your browser.

