# Mod Lycos FTP

$TOUT = 4;
sub Lycos_FTP { my ($title,$URL,$description,$size,$date,$ftp_site,$permission);
my $accuracy = "N/A";while ($buf =~ m{$reg}go) {
$permission = $1;$size = $2;$date = $4.'-'.$5.'-'.$3;$ftp_site = $6;
$title = $8;$URL = $7;$size =~ s/^\s+//g;
$description = "<b>File-Size:</b> $size, <b>Date:</b> $date. <BR><b>File-Mode:</b> $permission, <b>FTP-site:</b> <a href=\"ftp://$ftp_site\">$ftp_site</a>";$total++;
@results = (@results,"Lycos_FTP|<a href=\"http\:\/\/ftpsearch\.lycos\.com\/\">Lycos_FTP</a>|$accuracy|$title|ftp://$URL|$description");}}
sub url_Lycos_FTP {#my ($query,$match) = @_;
return "http://ftpsearch.lycos.com/cgi-bin/search?form=medium&query=$_[0]&doit=Search&type=Case+insensitive+multiple+substrings+search&hits=50&f1=Count&f2=Mode&f3=Size&f4=Date&f5=Host&f6=Path&header=none&sort=none&trlen=20";}
sub match_Lycos_FTP {return '.*?\d+ <TT>(.*?)</TT> <B>(.*?)</B> (\d+).*?(\w\w\w).*?(\d+) <A HREF="/cgi-bin/search?.*?">(.*?)</A>.*?<A HREF="/cgi-bin/search.*?oquery=(.*?)">(.*?)</A>';}

1;