<?

$ip = $_SERVER["REMOTE_ADDR"];

$page = implode("", file("http://www.searchfeed.com/rd/feed/TextFeed.jsp?trackID=$sftrackid&excID=&pID=$sfaffid&cat=".urlencode($keyword)."&nl=$nres&page=1&ip=$ip"));

preg_match_all("/Title\|(.+?)\|(.+?)\|(.+?)URL\|(.+?)\|(.+?)\|(.+?)URI\|(.+?)\|(.+?)\|(.+?)Description\|(.+?)\|(.+?)\|(.+?)Bid\|(.+?)\|(.+?)\|/is", $page, $ads);
$ppcout = "";
while (list($i,$title) = each($ads[2])) {
	$ppcout.= "<a class=\"ppclinktitle\" href=\"". $ads[8][$i] ."\">". $title ."</a><br>\n<span class=\"ppclinkdescription\">". $ads[11][$i] . "</span><br>\n<span class=\"ppclinkurl\">" . $ads[5][$i]."</span><br><br>";
}

?>