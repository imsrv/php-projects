sub IP_Check
{
&Get_Lock("iplog");
open (IPLOG,"$Config[$cgipath]data/iplog.dat");
@IPS = <IPLOG>;
close (IPLOG);
&UnLock("iplog");

	foreach $ipl(@IPS){
		chomp($ipl);
		if ($IP eq $ipl){$IPCHK = "Y";}
	}

	if($IPCHK eq ""){
                &Get_Lock("iplog");
		open (IPLOG,">>$Config[$cgipath]data/iplog.dat");
		print IPLOG"$IP\n";
		close (IPLOG);
                &UnLock("iplog");
		}
}

sub Up_Check
{
&Get_Lock("update");
open (UPDATE,"$Config[$cgipath]data/update.dat");$update = <UPDATE>;close (UPDATE);
&UnLock("update");
($hr, $dy) = split(/;/,$update);

	if (($hr != $hour) || ($dy != $mday)){
		$UPTYPE = 1;
	if ($dy != $mday){$UPTYPE++;}
		&Get_Lock("update");
		open (Update, ">$Config[$cgipath]data/update.dat");
		print Update"$hour;$mday";
		close (Update);
		&UnLock("update");
		}
}

sub Reset
{
open (IP,">$Config[$cgipath]data/iplog.dat");close (IP);
&Get_Lock("post");
open (POST,"$Config[$cgipath]data/post.dat");
@POSTS = (<POST>);
close (POST);
if ($Config[$expire] eq "0"){ $Config[$expire] = 99999;} 
open (POST,">$Config[$cgipath]data/post.dat");
	foreach $pst(@POSTS){
		chomp($pst);
		@pdat = split (/;/,$pst);
		if ($pdat[0] > $Config[$minhits]){ $pdat[9] = 0;}
		if ($pdat[0] < 1){ $pdat[9] = $pdat[9] + 1;}
if ($pdat[7] ne "Y"){$pdat[9] = 0;}
if ($pdat[9] le $Config[$expire]){
print POST"0;$pdat[1];$pdat[2];$pdat[3];$pdat[4];$pdat[5];$pdat[6];$pdat[7];$pdat[8];$pdat[9]\n";
}
}
close (POST);
&UnLock("post");
}

sub Update
{
$cntr = 1;
&Get_Lock("post");
open (POST,"$Config[$cgipath]data/post.dat");
@POSTS = <POST>;
&UnLock("post");
@POSTS = reverse sort { $a <=> $b } @POSTS;
$total_list = "";
@LST3 = split(/\./,$Config[$ifile]);
     foreach $Cpost(@POSTS){
		@pstdat = split(/;/,$Cpost);
	  $catdat = $pstdat[2];        
        $catdat =~ s/\W//g;
        $catdat =~ tr/[A-Z]/[a-z]/;
        $catdat .= ".$LST3[1]";
if ($Config[$frame] eq "Y"){$gway = "$Config[$cgiurl]gallery.cgi?"};
if ($pstdat[7] eq "Y"){
		$total_list .= "<li> &nbsp; $pstdat[4] pics &nbsp; <a href=$catdat>$pstdat[2]</a> &nbsp; <a href=$gway$pstdat[5]>$pstdat[3]</a>";
}
if (($pstdat[0] >= $Config[$minhits]) && ($pstdat[7] eq "Y")){
		$CATEGORY[$cntr] = $pstdat[2];
		$DESCRIPTION[$cntr] = $pstdat[3];
		$PICS[$cntr] = $pstdat[4];
		$URL[$cntr] = $pstdat[5];
		$VOTES[$cntr] = $pstdat[0];        
		$cntr++;
	}
		}
$pagetitle = "Overall";
&Get_Subs;
$wf = $Config[$ifile];
$template_file = "$Config[$cgipath]templates/default.tpl";
	if (-e "$Config[$cgipath]templates/main.tpl") {
		$template_file = "$Config[$cgipath]templates/main.tpl";
		}
&WriteTemplate;
&Do_Subs;
}

sub WriteTemplate
{

$tmpcntr = 1;
open(TEMPLATE, $template_file);
while(<TEMPLATE>)
{
  $buffer .= $_;
}
close(TEMPLATE);

&PLATE_DATA("1","$cntr","<!--rank","0");
&PLATE_DATA("0","$cntr","<!--cat","1");
&PLATE_DATA("0","$cntr","<!--desc","2");
&PLATE_DATA("0","$cntr","<!--images","3");
&PLATE_DATA("0","$cntr","<!--votes","4");
&PLATE_DATA("","1","<!--page","5");
&PLATE_DATA("","1","<!--navbox","6");
&PLATE_DATA("","1","<!--join","7");
&PLATE_DATA("","1","<!--tjoin","8");
&PLATE_DATA("","1","<!--list","9");

$buffer = "";
}

sub PLATE_DATA
{
$tmpcntr = $_[0];
	while($tmpcntr < $_[1]){
		$replace = "$_[2]$tmpcntr-->";
if ($_[3] eq "0"){
		$newdata = "$tmpcntr";
		if ($tmpcntr >= $cntr){$newdata = "";}
		}
if ($_[3] eq "1"){
$catdat = $CATEGORY[$tmpcntr];
$catdat =~ s/\W//g;
$catdat =~ tr/[A-Z]/[a-z]/;
$catdat .= ".$LST3[1]";
$newdata = "<A HREF=$catdat>$CATEGORY[$tmpcntr]</A>";
}
if ($_[3] eq "2"){
$newdata = "<A href=$URL[$tmpcntr]>$DESCRIPTION[$tmpcntr]</A>";

if ($Config[$frame] eq "Y"){ 
$newdata = "<A HREF=$Config[$cgiurl]gallery.cgi?$URL[$tmpcntr]>$DESCRIPTION[$tmpcntr]</A>";
}
}
if ($_[3] eq "3"){$newdata = "$PICS[$tmpcntr]";}
if ($_[3] eq "4"){$newdata = "$VOTES[$tmpcntr]";}
if ($_[3] eq "5"){$newdata = "$pagetitle";}
if ($_[3] eq "6"){$newdata = "$navbox";}
if ($_[3] eq "7"){$newdata = "Webmasters : <a href=$Config[$cgiurl]new.cgi>Add Your Gallery</a>";}
if ($_[3] eq "8"){$newdata = "Webmasters : <a href=$Config[$cgiurl]new.cgi?t>Add Your Gallery</a>";}
if ($_[3] eq "9"){$newdata = "$total_list";}
$buffer =~ s/$replace/$newdata/g;
$tmpcntr++;
}

&Get_Lock("ifile");
open(UFILE,">$Config[$htmlpath]$wf");
print UFILE"$buffer";
close(HT);
&UnLock("ifile");
}

sub Do_Subs
{
&Get_Lock("category");
open (CATZ,"$Config[$cgipath]data/category.dat");
$CTG = <CATZ>;
close (CATZ);
&UnLock("category");
$cntr = 0;$tempcntr = 0;splice(@pstdat,0);splice(@CATEGORY,0);splice(@DESCRIPTION,0);splice(@PICS,0);splice(@VOTES,0);
@catadat = split(/;/,$CTG);
	foreach $category(@catadat){
		$template_file = "$Config[$cgipath]templates/sdefault.tpl";
		chomp($category);
                $pagetitle = $category;
		$ctfile = $category;
		$ctfile =~ s/\W//g;
		$ctfile =~ tr/[A-Z]/[a-z]/;
		$wf = "$ctfile.$LST3[1]";
		$ctfile .= ".tpl";
              if (-e "$Config[$cgipath]templates/$ctfile"){
		$template_file = "$Config[$cgipath]templates/$ctfile";
		}
$cntr = 1;
$total_list = "";
foreach $Cpost(@POSTS){
        @pstdat = split(/;/,$Cpost);
if ($Config[$frame] eq "Y"){$gway = "$Config[$cgiurl]gallery.cgi?"};
if (($pstdat[2] eq $category) && ($pstdat[7] eq "Y")){
		$total_list .= "<li> &nbsp; $pstdat[4] pics &nbsp; <a href=$gway$pstdat[5]>$pstdat[3]</a>";
}
        if ((($pstdat[0] >= $Config[$minhits]) && ($pstdat[7] eq "Y") && ($pstdat[2] eq $category))){
                $CATEGORY[$cntr] = $pstdat[2];
		$URL[$cntr] = $pstdat[5];
                $DESCRIPTION[$cntr] = $pstdat[3];
                $PICS[$cntr] = $pstdat[4];
                $VOTES[$cntr] = $pstdat[0];
                $cntr++;
         }
	}
&WriteTemplate;
$cntr = 1;
	}
}

sub Write_Hit
{
&Get_Lock("post");
open (POSTS,"$Config[$cgipath]data/post.dat");
@POSTS = <POSTS>;
close (POSTS);
open (POSTS,">$Config[$cgipath]data/post.dat");
	foreach $pst(@POSTS){
		chomp($pst);
		@post = split (/;/,$pst);
		if ($post[8] eq $query){ $post[0]++;}
		print POSTS"$post[0];$post[1];$post[2];$post[3];$post[4];$post[5];$post[6];$post[7];$post[8];$post[9]\n";
		}
close(POSTS);
&UnLock("post");
}


sub Get_Subs {
$navbox = "";
$navbox .= "<SCRIPT type=\"text/javascript\">\n";
$navbox .= "function GoUrl(s)\n";
$navbox .= "{       var d = s.options[s.selectedIndex].value\n";
$navbox .= "  window.top.location.href = d\n";
$navbox .= "    s.selectedIndex=0\n";
$navbox .= "}\n";
$navbox .= "</script>\n";
$navbox .= "<FORM>\n";
$navbox .= "<SELECT NAME=target onchange=GoUrl(this)>\n";
$navbox .= "<OPTION VALUE= SELECTED>- Select Category -</OPTION>\n";
$navbox .= "<OPTION VALUE=$Config[$htmlurl]$Config[$ifile]>Top Overall</OPTION>\n";
&Get_Lock("category");
open (CATZ,"$Config[$cgipath]data/category.dat");
@CATZ = <CATZ>;
	foreach $catz(@CATZ){
		chomp($catz);
		@ctl = split(/;/,$catz);
		$ARZ = @ctl;
		}
	$cout = 0;
	while ($cout < $ARZ){
		$sfile = "$ctl[$cout]";
		$sfile =~ s/\W//g;
		$sfile =~ tr/[A-Z]/[a-z]/;
		$navbox .= "<option value=$Config[$htmlurl]$sfile.$LST3[1]>$ctl[$cout]</option>\n";
		$cout++;
		}
$navbox .= "</select></form>\n";
close (CATZ);
&UnLock("category");
}
1;
