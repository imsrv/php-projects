sub HTML_Header
    {
    if (!@_[3]){@_[3] = "#000000";@_[4] = "#FFFFFF";@_[5] = "#0000EE";@_[6] = "#551A8B";@_[7] = "#FF0000";}
    print "Content-type: text/html\n\n";
    print "<HTML>\n";
    print "<HEAD>\n";
    print "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\n";
    print "<meta name=\"author\" content=\"$author\">\n";
  if (@_[1] ne ""){
    print "<meta name=\"description\" content=\"@_[1]\">\n";
}
  if (@_[2] ne ""){
    print "<meta name=\"keywords\" content=\"@_[2]\">\n";
}
    print "<meta name=\"GENERATOR\" content=\"$proggie\">\n";
    print "<TITLE>@_[0]</TITLE>\n";
    print "</HEAD>\n";
    print "<BODY text=\"@_[3]\" bgcolor=\"@_[4]\" link=\"@_[5]\" vlink=\"@_[6]\" alink=\"@_[7]\">\n";
    }

sub HTML_Footer
    {
    print "\n</BODY>\n";
    print "</HTML>\n";
    }

sub Load_Vars
    {
    $proggie = 'EliteTGP 2.01';
    $author = 'Jeremy Skeels';
    ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time);
    }

sub Get_Input
    {
    read(STDIN, $HACK, $ENV{'CONTENT_LENGTH'});
    if ((("@_" eq "1") && ($ENV{'REQUEST_METHOD'} ne "POST") && ($HACK ne ""))) { &Invalid_Entry;} 
    if (("@_" eq "2") && ($ENV{'REQUEST_METHOD'} ne "GET")) { &Invalid_Entry;} 
    if ($ENV{'REQUEST_METHOD'} ne "POST")
       { $HACK = $ENV{'QUERY_STRING'};}
    @fv_pairs = split /\&/ , $HACK;
    foreach $pair (@fv_pairs) {
    if($pair=~m/([^=]+)=(.*)/) {
      $field = $1;
      $value = $2;
      $value =~ s/\+/ /g;
      $value =~ s/%([\dA-Fa-f]{2})/pack("C", hex($1))/eg;
      $input{$field}=$value;
      }
     }
}

sub Invalid_Entry
 {
     &HTML_Header;
     print "<B>Invalid Entry : Aborting<B>";
     &HTML_Footer;
     exit;
 }

sub Get_Config
 {
$title = 0;$email = 1;
$password = 2;$ifile = 3;
$cgipath =4;$cgiurl = 5;
$htmlpath = 6;$htmlurl = 7;
$smailpath = 8;$smail = 9;
$validate = 10;$minhits = 11;
$expire = 12;$gateway = 13;
$textlink = 14;
$psid = 15;
$frame = 16;
$frameurl = 17;

&Get_Lock("elite");
open (CONFIG, "elite.cfg") || die "Can't open configuration file!\n";
@TEMP = <CONFIG>;close(CONFIG);
&UnLock("elite");
foreach $hit(@TEMP)
        {
        chomp($hit);
        @Config = split(/;/,$hit);
}
}

sub Get_Lock
{
$lockcnt = 0;
$lockfile = "$Config[$cgipath]data/$_[0].lock";
while (-f $lockfile){
      select(undef,undef,undef,0.1);
      if ($lockcnt > 75){ 
         $lockcnt =0;
         unlink($lockfile);
                        }
      $lockcnt++;
                   }
open($_[0],">$lockfile"); 
}

sub UnLock
{
$lockfile = "$Config[$cgipath]data/$_[0].lock";
close($lockfile);
unlink($lockfile);
}

1;
