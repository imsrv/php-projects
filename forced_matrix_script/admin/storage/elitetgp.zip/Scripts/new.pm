sub TERMS{
$buffer = "";
open(TERMS,"$Config[$cgipath]templates/terms.tpl");
$newdata = "<a href=$Config[$cgiurl]new.cgi>I Agree</A>";
while (<TERMS>){
 $buffer .= $_;
}
close (TERMS);
$buffer =~ s/<!--join-->/$newdata/g;
print $buffer;
exit;
}


sub checkdata {
$error = 0;

$chkurl = $input{url};
$chkurl =~ tr/[A-Z]/[a-z]/;
$chkurl =~ s/\W//g;
&Get_Lock("post");
open (POST,"$Config[$cgipath]data/post.dat");
while (<POST>){
   @pdat = split(/;/,$_);
   $matchurl = $pdat[5];
   $matchurl =~ tr/[A-Z]/[a-z]/;
   $matchurl =~ s/\W//g;
   if ($matchurl =~ /$chkurl/i){
$error++;
$errors .= "<B><TT>Duplicate URL</B></TT><BR>";
}
}
close(POST);
&UnLock("post");

$cemail = "$input{email}";
    if ($cemail =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|(\.$)/ || 
        ($cemail !~ /^.+\@localhost$/ && 
         $cemail !~ /^.+\@\[?(\w|[-.])+\.[a-zA-Z]{2,3}|[0-9]{1,3}\]?$/)) {
$errors .= "<B><TT>Invalid Email Address</B></TT><BR>";
$error++;
}
$input{url} =~ s/#//g;
$input{url} =~ s/\?//g;
if ((length($input{url}) < 12) || ($input{url} !~ /\./)){
$errors .= "<B><TT>Invalid URL</B></TT><BR>";
$error++;
}
if (length($input{desc}) < 5){
$errors .= "<B><TT>Invalid Description</B></TT><BR>";
$error++;
}
$ble = "<BR><B><TT>Banned Content:</B></TT><BR>";
open (BLACK,"$Config[$cgipath]data/blacklist.dat");
$BLK = <BLACK>;
close (BLACK);
$hack = $HACK;
$hack =~ tr/[A-Z]/[a-z]/;
@BLACK = split(/;/,$BLK);
	foreach $bl(@BLACK){
	chomp($bl);
	$bl =~ tr/[A-Z]/[a-z]/;
	if ($hack =~ /$bl/){
	$error++;
	$errors .= "$ble$bl";
	$ble = "<BR>";
}
}
if ($error ne "0"){
print "<B><TT>Errors in your submission:</B></TT><hr size=1 width=100%>$errors";
exit;}
open (ACC,"$Config[$cgipath]data/account.dat");
$ID = <ACC>;
$ID++;
close(ACC);
open (ACC,">$Config[$cgipath]data/account.dat");
print ACC"$ID";
close(ACC);
&Get_Lock("post");
open (POST,">>$Config[$cgipath]data/post.dat");
print POST"0;$ENV{REMOTE_ADDR};$input{cat};$input{desc};$input{images};$input{url};$input{email};$Config[$validate];$ID;0\n";
close(POST);
&UnLock("post");
$buffer="";
open (PST,"$Config[$cgipath]templates/post.tpl");
while(<PST>){
$buffer .= $_;
}
close(PST);
$newdata = "<form><textarea cols=60 rows=5><A HREF=$Config[$cgiurl]click.cgi?$ID>$Config[$textlink]</A></textarea></form>";
$buffer =~ s/<!--link-->/$newdata/g;

$newdata = "<A HREF=$Config[$htmlurl]>Continue</A>";
$buffer =~ s/<!--site-->/$newdata/g;


if ($Config[$smail] eq "Y"){
open(EM,"$Config[$cgipath]templates/mail.txt");
while (<EM>){
$nm .= $_;
}
$newdat = $Config[$title];
$nm =~ s/<!--title-->/$newdat/g;
$newdat = $Config[$email];
$nm =~ s/<!--email-->/$newdat/g;
$newdat = "$Config[$cgiurl]click.cgi?$ID";
$nm =~ s/<!--link-->/$newdat/g;
close(EM);

&SM_Mail("$input{email}","$Config[$email]","Your Gallery Submission!","$nm");
}
if ($input{mlist} eq "on"){
&Get_Lock("mail");
open (MLIST,"$Config[$cgipath]data/mail.dat");
while (<MLIST>){
	chomp($_);
	if ($input{email} eq $_){$WM++;}
}
close (MLIST);
if ($WM < 1){
open (MLIST,">>$Config[$cgipath]data/mail.dat");
print MLIST"$input{email}\n";
close (MLIST);
}
&UnLock("mail");
}
print $buffer;
$buffer = "";
&Update; #added
exit;
}


sub Make_Form {
open(NEWU,"$Config[$cgipath]templates/new.tpl");
$buffer = "";
while (<NEWU>){
 $buffer .= $_;
}
$newdata = "<form method=post action=$Config[$cgiurl]new.cgi><input type=hidden name=action value=checkdata>";
$buffer =~ s/<!--start-->/$newdata/g;

$newdata = "<input type=text name=email size=18 maxlength=40>";
$buffer =~ s/<!--email-->/$newdata/g;
$newdata = "<input type=checkbox name=mlist>";
$buffer =~ s/<!--mlist-->/$newdata/g;
$newdata = "<input type=text name=url value=http:// size=50 maxlength=80>";
$buffer =~ s/<!--url-->/$newdata/g;
$newdata = "<input type=text name=desc size=50 maxlength=50>";
$buffer =~ s/<!--desc-->/$newdata/g;
$newdata = "<input type=submit value=Submit></form>";
$buffer =~ s/<!--finish-->/$newdata/g;

$newdata = "<select name=cat>";
open (CATZ,"$Config[$cgipath]data/category.dat");
$CATZ = <CATZ>; close(CATZ);
        @CTZ = split(/;/,$CATZ);
	foreach $catd(@CTZ){
	chomp($catd);
$newdata .="<option>$catd</option>";
}
$newdata .="</select>";
$buffer =~ s/<!--cats-->/$newdata/g;


$images = "<select name=images>";
$cntr = 1;
while ($cntr < 100){
$images .="<option>$cntr</option>";
$cntr++;
}
$images .="<option>100+</option></select>";
$buffer =~ s/<!--pics-->/$images/g;

print $buffer;
exit;
}

1;
