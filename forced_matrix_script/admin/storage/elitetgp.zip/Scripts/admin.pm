sub Verify
{if ($Config[$password] ne $input{password}){ &Invalid_Entry;}}

sub WRITE_CONFIG
{
&Get_Lock("elite");
    open (CONFIG,">elite.cfg");
    print CONFIG "$input{title};$input{email};$input{passwd};$input{ifile};$input{cgipath};$input{cgiurl};$input{htmlpath};$input{htmlurl};$input{smailpath};$input{smail};$input{validate};$input{minhits};$input{expire};$input{gateway};$input{textlink};$Config[$psid];$input{frame};$input{frameurl}";
    close (CONFIG);
&UnLock("elite");
if ($pstmp ne "Y"){
&Get_Config;
&Update;
&Setup;
}
}

sub Del_It
{
$datf = "@_[0]";
$cfile = "$Config[$cgipath]data/$datf";
&Get_Lock("category");
open (catz, "$cfile");
$Ncat = <catz>;
chomp($cats);
close (catz);
$Ncat .= ";";
$Ncat =~ s/$input{newdat};//g;
$Ncat =~ s/;;/;/g;
$Ncat =~ s/;$//g;
$Ncat =~ s/^;//g;
open (catz, ">$cfile");
print catz"$Ncat";
close (catz);
&UnLock("category");
&Update;
&UPDAT("@_[0]","@_[1]","@_[2]","@_[3]","@_[4]");
exit;
}

sub Add_It
{
$datf = "@_[0]";
$cfile = "$Config[$cgipath]data/$datf";
&Get_Lock("category");
open (catz, "$cfile");
$cats = <catz>;
chomp($cats);
close (catz);
open (catz, ">$cfile");
$Ncat = $cats;
$Ncat .= ";";

$input{newdat}=~ s/([-?,`@;~%_+=\\\^<>\*\|'&\$!#\(\)\[\]\{\}'"])//g;

if ($cats !~ /$input{newdat};/){
$Ncat = "$cats;$input{newdat}";
}
$Ncat =~ s/;;/;/g;
$Ncat =~ s/;$//g;
$Ncat =~ s/^;//g;

@CA = split(/;/,$Ncat);
@CA = sort(@CA);
$Ncat = "";
foreach $Cz(@CA){
$Ncat .= "$Cz;";
} 
$Ncat =~ s/;;/;/g;
$Ncat =~ s/;$//g;
$Ncat =~ s/^;//g;
print catz"$Ncat";
close (catz);
&UnLock("category");
&Update;
&UPDAT("@_[0]","@_[1]","@_[2]","@_[3]","@_[4]");
exit;
 }

sub editp 
{
if ($input{edit} eq ""){&Main_Menu;}
&Get_Lock("post");
open(POST,"$Config[$cgipath]/data/post.dat");@POST=<POST>;close(POST);
&UnLock("post");
$cnt = 0;
foreach $post(@POST)
        {
$tchk = "d$cnt";
$tchk = "$input{$tchk}";
if ($tchk eq "on"){
$delarray .= "$cnt;";
                  }
$cnt++;
}
$delarray =~ s/;$//g;
@DEL = split(/;/,$delarray);
$total = $#DEL +1;
if ($total > 0) {
$pfile = "post.dat";
&delpost;
&Update;

&posts;
}

$cnt = 0;
foreach $post(@POST)
        {
        chomp($post);
        @partner = split(/;/,$post);
if ($cnt eq $input{edit}) {
$Op = "N";
if ($partner[7] eq "N"){$Op = "Y";}
&HTML_Header;
print "<B><TT>&nbsp;&nbsp;$proggie - Post Editor<table BGCOLOR=#FF0000 BORDER=1 COLS=1 CELLPADDING=4 WIDTH=50%>\n";
print "<tr>\n<td>\n";
print "<tt><b>Account :</B> #$partner[8]\n";
print "  Inactive for $partner[9] days.</tt><BR>"; 
print "<tt><b>Hits Recieved : </B>$partner[0]</tt><BR>\n";
print "<tt><b>Ip :</b> $partner[1]</b></tt><BR>\n";
print "<center><form method=POST action=admin.cgi><input type=hidden name=action value=editpwrite><input type=hidden name=password value=$input{password}><input type=hidden name=enum value=$input{edit}></center>\n";
print "<tt><b>Category......:\n";
&Get_Lock("category");
open (CATA,"$Config[$cgipath]/data/category.dat");@CAT =<CATA>;
close(CATA);
&UnLock("category");

print "<select name=\"post_type\">\n";
foreach $cat(@CAT){
chomp($cat);
@ct = split(/;/,$cat);
$ARGZ = @ct;
}
$count = 0;
while ($count < $ARGZ){
if ($ct[$count] ne $partner[2]){
$CHK = "";
}
print "<option $CHK>$ct[$count]";
$count++;
$CHK = "Selected";
}                    
print "</select>\n";
print "<BR>Description...:\n";
print "<input type=text name=desc size=40 value=\"$partner[3]\">\n";
print "<BR>URL...........:\n";
print "<input type=text name=url size=40 value=\"$partner[5]\">\n";
print "<BR>Images........:\n";
print "<select name=images><option selected>$partner[4]<option>2<option>3<option>4<option>5<option>6<option>7<option>8<option>9<option>10<option>11<option>12<option>13<option>14<option>15<option>16<option>17<option>18<option>19<option>20<option>21<option>22<option>23<option>24<option>25<option>26<option>27<option>28<option>29<option>30<option>31<option>32<option>33<option>34<option>35<option>36<option>37<option>38<option>39<option>40<option>41<option>42<option>43<option>44<option>45<option>46<option>47<option>48<option>49<option>50<option>51<option>52<option>53<option>54<option>55<option>56<option>57<option>58<option>59<option>60<option>61<option>62<option>63<option>64<option>65<option>66<option>67<option>68<option>69<option>70<option>71<option>72<option>73<option>74<option>75<option>76<option>77<option>78<option>79<option>80<option>81<option>82<option>83<option>84<option>85<option>86<option>87<option>88<option>89<option>90<option>91<option>92<option>93<option>94<option>95<option>96<option>97<option>98<option>99<option>100+</select>\n";
print "<BR>Email Address.:\n";
print "<input type=text name=email size=20 value=$partner[6]>\n";
print "<BR>Validated.....:</b>\n";
print "<select name=validated><option>$partner[7]<option>$Op</select>\n";
print "<input type=hidden name=hits value=$partner[0]>";
print "<input type=hidden name=ip value=$partner[1]>";
print "<input type=hidden name=account value=$partner[8]>";
print "<input type=hidden name=inactive value=$partner[9]>";
print "</td></tr></table><input type=submit value=\"Update Gallery\">\n";
print "</form>\n";
print "</body>\n";
print "</html>\n"; 
}
$cnt++;
}
exit;
}

sub editpwrite
{
&Get_Lock("post");
open(POST,"$Config[$cgipath]/data/post.dat");@POST=<POST>;close(POST);
open(PFILE,">$Config[$cgipath]/data/post.dat") || die "Can't open file $pfile for writing: $!\n";
close(PFILE);
$cnt = 0;
open(PFILE,">>$Config[$cgipath]/data/post.dat") || die "Can't open file $pfile for writing: $!\n";
foreach $post(@POST)
        {
        chomp($post);
        @partner = split(/;/,$post);
if ($cnt == $input{enum}){
$partner[0] = $input{hits};
$partner[1] = $input{ip};
$partner[2] = $input{post_type};
$partner[3] = $input{desc};
$partner[4] = $input{images};
$partner[5] = $input{url};
$partner[6] = $input{email};
$partner[7] = $input{validated};
$partner[8] = $input{account};
$partner[9] = $input{inactive};
$partner[0] =~ s/;//g;
$partner[1] =~ s/;//g;
$partner[2] =~ s/;//g;
$partner[3] =~ s/;//g;
$partner[4] =~ s/;//g;
$partner[5] =~ s/;//g;
$partner[6] =~ s/;//g;
$partner[7] =~ s/;//g;
$partner[8] =~ s/;//g;
$partner[9] =~ s/;//g;
}
print PFILE"$partner[0];$partner[1];$partner[2];$partner[3];$partner[4];$partner[5];$partner[6];$partner[7];$partner[8];$partner[9]\n";
$cnt++;
}                    
close(PFILE);
&UnLock("post");
&Update;
&posts;
exit;
}

sub delpost
{
&Get_Lock("post");
open(POST,"$Config[$cgipath]/data/$pfile");@POST=<POST>;close(POST);
open(PFILE,">$Config[$cgipath]/data/$pfile");
$cntr = 0;
@DEL = reverse(@DEL);
          foreach $pdat(@DEL){
splice(@POST, $pdat, 1);
}
foreach $pst(@POST){
$pst =~ s/^\s*//;
$pst =~ s/\s*$//;
print PFILE"$pst\n";
}
close(PFILE);
&UnLock("post");
&Update;
}

sub Compose {
&HTML_Header;
print <<"EOP";
<form method=POST action=admin.cgi>
<input type=hidden name=action value=SMM>
<input type=hidden name=password value=$input{password}>
<B><TT>$proggie - Mass Mail Composition
<hr size=1 width=70% ALIGN=LEFT>
Subject:<input type=text name=subject> Send As HTML<input type=checkbox name=html>
<BR><BR>
Message:<BR><textarea name=message cols=80 rows=10></textarea>
<hr size=1 width=70% ALIGN=LEFT>
<input type=submit value=\"Send It\">
EOP
exit;
}


sub Mass_Mail {
&HTML_Header;
&Get_Lock("mail");
open(MAIL,"$Config[$cgipath]data/mail.dat");
@addr=<MAIL>;close(MAIL);
close(MAIL);
&UnLock("mail");
$cntr = 0;
print "<hr size=1 width=20% ALIGN=LEFT>";
 foreach $addr(@addr){
       &SM_Mail("$addr","$Config[$email]","$_[0]","$_[1]");
       print "<B><TT>Sent:$addr</B></TT><br>";
       $cntr++;
       }
print "<hr size=1 width=20% ALIGN=LEFT>";
print "$cntr messages sent.";
print "<BR><FORM method=POST action=admin.cgi><input type=hidden name=password value=$input{password}>";
print "<input type=hidden name=action value=MAIN><input type=submit value=\"Main Menu\">";
exit;
}

sub SM_Mail {
$mailprog = "$Config[$smailpath] -t";
open (MAIL, "|$mailprog") or die "Can't start mail program: $!\n";
chomp($_[0]);
chomp($_[1]);
@RE = split(/\@/,$_[0]);
@SE = split(/\@/,$_[1]);
if ($input{html} eq "on"){
print MAIL "Content-type:text/html\n";
}
print MAIL "To: $RE[0]\@$RE[1]\n";
print MAIL "From: $Config[$email]\n";
print MAIL "Subject: $_[2]\n";
print MAIL "$_[3]\n\n";
if ($input{html} eq ""){
print MAIL "\nEliteTGP 2.0 Copyright (C) http://www.elitecgi.com\n";
} 
if ($input{html} eq "on"){
print MAIL "<BR><TT><B>EliteTGP 2.0 Copyright (C) <a href=\"http://www.elitecgi.com\">http://www.elitecgi.com</a></tt><b>\n";
}
close MAIL;
}

sub delmail
{
&Get_Lock("mail");
open (MDAT,"$Config[$cgipath]data/mail.dat");
@MLIST = <MDAT>;
close (MDAT);
&UnLock("mail");
$cntr = 0;
  foreach $address(@MLIST){
$chk = "$cntr";
if ($input{$chk} eq "on") {
          $dellist .= "$cntr;"
}
$cntr++;
}
$dellist =~ s/;$//g;
@DEL = split(/;/,$dellist);
$total = $#DEL +1;
if ($total > 0) {
$pfile = "mail.dat";
&delpost;
}
&editlist;
}
sub APA{
&Get_Lock("apa");
open (APA,"$Config[$cgipath]data/apa.dat");
@APA = <APA>;
close (APA);
&UnLock("apa");
srand(time ^ $$);
$num = int(rand(@APA));
}

sub Get_Acc
{
$temp ="$Config[$psid]";
chomp($temp);
if (length($temp) != 20){
srand(time ^ $$);
$cntr = 0;
@RNDN = (0..9,'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
   while ($cntr < 20){
    $num = rand(@RNDN);
    $pstmp .= "$RNDN[$num]";
    $cntr++;
                     }
$Config[$psid] = "$pstmp";
$input{title} = "$Config[$title]";
$input{email} = "$Config[$email]";
$input{passwd} = "$Config[$password]";
$input{ifile} = "$Config[$ifile]";
$input{cgipath} = "$Config[$cgipath]";
$input{cgiurl} = "$Config[$cgiurl]";
$input{htmlpath} = "$Config[$htmlpath]";
$input{htmlurl} = "$Config[$htmlurl]";
$input{smailpath} = "$Config[$smailpath]";
$input{smail} = "$Config[$smail]"; 
$input{validate} = "$Config[$validate]";
$input{minhits} = "$Config[$minhits]";
$input{expire} = "$Config[$expire]";
$input{gateway} = "$Config[$gateway]";
$input{textlink} = "$Config[$textlink]";
$input{frame} = "$Config[$frame]";
$input{frameurl} = "$Config[$frameurl]";
&WRITE_CONFIG;
}
}

sub addemail
{
$temp = $input{newemail};
$temp=~ s/[-?,`;~%+=\\\^<>\*\|'&\$!#\(\)\[\]\{\}'\"]//g;
if (((($temp ne "" ) && (length($temp) >= 7) && ($temp =~ /\@/) && ($temp =~ /\./)))){
&Get_Lock("mail");
open (MLIST,">>$Config[$cgipath]data/mail.dat");
print MLIST"$temp\n";
}
close (MLIST);
&UnLock("mail");
&editlist;
exit;
}

1;
