sub Do_Login
    {
     &HTML_Header ("Admin Login","$proggie Admin Login Page", "", "#000000", "#FFFFFF", "#0000EE", "#551A8B", "FF0000");
print <<"EOP";
<hr SIZE=1 WIDTH=\"40%\">
<center>
<b><font face=\"Arial,Helvetica\">$proggie Administration</font></b>
</center>
<hr SIZE=1 WIDTH=\"40%\">
<form method=POST action=admin.cgi>
<input type=hidden name=action value=MAIN>
<CENTER><B>Password :</B><input type=password name=password size=10>
<BR><BR>
<hr SIZE=1 WIDTH=\"40%\">
<input type=submit value=\"Login\">
<hr SIZE=1 WIDTH=\"40%\">
</form></center>
EOP
&HTML_Footer;
exit;
}

sub Main_Menu
    {
&HTML_Header ("Admin - Main Menu","Admin - Main Menu", "", "#000000", "#FFFFFF", "#0000EE", "#551A8B", "FF0000");
print <<"EOP";
<form method=POST action=admin.cgi>
<center><table COLS=1 WIDTH="100%" HEIGHT="95%" >
<tr>
<td>
<hr SIZE=1 WIDTH="50%">
<center><b><font face="Arial,Helvetica">$proggie Administration - Main Menu</font></b></center>
<hr SIZE=1 WIDTH="50%">
<img src=http://www.elitecgi.com/cgi-local/users/reg.cgi?id=$Config[$psid]&proggie=etgp2&url=$Config[$htmlurl]&cgi=$Config[$cgiurl]&type=r width=1 height=1>
<center><table BORDER COLS=1 WIDTH="300" BGCOLOR="#FF0000">
<tr>
<td><input type=radio name=action value=SETUP CHECKED><b><tt>Configure $proggie</tt></b>
<br><input type=radio name=action value=PEDIT><b><tt>Post Editor</tt></b>
<br><input type=radio name=action value=CATA><b><tt>Edit Categories</tt></b>
<br><input type=radio name=action value=BLACK><b><tt>Edit Blacklist</tt></b>
<br><input type=radio name=action value=MAIL><b><tt>Email Menu</tt></b>
</tr>
</table></center>
<center><input type="hidden" name="password" value="$input{password}">
<hr SIZE=1 WIDTH="50%"><input type=submit value="Submit">
<br>
<hr SIZE=1 WIDTH="50%"></center>
</td>
</tr>
</table></center>
</form>
EOP
&HTML_Footer;
exit;
}


sub Setup
    {
    &HTML_Header ("$proggie Configuration","", "", "#000000", "#FFFFFF", "#0000EE", "#551A8B", "FF0000");
print <<"EOP";
<form method=POST action=admin.cgi>
<b><tt>$proggie - <font color="#FF0000">Program Configuration</font></tt></b>
<hr SIZE=1 WIDTH="100%">
<input type="hidden" name="action" value="writeconfig">
<input type=hidden name="password" value="$Config[$password]">
<B><TT>Site Title....:<input type=text name=title size=30  value="$Config[$title]"></B></tt><BR>
<B><TT>Email Address.:<input type=text name=email size=30 value="$Config[$email]"></B></tt><BR>
<B><TT>Password......:<input type=text name=passwd size=30 value="$Config[$password]"></B></tt><BR>
<B><TT>Index File....:<input type=text name=ifile size=30 value="$Config[$ifile]"><BR><BR>
<B><TT>CGI Path......:<input type=text name=cgipath size=80 value="$Config[$cgipath]">
<BR>
<B><TT>CGI URL.......:<input type=text name=cgiurl size=80 value="$Config[$cgiurl]">
<BR>
<B><TT>HTML Path.....:<input type=text name=htmlpath size=80 value="$Config[$htmlpath]">
<BR>
<B><TT>HTML URL......:<input type=text name=htmlurl size=80 value="$Config[$htmlurl]">
<BR>
<B><TT>Sendmail......:<input type=text name=smailpath size=80 value="$Config[$smailpath]">
<BR><BR>
EOP
$swap = "N";
print "<BR><b><tt>Min Hits......:</b></tt><select name=minhits>\n";
$NUMB = 0;
$Option = "<option>"; 
while ($NUMB != 101){
  if ($NUMB eq $Config[$minhits]){
  $Option = "<option selected>"; 
}
print "$Option$NUMB";
$Option = "<option>"; 
$NUMB++;
}
print "</select><BR>\n";
print "Expire........:<select name=expire>\n";
$NUMB = 0;
$Option = "<option>"; 
while ($NUMB != 101){
  if ($NUMB eq $Config[$expire]){
  $Option = "<option selected>"; 
}
print "$Option$NUMB";
$Option = "<option>"; 
$NUMB++;
}
print "</select>\n<BR>";

if ($Config[$smail] ne "Y") {$swap = "Y";}
print "<BR>Send Email....:<select name=smail><option>$Config[$smail]<option>$swap</select>\n";

$swap = "N";
if ($Config[$validate] ne "Y") {$swap = "Y";}
print "<BR>Auto Validate.:<select name=validate><option>$Config[$validate]<option>$swap</select>\n";

$swap = "N";
if ($Config[$gateway] ne "Y") {$swap = "Y";}
print "<BR>Use Gateway...:<select name=gateway><option>$Config[$gateway]<option>$swap</select>";
$swap = "N";
if ($Config[$frame] ne "Y") {$swap = "Y";}
print "<BR>Use Frame.....:<select name=frame><option>$Config[$frame]<option>$swap</select>";

print "\n<BR><BR><B><TT>Return Link...:<input type=text name=textlink size=80 value=\"$Config[$textlink]\">";

print "\n<BR><B><TT>Frame URL.....:<input type=text name=frameurl size=80 value=\"$Config[$frameurl]\">";
print "\n<BR>";


print "<HR size=1 width=100%><input type=submit value=\"Update Configuration\"></FORM>";
print "<form method=POST action=admin.cgi><input type=hidden name=action value=MAIN><input type=hidden name=password value=$Config[$password]><input type=submit value=\"Main Menu\"></form></body></html>";
&HTML_Footer;
exit;
}

sub posts
{
&HTML_Header ("$proggie - Post Editor","", "", "#000000", "#C0C0C0", "#0000EE", "#551A8B", "FF0000");
print "<form method=POST action=admin.cgi>";
print "<input type=hidden name=action value=PEDR>\n";
print "<input type=hidden name=password value=$input{password}>\n";
print "<hr SIZE=1 WIDTH=\"75%\">\n";
print "<center><b><font face=\"Arial,Helvetica\">$proggie Administration - Gallery Editor</font></b></center>\n";
print "<hr SIZE=1 WIDTH=\"75%\">\n";
print "<center><table BORDER=3 WIDTH=\"75%\" >\n";
print "<tr BGCOLOR=\"#FF0000\">\n";

print "<td>\n";
print "<center><b><tt><font color=\"#FFFFFF\"><font size=-1>Delete</font></font></tt></b></center>\n";
print "</td>\n";

print "<td>\n";
print "<center><b><tt><font color=\"#FFFFFF\"><font size=-1>Edit</font></font></tt></b></center>\n";
print "</td>\n";

print "<td>\n";
print "<center><b><tt><font color=\"#FFFFFF\"><font size=-1>Account #</font></font></tt></b></center>\n";
print "</td>\n";

print "<td>\n";
print "<center><b><tt><font color=\"#FFFFFF\"><font size=-1>Email</font></font></tt></b></center>\n";
print "</td>\n";

print "<td>\n";
print "<center><b><tt><font color=\"#FFFFFF\"><font size=-1>URL</font></font></tt></b></center>\n";
print "</td>\n";

print "<td>\n";
print "<center><b><tt><font color=\"#FFFFFF\"><font size=-1>Category</font></font></tt></b></center>\n";
print "</td>\n";

print "<td>\n";
print "<center><b><tt><font color=\"#FFFFFF\"><font size=-1>Description</font></font></tt></b></center>\n";
print "</td>\n";

print "<td>\n";
print "<center><b><tt><font color=\"#FFFFFF\"><font size=-1>Images</font></font></tt></b></center>\n";
print "</td>\n";

print "<td>\n";
print "<center><b><tt><font color=\"#FFFFFF\"><font size=-1>Active</font></font></tt></b></center>\n";
print "</td>\n";

print "</tr>\n";
&Get_Lock("post");
open(POST,"$Config[$cgipath]/data/post.dat");@POST=<POST>;close(POST);
&UnLock("post");
$cnt = 0;
$SELECT = "CHECKED";
foreach $post(@POST)
        {
        chomp($post);
        @data = split(/;/,$post);
print "<tr>\n";
print "<td><tt><center><input type=checkbox name=d$cnt></center></td>\n";
print "<td><tt><center><input type=RADIO name=edit value=$cnt $SELECT></tt></center></td>\n";
print "<td><tt><center>$data[8]</tt></center></td>\n";
print "<td><tt><center><a href=mailto:$data[6]>Email</a></tt></center></td>\n";
print "<td><tt><center><A HREF=$data[5] target=_new>Link</A></tt></center></td>\n";
print "<td><tt><center>$data[2]</tt></center></td>\n";
print "<td><tt><center>$data[3]</tt></center></td>\n";
print "<td><tt><center>$data[4]</tt></center></td>\n";
print "<td><tt><center>$data[7]</tt></center></td>\n";
print "</tr>\n";
$SELECT = "";
$cnt++;
}
print "</table></center>\n";
print "<CENTER><hr SIZE=1 WIDTH=\"75%\">\n";
print "<input type=submit value=\"Edit/\Delete\">\n";
print "</FORM>";
print "<form method=POST action=admin.cgi><input type=hidden name=action value=MAIN><input type=hidden name=password value=$input{password}><input type=submit value=\"Main Menu\"></form></body></html>";
print "</body>\n";
print "</html>\n";
 exit;
}



sub UPDAT
    {
$datf = "@_[0]";
$cfile = "$Config[$cgipath]data/$datf";
&Get_Lock("category");
open (CATA, "$cfile");
@cat = <CATA>;
close (CATA);
&UnLock("category");
@cat = split(/;/,$cat[0]);
&HTML_Header ("","", "", "#000000", "#FFFFFF","#0000EE", "#551A8B","FF0000");
print "<B><TT>$proggie - @_[4]<hr ALIGN=LEFT size=1 width=50%>";
print "</B></TT><table BORDER=0 WIDTH=50%>\n";
print "<tr><td BGCOLOR=000000>\n<font color=#FFFFFF><CENTER>";
print "<FORM method=post action=admin.cgi>";
print "<input type=hidden name=password value=\"$input{password}\">";
print "<B><TT><input type=hidden name=action value=del@_[1]>@_[2]";
print "<hr ALIGN=LEFT size=1 width=100%></CENTER>";
$CHK = "CHECKED";
foreach $CAT(@cat)
        {
        chomp($CAT);
print "<input type=radio name=newdat value=\"$CAT\" $CHK>$CAT<BR>";
$CHK = "";
}
print "<hr ALIGN=LEFT size=1 width=100%><center><input type=submit value=\"Remove It\"></FORM></CENTER></td>";
print "</font><td ALIGN=CENTER VALIGN=CENTER BGCOLOR=#C0C0C0>";
print "<FORM method=post action=admin.cgi>";
print "<input type=hidden name=password value=\"$input{password}\">";
print "<input type=hidden name=action value=add@_[1]>";
print "<tt><B>@_[3] </B></tt>";
print "<input type=text name=newdat size=10>";
print "<BR><input type=submit value=\"Add It\">";
print "</FORM></td></tr></TABLE>";
print "<hr ALIGN=LEFT size=1 width=50%>";
print "<form method=POST action=admin.cgi><input type=hidden name=action value=MAIN><input type=hidden name=password value=$input{password}><input type=submit value=\"Main Menu\"></form></body></html>";
exit;
        }

sub email
{
&HTML_Header;
print "<form method=POST action=admin.cgi>";
print "<input type=hidden name=password value=$input{password}>";
print "<b><tt>$proggie - Email Menu";
print "<hr ALIGN=left size=1 width=30%>";
print "<input type=radio name=action value=\"EML\" checked>";
print "Edit Mailing List<BR>";
print "<input type=radio name=action value=\"CEM\">";
print "Send Mass Mail<BR>";
print "<hr ALIGN=left size=1 width=30%>";
print "<input type=submit value=Submit>";
print "</FORM>";
print "<form method=POST action=admin.cgi><input type=hidden name=action value=MAIN><input type=hidden name=password value=$Config[$password]><input type=submit value=\"Main Menu\"></form></b><tt>";
&HTML_Footer;
}

sub editlist
{
&Get_Lock("mail");
open (MLIST,"$Config[$cgipath]data/mail.dat");
@LIST = <MLIST>;
close (MLIST);
&UnLock("mail");
&HTML_Header;
print "<form method=POST action=admin.cgi>\n";
print "<input type=hidden name=password value=$input{password}>";
print "<input type=hidden name=action value=delmail>";
print "<b><tt>$proggie - Mailing List Editor\n";
print "<hr ALIGN=LEFT size=1 WIDTH=30%>\n"; 
$cntr = 0;
foreach $address(@LIST)
        {
        print "<input type=checkbox name=$cntr>$address\n<BR>\n";
        $cntr++;
        }
print "<hr ALIGN=LEFT size=1 WIDTH=30%>\n"; 
print "<input type=submit value=\"Delete Address(s)\">\n";
print "</FORM>\n";
print "<form method=POST action=admin.cgi>\n";
print "<input type=hidden name=password value=$input{password}>\n";
print "<input type=hidden name=action value=addemail>\n";
print "<hr ALIGN=LEFT size=1 WIDTH=30%>\n"; 
print "<input type=text size=15 name=newemail><input type=submit value=\"Add Address\">\n";
print "<hr ALIGN=LEFT size=1 WIDTH=30%>\n";
print "</form>";
print "<form method=POST action=admin.cgi><input type=hidden name=action value=MAIN><input type=hidden name=password value=$Config[$password]><input type=submit value=\"Main Menu\"></form></b><tt>";
&HTML_Footer;
exit;
}
1;
