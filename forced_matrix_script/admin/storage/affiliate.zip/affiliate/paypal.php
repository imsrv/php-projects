<?php

require("vars.php");

// read post from PayPal system and add 'cmd'
$postvars = array();
while (list ($key, $value) = each ($HTTP_POST_VARS)) {
        $postvars[] = $key;
}
$req = 'cmd=_notify-validate';
for ($var = 0; $var < count ($postvars); $var++) {
        $postvar_key = $postvars[$var];
        $postvar_value = $$postvars[$var];
        $req .= "&" . $postvar_key . "=" . urlencode ($postvar_value);
}

// post back to PayPal system to validate
$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen ($req) . "\r\n\r\n";
$fp = fsockopen ("www.paypal.com", 80, $errno, $errstr, 30);

// assign posted variables to local variables
// note: additional IPN variables also available -- see IPN documentation
$item_name = $HTTP_POST_VARS['item_name'];
$receiver_email = $HTTP_POST_VARS['receiver_email'];
$item_number = $HTTP_POST_VARS['item_number'];
$invoice = $HTTP_POST_VARS['invoice'];
$payment_status = $HTTP_POST_VARS['payment_status'];
$payment_gross = $HTTP_POST_VARS['payment_gross'];
$txn_id = $HTTP_POST_VARS['txn_id'];
$payer_email = $HTTP_POST_VARS['payer_email'];

$result = @mysql_query("select * from templates where id='$item_number'");
$row = @mysql_fetch_array($result);
$price = $row["price"];

if (!$fp) {
        // HTTP ERROR
        echo "$errstr ($errno)";
} else {
        fputs ($fp, $header . $req);
        while (!feof($fp)) {
                $res = fgets ($fp, 1024);
                if (strcmp ($res, "VERIFIED") == 0) {
                          //check variables and if they look good then process

                } elseif (strcmp ($res, "INVALID") == 0) {
                echo "<b>Insufficient payment.</b>";
                } else {

                // check that txn_id has not been previously processed
                // check that receiver_email is an email address in your PayPal account
         if($payment_status=="Completed"){

         if($receiver_email == "$paypal"){
	         
	     if( ($payment_gross == "$$price") || ($payment_gross == "$price") )
	     {

	         
	               $filename = $item_number . ".zip";
        $downloaddir = "/home/template/public_html/YlJwmnPitauJs2/n584c896/";
        // $downloaddir holds a fake site name "somesite" but everything after it
        // is the actual structure.

        $safedir = "/home/template/public_html/members/";
        // $safedir holds a fake site name "somesite" but everything after it
        // is the actual structure.

        $downloadURL = "http://www.templatepark.com/YlJwmnPitauJs2/n584c896/";
        // $downloadURL holds a fake domain name but everything after the .net
        // is the actual structure of where the files should go.

        $letters = 'abcdefghijklmnopqrstuvwxyz';
                srand((double) microtime() * 1000000);
                $string = md5($payer_email) . "_";
                for ($i = 1; $i <= rand(4,12); $i++) {
                  $q = rand(1,24);
                  $string = $string . $letters[$q];
                }
                $handle = opendir($downloaddir);
                while ($dir = readdir($handle)) {
                  if (is_dir($downloaddir . $dir)){
                     if ($dir != "." && $dir != ".."){
                        @unlink($downloaddir . $dir . "/" . $filename);
                        @rmdir($downloaddir . $dir);
                     }
                  }
                }

                closedir($handle);
                mkdir($downloaddir . $string, 0777);
                symlink($safedir . $filename, $downloaddir . $string . "/" . $filename);
        $url = $downloadURL . $string . "/" . $filename;
	  
     

     }
     }
      }
        }
        }
        
   
	                        mail($payer_email,"$reg_thx_subj","
        Thanks for purchasing a template from TemplatePark.com!\n
Your temporary download link is below. It will only work\n
once. If you encounter a problem, please contact us with the\n
template id, price, and PayPal transaction number. Thanks!\n
\n
$url\n\n
Enjoy!\n
-TemplatePark\n
Michael7237@aol.com\n\n","From: $you");
        
fclose ($fp);

}
?>
