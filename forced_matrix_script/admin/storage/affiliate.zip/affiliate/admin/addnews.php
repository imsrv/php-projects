<?php
echo "<form action=addnews.php method=post>";
echo "<font face=verdana size=2>News:</font><br>";
echo "<textarea cols=35 rows=7 name=news>This is some news.</textarea>";
echo "<br>";
echo "<input type=submit name=submit value=Add News!>";
echo "</form>";

if($submit)
{

@include('../vars.php');
@include('../fncn.php');

	
	$date = date("M d Y");
	
	$aQuery = "INSERT INTO news ";
	$aQuery .= "(newsdate,news) VALUES ";
	$aQuery .= "('" . $date . "','" . $news . "')";
	$aResult = @mysql_query($aQuery)
				or die("
				<font color=red><h3>MySQL Error</h3></font>
				" . mysql_error());
				
	echo "<br><b>Done adding news item!</b>";		
						
}

?>