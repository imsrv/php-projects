<?php

@include('../vars.php');
@include('../fncn.php');

$aQuery = "INSERT INTO categories ";
$aQuery .= "(parent,name) VALUES ";
$aQuery .= "('$parent','$name')";
$aResult = @mysql_query($aQuery)
			or die(mysql_error());
			
echo "<br><b>Category added successfully.</b>";

?>