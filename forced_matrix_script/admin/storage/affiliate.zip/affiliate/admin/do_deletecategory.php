<?php

@include('../vars.php');
@include('../fncn.php');

$aQuery = "DELETE FROM categories ";
$aQuery .= "WHERE cid = '" . $cid . "' LIMIT 1";
$aResult = @mysql_query($aQuery)
		or die(mysql_error());
			
echo "<br><b>Category deleted successfully.</b>";

?>