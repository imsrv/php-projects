<?php

@include('../vars.php');
@include('../fncn.php');

?>

<form action=do_addtemplate.php method=post enctype="multipart/form-data">

<table border="0" style="border-collapse: collapse" bordercolor="#111111" width="500" id="AutoNumber1" cellpadding="2" bgcolor="#FFFFFF" height="120">
  <tr>
    <td width="20%" height="19"><b><font face="Verdana" size="2">Category:</font></b></td>
    <td width="50%" height="19">
    
    <?php
    
    echo "<select name=cid>";
    
    $aQuery = "SELECT * FROM categories ";
    $aQuery .= "WHERE parent = '0'";
    $aResult = @mysql_query($aQuery);
    
    while( $aRow = @mysql_fetch_assoc($aResult) )
    {
	 
	    echo "<option value=" . $aRow["cid"] . ">" . $aRow["name"] . "</option>";
	    
	    $bQuery = "SELECT * FROM categories ";
	    $bQuery .= "WHERE parent = '" . $aRow["cid"] . "'";
	    $bResult = @mysql_query($bQuery);
	    
	    while( $bRow = @mysql_fetch_assoc($bResult) )
	    {
		    
		    echo "<option value=" . $bRow["cid"] . "> -- " . $bRow["name"] . "</option>";
		    
	    }
	    
    }
    
    echo "</select>";
    
    ?>
    
    </td>
  </tr>
  <tr>
    <td width="20%" height="22"><b><font face="Verdana" size="2">Price </b>(No $)<b>:</b></font></td>
    <td width="50%" height="22">
    <input type="text" name="price" size="42" style="color: #000000; font-family: verdana; font-size: 8pt; letter-spacing: 1pt; border: 1px solid #000000; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1; background-color: #E8E8E8"></td>
  </tr>
   <tr>
    <td width="20%" height="22"><b><font face="Verdana" size="2">Thumbnail </b>(jpg)<b>:</b></font></td>
    <td width="50%" height="22">
    <input type="file" name="thumbnail" size="42" style="color: #000000; font-family: verdana; font-size: 8pt; letter-spacing: 1pt; border: 1px solid #000000; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1; background-color: #E8E8E8"></td>
  </tr>
  <tr>
    <td width="20%" height="19"><b><font face="Verdana" size="2">Screenshot </b>(jpg)<b>:</b></font></td>
    <td width="50%" height="19">
    <input type="file" name="screenshot" size="42" style="color: #000000; font-family: verdana; font-size: 8pt; letter-spacing: 1pt; border: 1px solid #000000; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1; background-color: #E8E8E8"></td>
  </tr>
  <tr>
    <td width="20%" height="19"><font face="Verdana" size="2"><b>ZIP </b>(zip):</font></td>
    <td width="50%" height="19">
    <input type="file" name="zipfile" size="42" style="color: #000000; font-family: verdana; font-size: 8pt; letter-spacing: 1pt; border: 1px solid #000000; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1; background-color: #E8E8E8"></td>
  </tr>
  <tr>
    <td width="20%" height="21"><b><font face="Verdana" size="2">Upload:</font></b></td>
    <td width="50%" height="21">
    <input type=submit name=submit value=Upload! style="color: #000000; font-family: verdana; font-size: 8pt; letter-spacing: 1pt; border: 1px solid #000000; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1; background-color: #E8E8E8"></td>
  </tr>
</table>
</form>



<?

?>