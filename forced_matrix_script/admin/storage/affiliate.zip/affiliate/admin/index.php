<?php

@include('../vars.php');
@include('../fncn.php');

?>

<h2 align="center"><font face="Verdana">Administration Panel</font></h2>
<table border="1" cellpadding="2" style="border-collapse: collapse" bordercolor="#111111" width="700" id="AutoNumber1" bordercolorlight="#C0C0C0" bordercolordark="#C0C0C0">
  <tr>
    <td width="100%" bgcolor="#E8E8E8" colspan="2">
    <font face="Verdana" size="4">Template Management</font></td>
  </tr>
  <tr>
  <td width=100% colspan=2>
  <font face=verdana size=2>Select A Template Category | <a href=addtemplate.php>Add Template</a></font>
  <br></td>
  </tr>
  <tr>
    <td width="100%" colspan="2"><? cats(); ?></td>
  </tr>
  <tr>
    <td width="100%" bgcolor="#E8E8E8" colspan="2">
    <font face="Verdana" size="4">Category Management</font></td>
  </tr>
  <tr>
    <td width="50%">
    <p align="center"><br>
   <a href=addcategory.php> <font face="Verdana">Add Category</font></a><br>
&nbsp;</td>
    <td width="50%" align=center><a href=deletecategory.php><font face="Verdana">Delete Category</font></a></td>
  </tr>
  <tr>
    <td width="100%" bgcolor="#E8E8E8" colspan="2">
    <font face="Verdana" size="4">Subscriber Management</font></td>
  </tr>
  <tr>
    <td width="50%">
    <p align="center"><br>
    <a href=viewsubs.php><font face="Verdana">View Subscribers</font></a><br>
&nbsp;</td>
    <td width="50%">
    <p align="center"><br>
    <font face="Verdana">Currently 
    <?
    
    $num = @mysql_num_rows(mysql_query("select * from members"));
    echo $num;
    
    ?> Subscribers.</font><br>
&nbsp;</td>
  </tr>
  <tr>
    <td width="100%" bgcolor="#E8E8E8" colspan=2>
    <font face="Verdana" size="4">News Management</font></td>
  </tr>
 <tr colspan=2>
 <td width=50% align=center><br>
 &nbsp;<a href=addnews.php><font face=verdana>Add News</font></a>
 <br>&nbsp;</td>
 <td width=50%><br>
 &nbsp;<br>
 </td>
  </tr>
</table>