<?php

@include('../vars.php');
@include('../fncn.php');

$aQuery = "DELETE FROM templates ";
$aQuery .= "WHERE id = '" . $id . "'";
$aResult = @mysql_query($aQuery)
			or die(mysql_error());

			unlink($path . "/thumbs/" . $id . ".jpg");
			unlink($path . "/screenshots/" . $id . ".jpg");
			unlink($path . "/members/" . $id . ".zip");
			
echo "<br><b>New template deleted successfully!</b>";

?>