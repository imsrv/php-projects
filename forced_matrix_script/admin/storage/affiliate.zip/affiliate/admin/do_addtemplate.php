<?php

@include('../vars.php');
@include('../fncn.php');

$aQuery = "INSERT INTO templates ";
$aQuery .= "(cid,price) VALUES ('$cid','$price')";
$aResult = @mysql_query($aQuery)
			or die(mysql_error());

$bQuery = "SELECT * FROM templates ";
$bQuery .= "ORDER BY id DESC LIMIT 1";
$bResult = @mysql_query($bQuery);

$latest = @mysql_fetch_array($bResult);

$_FILES['thumbnail']['name'] = $latest["id"];

copy($thumbnail, $path . "/thumbs/" . $_FILES['thumbnail']['name'] . ".jpg");

$_FILES['screenshot']['name'] = $latest["id"]; 

copy($screenshot, $path . "/screenshots/" . $_FILES['screenshot']['name'] . ".jpg");

$_FILES['zipfile']['name'] = $latest["id"]; 

copy($zipfile, $path . "/members/" . $_FILES['zipfile']['name'] . ".zip");

echo "<br><b>New template added successfully!</b>";

?>