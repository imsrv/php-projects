<?php

@include('../fncn.php');
@include('../vars.php');

$admin_prev = 1;

echo get_name($cid);

echo "<hr align=center width=50% noshade><br>";

echo "<font face=verdana size=3>SubCategories:</font><br>";

	sub_cats($cid);

echo "<hr align=center width=50% noshade><br>";

if (!$start)
	$start = 0;
	
if (!isset($pages)) {
   
	$query = "SELECT * FROM templates WHERE cid = $cid ORDER BY id DESC";

    $result = @mysql_query($query)
   			or die(mysql_error());
   			
    $num = @mysql_num_rows($result);
   
   	if ($num > $num_per_page) {
	   	
      $pages = ceil($num/$num_per_page);
      
   	} elseif ($num > 0) {
	   
      $pages = 1;
   
      } else {
	      
      echo "<b>Sorry, no templates to display yet.</b>";

   		$start = 0;
	}
}

if (!$disp)

	$disp=$num_per_page;

   $query = "SELECT * FROM templates WHERE cid = $cid ORDER BY id DESC LIMIT $start,$disp";
   
   
   $rowcount = 0;
  
   echo "<table width=500 border=0 cellpadding=2 cellspacing=2><tr>";
   
   
   
   
   
   while($row = @mysql_fetch_assoc($result))
   {
   
   if ($rowcount != 0 && $rowcount % 3 == 0) {
        echo "</tr><tr>";
    }
    
    $id = $row["id"];
    

    
    if($admin_prev)
    {
	
	echo "<td>";
    echo "<img src=../thumbs/$id.jpg><br>";  
    echo "<a href=../view.php?id=$id>View</a> | ";
    echo "<a href=deletetemplate.php?id=$id>Delete</a>";
    echo "</td>";
    
    } else {

	echo "<td>";
    echo "<img src=thumbs/$id.jpg><br>";    
	echo "<a href=view.php?id=$id>View</a> | ";
	echo "<a href=members/$id.zip>Download</a>";
	echo "</td>";
	
	}
    
    $rowcount++;
    
    }
    
    echo "</table><br><br>";
   
   if ($pages > 1) {
   if ($start == 0) {
      $currpage = 1;
   } else {
      $currpage = ($start/$num_per_page) + 1;
}

// if not firstpage, link to prev
   if ($start != 0) {
      echo "<< <a href=\"display.php?cid=" . $cid . "&start=" . ($start -
$num_per_page) . "&pages=" . $pages . "\">Previous</a> ";
   }

// link numbered pages
   for ($i = 1; $i <= $pages; $i++) {
      $next = $start + $num_per_page;
      if ($i != $currpage) {
         echo "<a href=\"display.php?cid=" . $cid . "&start=" .
(($num_per_page * ($i - 1))) . "&pages=" . $pages . "\">" . $i
. "</a> ";
      } else {
         echo $i . " ";
      }
   }

 // if not lastpage, make next link
   if ($currpage != $pages) {
      echo "<a href=\"display.php?cid=". $cid . "&start=" . ($start +
$num_per_page) . "&pages=" . $pages . "\">Next</a> >>";
   }
   }

?>