<? include("header.php"); ?>
<? include("main.php"); ?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<u><b>Website News</b><br></u>
<? get_news("5"); ?>
<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>
<? include("footer.php"); ?>
