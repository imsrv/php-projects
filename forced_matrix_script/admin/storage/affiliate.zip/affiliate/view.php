<?php

include("header.php");

$row = mysql_fetch_array(mysql_query("select * from templates where id='$id'"));
$price = $row["price"];

echo "<br><br><center><img src=screenshots/$id.jpg border=1>";

echo "<br>";
echo "<b>ID:</b> $id<br>";
echo "<b>Price:</b> $price<br>";
echo "<a href=purchase.php?id=$id>Purchase</a></center>";

include("footer.php");

?>