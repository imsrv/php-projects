<?php

// Site URL - No ending slash

$siteurl = "http://localhost";

// Full Server Path

$path = getenv("DOCUMENT_ROOT");

// URL To PayPal Subscription

$paypal_url = "https://www.paypal.com/xclick/business=URL@url.com&item_name=TemplatePark.Com&item_number=template&amount=XXXX&no_note=1&currency_code=USD";

// PayPal Email Addy.
$paypal = "URL@url.com";

// Successful Registration Message : Subject

$reg_thx_subj = "Template Purchase";

// Successful Registration Message : Message

$reg_thx_msg = "
Thanks for purchasing a template from us!\n
Your temporary download link is below. It will only work\n
once. If you encounter a problem, please contact us with the\n
template id, price, and PayPal transaction number. Thanks!\n
\n
$url\n\n
Enjoy!\n
\n";

// Your Name <and email>

$you = "Me <me@you.com>";

// Number Of Templates Per Page

$num_per_page = 10;

// MySQL Host Server

$mysql_host = "localhost";

// MySQL User

$mysql_user = "root";

// MySQL Pass

//$mysql_pass = "";

// MySQL Database

$mysql_db = "templates";


// NO MORE EDITING

$conn = @mysql_connect($mysql_host, $mysql_user/*, $mysql_pass*/)
                                or die("
                                <h3><font color=red>MySQL Error</font></h3>
                                " . mysql_error);
                                
@mysql_select_db($mysql_db, $conn);


?>
