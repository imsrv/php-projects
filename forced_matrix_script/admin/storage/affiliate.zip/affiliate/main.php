<?php

include("vars.php");
include("fncn.php");

cats();

?>