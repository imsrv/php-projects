<?php

include("vars.php");
include("fncn.php");

get_news("5");

?>