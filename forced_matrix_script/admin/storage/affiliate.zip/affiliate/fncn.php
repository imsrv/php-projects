<?php

include("vars.php");

function cats()
{
        
                echo "<table width=100% border=0 cellpadding=3 cellspacing=3><tr>";
                
                $aQuery = "SELECT * FROM categories ";
                $aQuery .= "WHERE parent = '0'";
                $aResult = @mysql_query($aQuery)
                                        or die("
                                        <h3><font color=red>MySQL Error</font></h3>
                                        " . mysql_error());
        
                $rows = 0;
                                
                while( $aRow = @mysql_fetch_assoc($aResult) )
                {
        
                        if ($rows != 0 && $rows % 2 == 0)
                        {
                        echo "</tr><tr>";
                            }
                                
                        echo "<td>";
                        echo "<a href=display.php?cid=" . $aRow["cid"] . ">";
                        echo "<font face=verdana size=2>" . $aRow["name"] . "</font>";
                        echo "</a>";
                        echo "</td>";
        
                        $rows++;
                                        
                }

                echo "</table>";
            
}

function sub_cats($cid)
{

                $aQuery = "SELECT * FROM categories ";
                $aQuery .= "WHERE parent = '" . $cid . "'";
                $aResult = @mysql_query($aQuery);
                
                echo "<table width=100% border=0 cellpadding=3 cellspacing=3 align=center><tr>";
                
                $rows = 0; 
                
                $num = @mysql_num_rows($aResult);
                if($num <= 0){ echo "Sorry, no sub categories yet."; }
                
                while( $aRow = @mysql_fetch_assoc($aResult) )
                {
                        
                        if ($rows != 0 && $rows % 2 == 0)
                        {
                        echo "</tr><tr>";
                    }

                    echo "<td>";
                    echo "<a href=display.php?cid=" . $aRow["cid"] . ">";
                    echo "<font face=verdana size=2>" . $aRow["name"] . "</font>";
                    echo "</a>";
                    echo "</td>";
            
                    $rows++;
                    
            }
            
            echo "</table>";
                
}

function get_name($cid)
{
        
        $aQuery = "SELECT name FROM categories ";
        $aQuery .= "WHERE cid = '" . $cid . "'";
        $aResult = @mysql_query($aQuery)
                        or die("
                        <h3><font color=red>MySQL Error</font></h3>
                        " . mysql_error);
                        
        while( $aRow = @mysql_fetch_assoc($aResult) )
        {
        
                echo "<font face=verdana size=4>" . $aRow["name"] . " Templates</font>";
                        
        }
        
}

function get_news($days)
{

        $aQuery = "SELECT * FROM news ";
        $aQuery .= "ORDER BY id DESC ";
        $aQuery .= "LIMIT " . $days;
        $aResult = @mysql_query($aQuery)
                        or die("
                        <h3><font color=red>MySQL Error</font></h3>
                        " . mysql_error);
                        
        while( $aRow = @mysql_fetch_assoc($aResult) )
        {
        
                echo "<br>";
                echo "<font face=verdana size=2><b>" . $aRow["newsdate"] . "</b> - </font> ";
                echo "<font face=verdana size=2>" . nl2br($aRow["news"]) . "</font><br>";
                        
        }
        
                
}

function error( $error )
{
	
   	include("header.php");
		echo "<p align=\"center\"><font size=\"4\">Error: $error</font></center>\n";
		echo "<p align=\"center\"><a href=\"javascript:history.back()\"><b>Back</b></a></p>\n";
		include("footer.php");

}

?>
