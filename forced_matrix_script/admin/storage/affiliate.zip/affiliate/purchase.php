<?php

include("vars.php");
include("fncn.php");

$row = mysql_fetch_array(mysql_query("select * from templates where id='$id'"));
$price = $row["price"];
$paypal_url = str_replace("template",$id, $paypal_url);
$paypal_url = str_replace("XXXX",$price, $paypal_url);

header("location: $paypal_url");

?>