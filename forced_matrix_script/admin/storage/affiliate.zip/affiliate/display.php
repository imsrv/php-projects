<?php

//include("header.php");

/* *****************************
This is the coding for the first part of
multiple page use.
********************************* */

if (!$start)
	$start = 0;
	
if (!isset($pages)) {
   
	$query = "SELECT * FROM templates WHERE cid = $cid ORDER BY id DESC";

    $result = @mysql_query($query)
   			or die(mysql_error());
   			
    $num = @mysql_num_rows($result);
   
   	if ($num > $num_per_page) {
	   	
      $pages = ceil($num/$num_per_page);
      
   	} elseif ($num > 0) {
	   
      $pages = 1;
   
      } else {
	      
      echo "<b>Sorry, no templates to display yet.</b>";

   		$start = 0;
	}
}

if (!$disp)

	$disp=$num_per_page;
	
/* *****************************
This is the end of the first part of
multiple page use.
********************************* */	
		
   $aResult = @mysql_query("SELECT * FROM templates WHERE cid = $cid ORDER BY id DESC LIMIT $start,$disp");

   $rowcount = 0;
  
   echo "<table width=100% border=0 cellpadding=2 cellspacing=2 align=center><tr>";
   
   while( $aRow = @mysql_fetch_assoc($aResult) )
   {
   
   if ($rowcount != 0 && $rowcount % 2 == 0) {
        echo "</tr><tr>";
    }
    
    $id = $aRow["id"];
    $price = $aRow["price"];

    
    if($admin_prev)
    {
	
	echo "<td valign=middle align=center>";
    echo "<img src=../thumbs/$id.jpg><br>";  
    echo "<a href=../view.php?id=$id>View</a> | ";
    echo "<a href=deletetemplate.php?id=$id>Delete</a>";
    echo "</td>";
    
    } else {

	echo "<td valign=middle align=center>";
    echo "<font face=verdana size=1>$".$price."</font><br>";
    echo "<a href=view.php?id=$id><img src=thumbs/$id.jpg border=1 color=000000 "; ?>style="border: 1px solid #000000"><? echo "</a><br>";    
	echo "<font face=verdana size=1><a href=view.php?id=$id>View</a> | ";
	echo "<a href=purchase.php?id=$id>Purchase</a></font>";
	echo "</td>";
	
	}
    
    $rowcount++;
    
    }
    
    echo "</table><br><br>";

/* *****************************
This is the coding for the last part of
multiple page use.
********************************* */    
       
   if ($pages > 1) {
   if ($start == 0) {
      $currpage = 1;
   } else {
      $currpage = ($start/$num_per_page) + 1;
}

// if not firstpage, link to prev
   if ($start != 0) {
      echo "<< <a href=\"display.php?cid=" . $cid . "&start=" . ($start -
$num_per_page) . "&pages=" . $pages . "\">Previous</a> ";
   }

// link numbered pages
   for ($i = 1; $i <= $pages; $i++) {
      $next = $start + $num_per_page;
      if ($i != $currpage) {
         echo "<a href=\"display.php?cid=" . $cid . "&start=" .
(($num_per_page * ($i - 1))) . "&pages=" . $pages . "\">" . $i
. "</a> ";
      } else {
         echo $i . " ";
      }
   }

 // if not lastpage, make next link
   if ($currpage != $pages) {
      echo "<a href=\"display.php?cid=". $cid . "&start=" . ($start +
$num_per_page) . "&pages=" . $pages . "\">Next</a> >>";
   }
   }

/* *****************************
This is the coding for the ending
of multiple page use.
********************************* */


//include("footer.php");

?>
