<?php

 # includes the account_header, which contains the included files (vars.php,
 # fncn.php, autoglobals_on.php) the top navigation bar, the affilate
 # link, and the affilate log-in name.
    include_once ('account_header.php');

    if (isset($action) and $action == "WITHDRAW MONEY TO PAYPAL ACCOUNT"){
     if (isset($amount) and $amount < $withdraw){
        $money = "<H3 align='center'>Error: Money can be withdrawn only after account balance will exceed ";
        $money .= $withdraw;
        $money .= ".</H3>";
        echo $money;

     }elseif (isset($amount) and $amount >= $withdraw){
        $query = "UPDATE affiliate SET current_account_balance ='0'";
        $query2 = "UPDATE affiliate SET withdrawal = '$amount'";
        mysql_query($query) or error("An error occured while processing this request, please try again.");
        mysql_query($query2) or error("An error occured while processing this request, please try again.");
        $money = "<H3 align='center'>Funds will be sent to you via Paypal. </H3>";
        echo $money;
     }
   }
?>
    <TABLE align="center" border="2">
      <TBODY>
        <TR>
          <TD>
            Total money earned:
          </TD>
          <TD>&nbsp;
          </TD>
        </TR>
        <TR>
          <TD>
            Total money sent on Paypal account:
          </TD>
          <TD>&nbsp;
          </TD>
        </TR>
        <TR>
          <TD>
            Current account balance:
          </TD>
          <TD>&nbsp;
           
          </TD>
        </TR>
        <TR>
          <TD colspan="2">
            <FORM action="account.php" method="post">

              <?php
              $query3 = "SELECT current_account_balance FROM affiliate WHERE username = '" .$_SESSION['username']. "'";
              $results = @mysql_query($query3) or error("An error occured while processing this request, please try again.");
              ?>
              <INPUT type="hidden" value="<? echo $results; ?>" name="amount">
              <INPUT type="submit" value="WITHDRAW MONEY TO PAYPAL ACCOUNT" name="action">
            </FORM>
          </TD>
        </TR>
      </TBODY>
    </TABLE>
  </BODY>
</HTML>

