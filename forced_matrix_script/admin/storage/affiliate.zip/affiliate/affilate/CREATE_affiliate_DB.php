<?php
@include('../vars.php');
@include('../fncn.php');


$query = "CREATE TABLE affiliate (
             first_name VARCHAR(16) NOT NULL,
             last_name VARCHAR(25) NOT NULL,
             website_url TEXT,
             email VARCHAR(60) NOT NULL,
             paypal_email VARCHAR(60) NOT NULL,
             phone VARCHAR(20) NOT NULL,
             username VARCHAR(16) NOT NULL,
             password VARCHAR(18) NOT NULL,
             current_account_balance DECIMAL (7,2) DEFAULT '0',
             amount_to_date  DECIMAL (7,2) DEFAULT '0',
             amount_sent DECIMAL (7,2) DEFAULT '0',
             withdrawal DECIMAL (7,2) DEFAULT '0',
             time_stamp TIMESTAMP,
             PRIMARY KEY (username)
             )";

    @mysql_query($query) or error("DATABASE WAS NOT BUILT: mysql_error()");


?>
