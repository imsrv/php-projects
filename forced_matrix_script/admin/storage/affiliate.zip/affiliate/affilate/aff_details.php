 <?php
 # includes the account_header, which contains the included files (vars.php,
 # fncn.php, autoglobals_on.php) the top navigation bar, the affilate
 # link, and the affilate log-in name.
    include('account_header.php');
    if (isset($action) and $action == "change_details"){
       $change_d = "UPDATE affiliates SET first_name = '$fname', last_name='$lname', website_url='$host', email='$email', paypal_email='$paypal_email', phone='$phone'";
       mysql_query($change_d);
    }elseif (isset($action) and $action == "change"){
       $change_d = "UPDATE affiliates SET password = '$passwd'";
       mysql_query($change_d);
    }

 $info = mysql_query("SELECT first_name, last_name, website_url, email, paypal_email, phone FROM affiliate WHERE username = '" . $_SESSION['username'] ."'");
 $details = mysql_fetch_array($info, MYSQL_ASSOC);
 ?>
<!--//Update info--\\-->
<FORM action="aff_details.php" name="form" method=post><TABLE>
<TBODY>
<TR>
<TD><B>First Name <B></B></B></TD>
<TD><INPUT size=30 value="<? echo $details['first_name']; ?>" name="fname"></TD></TR>
<TR>
<TD><B>Last Name <B></B></B></TD>
<TD><INPUT size=30 value="<? echo $details['last_name']; ?>" name="lname"></TD></TR>
<TR>
<TD><B>Web site URL <B></B></B></TD>
<TD><INPUT size=30 name="host" value"<? echo $details['website_url']; ?>"></TD></TR>
<TR>
<TD><B>Regular E-Mail address <B></B></B></TD>
<TD><INPUT size=30 value="<? echo $details['email']; ?>" name="email"></TD></TR>
<TR>
<TD><B>Paypal address (<A href="https://www.paypal.com" target=_blank>Create one here</A>, if needed) <B></B></B></TD>
<TD><INPUT size=30 value="<? echo $details['paypal_email']; ?>" name="paypal_email"></TD></TR>
<TR>
<TD><B>Phone number <B></B></B></TD>
<TD><INPUT size=30 value="<? echo $details['phone']; ?>" name=phone></TD></TR></TBODY></TABLE>

<INPUT type=hidden value="change_details" name="action">
<INPUT type=submit value=" Change details "> 
</FORM><BR><BR>

<!--//Update Password\\-->

<FORM action="aff_details.php" name="formDetails" method="post" onSubmit="return CheckData()">
<INPUT type=hidden value="change" name="action"> 
<INPUT type=hidden value="true" name="login">
<TABLE>
<TBODY>
<TR>
<TD><B>Old password <B></B></B></TD>
<TD><INPUT type=password size=30 value="" name="opasswd"></TD></TR>
<TR>
<TD><B>New password <B></B></B></TD>
<TD><INPUT type=password size=30 value="" name="passwd"></TD></TR>
<TR>
<TD><B>Confirm password <B></B></B></TD>
<TD><INPUT type=password size=30 value="" name="passwd2"></TD></TR></TBODY></TABLE>
<INPUT type=hidden value="change_passwd" name="action">
<INPUT type=submit value=" Change password "> </FORM>


</body>

</html>
