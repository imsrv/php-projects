<?php
    include_once("../vars.php");
    include_once("../fncn.php");
    include_once('autoglobals_on.php');

    if (isset($send) and $send == 1 ){ # If the form was sent the following is done

# Trims white space from variables

         $fname = trim ( $fname);
         $lname = trim ( $lname);
         $host = trim ($host );
         $email = trim ($email );
         $paypal_email = trim ($paypal_email );
         $phone = trim ($phone );
         $username = trim ($username );
         $passwd = trim ($passwd );
         $passwd2 = trim ($passwd2);

//Entry Form Validation
			
         if( $fname == "" ) error( "First Name required" );
			if( $lname == "" ) error( "Last Name required" );
         if( $email == "" ) error( "E-mail required" );
			elseif ( !eregi( "^[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-z]{2,3}$", $email ) ) error( "Invalid e-mail.");
		   $result = mysql_query( "SELECT email FROM affiliate WHERE email='$email'" ) or error( mysql_error() );
			if( mysql_num_rows( $result ) >= 1 ) error( "This e-mail has already been registered with us" );
         if( $paypal_email == "" ) error( "In order to be paid, you need a Paypal account");
			elseif ( !eregi( "^[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\\.[a-z]{2,3}$", $email ) ) error( "Invalid Paypal E-mail.");
			if( $phone == "" ) error( "Your Phone Number is Required" );			
			if( $username == "" ) error( "Username Required" );
		   $result2 = mysql_query( "SELECT username FROM affiliate WHERE username ='$username'" ) or error( mysql_error() );
			if( mysql_num_rows( $result2 ) >= 1 ) error( "This Username is already in use, please select another" );
         if( $passwd == "" ) error( "Password required" );
			if( $passwd2 == "" ) error( "Please re-enter your password again" );
			if( $passwd != $passwd2 ) error( "Two password don't match" );

 //Loads the entry form results into the affilate database
         $query = "insert into affiliate (
                first_name,
                last_name,
                website_url,
                email,
                paypal_email,
                phone,
                username,
                password
                ) VALUES (
                '$fname',
                '$lname',
                '$host',
                '$email',
                '$paypal_email',
                '$phone',
                '$username',
                '$passwd')";

           mysql_query($query) or  mysql_error();

           if (( mysql_num_rows( $result ) < 1 ) and ( mysql_num_rows( $result2 ) < 1 )){
           //@require ('header.php');
           echo '<br><br><br><div align="center">Here is your unique affiliate link:<br><br>';
           $aff = '?aff=';
		     echo '<a href="' . $siteurl . $aff . $username . '">'. $siteurl . $aff . $username. '</a><br>';
           echo 'Please try to expose it as much as possible to gain more sales.<br>';
           echo '<FORM METHOD=post ACTION="aff_details.php">';
           echo '<INPUT TYPE="hidden" name="login" value="true">';
           echo '<INPUT TYPE="hidden" value="'.$username.'"name="username">';
           echo '<INPUT TYPE="hidden" value="'.$passwd.'"name="passwd">';
           echo '<INPUT TYPE="submit" VALUE="Go To Your Account"></FORM>';
           //@require ('footer.php');
      }
      }
?>
