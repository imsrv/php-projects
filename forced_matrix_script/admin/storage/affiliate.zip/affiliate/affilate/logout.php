<?php
 ## //This the log-out page. It destroys the sessions varibles.

   @include_once("vars.php");


  session_start();
  session_destroy();
  

  headder ("location: $siteurl");


 
?>
