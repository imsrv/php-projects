<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 3.2//EN">
<HTML>
  <HEAD>
    <TITLE>
      Log-in
    </TITLE>
  </HEAD>
  <BODY>
    <TABLE>
      <TR>
        <TD align="middle">
          Username
        </TD>
        <TD align="middle">
          <FORM action="aff_details.php" method="POST">
            <INPUT type="hidden" value="true" name="login" size="20"> <INPUT name="username" value="" size="20">
          </FORM>
        </TD>
      </TR>
      <TR>
        <TD align="middle">
          Password
        </TD>
        <TD align="middle">
          <INPUT type="password" value="" name="passwd" size="20">
        </TD>
      </TR>
      <TR>
        <TD align="right">
          &nbsp;
        </TD>
        <TD align="center">
          <INPUT type="submit" value=" GO " name="submit">
        </TD>
      </TR>
      <TR>
        <TD align="middle">
          &nbsp;
        </TD>
        <TD align="middle">
          <A href="forgot_password.php">Forgot your password?</A>
        </TD>
      </TR>
    </TABLE>
  </BODY>
</HTML>


