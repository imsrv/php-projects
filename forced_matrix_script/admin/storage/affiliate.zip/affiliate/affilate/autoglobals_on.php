<?php


   while(list($key,$value)= each($_POST)) {
    	$tmp = $key;
    	$$tmp = $value;		
    }	
    while(list($key,$value)= each($_GET)) {
    	$tmp = $key;
    	$$tmp = $value;		
    }
?>
