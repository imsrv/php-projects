<?php
    session_start();
    @include_once("../fncn.php");
    @include_once('autoglobals_on.php');

if (isset($login) and $login == "true"){
   $myinfo = "SELECT username, password From affiliate WHERE username ='$username' AND password ='$passwd'";
   $query = mysql_query($myinfo);

   $results = mysql_fetch_array ($query);

       if( $results['username'] == $username and $results['password'] == $passwd){

            if (!$_SESSION['username']) session_register('username');
            if (!$_SESSION['password']) session_register('passwd');
 }
} else {
   error ("Log-in failed, please go back and try again");
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Affiliate Account Panel</title>
 <script type="text/javascript" language="javascript">
 <!--//Hide.
     function CheckData(){
         if (document.formDetails.passwd.value.length <= 5){
		      alert("Enter a password at least 5 characters long.");
			   var problem = true;
		   }			
	 	  if (document.formDetails.passwd.value != document.formDetails.passwd2.value){
		     alert("Your confirmed password does not match the enter password.");
			  var problem = true;
		   }
        			
        if (problem == true){
		  	 return false;
		   } else {
			 return true;
		   }		
		 }
		 //-->
		 </script>

</head>
<body>
<!--//Affilate Account Navigation-->
	 <TABLE align="center">
      <TBODY>
        <TR>
          <TD>
            [ <A  href="account.php?login=true">Account balance</A> ]&nbsp;&nbsp;&nbsp;&nbsp;
          </TD>
          <TD>
            [ <A  href="banners.php?login=true">Banners</A> ]&nbsp;&nbsp;&nbsp;&nbsp;
          </TD>
          <TD>
            [ <A  href="aff_details.php?login=true">Account details</A> ]&nbsp;&nbsp;&nbsp;&nbsp;
          </TD>
          <TD>
            [ <A  href="terms.php?login=true">Descriptions/Terms</A> ]&nbsp;&nbsp;&nbsp;&nbsp;
          </TD>
          <TD>
            [ <A  href="logout.php?login=true">Logout</A> ]&nbsp;&nbsp;&nbsp;&nbsp;
          </TD>
        </TR>
      </TBODY>
    </TABLE>
<?
echo 'Your unique affiliate link is:' . $siteurl . '?aff=' . $_SESSION['username']. '<br>';
?>
Please try to send as much visitors as possible to TemplateMonster web site through this link.
<br>
<br>
<h3 align="center">Affiliate login:<? echo $_SESSION['username']; ?></h3>
