<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
  <HEAD>
    <TITLE>
      Affiliate Entry Form
    </TITLE>
 <script type="text/javascript" language="javascript">
 <!--//Hide.
     function CheckData(){
	 	  if (document.entry.fname.value.length <= 0){
		    alert("Enter First Name.");
			 document.entry.fname.value = "*** First Name";
			 document.entry.fname.focus();
			 var problem = true;
		   }
	 	  if (document.entry.lname.value.length <= 0){
		     alert("Enter Last Name.");
			 document.entry.lname.value = "*** Last Name";
			 document.entry.lname.focus();
			 var problem = true;
		   }		
	 	  if (document.entry.email.value.length <= 0){
		     alert("Enter E-mail Address.");
			 document.entry.email.value = "*** E-mail";
			 document.entry.email.focus();
			 var problem = true;
		   }
	 	  if (document.entry.paypal_email.value.length <= 0){
		     alert("Enter Paypal E-mail Address.");
			 document.entry.paypal_email.value = "*** Paypal E-mail Address";
			 document.entry.paypal_email.focus();
			 var problem = true;
		   }		
	 	  if (document.entry.phone.value.length <= 0){
		     alert("Enter Phone Number.");
			 document.entry.phone.value = "*** Phone Number";
			 document.entry.phone.focus();
			 var problem = true;
		   }
	 	  if (document.entry.username.value.length <= 0){
		     alert("Enter Username.");
			 document.entry.username.value = "*** Username";
			 document.entry.username.focus();
			 var problem = true;
		   }         		
	 	  	
         if (document.entry.passwd.value.length <= 5){
		     alert("Enter a password at least 5 characters long.");
			 var problem = true;
		   }			
	 	  if (document.entry.passwd.value != document.entry.passwd2.value){
		     alert("Your confirmed password does not match the enter password.");
			 var problem = true;
		   }
        if (!document.entry.terms.checked){
		     alert("You must accept the Affiliate Program Terms and Conditions.");
			 var problem = true;
		   }			
        if (problem == true){
		  	 return false;
		   } else {
			 return true;
		   }		
		 }
		 //-->
		 </script>
  </HEAD>
  <BODY>
    <FORM name="entry" action="affiliate_creator.php" method="POST" onSubmit="return CheckData()">
      <TABLE width="697" height="330">
        <TR>
          <TD width="323" height="22">
            First Name
          </TD>
          <TD width="364" height="22">
            <INPUT style="WIDTH: 150px" name="fname" size="20" tabindex="1" maxlength="16">
          </TD>
        </TR>
        <TR>
          <TD width="323" height="22">
            Last Name
          </TD>
          <TD width="364" height="22">
            <INPUT style="WIDTH: 150px" name="lname" size="20" tabindex="2" maxlength="25">
          </TD>
        </TR>
        <TR>
          <TD width="323" height="22">
            Web Site URL
          </TD>
          <TD width="364" height="22">
            <INPUT style="WIDTH: 150px" name="host" size="20" tabindex="3">
          </TD>
        </TR>
        <TR>
          <TD width="323" height="22">
            Regular E-mail Address
          </TD>
          <TD width="364" height="22">
            <INPUT style="WIDTH: 150px" name="email" size="20" tabindex="4" maxlength="60">
          </TD>
        </TR>
        <TR>
          <TD width="323" height="23">
            Paypal E-mail Address (<a href="http://www.paypal.com">Create one here, if needed</a>)
          </TD>
          <TD width="364" height="23">
            <INPUT style="WIDTH: 150px" name="paypal_email" size="20" tabindex="5" maxlength="60">&nbsp;(<U>?</U>)
          </TD>
        </TR>
        <TR>
          <TD width="323" height="22">
            Phone Number
          </TD>
          <TD width="364" height="22">
            <INPUT style="WIDTH: 150px" name="phone" size="20" tabindex="6" maxlength="20">
          </TD>
        </TR>
        <TR>
          <TD width="323" height="22">
            Desired Username
          </TD>
          <TD width="364" height="22">
            <INPUT style="WIDTH: 150px" name="username" size="20" tabindex="7" maxlength="16">
          </TD>
        </TR>
        <TR>
          <TD width="323" height="22">
            Password (min length 6, max length 18)
          </TD>
          <TD width="364" height="22">
            <INPUT style="WIDTH: 150px" type="password" value="" name="passwd" size="20" tabindex="8" maxlength="18">
          </TD>
        </TR>
        <TR>
          <TD width="323" height="22">
            Confirm Password
          </TD>
          <TD width="364" height="22">
            <INPUT style="WIDTH: 150px" type="password" value="" name="passwd2" size="20" tabindex="9" maxlength="18">
          </TD>
        </TR>
        <TR>
          <TD width="323" height="40">
            <BR>
          </TD>
          <TD width="364" height="40">
            <INPUT type="checkbox" value="read" name="terms"> I agree with
			<A class="light_blue" href="<?php echo $terms; ?>" target="_blank">
			<B>AFFILIATE PROGRAM TERMS AND CONDITIONS
			</B>
			</A>.
			<BR>
          </TD>
        </TR>
        <TR>
          <TD width="323" height="47">
            &nbsp;
          </TD>
          <TD width="364" height="47">
            <INPUT type="hidden" value="1" name="send"><INPUT type="submit" value="CONTINUE" name="submit" tabindex="10">
          </TD>
        </TR>
      </TABLE>
    </FORM>
  </BODY>
</HTML>


