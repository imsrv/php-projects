<?PHP
## This registersthe affilate's username
$referer = $_GET['aff'];
session_start();

session_register('referer');
setcookie('referer', $referer, time()+60*60*24*365,'', '', '0');

## This gets the referrer's name from the href address



?>
 <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>Untitled</title>
</head>
<body>


</body>
</htmL>
