<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("library/config/config.php");
include ("library/js.php");

$dbconnect = mysql_connect ($dbhost, $dbuser, $dbpass);
mysql_select_db ($dbname, $dbconnect);

$sql0 = "SELECT * FROM `$dbtable3` WHERE `user_name` = '$dbusers_user_name'"; 
$query0 = mysql_query ($sql0, $dbconnect);
$array0 = mysql_fetch_array ($query0);

$sql2 = "SELECT * FROM `$dbtable1` LIMIT 0, 30"; 
$query2 = mysql_query ($sql2, $dbconnect);
$array2 = mysql_fetch_array ($query2);

$sql4 = "SELECT * FROM `$dbtable2` WHERE `theme_name` = '".$array2[theme]."' LIMIT 0, 30"; 
$query4 = mysql_query ($sql4, $dbconnect);
$array4 = mysql_fetch_array ($query4);

include ("themes/".$array4[theme_directory]."/library/css.php");
include ("library/languages/".$array2[language].".php");

if ($array2[site_public] == "true") {
	$menu = "<a href=\"categories.php\">$link_index</a> | <a href=\"search.php\">$link_search</a> | <a href=\"sign_up.php\">$link_sign_up</a> | <a href=\"index.php\">$link_login</a>";
	}

$image = getimagesize ($file);

if ($array2[register_locked] == "true") {
	if (($array2[register_locked] == "true") && (!empty ($array2[register_locked_reason]))) {
		$info_register_locked_reason_output = "<font color=\"#FF0000\">".$array2[register_locked_reason]."</font>";
		$info_register_locked_reason_output = nl2br ($info_register_locked_reason_output);
		}
	else {
		$info_register_locked_reason_output = "$info_register_locked_reason";
		}
	$info_register_locked_output = "$info_register_locked";
	echo "
	<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">
	<html>
	<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">
	<title>".$array2[site_name]."</title>
	$css $js_browser_detection
	</head>
	
	<body onLoad=\"$js_browser_detection_onload\">
	<div align=\"center\">
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td width=\"16\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_left_head_b.gif\">&nbsp;</td>
		  <td align=\"center\" bgcolor=\"".$array4[table_bgcolor1]."\"><span class=\"Stil1\">$info_header1 ".$array2[site_name]." $info_header2</span></td>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_right_head.gif\">&nbsp;</td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr align=\"center\">
		  <td height=\"15\" align=\"center\" bgcolor=\"".$array4[table_bgcolor2]."\"><span class=\"Stil1\"></span></td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td height=\"303\" align=\"center\" valign=\"top\" bgcolor=\"#FFFFFF\"><br><br>
			  $info_register_locked_output$info_register_locked_reason_output<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">
			  <table width=\"100%\"  border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
				<tr>
			  </table>
		  </td></tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr align=\"center\">
		  <td height=\"15\" align=\"center\" bgcolor=\"".$array4[table_bgcolor2]."\"><strong><span class=\"Stil2\"></span></strong></td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_left_foot_b.gif\">&nbsp;</td>
		  <td bgcolor=\"".$array4[table_bgcolor1]."\">&nbsp;</td>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_right_foot.gif\">&nbsp;</td>
		</tr>
	  </table>
	  <p>".$array2[company_footer]."</p>
	</div>
	</body>
	</html>";
	die();
	}

$new_user_group = $array2[new_user_group];

$user_activation_key = "";
$length = 20;
$string = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
mt_srand ((double) microtime() * 1000000);
for ($i = 1; $i <= $length; $i++) {
	$user_activation_key .= substr ($string, mt_rand (0, strlen ($string)-1), 1);
	}

$user_register_date = date ("d.m.Y - H:i:s");

if ($email_public == "public") {
	$email_public = "true";
	}
else {
	$email_public = "false";
	}

$xtra .= "From: ".$array2[site_name]." <".$array2[admin_email].">\n";
$xtra .= "Content-Type: text/html\nContent-Transfer-Encoding: 8bit\n";
$xtra .= "X-Mailer: PHP ".phpversion()."\n";

$mail_content = "
$css
<img src=\"".$array2[site_url]."/themes/".$array4[theme_directory]."/images/".$array4[logo]."\"><p>
<span class=\"Stil2\">$activation_email_content1 $dbusers_user_name,<p>$activation_email_content2 <a href=\"".$array2[site_url]."\" target=\"_blank\"><strong>".$array2[site_name]."</strong></a>. $activation_email_content3<p><a href=\"".$array2[site_url]."/user_activation.php?user_name=$dbusers_user_name&user_email=$dbusers_user_email&activation_key=$user_activation_key\" target=\"_blank\"><strong>$link_activation</strong></a><p><br>$mail_footer<br><strong><a href=\"".$array2[site_url]."\" target=\"_blank\">".$array2[site_name]."</a><br><a href=\"mailto:".$array2[site_name]." %3C".$array2[admin_email]."%3E\">".$array2[admin_email]."</strong></span></a>
";

if ((empty ($dbusers_user_name)) || (empty ($dbusers_password)) || (empty ($dbusers_password_rep)) || (empty ($dbusers_user_email))) {
	$info_user_profile_output = "$info_su_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif ($array0[user_name] == $dbusers_user_name) {
	$info_user_profile_output = "$info_user_exists<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif (!empty ($file)) {
	if ($file_size > 102400) {
		$info_user_profile_output = "$info_user_image_error1<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	elseif ($file_type !== "image/pjpeg") {
		$info_user_profile_output = "$info_user_image_error2<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	elseif (($image[0] > 190) || ($image[1] > 220)) {
		$info_user_profile_output = "$info_user_image_error3<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	else {
		if ($dbusers_password !== $dbusers_password_rep) {
			$info_user_profile_output = "$info_pw_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
			}
		else {
			$sql = "INSERT INTO `$dbtable3` (`user_name`, `user_password`, `user_email`, `user_website`, `user_firstname`, `user_lastname`, `user_birthday`, `user_gender`, `user_country`, `user_state`, `user_zipcode`, `user_city`, `user_street`, `user_phone`, `user_fax`, `user_mobile`, `user_group`, `email_public`, `user_image`, `user_register_date`, `last_remote_address`, `last_user_agent`, `activation_key`, `activated`, `locked`) VALUES ('$dbusers_user_name', MD5('$dbusers_password'), '$dbusers_user_email', '$dbusers_user_website', '$dbusers_user_firstname', '$dbusers_user_lastname', '$dbusers_user_birthday', '$dbusers_user_gender', '$dbusers_user_country', '$dbusers_user_state', '$dbusers_user_zipcode', '$dbusers_user_city', '$dbusers_user_street', '$dbusers_user_phone', '$dbusers_user_fax', '$dbusers_user_mobile', '$new_user_group', '$email_public', 'true', '$user_register_date', '".$_SERVER['REMOTE_ADDR']."', '".$_SERVER['HTTP_USER_AGENT']."', '$user_activation_key', 'false', 'false')"; 
			mysql_query ($sql, $dbconnect);
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_name` = '$dbusers_user_name' LIMIT 1"; 
			$query3 = mysql_query ($sql3, $dbconnect);
			$array3 = mysql_fetch_array ($query3);
			if (@!copy ($file, "images/users/".$array3[id].".jpg")) {
				$info_user_profile_output = "$info_upload_error1<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
				}
			mail ($dbusers_user_email, "".$activation_email_subject." ".$array2[site_name]."", $mail_content, $xtra);
			if ($array2[new_user_report] == "true") {
				$xtra_report .= "From: ".$array2[site_name]." <".$array2[admin_email].">\n";
				$xtra_report .= "Content-Type: text/html\nContent-Transfer-Encoding: 8bit\n";
				$xtra_report .= "X-Mailer: PHP ".phpversion()."\n";
				if ($array3[user_group] == "1") {
					$user_group = wordwrap ($select_desc_admin, 70, "<br>", 1);
					}
				elseif ($array3[user_group] == "2") {
					$user_group = wordwrap ($select_desc_downloader, 70, "<br>", 1);
					}
				elseif ($array3[user_group] == "3") {
					$user_group = wordwrap ($select_desc_downloader_uploader, 70, "<br>", 1);
					}
				elseif ($array3[user_group] == "4") {
					$user_group = wordwrap ($select_desc_uploader, 70, "<br>", 1);
					}
				elseif ($array3[user_group] == "5") {
					$user_group = wordwrap ($select_desc_user, 70, "<br>", 1);
					}
				if ($array3[user_gender] == "1") {
					$user_gender_output = wordwrap ($select_desc_gender_male, 70, "<br>", 1);
					}
				elseif ($array3[user_gender] == "2") {
					$user_gender_output = wordwrap ($select_desc_gender_female, 70, "<br>", 1);
					}
				else {
					$user_gender_output = wordwrap ($no_data, 70, "<br>", 1);
					}
				$user_name = "<a href=\"".$array2[site_url]."/user_profile.php?id=".$array3[id]."\" target=\"_blank\"><font color=\"#0000FF\">".wordwrap ($array3[user_name], 70, "<br>", 1)."</font></a>";
				if (!empty ($array3[user_firstname])) {
					$user_firstname = wordwrap ($array3[user_firstname], 70, "<br>", 1);
					}
				else {
					$user_firstname = "$no_data";
					}
				if (!empty ($array3[user_lastname])) {
					$user_lastname = wordwrap ($array3[user_lastname], 70, "<br>", 1);
					}
				else {
					$user_lastname = "$no_data";
					}
				$user_email = "<a href=\"mailto:".$array3[user_email]."\"><font color=\"#0000FF\">".wordwrap ($array3[user_email], 70, "<br>", 1)."</font></a>";
				if (!empty ($array3[user_website])) {
					$user_website = "<a href=\"".$array3[user_website]."\" target=\"_blank\"><font color=\"#0000FF\">".wordwrap ($array3[user_website], 70, "<br>", 1)."</font></a>";
					}
				else {
					$user_website = "$no_data";
					}
				if (!empty ($array3[user_birthday])) {
					$user_birthday = wordwrap ($array3[user_birthday], 70, "<br>", 1);
					}
				else {
					$user_birthday = "$no_data";
					}
				if (!empty ($array3[user_street])) {
					$user_street = wordwrap ($array3[user_street], 70, "<br>", 1);
					}
				else {
					$user_street = "$no_data";
					}
				if (!empty ($array3[user_zipcode])) {
					$user_zipcode = wordwrap ($array3[user_zipcode], 70, "<br>", 1);
					}
				else {
					$user_zipcode = "$no_data";
					}
				if (!empty ($array3[user_city])) {
					$user_city = wordwrap ($array3[user_city], 70, "<br>", 1);
					}
				else {
					$user_city = "$no_data";
					}
				if (!empty ($array3[user_state])) {
					$user_state = wordwrap ($array3[user_state], 70, "<br>", 1);
					}
				else {
					$user_state = "$no_data";
					}
				if (!empty ($array3[user_country])) {
					$user_country = wordwrap ($array3[user_country], 70, "<br>", 1);
					}
				else {
					$user_country = "$no_data";
					}
				if (!empty ($array3[user_phone])) {
					$user_phone = wordwrap ($array3[user_phone], 70, "<br>", 1);
					}
				else {
					$user_phone = "$no_data";
					}
				if (!empty ($array3[user_fax])) {
					$user_fax = wordwrap ($array3[user_fax], 70, "<br>", 1);
					}
				else {
					$user_fax = "$no_data";
					}
				if (!empty ($array3[user_mobile])) {
					$user_mobile = wordwrap ($array3[user_mobile], 70, "<br>", 1);
					}
				else {
					$user_mobile = "$no_data";
					}
				$user_register_date = wordwrap ($array3[user_register_date], 70, "<br>", 1);
				$mail_content_report = "
				$css			
				<img src=\"".$array2[site_url]."/themes/".$array4[theme_directory]."/images/".$array4[logo]."\"><p>
				<span class=\"Stil2\">
				$new_user_report_content1,
				<p>$new_user_report_content2 <a href=\"".$array2[site_url]."\" target=\"_blank\"><strong>".$array2[site_name]."</strong></a> $new_user_report_content3</span><p>
				<table width=\"100%\"  border=\"0\" cellspacing=\"1\">
				  <tr bgcolor=\"".$array4[table_bgcolor4]."\">
					<td align=\"center\"><br>
						<table width=\"650\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
						  <tr>
							<td><fieldset>
							  <legend><font color=\"#0046D5\">$field_login</font></legend>
							  <table width=\"100%\"  border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
								<tr bgcolor=\"".$array4[table_bgcolor4]."\" valign=\"top\">
								  <td align=\"left\"><span class=\"Stil3\">$textfield_user_name_desc</span></td>
								  <td width=\"70%\" align=\"left\"><span class=\"Stil3\">$user_name</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_group_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_group</span></td>
								</tr>
							  </table>
							</fieldset></td>
						  </tr>
						</table>
						<br>
						<table width=\"650\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
						  <tr>
							<td><fieldset>
							  <legend><font color=\"#0046D5\">$field_eup_1</font></legend>
							  <table width=\"100%\" border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_firstname_desc</span></td>
								  <td width=\"70%\" bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_firstname</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_lastname_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_lastname</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_email_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><font color=\"#0000FF\">$user_email</font></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_website_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_website</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_birthday_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_birthday</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_gender_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_gender_output</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_street_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_street</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_zipcode_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_zipcode</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_city_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_city</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_state_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_state</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_country_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_country</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_phone_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_phone</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_fax_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_fax</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_mobile_desc</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_mobile</span></td>
								</tr>
							  </table>
							</fieldset></td>
						  </tr>
						</table>
						<br>
						<table width=\"650\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
						  <tr>
							<td><fieldset>
							  <legend><font color=\"#0046D5\">$field_information</font></legend>
							  <table width=\"100%\" border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_register_desc</span></td>
								  <td width=\"70%\" bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_register_date</span></td>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_last_remote_address</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">".wordwrap ($_SERVER['REMOTE_ADDR'], 70, "<br>", 1)."</span> - 
								  	<a href=\"http://www.ripe.net/perl/whois?form_type=simple&full_query_string=&searchtext=".$_SERVER['REMOTE_ADDR']."&do_search=Search\" target=\"_blank\" title=\"$link_desc_user_ripe_ncc: $link_desc_user_whois ".$_SERVER['REMOTE_ADDR']."\"><font color=\"#0000FF\">$link_desc_user_ripe_ncc</font></a> | 
									<a href=\"http://ws.arin.net/cgi-bin/whois.pl?queryinput=".$_SERVER['REMOTE_ADDR']."&do_search=Search\" target=\"_blank\" title=\"$link_desc_user_ripe_ncc: $link_desc_user_whois ".$_SERVER['REMOTE_ADDR']."\"><font color=\"#0000FF\">$link_desc_user_arin</font></a> | 
									<a href=\"http://lacnic.net/cgi-bin/lacnic/whois?query=".$_SERVER['REMOTE_ADDR']."\" target=\"_blank\" title=\"$link_desc_user_ripe_ncc: $link_desc_user_whois ".$_SERVER['REMOTE_ADDR']."\"><font color=\"#0000FF\">$link_desc_user_lapnic</font></a> | 
									<a href=\"http://www.apnic.net/apnic-bin/whois.pl?searchtext=".$_SERVER['REMOTE_ADDR']."\" target=\"_blank\" title=\"$link_desc_user_ripe_ncc: $link_desc_user_whois ".$_SERVER['REMOTE_ADDR']."\"><font color=\"#0000FF\">$link_desc_user_apnic</font></a>
								  </td>
								</tr>
								</tr>
								<tr align=\"left\" valign=\"top\">
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_last_user_agent</span></td>
								  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">".wordwrap ($_SERVER['HTTP_USER_AGENT'], 70, "<br>", 1)."</span></td>
								</tr>
							  </table>
							</fieldset></td>
						  </tr>
						</table>
						<br>
						<table width=\"650\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
						  <tr>
							<td><fieldset>
							  <legend><font color=\"#0046D5\">$field_sf_3</font></legend>
							  <table width=\"100%\" border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
								<tr bgcolor=\"".$array4[table_bgcolor4]."\" valign=\"top\">
								  <td align=\"left\"><span class=\"Stil3\">$field_ue</span></td>
								  <td width=\"70%\" align=\"left\">
								  <span class=\"Stil3\"><a href=\"".$array2[site_url]."/admin_users_edit.php?id=".$array3[id]."\" target=\"_blank\"><font color=\"#0000FF\">".wordwrap ($link_edit, 70, "<br>", 1)."</font></a></span>
								</tr>
							  </table>
							</fieldset></td>
						  </tr>
						</table>
						<br>
					</td>
				  </tr>
				</table>
				<p><br><span class=\"Stil2\">$mail_footer<br><strong><a href=\"".$array2[site_url]."\" target=\"_blank\">".$array2[site_name]."</a><br><a href=\"mailto:".$array2[site_name]." %3C".$array2[admin_email]."%3E\">".$array2[admin_email]."</strong></span></a>
				";
				mail ("".$array2[site_name]." <".$array2[admin_email].">", "".$new_user_report_subject." ".$array2[site_name]."", $mail_content_report, $xtra_report);
				}
			$info_user_profile_output = "$info_sign_up_success<p><input name=\"Login\" type=\"button\" id=\"Login\" onClick=\"window.location.href='index.php'\" value=\"$button_login\">";
			}
		}
	}
else {
	if ($dbusers_password !== $dbusers_password_rep) {
		$info_user_profile_output = "$info_pw_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	else {
		$sql = "INSERT INTO `$dbtable3` (`user_name`, `user_password`, `user_email`, `user_website`, `user_firstname`, `user_lastname`, `user_birthday`, `user_gender`, `user_country`, `user_state`, `user_zipcode`, `user_city`, `user_street`, `user_phone`, `user_fax`, `user_mobile`, `user_group`, `email_public`, `user_image`, `user_register_date`, `last_remote_address`, `last_user_agent`, `activation_key`, `activated`, `locked`) VALUES ('$dbusers_user_name', MD5('$dbusers_password'), '$dbusers_user_email', '$dbusers_user_website', '$dbusers_user_firstname', '$dbusers_user_lastname', '$dbusers_user_birthday', '$dbusers_user_gender', '$dbusers_user_country', '$dbusers_user_state', '$dbusers_user_zipcode', '$dbusers_user_city', '$dbusers_user_street', '$dbusers_user_phone', '$dbusers_user_fax', '$dbusers_user_mobile', '$new_user_group', '$email_public', 'false', '$user_register_date', '".$_SERVER['REMOTE_ADDR']."', '".$_SERVER['HTTP_USER_AGENT']."', '$user_activation_key', 'false', 'false')"; 
		mysql_query ($sql, $dbconnect);
		$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_name` = '$dbusers_user_name' LIMIT 1"; 
		$query3 = mysql_query ($sql3, $dbconnect);
		$array3 = mysql_fetch_array ($query3);
		mail ($dbusers_user_email, "".$activation_email_subject." ".$array2[site_name]."", $mail_content, $xtra);
		if ($array2[new_user_report] == "true") {
			$xtra_report .= "From: ".$array2[site_name]." <".$array2[admin_email].">\n";
			$xtra_report .= "Content-Type: text/html\nContent-Transfer-Encoding: 8bit\n";
			$xtra_report .= "X-Mailer: PHP ".phpversion()."\n";
			if ($array3[user_group] == "1") {
				$user_group = wordwrap ($select_desc_admin, 70, "<br>", 1);
				}
			elseif ($array3[user_group] == "2") {
				$user_group = wordwrap ($select_desc_downloader, 70, "<br>", 1);
				}
			elseif ($array3[user_group] == "3") {
				$user_group = wordwrap ($select_desc_downloader_uploader, 70, "<br>", 1);
				}
			elseif ($array3[user_group] == "4") {
				$user_group = wordwrap ($select_desc_uploader, 70, "<br>", 1);
				}
			elseif ($array3[user_group] == "5") {
				$user_group = wordwrap ($select_desc_user, 70, "<br>", 1);
				}
			if ($array3[user_gender] == "1") {
				$user_gender_output = wordwrap ($select_desc_gender_male, 70, "<br>", 1);
				}
			elseif ($array3[user_gender] == "2") {
				$user_gender_output = wordwrap ($select_desc_gender_female, 70, "<br>", 1);
				}
			else {
				$user_gender_output = wordwrap ($no_data, 70, "<br>", 1);
				}
			$user_name = "<a href=\"".$array2[site_url]."/user_profile.php?id=".$array3[id]."\" target=\"_blank\"><font color=\"#0000FF\">".wordwrap ($array3[user_name], 70, "<br>", 1)."</font></a>";
			if (!empty ($array3[user_firstname])) {
				$user_firstname = wordwrap ($array3[user_firstname], 70, "<br>", 1);
				}
			else {
				$user_firstname = "$no_data";
				}
			if (!empty ($array3[user_lastname])) {
				$user_lastname = wordwrap ($array3[user_lastname], 70, "<br>", 1);
				}
			else {
				$user_lastname = "$no_data";
				}
			$user_email = "<a href=\"mailto:".$array3[user_email]."\"><font color=\"#0000FF\">".wordwrap ($array3[user_email], 70, "<br>", 1)."</font></a>";
			if (!empty ($array3[user_website])) {
				$user_website = "<a href=\"".$array3[user_website]."\" target=\"_blank\"><font color=\"#0000FF\">".wordwrap ($array3[user_website], 70, "<br>", 1)."</font></a>";
				}
			else {
				$user_website = "$no_data";
				}
			if (!empty ($array3[user_birthday])) {
				$user_birthday = wordwrap ($array3[user_birthday], 70, "<br>", 1);
				}
			else {
				$user_birthday = "$no_data";
				}
			if (!empty ($array3[user_street])) {
				$user_street = wordwrap ($array3[user_street], 70, "<br>", 1);
				}
			else {
				$user_street = "$no_data";
				}
			if (!empty ($array3[user_zipcode])) {
				$user_zipcode = wordwrap ($array3[user_zipcode], 70, "<br>", 1);
				}
			else {
				$user_zipcode = "$no_data";
				}
			if (!empty ($array3[user_city])) {
				$user_city = wordwrap ($array3[user_city], 70, "<br>", 1);
				}
			else {
				$user_city = "$no_data";
				}
			if (!empty ($array3[user_state])) {
				$user_state = wordwrap ($array3[user_state], 70, "<br>", 1);
				}
			else {
				$user_state = "$no_data";
				}
			if (!empty ($array3[user_country])) {
				$user_country = wordwrap ($array3[user_country], 70, "<br>", 1);
				}
			else {
				$user_country = "$no_data";
				}
			if (!empty ($array3[user_phone])) {
				$user_phone = wordwrap ($array3[user_phone], 70, "<br>", 1);
				}
			else {
				$user_phone = "$no_data";
				}
			if (!empty ($array3[user_fax])) {
				$user_fax = wordwrap ($array3[user_fax], 70, "<br>", 1);
				}
			else {
				$user_fax = "$no_data";
				}
			if (!empty ($array3[user_mobile])) {
				$user_mobile = wordwrap ($array3[user_mobile], 70, "<br>", 1);
				}
			else {
				$user_mobile = "$no_data";
				}
			$user_register_date = wordwrap ($array3[user_register_date], 70, "<br>", 1);
			$mail_content_report = "
			$css			
			<img src=\"".$array2[site_url]."/themes/".$array4[theme_directory]."/images/".$array4[logo]."\"><p>
			<span class=\"Stil2\">
			$new_user_report_content1,
			<p>$new_user_report_content2 <a href=\"".$array2[site_url]."\" target=\"_blank\"><strong>".$array2[site_name]."</strong></a> $new_user_report_content3</span><p>
			<table width=\"100%\"  border=\"0\" cellspacing=\"1\">
			  <tr bgcolor=\"".$array4[table_bgcolor4]."\">
				<td align=\"center\"><br>
					<table width=\"650\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
					  <tr>
						<td><fieldset>
						  <legend><font color=\"#0046D5\">$field_login</font></legend>
						  <table width=\"100%\"  border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
							<tr bgcolor=\"".$array4[table_bgcolor4]."\" valign=\"top\">
							  <td align=\"left\"><span class=\"Stil3\">$textfield_user_name_desc</span></td>
							  <td width=\"70%\" align=\"left\"><span class=\"Stil3\">$user_name</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_group_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_group</span></td>
							</tr>
						  </table>
						</fieldset></td>
					  </tr>
					</table>
					<br>
					<table width=\"650\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
					  <tr>
						<td><fieldset>
						  <legend><font color=\"#0046D5\">$field_eup_1</font></legend>
						  <table width=\"100%\" border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_firstname_desc</span></td>
							  <td width=\"70%\" bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_firstname</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_lastname_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_lastname</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_email_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><font color=\"#0000FF\">$user_email</font></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_website_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_website</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_birthday_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_birthday</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_gender_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_gender_output</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_street_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_street</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_zipcode_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_zipcode</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_city_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_city</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_state_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_state</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_country_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_country</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_phone_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_phone</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_fax_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_fax</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_mobile_desc</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_mobile</span></td>
							</tr>
						  </table>
						</fieldset></td>
					  </tr>
					</table>
					<br>
					<table width=\"650\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
					  <tr>
						<td><fieldset>
						  <legend><font color=\"#0046D5\">$field_information</font></legend>
						  <table width=\"100%\" border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_register_desc</span></td>
							  <td width=\"70%\" bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$user_register_date</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_last_remote_address</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">".wordwrap ($_SERVER['REMOTE_ADDR'], 70, "<br>", 1)."</span> - 
								<a href=\"http://www.ripe.net/perl/whois?form_type=simple&full_query_string=&searchtext=".$_SERVER['REMOTE_ADDR']."&do_search=Search\" target=\"_blank\" title=\"$link_desc_user_ripe_ncc: $link_desc_user_whois ".$_SERVER['REMOTE_ADDR']."\"><font color=\"#0000FF\">$link_desc_user_ripe_ncc</font></a> | 
								<a href=\"http://ws.arin.net/cgi-bin/whois.pl?queryinput=".$_SERVER['REMOTE_ADDR']."&do_search=Search\" target=\"_blank\" title=\"$link_desc_user_ripe_ncc: $link_desc_user_whois ".$_SERVER['REMOTE_ADDR']."\"><font color=\"#0000FF\">$link_desc_user_arin</font></a> | 
								<a href=\"http://lacnic.net/cgi-bin/lacnic/whois?query=".$_SERVER['REMOTE_ADDR']."\" target=\"_blank\" title=\"$link_desc_user_ripe_ncc: $link_desc_user_whois ".$_SERVER['REMOTE_ADDR']."\"><font color=\"#0000FF\">$link_desc_user_lapnic</font></a> | 
								<a href=\"http://www.apnic.net/apnic-bin/whois.pl?searchtext=".$_SERVER['REMOTE_ADDR']."\" target=\"_blank\" title=\"$link_desc_user_ripe_ncc: $link_desc_user_whois ".$_SERVER['REMOTE_ADDR']."\"><font color=\"#0000FF\">$link_desc_user_apnic</font></a>							  
							  </td>
							</tr>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_user_last_user_agent</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">".wordwrap ($_SERVER['HTTP_USER_AGENT'], 70, "<br>", 1)."</span></td>
							</tr>
						  </table>
						</fieldset></td>
					  </tr>
					</table>
					<br>
					<table width=\"650\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
					  <tr>
						<td><fieldset>
						  <legend><font color=\"#0046D5\">$field_sf_3</font></legend>
						  <table width=\"100%\"  border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
							<tr bgcolor=\"".$array4[table_bgcolor4]."\" valign=\"top\">
							  <td align=\"left\"><span class=\"Stil3\">$field_ue</span></td>
							  <td width=\"70%\" align=\"left\">
							  <span class=\"Stil3\"><a href=\"".$array2[site_url]."/admin_users_edit.php?id=".$array3[id]."\" target=\"_blank\"><font color=\"#0000FF\">".wordwrap ($link_edit, 70, "<br>", 1)."</font></a></span>
							</tr>
						  </table>
						</fieldset></td>
					  </tr>
					</table>
					<br>
				</td>
			  </tr>
			</table>
			<p><br><span class=\"Stil2\">$mail_footer<br><strong><a href=\"".$array2[site_url]."\" target=\"_blank\">".$array2[site_name]."</a><br><a href=\"mailto:".$array2[site_name]." %3C".$array2[admin_email]."%3E\">".$array2[admin_email]."</strong></span></a>
			";
			mail ("".$array2[site_name]." <".$array2[admin_email].">", "".$new_user_report_subject." ".$array2[site_name]."", $mail_content_report, $xtra_report);
			}
		$info_user_profile_output = "$info_sign_up_success<p><input name=\"Login\" type=\"button\" id=\"Login\" onClick=\"window.location.href='index.php'\" value=\"$button_login\">";
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span><span class="Stil1"></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" align="center" valign="top" bgcolor="#FFFFFF"><br>
        <br>
          <?php echo $info_user_profile_output ?>
      </td></tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
