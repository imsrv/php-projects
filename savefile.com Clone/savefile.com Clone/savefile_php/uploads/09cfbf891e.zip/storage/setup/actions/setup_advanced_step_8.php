<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

function vpassthru() 
{ 
global $HTTP_POST_VARS, $HTTP_GET_VARS; 

reset ($HTTP_POST_VARS); 
while (list ($key, $val) = each ($HTTP_POST_VARS)) 
echo "<input type=hidden name='".$key."' value=\"".htmlspecialchars(stripslashes($val))."\">"; 

reset ($HTTP_GET_VARS);
while (list ($key, $val) = each ($HTTP_GET_VARS)) 
echo "<input type=hidden name='".$key."' value=\"".htmlspecialchars(stripslashes($val))."\">"; 
}

include ("../library/config.php");

if (!empty ($language)) {
	include ("../library/languages/actions/$language.php");
	}
else {
	include ("../library/languages/actions/English.php");
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $dbconfig_company_name ?> - Setup</title>
<link href="../library/main.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <p><img src="../images/logo.gif" width="563" height="100"></p>
  <table width="800"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="../images/table_corner_left_head.gif">&nbsp;</td>
      <td width="552" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="210" bgcolor="#BECEE7">&nbsp;</td>
      <td width="19" height="19" background="../images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="800"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="303" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="552" valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
        <tr align="center">
          <td width="5" background="../images/table_corner_left_head2.gif"></td>
          <td bgcolor="#38619E"><span class="Stil1"><?php echo "$dbconfig_company_name - Version $dbconfig_version Setup"; ?></span></td>
        </tr>
      </table>
        <table width="100%"  border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td height="277" align="center" valign="top" background="../images/inner_table_back1.gif" bgcolor="#F1F4FA"><p>&nbsp;</p>
              <table width="95%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="left">
				  <fieldset>
 				<legend><?php echo $field_setup_step_6 ?></legend>
   				<div>
			  <form name="form1" method="post" action="setup_advanced_step_9.php">
                <p><?php echo $info_setup_step_6 ?></p>
                <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="40%"><?php echo $textfield_s6_desc_1 ?>&nbsp;</td>
                    <td width="60%"><input name="dbusers_user_street" type="text" id="dbusers_user_street" value="<?php echo $dbusers_user_street ?>" size="40"></td>
                  </tr>
                  <tr>
                    <td width="40%"><?php echo $textfield_s6_desc_2 ?></td>
                    <td width="60%"><input name="dbusers_user_phone" type="text" id="dbusers_user_phone" value="<?php echo $dbusers_user_phone ?>" size="40"></td>
                  </tr>
                  <tr>
                    <td width="40%"><?php echo $textfield_s6_desc_3 ?></td>
                    <td width="60%"><input name="dbusers_user_fax" type="text" id="dbusers_user_fax" value="<?php echo $dbusers_user_fax ?>" size="40"></td>
                  </tr>
                  <tr>
                    <td width="40%"><?php echo $textfield_s6_desc_4 ?></td>
                    <td width="60%"><input name="dbusers_user_mobile" type="text" id="dbusers_user_mobile" value="<?php echo $dbusers_user_mobile ?>" size="40"></td>
                  </tr>
                </table>
                <p>&nbsp;</p>
                <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="70%" align="right"><input name="Back" type="button" id="Back" onClick="javascript:history.back();" value="<?php echo $button_back ?>">                      
                    <input name="Submit" type="submit" value="<?php echo $button_next ?>"></td><td width="7%">&nbsp;</td>
                    <td width="23%"><input name="Cancel" type="button" id="Cancel" onClick="window.location.href='../'" value="<?php echo $button_cancel ?>"></td>
                  </tr>
                </table>
				<?php vpassthru(); ?>
                </form>
				</div>
				</fieldset>
				  </td>
                </tr>
              </table></td>
          </tr>
        </table>
        <table width="100%"  border="0" cellpadding="0" cellspacing="0">
          <tr align="center">
            <td width="5" align="center" background="../images/table_corner_left_foot2.gif"></td>
            <td bgcolor="#F1F4FA">&nbsp;</td>
          </tr>
        </table></td>
      <td width="210" background="../images/table_back.gif" bgcolor="#BECEE7">&nbsp;</td>
      <td width="19" height="303" bgcolor="#BECEE7">&nbsp;</td>
    </tr>
  </table>
  <table width="800"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="../images/table_corner_left_foot.gif">&nbsp;</td>
      <td width="552" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="210" bgcolor="#BECEE7">&nbsp;</td>
      <td width="19" height="19" background="../images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $dbconfig_company_footer ?>&nbsp;</p>
</div>
</body>
</html>
