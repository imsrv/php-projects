<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

function vpassthru() 
{ 
global $HTTP_POST_VARS, $HTTP_GET_VARS; 

reset ($HTTP_POST_VARS); 
while (list ($key, $val) = each ($HTTP_POST_VARS)) 
echo "<input type=hidden name='".$key."' value=\"".htmlspecialchars(stripslashes($val))."\">"; 

reset ($HTTP_GET_VARS);
while (list ($key, $val) = each ($HTTP_GET_VARS)) 
echo "<input type=hidden name='".$key."' value=\"".htmlspecialchars(stripslashes($val))."\">"; 
}

if (!empty ($language)) {
	include ("../library/languages/actions/$language.php");
	}
else {
	include ("../library/languages/actions/English.php");
	}

//Table and Prefix-Names
$set_dbtable_prefix = "storage";
$set_dbtable_sep	= "_";
$set_dbtable1 = "config";
$set_dbtable2 = "themes";
$set_dbtable3 = "users";
$set_dbtable4 = "categories";
$set_dbtable5 = "files";
$set_dbtable6 = "filetypes";

$file = "../../library/config/config.php";

$dbconnect = @mysql_connect ($set_dbhost, $set_dbuser, $set_dbpass);
@mysql_select_db ($set_dbname, $dbconnect);

//Installation - Checks if Database-Connection, File-Open and File-Includes are correct - if not, create Error-Message - if yes, Install
if ((@!mysql_connect ($set_dbhost, $set_dbuser, $set_dbpass)) && (@!fopen ($file, "w+")) && (@!include ("../library/sql.php")) && (@!include ("../library/config.php"))) {
	$info_install_output = "$info_install_error$info_install_error1<br>$info_install_error2<br>$info_install_error3<br>$info_install_error4";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif ((@!mysql_connect ($set_dbhost, $set_dbuser, $set_dbpass)) && (@!fopen ($file, "w+")) && (@!include ("../library/sql.php"))) {
	$info_install_output = "$info_install_error$info_install_error1<br>$info_install_error2<br>$info_install_error3";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif ((@!mysql_connect ($set_dbhost, $set_dbuser, $set_dbpass)) && (@!fopen ($file, "w+")) && (@!include ("../library/config.php"))) {
	$info_install_output = "$info_install_error$info_install_error1<br>$info_install_error2<br>$info_install_error4";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif ((@!mysql_connect ($set_dbhost, $set_dbuser, $set_dbpass)) && (@!include ("../library/sql.php")) && (@!include ("../library/config.php"))) {
	$info_install_output = "$info_install_error$info_install_error1<br>$info_install_error3<br>$info_install_error4";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif ((@!fopen ($file, "w+")) && (@!include ("../library/sql.php")) && (@!include ("../library/config.php"))) {
	$info_install_output = "$info_install_error$info_install_error2<br>$info_install_error3<br>$info_install_error4";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif ((@!mysql_connect ($set_dbhost, $set_dbuser, $set_dbpass)) && (@!fopen ($file, "w+"))) {
	$info_install_output = "$info_install_error$info_install_error1<br>$info_install_error2";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif ((@!mysql_connect ($set_dbhost, $set_dbuser, $set_dbpass)) && (@!include ("../library/sql.php"))) {
	$info_install_output = "$info_install_error$info_install_error1<br>$info_install_error3";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif ((@!mysql_connect ($set_dbhost, $set_dbuser, $set_dbpass)) && (@!include ("../library/config.php"))) {
	$info_install_output = "$info_install_error$info_install_error1<br>$info_install_error4";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif ((@!fopen ($file, "w+")) && (@!include ("../library/sql.php"))) {
	$info_install_output = "$info_install_error$info_install_error2<br>$info_install_error3";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif ((@!fopen ($file, "w+")) && (@!include ("../library/config.php"))) {
	$info_install_output = "$info_install_error$info_install_error2<br>$info_install_error4";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif ((@!include ("../library/sql.php")) && (@!include ("../library/config.php"))) {
	$info_install_output = "$info_install_error$info_install_error3<br>$info_install_error4";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif (@!mysql_connect ($set_dbhost, $set_dbuser, $set_dbpass)) {
	$info_install_output = "$info_install_error$info_install_error1";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif (@!fopen ($file, "w+")) {
	$info_install_output = "$info_install_error$info_install_error2";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif (@!include ("../library/sql.php")) {
	$info_install_output = "$info_install_error$info_install_error3";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif (@!include ("../library/config.php")) {
	$info_install_output = "$info_install_error$info_install_error4";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
elseif (@!mkdir ("../../files/temp", 0777)) {
	$info_install_output = "$info_install_error$info_install_error5";
	$button_output_1 = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	$button_output_2 = "<input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\">";
	}
else {
	$dbconnect = @mysql_connect ($set_dbhost, $set_dbuser, $set_dbpass);
	include ("../library/sql.php");
	include ("../library/config.php");
	foreach ($sql as $query) {
		if (preg_match ('/^CREATE TABLE `([^`]+)`/', $query, $match)) {
			mysql_query ('DROP TABLE IF EXISTS `'.$match[1].'`');
			}
		mysql_query ($query);
		}
	mysql_close ($dbconnect);
	$resource = @fopen ($file, "w+");
	fopen ($file, "w+");
	fwrite ($resource, $content);
	fclose ($resource);
	$info_install_output = "$info_install_success";
	$button_output_2 = "<input name=\"Start\" type=\"button\" id=\"Start\" onClick=\"window.location.href='../../'\" value=\"$button_start\">";
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $dbconfig_company_name ?> - Setup</title>
<link href="../library/main.css" rel="stylesheet" type="text/css">
</head>

<body>
<div align="center">
  <p><img src="../images/logo.gif" width="563" height="100"></p>
  <table width="800"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="../images/table_corner_left_head.gif">&nbsp;</td>
      <td width="552" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="210" bgcolor="#BECEE7">&nbsp;</td>
      <td width="19" height="19" background="../images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="800"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="303" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="552" valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
        <tr align="center">
          <td width="5" background="../images/table_corner_left_head2.gif"></td>
          <td bgcolor="#38619E"><span class="Stil1"><?php echo "$dbconfig_company_name - Version $dbconfig_version Setup"; ?></span></td>
        </tr>
      </table>
        <table width="100%"  border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td height="277" align="center" valign="top" background="../images/inner_table_back1.gif" bgcolor="#F1F4FA"><p>&nbsp;</p>
              <table width="95%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="left">
				  <fieldset>
 				<legend><?php echo $field_install ?></legend>
   				<div>
			  <form name="form1" method="post" action="">
                <p><?php echo $info_install_output ?></p>
                <p>&nbsp;</p>
                <table width="100%"  border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="70%" align="right"><?php echo $button_output_1 ?></td>
                    <td width="7%">&nbsp;</td>
                    <td width="23%"><?php echo $button_output_2 ?></td>
                  </tr>
                </table>
				<?php vpassthru(); ?>
                </form>
				</div>
				</fieldset>
				  </td>
                </tr>
              </table></td>
          </tr>
        </table>
        <table width="100%"  border="0" cellpadding="0" cellspacing="0">
          <tr align="center">
            <td width="5" align="center" background="../images/table_corner_left_foot2.gif"></td>
            <td bgcolor="#F1F4FA">&nbsp;</td>
          </tr>
        </table></td>
      <td width="210" background="../images/table_back.gif" bgcolor="#BECEE7">&nbsp;</td>
      <td width="19" height="303" bgcolor="#BECEE7">&nbsp;</td>
    </tr>
  </table>
  <table width="800"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="../images/table_corner_left_foot.gif">&nbsp;</td>
      <td width="552" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="210" bgcolor="#BECEE7">&nbsp;</td>
      <td width="19" height="19" background="../images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $dbconfig_company_footer ?>&nbsp;</p>
</div>
</body>
</html>
