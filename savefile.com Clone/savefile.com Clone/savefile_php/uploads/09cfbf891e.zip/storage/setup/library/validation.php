<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("../library/config.php");

if (!empty ($language)) {
	include ("../library/languages/actions/$language.php");
	}
else {
	include ("../library/languages/actions/English.php");
	}

$validation_output = "
<div align=\"center\">
  <p><img src=\"../images/logo.gif\" width=\"563\" height=\"100\"></p>
  <table width=\"800\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
    <tr>
      <td width=\"19\" height=\"19\" background=\"../images/table_corner_left_head.gif\">&nbsp;</td>
      <td width=\"552\" bgcolor=\"#FFFFFF\">&nbsp;</td>
      <td width=\"210\" bgcolor=\"#BECEE7\">&nbsp;</td>
      <td width=\"19\" height=\"19\" background=\"../images/table_corner_right_head.gif\">&nbsp;</td>
    </tr>
  </table>
  <table width=\"800\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
    <tr>
      <td width=\"19\" height=\"303\" bgcolor=\"#FFFFFF\">&nbsp;</td>
      <td width=\"552\" valign=\"top\" bgcolor=\"#FFFFFF\"><table width=\"100%\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
        <tr align=\"center\">
          <td width=\"5\" background=\"../images/table_corner_left_head2.gif\"></td>
          <td bgcolor=\"#38619E\"><span class=\"Stil1\">$dbconfig_company_name - Version $dbconfig_version Setup</span></td>
        </tr>
      </table>
        <table width=\"100%\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
          <tr>
            <td height=\"277\" align=\"center\" valign=\"top\" background=\"../images/inner_table_back1.gif\" bgcolor=\"#F1F4FA\"><p>&nbsp;</p>
              <table width=\"95%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
                <tr>
                  <td align=\"left\">
				  <fieldset>
 				<legend>$field_setup_validation</legend>
   				<div>
			  <form name=\"form1\" method=\"post\" action=\"../actions/setup_advanced_step_2.php\">
                <p>$info_setup_validation</p>
                <p>&nbsp;</p>
                <table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
                  <tr>
                    <td width=\"70%\" align=\"right\"><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">                      
                    </td>
                    <td width=\"7%\">&nbsp;</td>
                    <td width=\"23%\"><input name=\"Cancel\" type=\"button\" id=\"Cancel\" onClick=\"window.location.href='../'\" value=\"$button_cancel\"></td>
                  </tr>
                </table>
                </form>
				</div>
				</fieldset>
				  </td>
                </tr>
              </table></td>
          </tr>
        </table>
        <table width=\"100%\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
          <tr align=\"center\">
            <td width=\"5\" align=\"center\" background=\"../images/table_corner_left_foot2.gif\"></td>
            <td bgcolor=\"#F1F4FA\">&nbsp;</td>
          </tr>
        </table></td>
      <td width=\"210\" background=\"../images/table_back.gif\" bgcolor=\"#BECEE7\">&nbsp;</td>
      <td width=\"19\" height=\"303\" bgcolor=\"#BECEE7\">&nbsp;</td>
    </tr>
  </table>
  <table width=\"800\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
    <tr>
      <td width=\"19\" height=\"19\" background=\"../images/table_corner_left_foot.gif\">&nbsp;</td>
      <td width=\"552\" bgcolor=\"#FFFFFF\">&nbsp;</td>
      <td width=\"210\" bgcolor=\"#BECEE7\">&nbsp;</td>
      <td width=\"19\" height=\"19\" background=\"../images/table_corner_right_foot.gif\">&nbsp;</td>
    </tr>
  </table>
  <p>$dbconfig_company_footer</p>
</div>";
	
?>