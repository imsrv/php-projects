<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

//Choose Install-Type
$default  = "<strong>Default Installation</strong> (recommanded)<br>If you won't change the default Values, choose this Option.";
$advanced = "<strong>Advanced Installation</strong><br>For the advanced Installation, choose this Option.";

//Setup Step 1
$info_setup_step_1 	 = "Please fill in the Information of your Database.";
$textfield_s1_desc_1 = "<strong>Database-Hostname</strong>";
$textfield_s1_desc_2 = "<strong>Database-Name</strong>";
$textfield_s1_desc_3 = "<strong>Database-Username</strong>";
$textfield_s1_desc_4 = "<strong>Database-Password</strong>";

//Setup Step 2
$info_setup_step_2	  = "Please fill in the Information of your Site.";
$info_setup_step_2a	  = "Please fill in the Table-Prefix (without Underscore - sets automatically), as well as the rest of the Table-Information.";
$textfield_s2_desc_1  = "<strong>Site-Name</strong>";
$textfield_s2a_desc_1 = "<strong>Table-Prefix</strong>";
$textfield_s2_desc_2  = "<strong>Site-URL</strong>";
$textfield_s2a_desc_2 = "<strong>Table-Name Configuration</strong>";
$textfield_s2_desc_3  = "<strong>Admin-E-Mail</strong>";

//Setup Step 3
$info_setup_step_3	  = "Please fill in your Login-Information.";
$info_setup_step_3a	  = "Please fill in the rest of the Table-Information.";
$textfield_s3_desc_1  = "<strong>Username</strong>";
$textfield_s3a_desc_1 = "<strong>Table-Name Themes</strong>";
$textfield_s3_desc_2  = "<strong>Password</strong>";
$textfield_s3a_desc_2 = "<strong>Table-Name Users</strong>";
$textfield_s3_desc_3  = "<strong>E-Mail</strong>";
$textfield_s3a_desc_3 = "<strong>Table-Name Categories</strong>";
$textfield_s3_desc_4  = "<strong>Website</strong> (optional)";
$textfield_s3a_desc_4 = "<strong>Table-Name Files</strong>";
$textfield_s3a_desc_5 = "<strong>Table-Name Filetypes</strong>";

//Setup Step 4
$info_setup_step_4	  	   = "Please fill in your personal Information.";
$textfield_s4_desc_1  	   = "<strong>Firstname</strong> (optional)";
$textfield_s4_desc_2  	   = "<strong>Lastname</strong> (optional)";
$textfield_s4_desc_3  	   = "<strong>Birthday</strong> (optional)";
$textfield_s4_desc_4  	   = "<strong>Gender</strong> (optional)";
$select_desc_gender_female = "Female";
$select_desc_gender_male   = "Male";

//Setup Step 5
$info_setup_step_5	 = "Please fill in your personal Information.";
$textfield_s5_desc_1 = "<strong>Country</strong> (optional)";
$textfield_s5_desc_2 = "<strong>State</strong> (optional)";
$textfield_s5_desc_3 = "<strong>ZIP-Code</strong> (optional)";
$textfield_s5_desc_4 = "<strong>City</strong> (optional)";

//Setup Step 6
$info_setup_step_6	 = "Please fill in your personal Information.";
$textfield_s6_desc_1 = "<strong>Street</strong> (optional)";
$textfield_s6_desc_2 = "<strong>Phone</strong> (optional)";
$textfield_s6_desc_3 = "<strong>Fax</strong> (optional)";
$textfield_s6_desc_4 = "<strong>Mobile</strong> (optional)";

//Setup Step 7
$info_setup_step_7 = "The Setup-Assistant has collected all neccessary Information and is ready to install.";
$textarea_s7_1	   = "Database-Hostname:";
$textarea_s7_2	   = "Database-Name:";
$textarea_s7_3	   = "Database-Username:";
$textarea_s7_4	   = "Table-Prefix:";
$textarea_s7_5	   = "Table-Name Configuration:";
$textarea_s7_6	   = "Table-Name Themes:";
$textarea_s7_7	   = "Table-Name Users:";
$textarea_s7_8	   = "Table-Name Categories:";
$textarea_s7_9	   = "Table-Name Files:";
$textarea_s7_10    = "Table-Name Filetypes:";
$textarea_s7_11    = "Site-Name:";
$textarea_s7_12    = "Site-URL:";
$textarea_s7_13    = "Admin-E-Mail:";
$textarea_s7_14    = "Username:";
$textarea_s7_15    = "User-E-Mail:";
$textarea_s7_16    = "User-Website:";
$textarea_s7_17    = "Firstname:";
$textarea_s7_18    = "Lastname:";
$textarea_s7_19    = "Birthday:";
$textarea_s7_20    = "Gender:";
$textarea_s7_21    = "Country:";
$textarea_s7_22    = "State:";
$textarea_s7_23    = "ZIP-Code:";
$textarea_s7_24    = "City:";
$textarea_s7_25    = "Street:";
$textarea_s7_26    = "Phone:";
$textarea_s7_27    = "Fax:";
$textarea_s7_28    = "Mobile:";

//Validation
$info_setup_validation = "<font color=\"#FF0000\">One or more required Fields are empty. Please complete your Information.</font>";

//Fields
$field_setup_type       = "Setup-Type";
$field_setup_step_1	    = "Database-Information";
$field_setup_step_2     = "Site-Information";
$field_setup_step_2a    = "Table-Information";
$field_setup_step_3     = "User-Information";
$field_setup_step_3a    = "Table-Information";
$field_setup_step_4     = "Personal-Information";
$field_setup_step_5     = "Personal-Information";
$field_setup_step_6     = "Personal-Information";
$field_setup_step_7     = "Information complete";
$field_install		    = "Installation";
$field_uninstall_step_1 = "Uninstall";
$field_setup_validation = "Validation";

//Install
$info_install_success = "The Setup has been successfully finished. Click on \"Start\" to go to the Login-Site.<p><strong>Attention</strong><br>Don't forget to remove the directory \"Setup\". It is not needed any longer.";
$info_install_error   = "<font color=\"#FF0000\">The Setup has not been finished.<p><strong>Error</strong><br></font>";
$info_install_error1  = "<font color=\"#FF0000\">- Connection to Database failed. Check if the Database-Information are correct.</font>";
$info_install_error2  = "<font color=\"#FF0000\">- Could not create \"config.php\". Check if the directory \"config\" has the neccessary rights to write (777).</font>";
$info_install_error3  = "<font color=\"#FF0000\">- File \"sql.php\" not found.</font>";
$info_install_error4  = "<font color=\"#FF0000\">- File \"config.php\" not found.</font>";
$info_install_error5  = "<font color=\"#FF0000\">- Could not create the directory \"temp\". Check if the directory \"files\" has the neccessary rights to write (777).</font>";

//Buttons
$button_back	  = "< Back ";
$button_next	  = " Next >";
$button_cancel	  = "Cancel";
$button_install	  = " Install ";
$button_uninstall = " Uninstall ";
$button_start	  = " Start ";
$button_close	  = " Close ";

?>