<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

$field_setup     = "Setup";
$welcome_german  = "<strong>Deutsch</strong><br>Willkomen zum Setup von Quasars Storage. Dieser Assistent leitet Sie durch die Installation. Falls Sie bereits eine Installation  durchgef&uuml;hrt haben, k&ouml;nnen Sie das System auch wieder de-installieren. Bitte w&auml;hlen Sie zun&auml;chst Ihre Sprache.<p>";
$welcome_english = "<strong>English</strong><br>Welcome to Quasars Storage Setup. This Guide will help you to setup Quasars Storage. If you have installed it already, you can uninstall the System using this Setup. Please choose your Language.";

?>