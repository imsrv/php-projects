<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

//Choose Install-Type
$default  = "<strong>Standardinstallation</strong> (empfohlen)<br>Wenn Sie die vorgegebenen Standardwerte nicht &auml;ndern m&ouml;chten, w&auml;hlen Sie diese Option.";
$advanced = "<strong>Benutzerdefinierte Installation</strong><br>F&uuml;r eine benutzerdefinierte Installation, w&auml;hlen Sie diese Option.";

//Setup Step 1
$info_setup_step_1	 = "Bitte geben Sie die Datenbankinformationen an.";
$textfield_s1_desc_1 = "<strong>Datenbank-Hostname</strong>";
$textfield_s1_desc_2 = "<strong>Datenbank-Name</strong>";
$textfield_s1_desc_3 = "<strong>Datenbank-Username</strong>";
$textfield_s1_desc_4 = "<strong>Datenbank-Passwort</strong>";

//Setup Step 2
$info_setup_step_2	  = "Bitte geben Sie die Site-Informationen an.";
$info_setup_step_2a	  = "Bitte geben Sie die den Tabellen-Prefix (ohne Unterstrich - wird automatisch gesetzt), sowie die weiteren Tabellen-Informationen an.";
$textfield_s2_desc_1  = "<strong>Site-Name</strong>";
$textfield_s2a_desc_1 = "<strong>Tabellen-Prefix</strong>";
$textfield_s2_desc_2  = "<strong>Site-URL</strong>";
$textfield_s2a_desc_2 = "<strong>Tabellen-Name Konfiguration</strong>";
$textfield_s2_desc_3  = "<strong>Admin-E-Mail</strong>";

//Setup Step 3
$info_setup_step_3	  = "Bitte geben Sie Ihre Anmeldeinformationen an.";
$info_setup_step_3a	  = "Bitte geben Sie die weiteren Tabellen-Informationen an.";
$textfield_s3_desc_1  = "<strong>Benutzername</strong>";
$textfield_s3a_desc_1 = "<strong>Tabellen-Name Themen</strong>";
$textfield_s3_desc_2  = "<strong>Passwort</strong>";
$textfield_s3a_desc_2 = "<strong>Tabellen-Name User</strong>";
$textfield_s3_desc_3  = "<strong>E-Mail</strong>";
$textfield_s3a_desc_3 = "<strong>Tabellen-Name Kategorien</strong>";
$textfield_s3_desc_4  = "<strong>Website</strong> (optional)";
$textfield_s3a_desc_4 = "<strong>Tabellen-Name Dateien</strong>";
$textfield_s3a_desc_5 = "<strong>Tabellen-Name Dateitypen</strong>";

//Setup Step 4
$info_setup_step_4	  	   = "Bitte geben Sie Ihre pers&ouml;nlichen Informationen an.";
$textfield_s4_desc_1  	   = "<strong>Vorname</strong> (optional)";
$textfield_s4_desc_2  	   = "<strong>Nachname</strong> (optional)";
$textfield_s4_desc_3  	   = "<strong>Geburtsdatum</strong> (optional)";
$textfield_s4_desc_4  	   = "<strong>Geschlecht</strong> (optional)";
$select_desc_gender_female = "Weiblich";
$select_desc_gender_male   = "M�nnlich";

//Setup Step 5
$info_setup_step_5	 = "Bitte geben Sie Ihre pers&ouml;nlichen Informationen an.";
$textfield_s5_desc_1 = "<strong>Land</strong> (optional)";
$textfield_s5_desc_2 = "<strong>Bundesland</strong> (optional)";
$textfield_s5_desc_3 = "<strong>Postleitzahl</strong> (optional)";
$textfield_s5_desc_4 = "<strong>Ort</strong> (optional)";

//Setup Step 6
$info_setup_step_6	 = "Bitte geben Sie Ihre pers&ouml;nlichen Informationen an.";
$textfield_s6_desc_1 = "<strong>Strasse</strong> (optional)";
$textfield_s6_desc_2 = "<strong>Telefon</strong> (optional)";
$textfield_s6_desc_3 = "<strong>Fax</strong> (optional)";
$textfield_s6_desc_4 = "<strong>Mobil</strong> (optional)";

//Setup Step 7
$info_setup_step_7 = "Der Setup-Assistent hat alle notwendigen Informationen zusammengetragen und kann nun mit der Installation beginnen.";
$textarea_s7_1	   = "Datenbank-Hostname:";
$textarea_s7_2	   = "Datenbank-Name:";
$textarea_s7_3	   = "Datenbank-Username:";
$textarea_s7_4	   = "Tabellen-Prefix:";
$textarea_s7_5	   = "Tabellen-Name Konfiguration:";
$textarea_s7_6	   = "Tabellen-Name Themen:";
$textarea_s7_7	   = "Tabellen-Name User:";
$textarea_s7_8	   = "Tabellen-Name Kategorien:";
$textarea_s7_9	   = "Tabellen-Name Dateien:";
$textarea_s7_10    = "Tabellen-Name Dateitypen:";
$textarea_s7_11    = "Site-Name:";
$textarea_s7_12    = "Site-URL:";
$textarea_s7_13    = "Admin-E-Mail:";
$textarea_s7_14    = "Benutzername:";
$textarea_s7_15    = "Benutzer-E-Mail:";
$textarea_s7_16    = "Benutzer-Website:";
$textarea_s7_17    = "Vorname:";
$textarea_s7_18    = "Nachname:";
$textarea_s7_19    = "Geburtsdatum:";
$textarea_s7_20    = "Geschlecht:";
$textarea_s7_21    = "Land:";
$textarea_s7_22    = "Bundesland:";
$textarea_s7_23    = "Postleitzahl:";
$textarea_s7_24    = "Ort:";
$textarea_s7_25    = "Strasse:";
$textarea_s7_26    = "Telefon:";
$textarea_s7_27    = "Fax:";
$textarea_s7_28    = "Mobil:";

//Validation
$info_setup_validation = "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";

//Fields
$field_setup_type       = "Setup-Typ";
$field_setup_step_1     = "Datenbank-Informationen";
$field_setup_step_2     = "Site-Informationen";
$field_setup_step_2a    = "Tabellen-Informationen";
$field_setup_step_3     = "Benutzer-Informationen";
$field_setup_step_3a    = "Tabellen-Informationen";
$field_setup_step_4     = "Pers&ouml;nliche-Informationen";
$field_setup_step_5     = "Pers&ouml;nliche-Informationen";
$field_setup_step_6     = "Pers&ouml;nliche-Informationen";
$field_setup_step_7     = "Informationen vollst&auml;ndig";
$field_install		    = "Installation";
$field_uninstall_step_1 = "De-Installation";
$field_setup_validation = "Pr&uuml;fung";

//Install
$info_install_success = "Das Setup wurde erfolgreich abgeschlossen. Klicken Sie auf \"Starten\", um zur Login-Seite zu gelangen.<p><strong>Achtung</strong><br>Denken Sie daran, das Verzeichnis \"Setup\" zu entfernen. Dies wird ab sofort nicht mehr ben&ouml;tigt und stellt ein Sicherheitsrisiko f&uuml;r Ihre Site dar, wenn es nicht gel&ouml;scht wird.";
$info_install_error   = "<font color=\"#FF0000\">Das Setup wurde nicht abgeschlossen.<p><strong>Fehler</strong><br></font>";
$info_install_error1  = "<font color=\"#FF0000\">- Verbindung zur Datenbank fehlgeschlagen. Pr&uuml;fen Sie, ob Sie die Datenbank-Informationen korrekt angegeben haben.</font>";
$info_install_error2  = "<font color=\"#FF0000\">- Datei \"config.php\" konnte nicht angelegt werden. Pr&uuml;fen Sie, ob das Verzeichnis \"config\" die erforderlichen Schreibrechte besitzt (777).</font>";
$info_install_error3  = "<font color=\"#FF0000\">- Datei \"sql.php\" wurde nicht gefunden.</font>";
$info_install_error4  = "<font color=\"#FF0000\">- Datei \"config.php\" wurde nicht gefunden.</font>";
$info_install_error5  = "<font color=\"#FF0000\">- Das Verzeichnis \"temp\" konnte nicht angelegt werden. Pr&uuml;fen Sie, ob das Verzeichnis \"files\" die erforderlichen Schreibrechte besitzt (777).</font>";

//Buttons
$button_back	  = "< Zur&uuml;ck ";
$button_next	  = " Weiter >";
$button_cancel	  = "Abbrechen";
$button_install	  = "Installieren";
$button_uninstall = "De-Installieren";
$button_start	  = "Starten";
$button_close	  = "Schliessen";

?>