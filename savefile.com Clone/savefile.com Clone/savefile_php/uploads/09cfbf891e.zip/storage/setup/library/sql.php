<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

//Inserts for Table config
$dbconfig_theme 	  	    = "Default";
$dbconfig_language 	   	    = "English";
$dbconfig_new_user_group    = "5";	//1 = Admin, 2 = Downloader, 3 = Downloader/Uploader, 4 = Uploader, 5 = User
$dbconfig_limit_file_size   = "";
$dbconfig_site_public		= "false";
$dbconfig_site_locked		= "false";
$dbconfig_register_locked	= "false";
$dbconfig_install_date 	    = date ("d.m.Y - H:i:s");
$dbconfig_new_user_report	= "false";
$dbconfig_new_upload_report = "false";

//Inserts for Table themes - Default Theme
$dbthemes_theme_name		= "Default";
$dbthemes_theme_description = "Default Theme";
$dbthemes_theme_directory	= "Default";
$dbthemes_logo 				= "logo.gif";
$dbthemes_font_family 		= "Verdana, Arial, Helvetica, sans-serif";
$dbthemes_font_size 		= "10px";
$dbthemes_font_color 		= "#38619E";
$dbthemes_link_size 		= "10px";
$dbthemes_link_color 		= "#FFFFFF";
$dbthemes_site_bgcolor  	= "#38619E";
$dbthemes_site_bgimage 	 	= "true";
$dbthemes_number_result	 	= "30";
$dbthemes_table_width 	 	= "95%";
$dbthemes_table_bgcolor1 	= "#BECEE7";
$dbthemes_table_bgcolor2 	= "#517DBF";
$dbthemes_table_bgcolor3 	= "#8EABD7";
$dbthemes_table_bgcolor4 	= "#EDF2FA";
$dbthemes_table_hlcolor1  	= "#BECEE7";
$dbthemes_table_hlcolor2  	= "#BECEE7";
$dbthemes_ie_compatible  	= "false";

//Inserts for Table themes - Silver Theme
$dbthemes_theme_name_2		  = "Silver";
$dbthemes_theme_description_2 = "Silver Theme";
$dbthemes_theme_directory_2	  = "Silver";
$dbthemes_logo_2 			  = "logo.gif";
$dbthemes_font_family_2 	  = "Verdana, Arial, Helvetica, sans-serif";
$dbthemes_font_size_2 		  = "10px";
$dbthemes_font_color_2 		  = "#50617A";
$dbthemes_link_size_2 		  = "10px";
$dbthemes_link_color_2 		  = "#FFFFFF";
$dbthemes_site_bgcolor_2  	  = "#50617A";
$dbthemes_site_bgimage_2 	  = "true";
$dbthemes_number_result_2	  = "30";
$dbthemes_table_width_2 	  = "95%";
$dbthemes_table_bgcolor1_2 	  = "#D3D9E2";
$dbthemes_table_bgcolor2_2 	  = "#8697B0";
$dbthemes_table_bgcolor3_2 	  = "#B7C1D0";
$dbthemes_table_bgcolor4_2	  = "#EAEDF2";
$dbthemes_table_hlcolor1_2    = "#DBE0E8";
$dbthemes_table_hlcolor2_2    = "#DBE0E8";
$dbthemes_ie_compatible_2  	  = "false";

//Inserts for Table users - Admin
$dbusers_user_group 	 = "1";
$dbusers_limit_file_size = "";
$dbusers_email_public	 = "true";
$dbusers_user_image		 = "false";
$dbusers_activated  	 = "true";
$dbusers_locked  		 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name 		  = "exe";
$dbfiletypes_filetype_description = "Executable-File";
$dbfiletypes_filetype_locked 	  = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_2 		= "zip";
$dbfiletypes_filetype_description_2 = "Zip-Compressed-File";
$dbfiletypes_filetype_locked_2 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_3 		= "ace";
$dbfiletypes_filetype_description_3 = "Ace-Archive";
$dbfiletypes_filetype_locked_3 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_4 		= "rar";
$dbfiletypes_filetype_description_4 = "Rar-Archive";
$dbfiletypes_filetype_locked_4 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_5 		= "jpg";
$dbfiletypes_filetype_description_5 = "JPEG-Image";
$dbfiletypes_filetype_locked_5 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_6 		= "gif";
$dbfiletypes_filetype_description_6 = "Graphic Interchange Format";
$dbfiletypes_filetype_locked_6 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_7 		= "bat";
$dbfiletypes_filetype_description_7 = "Batch-File";
$dbfiletypes_filetype_locked_7 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_8 		= "js";
$dbfiletypes_filetype_description_8 = "Javascript-File";
$dbfiletypes_filetype_locked_8 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_9 		= "html";
$dbfiletypes_filetype_description_9 = "HTML-Document";
$dbfiletypes_filetype_locked_9 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_10 		 = "htm";
$dbfiletypes_filetype_description_10 = "HTM-Document";
$dbfiletypes_filetype_locked_10	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_11 		 = "pl";
$dbfiletypes_filetype_description_11 = "Pearl-File";
$dbfiletypes_filetype_locked_11	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_12 		 = "doc";
$dbfiletypes_filetype_description_12 = "Microsoft Word-Document";
$dbfiletypes_filetype_locked_12	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_13 		 = "dot";
$dbfiletypes_filetype_description_13 = "Microsoft Word-Template";
$dbfiletypes_filetype_locked_13	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_14 		 = "xls";
$dbfiletypes_filetype_description_14 = "Microsoft Excel-Document";
$dbfiletypes_filetype_locked_14	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_15 		 = "xlt";
$dbfiletypes_filetype_description_15 = "Microsoft Excel-Template";
$dbfiletypes_filetype_locked_15	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_16 		 = "mdb";
$dbfiletypes_filetype_description_16 = "Microsoft Database-File";
$dbfiletypes_filetype_locked_16	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_17 		 = "mp3";
$dbfiletypes_filetype_description_17 = "MPEG Audio-File";
$dbfiletypes_filetype_locked_17	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_18 		 = "mpeg";
$dbfiletypes_filetype_description_18 = "MPEG Video-File";
$dbfiletypes_filetype_locked_18	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_19 		 = "php";
$dbfiletypes_filetype_description_19 = "PHP Script-File";
$dbfiletypes_filetype_locked_19	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_20 		 = "txt";
$dbfiletypes_filetype_description_20 = "Text-File";
$dbfiletypes_filetype_locked_20	  	 = "false";

//MySQL-Actions

//Create Tables
$sql = array();

$sql[] = 'CREATE TABLE `'.$set_dbtable_prefix.$set_dbtable_sep.$set_dbtable1.'` (
          `id` INT(10) NOT NULL AUTO_INCREMENT,
          `site_name` TEXT NOT NULL,
          `site_url` TEXT NOT NULL,
          `admin_email` TEXT NOT NULL,
          `theme` TEXT NOT NULL,
          `language` TEXT NOT NULL,
          `new_user_group` TEXT NOT NULL,
          `limit_file_size` TEXT NOT NULL,
          `file_size` TEXT NOT NULL,
          `site_public` TEXT NOT NULL,
          `site_locked` TEXT NOT NULL,
          `site_locked_reason` TEXT NOT NULL,
          `register_locked` TEXT NOT NULL,
          `register_locked_reason` TEXT NOT NULL,
          `upload_locked` TEXT NOT NULL,
          `upload_locked_reason` TEXT NOT NULL,
          `download_locked` TEXT NOT NULL,
          `download_locked_reason` TEXT NOT NULL,
          `zip_download_locked` TEXT NOT NULL,
          `zip_download_locked_reason` TEXT NOT NULL,
          `version` TEXT NOT NULL,
          `install_date` TEXT NOT NULL,
          `new_user_report` TEXT NOT NULL,
          `new_upload_report` TEXT NOT NULL,
          `company_name` TEXT NOT NULL,
          `company_footer` TEXT NOT NULL,
          PRIMARY KEY (`id`)
          )';

$sql[] = 'CREATE TABLE `'.$set_dbtable_prefix.$set_dbtable_sep.$set_dbtable2.'` (
          `id` INT(10) NOT NULL AUTO_INCREMENT,
          `theme_name` VARCHAR(30) NOT NULL, 
          `theme_description` TEXT NOT NULL,
          `theme_directory` TEXT NOT NULL,
          `logo` TEXT NOT NULL,
          `site_bgcolor` TEXT NOT NULL,
          `site_bgimage` TEXT NOT NULL,
          `number_result` TEXT NOT NULL,
          `font_family` TEXT NOT NULL,
          `font_size` TEXT NOT NULL,
          `font_color` TEXT NOT NULL,
          `link_size` TEXT NOT NULL,
          `link_color` TEXT NOT NULL,
          `table_width` TEXT NOT NULL,
          `table_bgcolor1` TEXT NOT NULL,
          `table_bgcolor2` TEXT NOT NULL,
          `table_bgcolor3` TEXT NOT NULL,
          `table_bgcolor4` TEXT NOT NULL,
          `table_hlcolor1` TEXT NOT NULL,
          `table_hlcolor2` TEXT NOT NULL,
          `ie_compatible` TEXT NOT NULL,
          PRIMARY KEY (`id`),
		  UNIQUE (`theme_name`)
          )';

$sql[] = 'CREATE TABLE `'.$set_dbtable_prefix.$set_dbtable_sep.$set_dbtable3.'` (
          `id` INT(10) NOT NULL AUTO_INCREMENT,
          `user_name` VARCHAR(30) NOT NULL, 
          `user_password` TEXT NOT NULL,
          `user_password_temp` TEXT NOT NULL,
          `user_password_activation_key` TEXT NOT NULL,
          `user_email` TEXT NOT NULL,
          `user_website` TEXT NOT NULL,
          `user_firstname` TEXT NOT NULL,
          `user_lastname` TEXT NOT NULL,
          `user_birthday` TEXT NOT NULL,
          `user_gender` TEXT NOT NULL,
          `user_country` TEXT NOT NULL,
          `user_state` TEXT NOT NULL,
          `user_zipcode` TEXT NOT NULL,
          `user_city` TEXT NOT NULL,
          `user_street` TEXT NOT NULL,
          `user_phone` TEXT NOT NULL,
          `user_fax` TEXT NOT NULL,
          `user_mobile` TEXT NOT NULL,
          `user_group` TEXT NOT NULL,
          `limit_file_size` TEXT NOT NULL,
          `file_size` TEXT NOT NULL,
          `email_public` TEXT NOT NULL,
          `user_image` TEXT NOT NULL,
          `user_session` TEXT NOT NULL,
          `user_register_date` TEXT NOT NULL,
          `last_login_date` TEXT NOT NULL,
          `last_remote_address` TEXT NOT NULL,
          `last_user_agent` TEXT NOT NULL,
          `activation_key` TEXT NOT NULL,
          `activated` TEXT NOT NULL,
          `locked` TEXT NOT NULL,
          `locked_reason` TEXT NOT NULL,
          PRIMARY KEY (`id`),
		  UNIQUE (`user_name`)
          )';

$sql[] = 'CREATE TABLE `'.$set_dbtable_prefix.$set_dbtable_sep.$set_dbtable4.'` (
          `id` INT(10) NOT NULL AUTO_INCREMENT,
          `category` TEXT NOT NULL,
          `category_description` TEXT NOT NULL,
          `category_id` INT(10) NOT NULL,
          PRIMARY KEY (`id`)
          )';

$sql[] = 'CREATE TABLE `'.$set_dbtable_prefix.$set_dbtable_sep.$set_dbtable5.'` (
          `id` INT(10) NOT NULL AUTO_INCREMENT,
          `file_subject` TEXT NOT NULL,
          `file_description` TEXT NOT NULL,
          `file_name` TEXT NOT NULL,
          `file_size` TEXT NOT NULL,
          `file_extension` TEXT NOT NULL,
          `file_date` TEXT NOT NULL,
          `file_date_edit` TEXT NOT NULL,
          `maincategory` TEXT NOT NULL,
          `subcategory` TEXT NOT NULL,
          `mime_type` TEXT NOT NULL,
          `upload_user_id` TEXT NOT NULL,
          `download_counter` INT(10) DEFAULT \'0\' NOT NULL,
          PRIMARY KEY (`id`)
          )';

$sql[] = 'CREATE TABLE `'.$set_dbtable_prefix.$set_dbtable_sep.$set_dbtable6.'` (
          `id` INT(10) NOT NULL AUTO_INCREMENT,
          `filetype_name` TEXT NOT NULL,
          `filetype_description` TEXT NOT NULL,
          `filetype_locked` TEXT NOT NULL,
          PRIMARY KEY (`id`)
          )';
	  
//Create Table-Inserts
$sql[] = 'INSERT INTO `'.$set_dbtable_prefix.$set_dbtable_sep.$set_dbtable1.'` (
		  `site_name`,
		  `site_url`,
		  `admin_email`,
		  `theme`,
		  `language`,
		  `new_user_group`,
		  `limit_file_size`,
		  `site_public`,
		  `site_locked`,
		  `register_locked`,
		  `version`,
		  `install_date`,
		  `new_user_report`,
		  `new_upload_report`,
		  `company_name`,
		  `company_footer`)
		  VALUES (
		  \''.$dbconfig_site_name.'\',
		  \''.$dbconfig_site_url.'\',
		  \''.$dbconfig_admin_email.'\',
		  \''.$dbconfig_theme.'\',
		  \''.$dbconfig_language.'\',
		  \''.$dbconfig_new_user_group.'\',
		  \''.$dbconfig_limit_file_size.'\',
		  \''.$dbconfig_site_public.'\',
		  \''.$dbconfig_site_locked.'\',
		  \''.$dbconfig_register_locked.'\',
		  \''.$dbconfig_version.'\',
		  \''.$dbconfig_install_date.'\',
		  \''.$dbconfig_new_user_report.'\',
		  \''.$dbconfig_new_upload_report.'\',
		  \''.$dbconfig_company_name.'\',
		  \''.$dbconfig_company_footer.'\'
		  )';

$sql[] = 'INSERT INTO `'.$set_dbtable_prefix.$set_dbtable_sep.$set_dbtable2.'` (
		  `theme_name`,
		  `theme_description`,
		  `theme_directory`,
		  `logo`,
		  `site_bgcolor`,
		  `site_bgimage`,
		  `number_result`,
		  `font_family`,
		  `font_size`,
		  `font_color`,
		  `link_size`,
		  `link_color`,
		  `table_width`,
		  `table_bgcolor1`,
		  `table_bgcolor2`,
		  `table_bgcolor3`,
		  `table_bgcolor4`,
		  `table_hlcolor1`,
		  `table_hlcolor2`,
		  `ie_compatible`)
		  VALUES (
		  \''.$dbthemes_theme_name.'\',
		  \''.$dbthemes_theme_description.'\',
		  \''.$dbthemes_theme_directory.'\',
		  \''.$dbthemes_logo.'\',
		  \''.$dbthemes_site_bgcolor.'\',
		  \''.$dbthemes_site_bgimage.'\',
		  \''.$dbthemes_number_result.'\',
		  \''.$dbthemes_font_family.'\',
		  \''.$dbthemes_font_size.'\',
		  \''.$dbthemes_font_color.'\',
		  \''.$dbthemes_link_size.'\',
		  \''.$dbthemes_link_color.'\',
		  \''.$dbthemes_table_width.'\',
		  \''.$dbthemes_table_bgcolor1.'\',
		  \''.$dbthemes_table_bgcolor2.'\',
		  \''.$dbthemes_table_bgcolor3.'\',
		  \''.$dbthemes_table_bgcolor4.'\',
		  \''.$dbthemes_table_hlcolor1.'\',
		  \''.$dbthemes_table_hlcolor2.'\',
		  \''.$dbthemes_ie_compatible.'\'
		  ), (
		  \''.$dbthemes_theme_name_2.'\',
		  \''.$dbthemes_theme_description_2.'\',
		  \''.$dbthemes_theme_directory_2.'\',
		  \''.$dbthemes_logo_2.'\',
		  \''.$dbthemes_site_bgcolor_2.'\',
		  \''.$dbthemes_site_bgimage_2.'\',
		  \''.$dbthemes_number_result_2.'\',
		  \''.$dbthemes_font_family_2.'\',
		  \''.$dbthemes_font_size_2.'\',
		  \''.$dbthemes_font_color_2.'\',
		  \''.$dbthemes_link_size_2.'\',
		  \''.$dbthemes_link_color_2.'\',
		  \''.$dbthemes_table_width_2.'\',
		  \''.$dbthemes_table_bgcolor1_2.'\',
		  \''.$dbthemes_table_bgcolor2_2.'\',
		  \''.$dbthemes_table_bgcolor3_2.'\',
		  \''.$dbthemes_table_bgcolor4_2.'\',
		  \''.$dbthemes_table_hlcolor1_2.'\',
		  \''.$dbthemes_table_hlcolor2_2.'\',
		  \''.$dbthemes_ie_compatible_2.'\'
		  )';

$sql[] = 'INSERT INTO `'.$set_dbtable_prefix.$set_dbtable_sep.$set_dbtable3.'` (
		  `user_name`,
		  `user_password`,
		  `user_email`,
		  `user_website`,
		  `user_firstname`,
		  `user_lastname`,
		  `user_birthday`,
		  `user_gender`,
		  `user_country`,
		  `user_state`,
		  `user_zipcode`,
		  `user_city`,
		  `user_street`,
		  `user_phone`,
		  `user_fax`,
		  `user_mobile`,
		  `user_group`,
		  `limit_file_size`,
		  `email_public`,
		  `user_image`,
		  `user_register_date`,
		  `activated`,
		  `locked`)
		  VALUES (
		  \''.$dbusers_user_name.'\',
		  MD5(\''.$dbusers_user_password.'\'),
		  \''.$dbusers_user_email.'\',
		  \''.$dbusers_user_website.'\',
		  \''.$dbusers_user_firstname.'\',
		  \''.$dbusers_user_lastname.'\',
		  \''.$dbusers_user_birthday.'\',
		  \''.$dbusers_user_gender.'\',
		  \''.$dbusers_user_country.'\',
		  \''.$dbusers_user_state.'\',
		  \''.$dbusers_user_zipcode.'\',
		  \''.$dbusers_user_city.'\',
		  \''.$dbusers_user_street.'\',
		  \''.$dbusers_user_phone.'\',
		  \''.$dbusers_user_fax.'\',
		  \''.$dbusers_user_mobile.'\',
		  \''.$dbusers_user_group.'\',
		  \''.$dbusers_limit_file_size.'\',
		  \''.$dbusers_email_public.'\',
		  \''.$dbusers_user_image.'\',
		  \''.$dbconfig_install_date.'\',
		  \''.$dbusers_activated.'\',
		  \''.$dbusers_locked.'\'
		  )';

$sql[] = 'INSERT INTO `'.$set_dbtable_prefix.$set_dbtable_sep.$set_dbtable6.'` (
		  `filetype_name`,
		  `filetype_description`,
		  `filetype_locked`)
		  VALUES (
		  \''.$dbfiletypes_filetype_name.'\',
		  \''.$dbfiletypes_filetype_description.'\',
		  \''.$dbfiletypes_filetype_locked.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_2.'\',
		  \''.$dbfiletypes_filetype_description_2.'\',
		  \''.$dbfiletypes_filetype_locked_2.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_3.'\',
		  \''.$dbfiletypes_filetype_description_3.'\',
		  \''.$dbfiletypes_filetype_locked_3.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_4.'\',
		  \''.$dbfiletypes_filetype_description_4.'\',
		  \''.$dbfiletypes_filetype_locked_4.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_5.'\',
		  \''.$dbfiletypes_filetype_description_5.'\',
		  \''.$dbfiletypes_filetype_locked_5.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_6.'\',
		  \''.$dbfiletypes_filetype_description_6.'\',
		  \''.$dbfiletypes_filetype_locked_6.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_7.'\',
		  \''.$dbfiletypes_filetype_description_7.'\',
		  \''.$dbfiletypes_filetype_locked_7.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_8.'\',
		  \''.$dbfiletypes_filetype_description_8.'\',
		  \''.$dbfiletypes_filetype_locked_8.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_9.'\',
		  \''.$dbfiletypes_filetype_description_9.'\',
		  \''.$dbfiletypes_filetype_locked_9.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_10.'\',
		  \''.$dbfiletypes_filetype_description_10.'\',
		  \''.$dbfiletypes_filetype_locked_10.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_11.'\',
		  \''.$dbfiletypes_filetype_description_11.'\',
		  \''.$dbfiletypes_filetype_locked_11.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_12.'\',
		  \''.$dbfiletypes_filetype_description_12.'\',
		  \''.$dbfiletypes_filetype_locked_12.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_13.'\',
		  \''.$dbfiletypes_filetype_description_13.'\',
		  \''.$dbfiletypes_filetype_locked_13.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_14.'\',
		  \''.$dbfiletypes_filetype_description_14.'\',
		  \''.$dbfiletypes_filetype_locked_14.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_15.'\',
		  \''.$dbfiletypes_filetype_description_15.'\',
		  \''.$dbfiletypes_filetype_locked_15.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_16.'\',
		  \''.$dbfiletypes_filetype_description_16.'\',
		  \''.$dbfiletypes_filetype_locked_16.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_17.'\',
		  \''.$dbfiletypes_filetype_description_17.'\',
		  \''.$dbfiletypes_filetype_locked_17.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_18.'\',
		  \''.$dbfiletypes_filetype_description_18.'\',
		  \''.$dbfiletypes_filetype_locked_18.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_19.'\',
		  \''.$dbfiletypes_filetype_description_19.'\',
		  \''.$dbfiletypes_filetype_locked_19.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_20.'\',
		  \''.$dbfiletypes_filetype_description_20.'\',
		  \''.$dbfiletypes_filetype_locked_20.'\'
		  )';

//Content of config.php
$content = "<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

\$dbhost = \"$set_dbhost\"; //Hostname of the MySQL-Server
\$dbname = \"$set_dbname\"; //Database-Name
\$dbuser = \"$set_dbuser\"; //Database-Username
\$dbpass = \"$set_dbpass\"; //Database-Password

\$dbtable_prefix = \"$set_dbtable_prefix\"; //Table-Prefix
\$dbtable1 = \"$set_dbtable_prefix$set_dbtable_sep$set_dbtable1\"; //Table 1
\$dbtable2 = \"$set_dbtable_prefix$set_dbtable_sep$set_dbtable2\"; //Table 2
\$dbtable3 = \"$set_dbtable_prefix$set_dbtable_sep$set_dbtable3\"; //Table 3
\$dbtable4 = \"$set_dbtable_prefix$set_dbtable_sep$set_dbtable4\"; //Table 4
\$dbtable5 = \"$set_dbtable_prefix$set_dbtable_sep$set_dbtable5\"; //Table 5
\$dbtable6 = \"$set_dbtable_prefix$set_dbtable_sep$set_dbtable6\"; //Table 6

?>";

?>