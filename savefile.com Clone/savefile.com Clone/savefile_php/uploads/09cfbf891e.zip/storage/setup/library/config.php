<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

$dbconfig_company_name		= "Quasars Storage";
$dbconfig_version			= "1.1";
$dbconfig_company_footer	= "<font color=\"#FFFFFF\"><a href=\"http://projects.quasars.de/storage\" target=\"_blank\"><strong>$dbconfig_company_name</strong></a> Version $dbconfig_version - &copy; 2005 by <a href=\"http://www.quasars.de\" target=\"_blank\"><strong>Quasars</strong></a></font>";

?>