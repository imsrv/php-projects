<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

//Choose Install-Type
$default  = "<strong>Standaard Installatie</strong> (aanbevolen)<br>Als u de standaardwaarden niet wilt veranderen, kies deze Optie.";
$advanced = "<strong>Geavanceerde Installatie</strong><br>Voor de geavanceerde Installatie, kies deze Optie.";

//Setup Step 1
$info_setup_step_1 	 = "Gelieve de Informatie in te vullen van uw Database.";
$textfield_s1_desc_1 = "<strong>Database-Hostnaam</strong>";
$textfield_s1_desc_2 = "<strong>Database-Naam</strong>";
$textfield_s1_desc_3 = "<strong>Database-Gebruikersnaam</strong>";
$textfield_s1_desc_4 = "<strong>Database-Paswoord</strong>";

//Setup Step 2
$info_setup_step_2	  = "Gelieve de Informatie in te vullen van uw site.";
$info_setup_step_2a	  = "Gelieve de Table-Prefix in te vullen (zonder Onderstreepteken - plaats automatisch), evenals de rest van de Table-Prefix.";
$textfield_s2_desc_1  = "<strong>Site-Naam</strong>";
$textfield_s2a_desc_1 = "<strong>Table-Prefix</strong>";
$textfield_s2_desc_2  = "<strong>Site-URL</strong>";
$textfield_s2a_desc_2 = "<strong>Table-Naam Configuratie</strong>";
$textfield_s2_desc_3  = "<strong>Admin-E-Mail</strong>";

//Setup Step 3
$info_setup_step_3	  = "Gelieve uw login-Informatie in te vullen.";
$info_setup_step_3a	  = "Gelieve de rest van de Table-Informatie in te vullen.";
$textfield_s3_desc_1  = "<strong>Gebruikersnaam</strong>";
$textfield_s3a_desc_1 = "<strong>Table-Naam Themes</strong>";
$textfield_s3_desc_2  = "<strong>Paswoord</strong>";
$textfield_s3a_desc_2 = "<strong>Table-Naam Gebruikers</strong>";
$textfield_s3_desc_3  = "<strong>E-Mail</strong>";
$textfield_s3a_desc_3 = "<strong>Table-Naam Categorie�n</strong>";
$textfield_s3_desc_4  = "<strong>Website</strong> (facultatief)";
$textfield_s3a_desc_4 = "<strong>Table-Naam Bestanden</strong>";
$textfield_s3a_desc_5 = "<strong>Table-Naam Bestandtypes</strong>";

//Setup Step 4
$info_setup_step_4	  	   = "Gelieve uw persoonlijke Informatie in te vullen.";
$textfield_s4_desc_1  	   = "<strong>VoorNaam</strong> (facultatief)";
$textfield_s4_desc_2  	   = "<strong>AchterNaam</strong> (facultatief)";
$textfield_s4_desc_3  	   = "<strong>Verjaardag</strong> (facultatief)";
$textfield_s4_desc_4  	   = "<strong>Geslach</strong> (facultatief)";
$select_desc_gender_female = "Vrouw";
$select_desc_gender_male   = "Man";

//Setup Step 5
$info_setup_step_5	 = "Gelieve uw persoonlijke Informatie in te vullen.";
$textfield_s5_desc_1 = "<strong>Land</strong> (facultatief)";
$textfield_s5_desc_2 = "<strong>Staat</strong> (facultatief)";
$textfield_s5_desc_3 = "<strong>Post-code</strong> (facultatief)";
$textfield_s5_desc_4 = "<strong>Stad</strong> (facultatief)";

//Setup Step 6
$info_setup_step_6	 = "Gelieve uw persoonlijke Informatie in te vullen.";
$textfield_s6_desc_1 = "<strong>Straat</strong> (facultatief)";
$textfield_s6_desc_2 = "<strong>Telefoon</strong> (facultatief)";
$textfield_s6_desc_3 = "<strong>Fax</strong> (facultatief)";
$textfield_s6_desc_4 = "<strong>GSM</strong> (facultatief)";

//Setup Step 7
$info_setup_step_7 = "De Setup-Assistent heeft alle nodige Informatie verzameld en is klaar voor het installeren.";
$textarea_s7_1	   = "Database-Hostnaam:";
$textarea_s7_2	   = "Database-Naam:";
$textarea_s7_3	   = "Database-Gebruikersnaam:";
$textarea_s7_4	   = "Table-Prefix:";
$textarea_s7_5	   = "Table-Naam Configuratie:";
$textarea_s7_6	   = "Table-Naam Themes:";
$textarea_s7_7	   = "Table-Naam Gebruiker:";
$textarea_s7_8	   = "Table-Name Categorie�n:";
$textarea_s7_9	   = "Table-Name Bestanden:";
$textarea_s7_10    = "Table-Name Bestandtypes:";
$textarea_s7_11    = "Site-Naam:";
$textarea_s7_12    = "Site-URL:";
$textarea_s7_13    = "Admin-E-Mail:";
$textarea_s7_14    = "Gebruikersnaam:";
$textarea_s7_15    = "Gebruikers-E-Mail:";
$textarea_s7_16    = "Gebruikers-Website:";
$textarea_s7_17    = "VoorNaam:";
$textarea_s7_18    = "AchterNaam:";
$textarea_s7_19    = "Verjaardag:";
$textarea_s7_20    = "Geslacht:";
$textarea_s7_21    = "Land:";
$textarea_s7_22    = "Staat:";
$textarea_s7_23    = "Post-Code:";
$textarea_s7_24    = "Stad:";
$textarea_s7_25    = "Straat:";
$textarea_s7_26    = "Telefoon:";
$textarea_s7_27    = "Fax:";
$textarea_s7_28    = "GSM:";

//Validation
$info_setup_validation = "<font color=\"#FF0000\">��n of meerdere vereiste Velden zijn leeg. Gelieve uw Informatie te voltooien.</font>";

//Fields
$field_setup_type       = "Setup-Type";
$field_setup_step_1	    = "Database-Informatie";
$field_setup_step_2     = "Site-Informatie";
$field_setup_step_2a    = "Table-Informatie";
$field_setup_step_3     = "Gebruikers-Informatie";
$field_setup_step_3a    = "Table-Informatie";
$field_setup_step_4     = "Persoonlijke-Informatie";
$field_setup_step_5     = "Persoonlijke-Informatie";
$field_setup_step_6     = "Persoonlijke-Informatie";
$field_setup_step_7     = "Informatie compleet";
$field_install		    = "Installatie";
$field_uninstall_step_1 = "Desinstallatie";
$field_setup_validation = "Bevestiging";

//Install
$info_install_success = "De Setup is met succes be�indigd. Klik op \"Start\" om naar de login-Pagina te gaan.<p><strong>Aandacht</strong><br>Vergeet niet om deze directory te verwijderen \"Setup\". Het is niet langer nodig.";
$info_install_error   = "<font color=\"#FF0000\">De Setup is niet be�indigd.<p><strong>Fout</strong><br></font>";
$info_install_error1  = "<font color=\"#FF0000\">- Verbinding met Database ontbroken. Controleer of de Database-Informatie correct is.</font>";
$info_install_error2  = "<font color=\"#FF0000\">- Kan niet aanmaken van \"config.php\". Controleer of de directory \"config\" de rechten van beschrijven heeft (777).</font>";
$info_install_error3  = "<font color=\"#FF0000\">- Bestand \"sql.php\" niet gevonden.</font>";
$info_install_error4  = "<font color=\"#FF0000\">- Bestand \"config.php\" niet gevonden.</font>";
$info_install_error5  = "<font color=\"#FF0000\">- Kan niet aanmaken van directory \"temp\". Controleer of de directory \"files\" de rechten van beschrijven heeft (777).</font>";

//Buttons
$button_back	  = "< Terug ";
$button_next	  = " Volgende >";
$button_cancel	  = "Annuleer";
$button_install	  = " Installeer ";
$button_uninstall = " Desinstallatie ";
$button_start	  = " Start ";
$button_close	  = " Sluit ";

?>