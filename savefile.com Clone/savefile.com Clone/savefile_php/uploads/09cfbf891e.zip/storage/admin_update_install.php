<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");
include ("admin_update_version.php");

admin();

$set_dbtable_sep	= "_";
$dbtable6 = "filetypes";
$company_footer = "<font color=\"#FFFFFF\"><a href=\"http://projects.quasars.de/storage\" target=\"_blank\"><strong>Quasars Storage</strong></a> Version $update_version - &copy; 2005 by <a href=\"http://www.quasars.de\" target=\"_blank\"><strong>Quasars</strong></a></font>";

//Inserts for Table filetypes
$dbfiletypes_filetype_name 		  = "exe";
$dbfiletypes_filetype_description = "Executable-File";
$dbfiletypes_filetype_locked 	  = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_2 		= "zip";
$dbfiletypes_filetype_description_2 = "Zip-Compressed-File";
$dbfiletypes_filetype_locked_2 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_3 		= "ace";
$dbfiletypes_filetype_description_3 = "Ace-Archive";
$dbfiletypes_filetype_locked_3 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_4 		= "rar";
$dbfiletypes_filetype_description_4 = "Rar-Archive";
$dbfiletypes_filetype_locked_4 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_5 		= "jpg";
$dbfiletypes_filetype_description_5 = "JPEG-Image";
$dbfiletypes_filetype_locked_5 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_6 		= "gif";
$dbfiletypes_filetype_description_6 = "Graphic Interchange Format";
$dbfiletypes_filetype_locked_6 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_7 		= "bat";
$dbfiletypes_filetype_description_7 = "Batch-File";
$dbfiletypes_filetype_locked_7 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_8 		= "js";
$dbfiletypes_filetype_description_8 = "Javascript-File";
$dbfiletypes_filetype_locked_8 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_9 		= "html";
$dbfiletypes_filetype_description_9 = "HTML-Document";
$dbfiletypes_filetype_locked_9 	  	= "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_10 		 = "htm";
$dbfiletypes_filetype_description_10 = "HTM-Document";
$dbfiletypes_filetype_locked_10	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_11 		 = "pl";
$dbfiletypes_filetype_description_11 = "Pearl-File";
$dbfiletypes_filetype_locked_11	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_12 		 = "doc";
$dbfiletypes_filetype_description_12 = "Microsoft Word-Document";
$dbfiletypes_filetype_locked_12	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_13 		 = "dot";
$dbfiletypes_filetype_description_13 = "Microsoft Word-Template";
$dbfiletypes_filetype_locked_13	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_14 		 = "xls";
$dbfiletypes_filetype_description_14 = "Microsoft Excel-Document";
$dbfiletypes_filetype_locked_14	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_15 		 = "xlt";
$dbfiletypes_filetype_description_15 = "Microsoft Excel-Template";
$dbfiletypes_filetype_locked_15	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_16 		 = "mdb";
$dbfiletypes_filetype_description_16 = "Microsoft Database-File";
$dbfiletypes_filetype_locked_16	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_17 		 = "mp3";
$dbfiletypes_filetype_description_17 = "MPEG Audio-File";
$dbfiletypes_filetype_locked_17	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_18 		 = "mpeg";
$dbfiletypes_filetype_description_18 = "MPEG Video-File";
$dbfiletypes_filetype_locked_18	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_19 		 = "php";
$dbfiletypes_filetype_description_19 = "PHP Script-File";
$dbfiletypes_filetype_locked_19	  	 = "false";

//Inserts for Table filetypes
$dbfiletypes_filetype_name_20 		 = "txt";
$dbfiletypes_filetype_description_20 = "Text-File";
$dbfiletypes_filetype_locked_20	  	 = "false";

//Create/Update Tables
$sql = array();

$sql[] = 'CREATE TABLE `'.$dbtable_prefix.$set_dbtable_sep.$dbtable6.'` (
          `id` INT(10) NOT NULL AUTO_INCREMENT,
          `filetype_name` TEXT NOT NULL,
          `filetype_description` TEXT NOT NULL,
          `filetype_locked` TEXT NOT NULL,
          PRIMARY KEY (`id`)
          )';

$sql[] = 'INSERT INTO `'.$dbtable_prefix.$set_dbtable_sep.$dbtable6.'` (
		  `filetype_name`,
		  `filetype_description`,
		  `filetype_locked`)
		  VALUES (
		  \''.$dbfiletypes_filetype_name.'\',
		  \''.$dbfiletypes_filetype_description.'\',
		  \''.$dbfiletypes_filetype_locked.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_2.'\',
		  \''.$dbfiletypes_filetype_description_2.'\',
		  \''.$dbfiletypes_filetype_locked_2.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_3.'\',
		  \''.$dbfiletypes_filetype_description_3.'\',
		  \''.$dbfiletypes_filetype_locked_3.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_4.'\',
		  \''.$dbfiletypes_filetype_description_4.'\',
		  \''.$dbfiletypes_filetype_locked_4.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_5.'\',
		  \''.$dbfiletypes_filetype_description_5.'\',
		  \''.$dbfiletypes_filetype_locked_5.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_6.'\',
		  \''.$dbfiletypes_filetype_description_6.'\',
		  \''.$dbfiletypes_filetype_locked_6.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_7.'\',
		  \''.$dbfiletypes_filetype_description_7.'\',
		  \''.$dbfiletypes_filetype_locked_7.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_8.'\',
		  \''.$dbfiletypes_filetype_description_8.'\',
		  \''.$dbfiletypes_filetype_locked_8.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_9.'\',
		  \''.$dbfiletypes_filetype_description_9.'\',
		  \''.$dbfiletypes_filetype_locked_9.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_10.'\',
		  \''.$dbfiletypes_filetype_description_10.'\',
		  \''.$dbfiletypes_filetype_locked_10.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_11.'\',
		  \''.$dbfiletypes_filetype_description_11.'\',
		  \''.$dbfiletypes_filetype_locked_11.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_12.'\',
		  \''.$dbfiletypes_filetype_description_12.'\',
		  \''.$dbfiletypes_filetype_locked_12.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_13.'\',
		  \''.$dbfiletypes_filetype_description_13.'\',
		  \''.$dbfiletypes_filetype_locked_13.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_14.'\',
		  \''.$dbfiletypes_filetype_description_14.'\',
		  \''.$dbfiletypes_filetype_locked_14.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_15.'\',
		  \''.$dbfiletypes_filetype_description_15.'\',
		  \''.$dbfiletypes_filetype_locked_15.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_16.'\',
		  \''.$dbfiletypes_filetype_description_16.'\',
		  \''.$dbfiletypes_filetype_locked_16.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_17.'\',
		  \''.$dbfiletypes_filetype_description_17.'\',
		  \''.$dbfiletypes_filetype_locked_17.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_18.'\',
		  \''.$dbfiletypes_filetype_description_18.'\',
		  \''.$dbfiletypes_filetype_locked_18.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_19.'\',
		  \''.$dbfiletypes_filetype_description_19.'\',
		  \''.$dbfiletypes_filetype_locked_19.'\'
		  ), (
		  \''.$dbfiletypes_filetype_name_20.'\',
		  \''.$dbfiletypes_filetype_description_20.'\',
		  \''.$dbfiletypes_filetype_locked_20.'\'
		  )';

$sql[] = 'ALTER TABLE `'.$dbtable1.'`
		  ADD `zip_download_locked` TEXT NOT NULL AFTER `download_locked_reason`,
		  ADD `zip_download_locked_reason` TEXT NOT NULL AFTER `zip_download_locked`'; 

$sql[] = 'ALTER TABLE `'.$dbtable3.'`
		ADD `last_remote_address` TEXT NOT NULL AFTER `last_login_date`,
		ADD `last_user_agent` TEXT NOT NULL AFTER `last_remote_address`';

$sql[] = 'UPDATE `'.$dbtable1.'` SET
		  `version` = \''.$update_version.'\',
		  `company_footer` = \''.$company_footer.'\' WHERE `id` = 1 LIMIT 1'; 

$content = "<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

\$dbhost = \"$dbhost\"; //Hostname of the MySQL-Server
\$dbname = \"$dbname\"; //Database-Name
\$dbuser = \"$dbuser\"; //Database-Username
\$dbpass = \"$dbpass\"; //Database-Password

\$dbtable_prefix = \"$dbtable_prefix\"; //Table-Prefix
\$dbtable1 = \"$dbtable1\"; //Table 1
\$dbtable2 = \"$dbtable2\"; //Table 2
\$dbtable3 = \"$dbtable3\"; //Table 3
\$dbtable4 = \"$dbtable4\"; //Table 4
\$dbtable5 = \"$dbtable5\"; //Table 5
\$dbtable6 = \"$dbtable_prefix$set_dbtable_sep$dbtable6\"; //Table 6

?>";

$file = "library/config/config.php";

//Update - Checks if Version, Database-Connection and File-Open are correct - if not, create Error-Message - if yes, Update
if (($array2[version] == $update_version) || ($array2[version] > $update_version)) {
	$info_update_output = "$info_no_update";
	$button_output = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif ((@!mysql_connect ($dbhost, $dbuser, $dbpass)) && (@!fopen ($file, "r+"))) {
	$info_update_output = "$info_update_error$info_update_error1<br>$info_update_error2";
	$button_output = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif (@!mysql_connect ($dbhost, $dbuser, $dbpass)) {
	$info_update_output = "$info_update_error$info_update_error1";
	$button_output = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif (@!fopen ($file, "r+")) {
	$info_update_output = "$info_update_error$info_update_error2";
	$button_output = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif (@!mkdir ("files/temp", 0777)) {
	$info_update_output = "$info_update_error$info_update_error3";
	$button_output = "<input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
else {
	foreach ($sql as $query) {
		if (preg_match ('/^CREATE TABLE `([^`]+)`/', $query, $match)) {
			mysql_query ('DROP TABLE IF EXISTS `'.$match[1].'`');
			}
		mysql_query ($query);
		}
	mysql_close ($dbconnect);
	$resource = @fopen ($file, "w+");
	fopen ($file, "w+");
	fwrite ($resource, $content);
	fclose ($resource);
	$info_update_output = "$info_update_success";
	$button_output = "<input name=\"OK\" type=\"button\" id=\"OK\" onClick=\"window.location.href='admin_index.php'\" value=\"$button_ok\">";
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>
        <br>
          <table width="100%"  border="0" cellspacing="1">
            <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
              <td align="center" bgcolor="<?php echo $array4[table_bgcolor4] ?>"><br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                        <legend><?php echo $field_install_update ?></legend>
                        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                          <tr bgcolor="#EDF2FA">
                            <td align="left" bgcolor="<?php echo $array4[table_bgcolor4] ?>"><?php echo $info_update_output ?>
                              <p align="right">&nbsp;<?php echo $button_output ?></p></td></tr>
                        </table>
                      </fieldset></td>
                    </tr>
                  </table>
                <br></td>
            </tr>
            <tr>
              <td align="center">&nbsp;</td>
            </tr>
            <tr>
              <td align="center"><table width="650" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="left">&nbsp;</td>
                  </tr>
              </table></td>
            </tr>
          </table>
        </div>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
