<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

if (empty ($select)) {
	$info_fd_output = "$delete_error<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
else {
	if ($action == "delete") {
		for ($i = 0; $i < count ($select); $i++) {
			$sql3 = "SELECT * FROM `$dbtable5` WHERE `id` = '".$select[$i]."'"; 
			$query3 = mysql_query ($sql3, $dbconnect);
			$array3 = mysql_fetch_array ($query3);
			unlink ("files/".$array3[maincategory]."/".$array3[subcategory]."/".$array3[file_name]."");
			$sql4 = "DELETE FROM `$dbtable5` WHERE `id` = '".$select[$i]."'";
			mysql_query ($sql4, $dbconnect);
			}
		$info_fd_output = "$delete_success";
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>
		<br>
        <?php echo $info_fd_output ?></div>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
