<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

$sql3 = "SELECT * FROM `$dbtable3` WHERE `id` = '$id'";
$query3 = mysql_query ($sql3, $dbconnect);
$array3 = mysql_fetch_array ($query3);

$image = getimagesize ($file);

if ($email_public == "public") {
	$email_public = "true";
	}
else {
	$email_public = "false";
	}

if ($lock_account == "lock") {
	$lock_account = "true";
	}
else {
	$lock_account = "false";
	}

if ($logout_user == "logout") {
	$logout_user = ", `user_session` = ''";
	}

if ($dbusers_file_size == "Byte") {
	$dbusers_limit_file_size = $dbusers_limit_file_size;
	}
elseif ($dbusers_file_size == "KB") {
	$dbusers_limit_file_size = $dbusers_limit_file_size * 1024;
	}
elseif ($dbusers_file_size == "MB") {
	$dbusers_limit_file_size = $dbusers_limit_file_size * 1048576;
	}
elseif ($dbusers_file_size == "GB") {
	$dbusers_limit_file_size = $dbusers_limit_file_size * 1073741824;
	}
elseif ($dbusers_file_size == "TB") {
	$dbusers_limit_file_size = $dbusers_limit_file_size * 1099511627776;
	}
elseif ($dbusers_file_size == "PB") {
	$dbusers_limit_file_size = $dbusers_limit_file_size * 1125899906842624;
	}
elseif ($dbusers_file_size == "EB") {
	$dbusers_limit_file_size = $dbusers_limit_file_size * 1152921504606847000;
	}

if (empty ($dbusers_limit_file_size)) {
	$dbusers_limit_file_size = "";
	$dbusers_file_size = "";
	}

if ((empty ($dbusers_user_name)) || (empty ($dbusers_user_email))) {
	$info_user_profile_output = "$info_upe_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif ($delete_account == "delete") {
	if ($array3[user_image] == "true") {
		unlink ("images/users/".$array3[id].".jpg");
		}
	$sql = "DELETE FROM `$dbtable3` WHERE `id` = '$id'";
	mysql_query ($sql, $dbconnect);
	$info_user_profile_output = "$delete_user_success";
	}
elseif (!empty ($file)) {
	if ($file_size > 102400) {
		$info_user_profile_output = "$info_user_image_error1<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	elseif ($file_type !== "image/pjpeg") {
		$info_user_profile_output = "$info_user_image_error2<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	elseif (($image[0] > 190) || ($image[1] > 220)) {
		$info_user_profile_output = "$info_user_image_error3<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	else {
		if ($dbusers_user_name !== $dbusers_user_name_old) {
			$sql5 = "SELECT * FROM `$dbtable3` WHERE `user_name` = '$dbusers_user_name'"; 
			$query5 = mysql_query ($sql5, $dbconnect);
			$array5 = mysql_fetch_array ($query5);
			}
		if ($array5[user_name] == $dbusers_user_name) {
			$info_user_profile_output = "$info_user_exists";
			}
		else {
			if ((empty ($dbusers_password_ch)) || (empty ($dbusers_password_rep))) {
				if ($array3[user_image] == "true") {
					unlink ("images/users/".$array3[id].".jpg");
					}
				$sql = "UPDATE `$dbtable3` SET `user_name` = '$dbusers_user_name', `user_firstname` = '$dbusers_user_firstname', `user_lastname` = '$dbusers_user_lastname', `user_email` = '$dbusers_user_email', `user_website` = '$dbusers_user_website', `user_birthday` = '$dbusers_user_birthday', `user_gender` = '$dbusers_user_gender', `user_street` = '$dbusers_user_street', `user_zipcode` = '$dbusers_user_zipcode', `user_city` = '$dbusers_user_city', `user_state` = '$dbusers_user_state', `user_country` = '$dbusers_user_country', `user_phone` = '$dbusers_user_phone', `user_fax` = '$dbusers_user_fax', `user_mobile` = '$dbusers_user_mobile', `user_group` = '$dbusers_user_group', `limit_file_size` = '$dbusers_limit_file_size', `file_size` = '$dbusers_file_size', `email_public` = '$email_public', `user_image` = 'true', `locked` = '$lock_account', `locked_reason` = '$dbusers_user_lock_account_reason'$logout_user WHERE `id` = '$id'";
				mysql_query ($sql, $dbconnect);
				if (@!copy ($file, "images/users/".$array3[id].".jpg")) {
					$info_user_profile_output = "$info_upload_error1<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
					}
				$info_user_profile_output = "$info_upload_edit $info_upload";
				}
			elseif ((!empty ($dbusers_password_ch)) || (!empty ($dbusers_password_rep))) {
				if ($dbusers_password_ch !== $dbusers_password_rep) {
					$info_user_profile_output = "$info_pw_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
					}
				else {
					if ($array3[user_image] == "true") {
						unlink ("images/users/".$array3[id].".jpg");
						}
					$sql = "UPDATE `$dbtable3` SET `user_name` = '$dbusers_user_name', `user_password` = MD5('$dbusers_password_ch'), `user_firstname` = '$dbusers_user_firstname', `user_lastname` = '$dbusers_user_lastname', `user_email` = '$dbusers_user_email', `user_website` = '$dbusers_user_website', `user_birthday` = '$dbusers_user_birthday', `user_gender` = '$dbusers_user_gender', `user_street` = '$dbusers_user_street', `user_zipcode` = '$dbusers_user_zipcode', `user_city` = '$dbusers_user_city', `user_state` = '$dbusers_user_state', `user_country` = '$dbusers_user_country', `user_phone` = '$dbusers_user_phone', `user_fax` = '$dbusers_user_fax', `user_mobile` = '$dbusers_user_mobile', `user_group` = '$dbusers_user_group', `limit_file_size` = '$dbusers_limit_file_size', `file_size` = '$dbusers_file_size', `email_public` = '$email_public', `user_image` = 'true', `locked` = '$lock_account', `locked_reason` = '$dbusers_user_lock_account_reason'$logout_user WHERE `id` = '$id'";
					mysql_query ($sql, $dbconnect);
					if (@!copy ($file, "images/users/".$array3[id].".jpg")) {
						$info_user_profile_output = "$info_upload_error1<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
						}
					$info_user_profile_output = "$info_upload_edit $info_upload";
					}
				}
			}
		}
	}
else {
	if ($delete_user_image == "delete") {
		unlink ("images/users/".$array3[id].".jpg");
		$user_image = "false";
		}
	elseif ($array3[user_image] == "true") {
		$user_image = "true";
		}
	else {
		$user_image = "false";
		}
	if ($dbusers_user_name !== $dbusers_user_name_old) {
		$sql5 = "SELECT * FROM `$dbtable3` WHERE `user_name` = '$dbusers_user_name'"; 
		$query5 = mysql_query ($sql5, $dbconnect);
		$array5 = mysql_fetch_array ($query5);
		}
	if ($array5[user_name] == $dbusers_user_name) {
		$info_user_profile_output = "$info_user_exists";
		}
	else {
		if ((empty ($dbusers_password_ch)) || (empty ($dbusers_password_rep))) {
			$sql = "UPDATE `$dbtable3` SET `user_name` = '$dbusers_user_name', `user_firstname` = '$dbusers_user_firstname', `user_lastname` = '$dbusers_user_lastname', `user_email` = '$dbusers_user_email', `user_website` = '$dbusers_user_website', `user_birthday` = '$dbusers_user_birthday', `user_gender` = '$dbusers_user_gender', `user_street` = '$dbusers_user_street', `user_zipcode` = '$dbusers_user_zipcode', `user_city` = '$dbusers_user_city', `user_state` = '$dbusers_user_state', `user_country` = '$dbusers_user_country', `user_phone` = '$dbusers_user_phone', `user_fax` = '$dbusers_user_fax', `user_mobile` = '$dbusers_user_mobile', `user_group` = '$dbusers_user_group', `limit_file_size` = '$dbusers_limit_file_size', `file_size` = '$dbusers_file_size', `email_public` = '$email_public', `user_image` = '$user_image', `locked` = '$lock_account', `locked_reason` = '$dbusers_user_lock_account_reason'$logout_user WHERE `id` = '$id'";
			mysql_query ($sql, $dbconnect);
			$info_user_profile_output = "$info_upload_edit";
			}
		elseif ((!empty ($dbusers_password_ch)) || (!empty ($dbusers_password_rep))) {
			if ($dbusers_password_ch !== $dbusers_password_rep) {
				$info_user_profile_output = "$info_pw_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
				}
			else {
				$sql = "UPDATE `$dbtable3` SET `user_name` = '$dbusers_user_name', `user_password` = MD5('$dbusers_password_ch'), `user_firstname` = '$dbusers_user_firstname', `user_lastname` = '$dbusers_user_lastname', `user_email` = '$dbusers_user_email', `user_website` = '$dbusers_user_website', `user_birthday` = '$dbusers_user_birthday', `user_gender` = '$dbusers_user_gender', `user_street` = '$dbusers_user_street', `user_zipcode` = '$dbusers_user_zipcode', `user_city` = '$dbusers_user_city', `user_state` = '$dbusers_user_state', `user_country` = '$dbusers_user_country', `user_phone` = '$dbusers_user_phone', `user_fax` = '$dbusers_user_fax', `user_mobile` = '$dbusers_user_mobile', `user_group` = '$dbusers_user_group', `limit_file_size` = '$dbusers_limit_file_size', `file_size` = '$dbusers_file_size', `email_public` = '$email_public', `user_image` = '$user_image', `locked` = '$lock_account', `locked_reason` = '$dbusers_user_lock_account_reason'$logout_user WHERE `id` = '$id'";
				mysql_query ($sql, $dbconnect);
				$info_user_profile_output = "$info_upload_edit";
				}
			}
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" align="center" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>
		<br>
            <?php echo $info_user_profile_output ?>
	    </div>
        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
            <tr>
        </table>
      </td></tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
