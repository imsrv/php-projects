<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

$sql0 = "SELECT * FROM `$dbtable3` WHERE `user_name` = '$dbusers_user_name'"; 
$query0 = mysql_query ($sql0, $dbconnect);
$array0 = mysql_fetch_array ($query0);

$image = getimagesize ($file);

$new_user_group = $array2[new_user_group];
$limit_file_size = $array2[limit_file_size];

$user_register_date = date ("d.m.Y - H:i:s");

if ($email_public == "public") {
	$email_public = "true";
	}
else {
	$email_public = "false";
	}
if ($lock_account == "lock") {
	$lock_account = "true";
	}
else {
	$lock_account = "false";
	}

if ($dbusers_file_size == "Byte") {
	$dbusers_limit_file_size = $dbusers_limit_file_size;
	}
elseif ($dbusers_file_size == "KB") {
	$dbusers_limit_file_size = $dbusers_limit_file_size * 1024;
	}
elseif ($dbusers_file_size == "MB") {
	$dbusers_limit_file_size = $dbusers_limit_file_size * 1048576;
	}
elseif ($dbusers_file_size == "GB") {
	$dbusers_limit_file_size = $dbusers_limit_file_size * 1073741824;
	}
elseif ($dbusers_file_size == "TB") {
	$dbusers_limit_file_size = $dbusers_limit_file_size * 1099511627776;
	}
elseif ($dbusers_file_size == "PB") {
	$dbusers_limit_file_size = $dbusers_limit_file_size * 1125899906842624;
	}
elseif ($dbusers_file_size == "EB") {
	$dbusers_limit_file_size = $dbusers_limit_file_size * 1152921504606847000;
	}

if (empty ($dbusers_limit_file_size)) {
	$dbusers_limit_file_size = "";
	$dbusers_file_size = "";
	}

if ((empty ($dbusers_user_name)) || (empty ($dbusers_password)) || (empty ($dbusers_password_rep)) || (empty ($dbusers_user_email))) {
	$info_user_profile_output = "$info_su_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif ($array0[user_name] == $dbusers_user_name) {
	$info_user_profile_output = "$info_user_exists<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif (!empty ($file)) {
	if ($file_size > 102400) {
		$info_user_profile_output = "$info_user_image_error1<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	elseif ($file_type !== "image/pjpeg") {
		$info_user_profile_output = "$info_user_image_error2<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	elseif (($image[0] > 190) || ($image[1] > 220)) {
		$info_user_profile_output = "$info_user_image_error3<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	else {
		if ($dbusers_password !== $dbusers_password_rep) {
			$info_user_profile_output = "$info_pw_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
			}
		else {
			$sql = "INSERT INTO `$dbtable3` (`user_name`, `user_password`, `user_email`, `user_website`, `user_firstname`, `user_lastname`, `user_birthday`, `user_gender`, `user_country`, `user_state`, `user_zipcode`, `user_city`, `user_street`, `user_phone`, `user_fax`, `user_mobile`, `user_group`, `limit_file_size`, `file_size`, `email_public`, `user_image`, `user_register_date`, `activated`, `locked`, `locked_reason`) VALUES ('$dbusers_user_name', MD5('$dbusers_password'), '$dbusers_user_email', '$dbusers_user_website', '$dbusers_user_firstname', '$dbusers_user_lastname', '$dbusers_user_birthday', '$dbusers_user_gender', '$dbusers_user_country', '$dbusers_user_state', '$dbusers_user_zipcode', '$dbusers_user_city', '$dbusers_user_street', '$dbusers_user_phone', '$dbusers_user_fax', '$dbusers_user_mobile', '$dbusers_user_group', '$dbusers_limit_file_size', '$dbusers_file_size', '$email_public', 'true', '$user_register_date', 'true', '$lock_account', '$dbusers_user_lock_account_reason')"; 
			mysql_query ($sql, $dbconnect);
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_name` = '$dbusers_user_name' LIMIT 1"; 
			$query3 = mysql_query ($sql3, $dbconnect);
			$array3 = mysql_fetch_array ($query3);
			if (@!copy ($file, "images/users/".$array3[id].".jpg")) {
				$info_user_profile_output = "$info_upload_error1<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
				}
			$info_user_profile_output = "$info_new_user_success";
			}
		}
	}
else {
	if ($dbusers_password !== $dbusers_password_rep) {
		$info_user_profile_output = "$info_pw_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	else {
		$sql = "INSERT INTO `$dbtable3` (`user_name`, `user_password`, `user_email`, `user_website`, `user_firstname`, `user_lastname`, `user_birthday`, `user_gender`, `user_country`, `user_state`, `user_zipcode`, `user_city`, `user_street`, `user_phone`, `user_fax`, `user_mobile`, `user_group`, `limit_file_size`, `file_size`, `email_public`, `user_image`, `user_register_date`, `activated`, `locked`, `locked_reason`) VALUES ('$dbusers_user_name', MD5('$dbusers_password'), '$dbusers_user_email', '$dbusers_user_website', '$dbusers_user_firstname', '$dbusers_user_lastname', '$dbusers_user_birthday', '$dbusers_user_gender', '$dbusers_user_country', '$dbusers_user_state', '$dbusers_user_zipcode', '$dbusers_user_city', '$dbusers_user_street', '$dbusers_user_phone', '$dbusers_user_fax', '$dbusers_user_mobile', '$dbusers_user_group', '$dbusers_limit_file_size', '$dbusers_file_size', '$email_public', 'false', '$user_register_date', 'true', '$lock_account', '$dbusers_user_lock_account_reason')"; 
		mysql_query ($sql, $dbconnect);
		$info_user_profile_output = "$info_new_user_success";
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" align="center" valign="top" bgcolor="#FFFFFF">
		<div align="center">
		<?php admin_menu(); ?>
		<br>
		<br>
            <?php echo $info_user_profile_output ?>
	    </div>
		<table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
            <tr>
        </table>
      </td></tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
