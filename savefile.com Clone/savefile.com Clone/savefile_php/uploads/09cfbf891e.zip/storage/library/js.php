<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("config/config.php");

$dbconnect = mysql_connect ($dbhost, $dbuser, $dbpass);
mysql_select_db ($dbname, $dbconnect);

$sql_js2 = "SELECT * FROM `$dbtable1` LIMIT 0, 30"; 
$query_js2 = mysql_query ($sql_js2, $dbconnect);
$array_js2 = mysql_fetch_array ($query_js2);

$sql_js4 = "SELECT * FROM `$dbtable2` WHERE `theme_name` = '".$array_js2[theme]."' LIMIT 0, 30"; 
$query_js4 = mysql_query ($sql_js4, $dbconnect);
$array_js4 = mysql_fetch_array ($query_js4);

//Browser-Detection
if ($array_js4[ie_compatible] == "true") {
	$js_browser_detection = "
	<script language=\"JavaScript\" type=\"text/javascript\">
		function browser_detection()
		{
		if(navigator.appName !== \"Microsoft Internet Explorer\")
			{
			window.location=\"browser_info.php\"
			return
			}
		}
	</script>";
	$js_browser_detection_onload = "browser_detection();";
	}

//Upload Progess-Bar
$js_progress_bar = "
<script language=\"JavaScript\" type=\"text/javascript\">
	var w3c=(document.getElementById)?true:false;
	var ie=(document.all)?true:false;
	var N=-1;
	
	function createBar(w,h,bgc,brdW,brdC,blkC,speed,blocks,count,action){
	if(ie||w3c){
	var t='<div id=\"_xpbar'+(++N)+'\" style=\"visibility:visible; position:relative; overflow:hidden; width:'+w+'px; height:'+h+'px; background-color:'+bgc+'; border-color:'+brdC+'; border-width:'+brdW+'px; border-style:solid; font-size:1px;\">';
	t+='<span id=\"blocks'+N+'\" style=\"left:-'+(h*2+1)+'px; position:absolute; font-size:1px\">';
	for(i=0;i<blocks;i++){
	t+='<span style=\"background-color:'+blkC+'; left:-'+((h*i)+i)+'px; font-size:1px; position:absolute; width:'+h+'px; height:'+h+'px; '
	t+=(ie)?'filter:alpha(opacity='+(100-i*(100/blocks))+')':'-Moz-opacity:'+((100-i*(100/blocks))/100);
	t+='\"></span>';
	}
	t+='</span></div>';
	document.write(t);
	var bA=(ie)?document.all['blocks'+N]:document.getElementById('blocks'+N);
	bA.bar=(ie)?document.all['_xpbar'+N]:document.getElementById('_xpbar'+N);
	bA.blocks=blocks;
	bA.N=N;
	bA.w=w;
	bA.h=h;
	bA.speed=speed;
	bA.ctr=0;
	bA.count=count;
	bA.action=action;
	bA.togglePause=togglePause;
	bA.showBar=function(){
	this.bar.style.visibility=\"visible\";
	}
	bA.hideBar=function(){
	this.bar.style.visibility=\"hidden\";
	}
	bA.tid=setInterval('startBar('+N+')',speed);
	return bA;
	}}
	
	function startBar(bn){
	var t=(ie)?document.all['blocks'+bn]:document.getElementById('blocks'+bn);
	if(parseInt(t.style.left)+t.h+1-(t.blocks*t.h+t.blocks)>t.w){
	t.style.left=-(t.h*2+1)+'px';
	t.ctr++;
	if(t.ctr>=t.count){
	eval(t.action);
	t.ctr=0;
	}}else t.style.left=(parseInt(t.style.left)+t.h+1)+'px';
	}
	
	function togglePause(){
	if(this.tid==0){
	this.tid=setInterval('startBar('+this.N+')',this.speed);
	}else{
	clearInterval(this.tid);
	this.tid=0;
	}}
	
	function togglePause(){
	if(this.tid==0){
	this.tid=setInterval('startBar('+this.N+')',this.speed);
	}else{
	clearInterval(this.tid);
	this.tid=0;
	}}
</script>";

$js_progress_bar_output = "
<script language=\"JavaScript\">
	var bar1= createBar(315,12,'#FFFFFF',1,'#38619E','#3553E1',85,7,3,\"\");
</script>";

$js_progress_message = "
<script language=\"JavaScript\" type=\"text/javascript\">
	function showMessage()
	{
	if(document.getElementById)
	document.getElementById(\"invisible\").style.visibility = \"visible\";
	}
</script>";

$js_select_checkbox = "
<script language=\"JavaScript\" type=\"text/javascript\">
	function CheckAll()	{
		var ml = document.results;
		var len = ml.elements.length;
		for (var i = 0; i < len; i++) {
			var e = ml.elements[i];
			if (e.name == \"select[]\") {
				if (e.checked == false) {
					e.checked = true;
					}
				else {
					e.checked = false;
					}				
			}
		}
	}
</script>";

?>