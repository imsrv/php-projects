<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("config/config.php");

function connect() {
	global $dbhost, $dbname, $dbuser, $dbpass;
	$dbconnect = mysql_connect ($dbhost, $dbuser, $dbpass);
	mysql_select_db ($dbname, $dbconnect);
	}

function check_user($name, $pass) {
	global $dbtable3;
    $sql_sn1 = "SELECT id FROM `$dbtable3` WHERE user_name = '".$name."' AND user_password = MD5('".$pass."') LIMIT 1";
    $result_sn1 = mysql_query ($sql_sn1) or die (mysql_error());
    if (mysql_num_rows ($result_sn1)==1) {
        $user = mysql_fetch_assoc ($result_sn1);
        return $user['id'];
    	}
    else
        return false;
	}

function login($userid) {
	global $dbtable3;
	$last_login_date = date ("d.m.Y - H:i:s");
	$sql_sn3 = "UPDATE `$dbtable3` SET user_session = '".session_id()."' WHERE id = ".$userid;
    mysql_query ($sql_sn3);
	$sql_sn2 = "UPDATE `$dbtable3` SET last_login_date = '$last_login_date' WHERE user_session = '".session_id()."'";
    mysql_query ($sql_sn2);
	$sql_sn4 = "UPDATE `$dbtable3` SET last_remote_address = '".$_SERVER['REMOTE_ADDR']."' WHERE user_session = '".session_id()."'";
    mysql_query ($sql_sn4);
	$sql_sn5 = "UPDATE `$dbtable3` SET last_user_agent = '".$_SERVER['HTTP_USER_AGENT']."' WHERE user_session = '".session_id()."'";
    mysql_query ($sql_sn5);
	}

function logged_in() {
	global $dbtable3;
    $sql_sn6 = "SELECT id FROM `$dbtable3` WHERE user_session = '".session_id()."' LIMIT 1";
    $result_sn6 = mysql_query ($sql_sn6);
    return (mysql_num_rows ($result_sn6)==1);
	}

function logout() {
	global $dbhost, $dbname, $dbuser, $dbpass, $dbtable3;
	$dbconnect = mysql_connect ($dbhost, $dbuser, $dbpass);
    $sql_sn7 = "UPDATE `$dbtable3` SET user_session = NULL WHERE user_session = '".session_id()."'";
    mysql_query ($sql_sn7);
	mysql_close ($dbconnect);
	}

connect();

?> 