<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

//Global
$yes = "Ja";
$no	 = "Nee";
$download  = "Download";
$downloads = "Downloads";
$info_browser_detection = "<font color=\"#FF0000\">U gebruikt de verkeerde Browser.<br>Deze site is geoptimaliseerd voor Internet Explorer.</font>";

//Session
$info_login_error1 			 	= "<font color=\"#FF0000\">Fout. Uw login-Informatie is onjuist.<br>Gelieve opnieuw te proberen.</font>";
$info_login_error2 		 	 	= "<font color=\"#FF0000\">Fout. U bent niet ingelogd.<br>Log nu in.</font>";
$info_login_error3			 	= "<font color=\"#FF0000\">Fout. Uw Account is niet geactiveerd.<br>Gelieve uw Account eerst te activeren.</font>";
$info_user_locked  			 	= "<font color=\"#FF0000\">Uw Account is gesloten door de Beheerder.<p><strong>Bericht van de Beheerder:</strong><br></font>";
$info_user_locked_no_reason  	= "<font color=\"#FF0000\">Geen Reden gepost.</font>";
$info_logout	 			 	= "U bent met succes uitgelogd. Als u opnieuw wilt inlogen, klik op \"Login\".";
$info_site_locked  			 	= "<font color=\"#FF0000\">De Site is gesloten door de Beheerder.<p><strong>Bericht van de Beheerder:</strong><br></font>";
$info_site_locked_no_reason	 	= "<font color=\"#FF0000\">Geen Reden gepost.</font>";
$info_register_locked		 	= "<font color=\"#FF0000\">De Registratie is gesloten door de Beheerder.<p><strong>Bericht van de Beheerder:</strong><br></font>";
$info_register_locked_reason 	= "<font color=\"#FF0000\">Geen Reden gepost.</font>";
$info_upload_locked  		 	= "<font color=\"#FF0000\">Het Uploaden is gesloten door de Beheerder.<p><strong>Bericht van de Beheerder:</strong><br></font>";
$info_upload_locked_no_reason 	= "<font color=\"#FF0000\">Geen Reden gepost.</font>";
$info_download_locked  			= "<font color=\"#FF0000\">Het Downloaden is gesloten door de Beheerder.<p><strong>Bericht van de Beheerder:</strong><br></font>";
$info_download_locked_no_reason = "<font color=\"#FF0000\">Geen Reden gepost.</font>";
$info_admin					  	= "<font color=\"#FF0000\">Fout. U hebt geen Toestemming om deze Site te bekijken.</font>";

//Fields
$field_logout 			 = "Uitloggen";
$field_login  			 = "Login";
$field_as_1	  			 = "Configuratie";
$field_as_2	  			 = "Bericht";
$field_as_3	  			 = "Installatie";
$field_adb_1  			 = "Database-Verbinding";
$field_adb_2  			 = "Table-Informatie";
$field_adb_3			 = "Optimaliseer";
$field_at_1	  			 = "Theme-Informatie";
$field_at_2	  			 = "Site-Layout";
$field_at_3	  			 = "Font-instellingen";
$field_at_4	  			 = "Table-Layout";
$field_at_5	  			 = "Compatibel";
$field_at_6	  			 = "Wis";
$field_ti_1	  			 = "Actie";
$field_ts_1	  			 = "Selecteer";
$field_fi_1	  			 = "Actie";
$field_search 			 = "Zoek";
$field_show	  			 = "Toon";
$field_sf_1	  			 = "Download";
$field_sf_2	  			 = "Bestand-informatie";
$field_sf_3	  			 = "Actie";
$field_fe_1	  			 = "Wissen";
$field_eup_1  			 = "Gebruikers-informatie";
$field_user_pic 		 = "Gebruikers-Image";
$field_maincategory 	 = "Cre�er Maincategory";
$field_subcategory  	 = "Cre�er Subcategory";
$field_maincategory_edit = "Aanpassen Maincategory";
$field_subcategory_edit  = "Aanpassen Subcategory";
$field_categories_edit	 = "Aanpassen Category";
$field_receiver			 = "Bericht-ontvanger";
$field_mail_content		 = "Bericht";
$field_options			 = "Opties";
$field_information		 = "Informatie";
$field_lock			 	 = "Sluit";
$field_delete  			 = "Wis";
$field_ue	  			 = "Actie";
$field_install_update	 = "Installeer Update";
$field_ui_1				 = "Actie";
$field_ci_1				 = "Actie";
$field_filetype			 = "Bestands-informatie";
$field_uninstall		 = "Desinstallatie";

//Files, Categories
$description_file_subject 	   = "<strong>Titel</strong>";
$description_file_description  = "<strong>Beschrijving</strong>";
$description_file_name 		   = "<strong>Bestandsnaam</strong>";
$description_file_size 		   = "<strong>Best. grote</strong>";
$description_file_extension	   = "<strong>Bestands type</strong>";
$description_file_date 		   = "<strong>Upload-Datum</strong>";
$description_file_delete	   = "<strong>Wis</strong>";
$description_file_zip_download = "<strong>Zip-Download</strong>";
$description_maincategory	   = "<strong>Maincategory</strong>";
$description_subcategory	   = "<strong>Subcategory</strong>";
$description_description	   = "<strong>Beschrijving</strong>";
$description_downloads		   = "<strong>Downloads</strong>";
$zip_error					   = "<font color=\"#FF0000\">Geen Bestanden zijn geselecteerd.</font>";
$zip_error2	  				   = "<font color=\"#FF0000\">Fout. Het zip-Bestand kon niet worden gecre�erd.<br>De Directory \"temp\" heeft misschien niet de noodzakelijke Rechten om te schrijven (777) of het Bestand is te groot.<br>Contacteer de Beheerder.</font>";
$info_zip_download_locked	   = "<font color=\"#FF0000\">De zip-download-Functie is gesloten door de Beheerder.<p><strong>Bericht van de Beheerder:</strong><br></font>";
$info_zip_locked_no_reason	   = "<font color=\"#FF0000\">Geen Reden gepost.</font>";
$user_id					   = "Gebruikers-ID";

//Categories, Upload-Select, Show File, Upload-Edit, Edit User-Profile
$textfield_us_desc_1  	    = "<strong>Maincategory</strong>";
$textfield_us_desc_2  	    = "<strong>Subcategory</strong>";
$textfield_us_desc_3  	    = "<strong>Titel</strong>";
$textfield_us_desc_4  	    = "<strong>Beschrijving</strong>";
$textfield_us_desc_5  	    = "<strong>verander Bestand</strong>";
$textfield_us_desc_6   	    = "<strong>Huidig Bestand</strong>";
$textfield_us_desc_7  	    = "<strong>Laatste Verandering</strong>";
$textfield_us_desc_8        = "<strong>Upload van Gebruiker</strong>";
$textfield_us_desc_9  	    = "<strong>Bestand</strong>";
$textfield_us_desc_10 	    = "<strong>Selectie</strong>";
$textfield_us_desc_11	    = "<strong>Wis Upload</strong>";
$textfield_us_desc_12	    = "<strong>Toon</strong>";
$textfield_us_dc			= "<strong>Aantal Downloads</strong>";
$info_file_edit			    = "Geen Veranderingen sinds Upload";
$delete_file_success  	    = "Upload is met succes gewist.";
$no_user				    = "De Gebruiker bestaat niet meer";
$new_upload_report_subject  = "Nieuwe Upload op";
$new_upload_report_content1 = "Hallo";
$new_upload_report_content2 = "het bestand is geupload op";
$new_upload_report_content3 = "Zie de Informatie hier onder:";
$info_upload_maincategory	= "Kies een Maincategory, waar u een nieuwe Download wilt tot stand brengen.";
$info_upload_subcategory 	= "Kies een Subcategory, waar u een nieuwe Download wilt tot stand brengen.";
$info_upload_error			= "<font color=\"#FF0000\">Fout. Het Bestand die u wilt uploaden is te groot.<br>De globale upload Grote is</font>";
$info_upload_error_user		= "<font color=\"#FF0000\">Fout. Het Bestand die u wilt uploaden is te groot.<br>De globale upload Grote is</font>";
$info_user_image_error1		= "<font color=\"#FF0000\">Fout. De gebruiker-Foto die u wilt uploaden is te groot.<br>Toelaatbare Grote: 100 KB.</font>";
$info_user_image_error2		= "<font color=\"#FF0000\">Fout. De gebruiker-Foto die u wilt uploaden heeft het verkeerde Formaat.<br>Enkel JPEG toegestaan.</font>";
$info_user_image_error3		= "<font color=\"#FF0000\">Fout. De gebruiker-Foto die u wilt uploaden heeft het verkeerde Formaat.<br>Toelaatbare Data: W: 190 x H: 220.</font>";
$info_no_maincategory_1		= "Welkom op";
$info_no_maincategory_2		= "Geen Maincategory is beschikbaar.<br>Om Bestanden te beheren, de Beheerder moet Categori�en in het Administratie-Paneel tot stand brengen.";
$info_no_subcategory		= "Geen Subcategorie is beschikbaar in deze Maincategory.<br>Om Bestanden te beheren, de Beheerder moet SubCategori�en in het Administratie-Paneel tot stand brengen.";

//Login
$textfield_login_desc_1 = "<strong>Gebruikersnaam</strong>";
$textfield_login_desc_2 = "<strong>Paswoord</strong>";

//Upload
$info_upload	  		= "Upload was succesvol.";
$info_upload_edit		= "De Veranderingen zijn met succes bewaard.";
$info_upload_validation = "<font color=\"#FF0000\">��n of meerdere vereiste velden zijn leeg. Gelieve de Informatie te voltooien.</font>";
$info_upload_error1		= "<font color=\"#FF0000\">Fout. Upload was niet succesvol. De Directory \"files\" heeft misschien niet de noodzakelijke Rechten om te schrijven (777).<br>Contacteer de Beheerder.</font>";
$info_upload_error2		= "<font color=\"#FF0000\">Fout. U hebt geen Toestemming om Bestanden te uploaden.</font>";
$info_upload_error3		= "<font color=\"#FF0000\">Het Bestand dat u hebt willen uploaden of de Titel die u wilt gebruiken, bestaat reeds.<br>Gelieve uw Informatie te verbeteren.</font>";
$info_upload_error4		= "<font color=\"#FF0000\">Fout. Bestandtype die u wilt uploaden wordt niet toegelaten.</font>";
$progress_message		= "Bewaar de Informatie.";

//Download
$info_download_error1 = "<font color=\"#FF0000\">Fout. U hebt geen Toestemming om Bestanden te downloaden.</font>";

//Search
$info_search		 	 = "Hier kunt u naar Bestanden zoeken.";
$textfield_search_desc_1 = "<strong>Toon allen</strong>";
$textfield_search_desc_2 = "<strong>Maincategory</strong>";
$textfield_search_desc_3 = "<strong>Subcategory</strong>";
$textfield_search_desc_4 = "<strong>Zoek-String</strong>";
$textfield_search_desc_5 = "<strong>Zoek-Optie</strong>";
$textfield_search_desc_6 = "<strong>Niet geactiveerde Accounts</strong>";
$textfield_search_desc_7 = "<strong>Toon Groupen</strong>";
$select_search_1_1		 = "Zoek alles";
$select_search_1_2		 = "Zoek enkel titel";
$select_search_1_3		 = "Zoek enkel Beschrijving";
$select_search_1_4		 = "Zoek enkel Bestandsnaam";
$select_search_1_5		 = "Zoek enkel Bestands grote";
$select_search_1_6		 = "Zoek enkel Bestandstype";
$select_search_1_7		 = "Zoek enkel Datum";
$select_search_1_8		 = "Zoek enkel Maincategory";
$select_search_1_9		 = "Zoek enkel Subcategory";

//User
$textfield_user_name_desc	    	= "<strong>GebruikersNaam</strong>";
$textfield_user_pw			    	= "<strong>Paswoord</strong>";
$textfield_user_pw_ch_desc	    	= "<strong>Verander Paswoord</strong>";
$textfield_user_pw_rep_desc     	= "<strong>Herhaal Paswoord</strong>";
$textfield_user_group_desc	    	= "<strong>Gebruikers-Group</strong>";
$textfield_user_firstname_desc  	= "<strong>Voornaam</strong>";
$textfield_user_lastname_desc   	= "<strong>Achternaam</strong>";
$textfield_user_email_desc	    	= "<strong>E-Mail</strong>";
$textfield_user_website_desc    	= "<strong>Website</strong>";
$textfield_user_birthday_desc   	= "<strong>Verjaardag</strong>";
$textfield_user_gender_desc	    	= "<strong>Geslacht</strong>";
$textfield_user_country_desc    	= "<strong>Land</strong>";
$textfield_user_state_desc	    	= "<strong>Staat</strong>";
$textfield_user_zipcode_desc    	= "<strong>Post-Code</strong>";
$textfield_user_city_desc	    	= "<strong>Stad</strong>";
$textfield_user_street_desc	    	= "<strong>Straat</strong>";
$textfield_user_phone_desc	    	= "<strong>Telefoon</strong>";
$textfield_user_fax_desc	    	= "<strong>Fax</strong>";
$textfield_user_register_desc  		= "<strong>Datum van Registratie</strong>";
$textfield_user_last_login_date 	= "<strong>Laatste Login</strong>";
$textfield_user_last_remote_address = "<strong>Laatste ip-Adres</strong>";
$textfield_user_last_user_agent 	= "<strong>Laatste gebruiker-Agent</strong>";
$textfield_user_whois_ip_address	= "<strong>Whois IP-Adres</strong>";
$textfield_user_activated_desc  	= "<strong>Account geactiveerd</strong>";
$textfield_user_mobile_desc	    	= "<strong>GSM</strong>";
$textfield_user_status_desc	    	= "<strong>Status</strong>";
$textfield_user_online_desc	    	= "<font color=\"#008800\">Online</font>";
$textfield_user_offline_desc    	= "<font color=\"#FF0000\">Offline</font>";
$textfield_user_uploads_desc    	= "<strong>Uploads</strong>";
$info_user_list				    	= "Hier kunt u naar Gebruikers zoeken.";
$textfield_user_email_pub_desc  	= "Openbaar";
$textfield_delete_account_desc  	= "<strong>Wis Account</strong>";
$select_desc_gender_female	    	= "Vrouw";
$select_desc_gender_male	    	= "Man";
$info_pw_validation			    	= "<font color=\"#FF0000\">De Wachtwoorden zijn niet identiek. Gelieve uw Informatie te controleren.</font>";
$info_user_image			    	= "Toelaatbare Gegevens: W: 190 x H: 220, Size: 100 KB, JPEG";
$textfield_del_user_image_desc  	= "<strong>Wis Image</strong>";
$no_user_image				    	= "<strong><font color=\"#FFFFFF\">Geen Beeld beschikbaar</font></strong>";
$no_user_email				    	= "Niet openbaar";
$no_data					    	= "Geen Informatie";
$info_sign_up				    	= "Hier kunt u registreren. De gebieden gemerkt met een Ster zijn vereiste velden.";
$no_login							= "Geen Logins sinds de Registratie";

//Edit User-Profile
$info_upe_validation 	= "<font color=\"#FF0000\">��n of meerdere vereiste velden zijn leeg. Gelieve de Informatie te voltooien.</font>";
$delete_account_success = "Uw Account is met succes gewist.";

//Search User
$select_search_user_1_1	 = "Zoek in alles";
$select_search_user_1_2	 = "Zoek enkel op Gebruikersnaam";
$select_search_user_1_3	 = "Zoek enkel op Voornaam";
$select_search_user_1_4	 = "Zoek enkel op Achternaam";
$select_search_user_1_5	 = "Zoek enkel op E-Mail";
$select_search_user_1_6	 = "Zoek enkel op Website";
$select_search_user_1_7	 = "Zoek enkel op Verjaardag";
$select_search_user_1_8	 = "Zoek enkel op Stad";
$select_search_user_1_9	 = "Zoek enkel op Land";
$select_search_user_1_10 = "Zoek enkel op niet geactiveerde Accounts";

//Header
$info_header1 = "Welkom op";
$info_header2 = "- De Filemanager";

//Sign Up
$info_sign_up_success	   	  = "Uw gebruiker-Account is met succes gecre�erd.<br>U zal een E-mail met een activerings-Link ontvangen. Om in te loggen met uw gebruikers-Gegevens, moet je eerst uw Account activeren.<br>Om dit te doen, controleer uw E-mail en klik op de activerings-Link in de informatie-Mail.<br>Nu kun je inloggen met uw gebruiker-Gegevens.<p>Als je uw Account reeds hebt geactiveerd, Klik op \"Login\".";
$activation_email_subject  	  = "Uw Registratie bij";
$activation_email_content1 	  = "Hallo";
$activation_email_content2 	  = "dank voor uw Registratie bij";
$activation_email_content3 	  = "Om in te loggen met uw gebruiker-Gegevens, moet je eerst uw Account activeren. Klik op \"Activeer nu\" om uw Account te activeren. Nu kun je inloggen met uw gebruiker-Gegevens.";
$info_user_activation_success = "De Activering was succesvol. Om in te loggen, klik op \"Login\".";
$info_user_activation_error	  = "<font color=\"#FF0000\">De Activering was niet succesvol. De activering-Code is ongeldig.<br>Contacteer de Beheerder.</font>";
$info_user_activated		  = "Uw Account is reeds geactiveerd. Om in te loggen, klik op \"Login\".";
$info_su_validation			  = "<font color=\"#FF0000\">��n of meerdere vereiste velden zijn leeg. Gelieve de Informatie te voltooien.</font>";
$new_user_report_content1	  = "Hallo";
$new_user_report_content2	  = "een nieuwe Gebruiker is geregistreerd op";
$new_user_report_content3	  = "Zie de gebruikers-Informatie hieronder:";
$new_user_report_subject	  = "Nieuwe Gebruiker bij";
$info_user_exists			  = "<font color=\"#FF0000\">De Gebruikersnaam die je wil gebruiken bestaat reeds. Gelieve een ander te kiezen.</font>";

//New Password
$info_new_password		 	 	  = "Als je uw Wachtwoord vergeten bent kun je een nieuw Wachtwoord naar uw E-Mail-Adres verzenden type uw Gebruikersnaam en E-Mail-Adres.<br>Het nieuwe Wachtwoord moet eerst worden geactiveerd, alvorens u het kunt gebruiken.";
$info_np_validation		 		  = "<font color=\"#FF0000\">��n of meerdere vereiste velden zijn leeg. Gelieve de Informatie te voltooien.</font>";
$info_np_send_success	 	 	  = "Het nieuwe Wachtwoord is verzonden naar uw E-Mail-Adres. Om uw nieuw Wachtwoord geldig te maken, moet u het eerst activeren.<br>Om dit te doen, controleer uw E-mail en klik op de activering-Link in de informatie-Mail.<p>Om in te loggen, klik op \"Login\".";
$info_new_password_error 	 	  = "<font color=\"#FF0000\">Fout. De gebruiker-Informatie was ongeldig.</font>";
$new_password_email_subject  	  = "Uw nieuw Wachtwoord bij";
$new_password_email_content1 	  = "Hallo";
$new_password_email_content2 	  = "U hebt gevraagd om uw Wachtwoord aan te passen. Uw nieuw Wachtwoord is";
$new_password_email_content3 	  = "Om uw nieuw Paswoord geldig te maken, moet je het eerst activeren. Klik op \"Activeer nu\" om uw Paswoord te activeren.";
$new_password_email_content4 	  = "Het is aangeraden dat je uw Wachtwoord na de eerste Login verandert.<br>Als u uw Wachtwoord niet wilt veranderen of geen aanvraag tot veranderen hebt gedaan, negeer je eenvoudig dit Bericht.";
$info_password_activation_success = "De Activering was succesvol. Om in te loggen, klik op \"Login\".";
$info_password_activation_error	  = "<font color=\"#FF0000\">De Activering was niet succesvol. De Gebruikersnaam, het E-Mail-Adres of het Paswoord zijn ongeldig.<br>Contacteer de Beheerder.</font>";
$info_password_activated		  = "Uw Wachtwoord is reeds geactiveerd. Om in te loggen, Klik op \"Login\".";

//Admin-Get Document
$get_document_error = "<font color=\"#FF0000\">Het gevraagde Bestand bestaat niet.</font>";

//Admin-Index
$admin_title 	 				   = "Beheer";
$info_admin_index 				   = "Welkom op het Beheer-Paneel. Gelieve een Actie te kiezen uit het Menu.";
$description_admin_menu_settings   = "Instellingen";
$description_admin_menu_db		   = "Database";
$description_admin_menu_themes	   = "Thema's";
$description_admin_menu_files	   = "Beheer Bestanden";
$description_admin_menu_categories = "Beheer Categori�en";
$description_admin_menu_users	   = "Beheer Gebruikers";
$description_admin_menu_mail	   = "Stuur E-Mail";

//Admin-Settings
$textfield_as_desc_1 				 	 = "<strong>Site-Naam</strong>";
$textfield_as_desc_2 				 	 = "<strong>URL</strong>";
$textfield_as_desc_3 				 	 = "<strong>Admin-E-Mail</strong>";
$textfield_as_desc_4 				 	 = "<strong>Thema</strong>";
$textfield_as_desc_5 				 	 = "<strong>Taal</strong>";
$textfield_as_desc_6  				 	 = "<strong>Nieuwe Gebruikers worden</strong>";
$textfield_as_desc_7  				 	 = "<strong>Max. Bestandsgrote Uploads</strong>";
$textfield_as_desc_8  				 	 = "<strong>Nieuwe gebruiker melden</strong>";
$textfield_as_desc_9				 	 = "<strong>Nieuwe Uploads melden</strong>";
$textfield_as_desc_10				 	 = "<strong>Versie-Nummer</strong>";
$textfield_as_desc_11				 	 = "<strong>Instalatie-datum</strong>";
$textfield_as_desc_12 				 	 = "<strong>controle van Update</strong>";
$textfield_as_desc_13 				 	 = "<strong>Installeer Update</strong>";
$textfield_as_desc_14 				 	 = "<strong>Desinstallatie</strong>";
$info_as_validation   				 	 = "<font color=\"#FF0000\">��n of meerdere vereiste velden zijn leeg. Gelieve de Informatie te voltooien.</font>";
$info_admin_settings  				 	 = "De Veranderingen zijn met succes bewaard.";
$textfield_site_public_desc			 	 = "<strong>De Site is openbaar</strong>";
$textfield_lock_site_desc			 	 = "<strong>Sluit Site</strong>";
$textfield_lock_site_reason_desc	 	 = "<strong>Reden</strong>";
$textfield_lock_register_desc	 	 	 = "<strong>Sluit Registratie</strong>";
$textfield_lock_register_reason_desc 	 = "<strong>Reden</strong>";
$textfield_lock_upload_desc		 	 	 = "<strong>Sluit Uploads</strong>";
$textfield_lock_upload_reason_desc	 	 = "<strong>Reden</strong>";
$textfield_lock_download_desc		 	 = "<strong>Sluit Downloads</strong>";
$textfield_lock_download_reason_desc 	 = "<strong>Reden</strong>";
$textfield_lock_zip_download_desc	 	 = "<strong>Sluit Zip-Downloads</strong>";
$textfield_lock_zip_download_reason_desc = "<strong>Reden</strong>";
$select_file_size_byte				 	 = "Byte";
$select_file_size_kb				 	 = "KB (Kilobyte)";
$select_file_size_mb				 	 = "MB (Megabyte)";
$select_file_size_gb				 	 = "GB (Gigabyte)";
$select_file_size_tb				 	 = "TB (Terabyte)";
$select_file_size_pb				 	 = "PB (Petabyte)";
$select_file_size_eb				 	 = "EB (Exabyte)";

//Admin-DB
$textfield_adb_desc_1  = "<strong>Database-Hostnaam</strong>";
$textfield_adb_desc_2  = "<strong>Database-Naam</strong>";
$textfield_adb_desc_3  = "<strong>Database-Gebruikernaam</strong>";
$textfield_adb_desc_4  = "<strong>Database-Paswoord</strong>";
$textfield_adb_desc_5  = "<strong>Table-Prefix</strong>";
$textfield_adb_desc_6  = "<strong>Table Configuratie</strong>";
$textfield_adb_desc_7  = "<strong>Table Themes</strong>";
$textfield_adb_desc_8  = "<strong>Table Gebruiker</strong>";
$textfield_adb_desc_9  = "<strong>Table Categori�en</strong>";
$textfield_adb_desc_10 = "<strong>Table Bestanden</strong>";
$textfield_adb_desc_11 = "<strong>Table Bestandtypes</strong>";
$textfield_adb_desc_12 = "<strong>Optimaliseer Tables</strong>";
$info_db_validation    = "<font color=\"#FF0000\">��n of meerdere vereiste velden zijn leeg. Gelieve de Informatie te voltooien.</font>";
$info_db_error1 	   = "<font color=\"#FF0000\">Database-verbinding Onderbroken. Controleer, of de Database-Informatie correct is.</font>";
$info_db_error2 	   = "<font color=\"#FF0000\">Bestand \"config.php\" kon niet worden gecre�erd. Controleer als de Directory \"config\" de noodzakelijke Rechten heeft om te schrijven (777).</font>";
$info_db 			   = "De Veranderingen zijn met succes bewaard.";
$info_db_optimize	   = "Alle Tabellen zijn met succes geoptimaliseerd.";
$info_backup_config    = "<strong>Aandacht</strong><br>Wees zeker, dat de Database-Informatie correct is. Als de Informatie ongeldig is, is het mogelijk dat u geen Verbinding meer kan maken met het Systeem. Om dit te vermijden, kunt u het configuratie-Bestand eerst bewaren. Dan, kunt u het terugvinden door het Bestand te uploaden in de Directory \"config\".";

//Admin-Themes
$select_themes_edit    = "Beheer Thema's";
$select_themes_new     = "Cre�er nieuw Thema";
$info_themes_index	   = "Kies een Actie.";
$info_themes_select	   = "Kies een Thema, dat u wilt aanpassen.";
$textfield_at_desc_1   = "<strong>Thema-Naam</strong>";
$textfield_at_desc_2   = "<strong>Thema-Beschrijving</strong>";
$textfield_at_desc_3   = "<strong>Thema-Directory</strong>";
$textfield_at_desc_4   = "<strong>Logo</strong>";
$textfield_at_desc_5   = "<strong>Achtergrond-kleur</strong>";
$textfield_at_desc_6   = "<strong>Achtergrond-beeld</strong>";
$textfield_at_desc_7   = "<strong>Resultaten per Site</strong>";
$textfield_at_desc_8   = "<strong>Font-Family</strong>";
$textfield_at_desc_9   = "<strong>Font-Grote</strong>";
$textfield_at_desc_10  = "<strong>Font-kleur</strong>";
$textfield_at_desc_11  = "<strong>Font-Grote Hyperlinks</strong>";
$textfield_at_desc_12  = "<strong>Font-kleur Hyperlinks</strong>";
$textfield_at_desc_13  = "<strong>Table-Breedte</strong>";
$textfield_at_desc_14  = "<strong>Table-kleur 1</strong>";
$textfield_at_desc_15  = "<strong>Table-kleur 2</strong>";
$textfield_at_desc_16  = "<strong>Table-kleur 3</strong>";
$textfield_at_desc_17  = "<strong>Table-kleur 4</strong>";
$textfield_at_desc_18  = "<strong>Highlight Table-kleur 1</strong>";
$textfield_at_desc_19  = "<strong>Highlight Table-kleur 2</strong>";
$textfield_at_desc_20  = "<strong>Enkel Internet Explorer</strong>";
$textfield_at_desc_21  = "<strong>Wis Thema</strong>";
$textfield_at_desc_22  = "<strong>Kies</strong>";
$themes_select_yes	   = "Ja";
$themes_select_no	   = "Nee";
$info_te_validation	   = "<font color=\"#FF0000\">��n of meerdere vereiste velden zijn leeg. Gelieve de Informatie te voltooien.</font>";
$info_themes_edit	   = "De Veranderingen zijn met succes bewaard.";
$info_tn_validation	   = "<font color=\"#FF0000\">��n of meerdere vereiste velden zijn leeg. Gelieve de Informatie te voltooien.</font>";
$info_tn_error1		   = "<font color=\"#FF0000\">Het Veld \"$textfield_at_desc_7\" bevat een ongeldige Waarde. De Waarde moet numeriek zijn en niet onder de 1.<br>Gelieve uw Informatie te verbeteren.</font>";
$info_tn_error2		   = "<font color=\"#FF0000\">De Thema-Naam die u wilt gebruiken bestaat reeds. Gelieve een andere te kiezen.</font>";
$info_tn_error3		   = "<font color=\"#FF0000\">Het Thema die u wilt schrappen is actief in gebruik.<br>Om het Thema te wissen, moet u eerst een ander Thema activeren in $description_admin_menu_settings.</font>";
$info_themes_new	   = "Het Thema is met succes gecre�erd.";
$info_themes_deleted   = "Het Thema is met succes gewist.";
$info_cn_validation    = "<font color=\"#FF0000\">��n of meerdere vereiste velden zijn leeg. Gelieve de Informatie te voltooien.</font>";

//Admin-Files, Filetypes
$description_filetype_name 		  = "<strong>Bestandtype</strong>";
$description_filetype_description = "<strong>Beschrijving</strong>";
$description_filetype_status	  = "<strong>Status</strong>";
$description_filetype_delete	  = "<strong>Wis</strong>";
$select_manage_files 	  		  = "Beheer Bestanden";
$select_manage_filetypes  		  = "Beheer Bestandtypes";
$select_filetype_unlocked 		  = "Sluit";
$select_filetype_locked   		  = "Geopend";
$select_filetype_new	  		  = "Maak Bestandtypes";
$info_files_index 		  		  = "Kies een Actie.";
$info_filetypes_index  	  		  = "Hier kunt u naar Bestandtypes zoeken.";
$textfield_af_desc_1 	  		  = "<strong>Kies</strong>";
$delete_confirm	  		  		  = "Wilt u werkelijk Bestanden wissen?";
$delete_success	  		  		  = "Geselecteerde Bestanden zijn met succes gewist.";
$delete_error	  		  		  = "<font color=\"#FF0000\">Geen Bestanden zijn geselecteerd.</font>";
$info_new_filetype		  		  = "Hier kunt u nieuwe Bestandtype's cre�ren.";
$textfield_filetypes_1	  		  = "<strong>Bestandtype</strong>";
$textfield_filetypes_2	  		  = "<strong>Beschrijving</strong>";
$textfield_filetypes_3	  		  = "<strong>Verbied uploaden</strong>";
$textfield_filetypes_4	  		  = "<strong>Bestandstype-Status</strong>";
$textfield_filetypes_5	  		  = "<strong>Wis Bestandstype</strong>";
$filetype_status_unlocked		  = "<font color=\"#008800\">Ontgrendel</font>";
$filetype_status_locked			  = "<font color=\"#FF0000\">Sluit</font>";
$info_filetypes_new	 	  		  = "Bestandstype is met succes gecre�erd.";
$info_filetype_exists			  = "<font color=\"#FF0000\">Bestandstype die u wilt tot stand brengen bestaat reeds.</font>";
$info_filetype_exists_2			  = "<font color=\"#FF0000\">Bestandstype die u wilt gebruiken bestaat reeds.</font>";
$info_ft_validation   	  		  = "<font color=\"#FF0000\">��n of meerdere vereiste velden zijn leeg. Gelieve de Informatie te voltooien.</font>";
$delete_filetypes_success		  = "Geselecteerde Bestandstype is met succes gewist.";
$delete_filetype_success  	      = "Het Bestandstype is met succes gewist.";
$delete_filetype_error 	  		  = "<font color=\"#FF0000\">Geen Bestandtypes zijn geselecteerd.</font>";
$edit_filetype_success			  = "De Veranderingen zijn met succes bewaard.";
$delete_filetype_confirm		  = "Wilt u werkelijk Bestandtype's wissen?";
$textfield_fe_lock				  = "<strong>Sluit</strong>";

//Admin-Categories
$select_category_edit   = "Beheer Categori�en";
$select_category_new    = "Cre�er nieuwe Categorie";
$textfield_ac_desc_1	= "<strong>Kies</strong>";
$info_new_categories	= "Hier kunt u nieuwe Categori�en tot stand brengen.";
$textfield_categories_1 = "<strong>Naam</strong>";
$textfield_categories_2 = "<strong>Beschrijving</strong>";
$textfield_categories_3 = "<strong>In Maincategorie</strong>";
$textfield_categories_4 = "<strong>Wis Categorie</strong>";
$info_categories_new	= "De Categorie is met succes gecre�erd.";
$info_categories_select	= "Kies een Categorie, die u wilt aanpassen.";
$info_category_deleted	= "De Categorie is met succes gewist.";
$info_ce_validation		= "<font color=\"#FF0000\">��n of meerdere vereiste velden zijn leeg. Gelieve de Informatie te voltooien.</font>";
$info_cn_error			= "<font color=\"#FF0000\">De categorie-Naam die je wilt gebruiken bestaat reeds. Gelieve een andere te kiezen.</font>";
$info_cn_error2			= "<font color=\"#FF0000\">De subcategorie-Naam die u in de Maincategorie wilt gebruiken bestaat reeds. Kies een ander.</font>";

//Admin-Users
$select_manage_users				= "Beheer Gebruikers";
$select_new_user					= "Cre�er nieuwe Gebruiker";
$info_users_index 					= "Kies een Actie.";
$textfield_au_desc_1				= "<strong>Selectie</strong>";
$info_new_user						= "Hier kunt u een nieuwe Gebruiker cre�ren.";
$info_new_user_success				= "De gebruiker-Account is met succes gecre�erd.";
$delete_users_success 		  	 	= "Geselecteerde gebruiker is met succes gewist.";
$delete_user_success				= "De gebruiker is met succes gewist.";
$delete_users_error	  		  		= "<font color=\"#FF0000\">Geen Gebruikers zijn geselecteerd.</font>";
$delete_user_confirm		  		= "Wilt u werkelijk deze Gebruikers wissen?";
$textfield_lock_account_desc  		= "<strong>Sluit Account</strong>";
$textfield_lock_account_reason_desc = "<strong>Reden</strong>";
$select_desc_admin					= "Admin";
$select_desc_downloader		  		= "Downloader";
$select_desc_downloader_uploader	= "Downloader/Uploader";
$select_desc_uploader				= "Uploader";
$select_desc_user					= "Gebruiker";
$textfield_user_limit_file_size		= "<strong>Max. Bestands grote upload</strong>";
$textfield_logout_user				= "<strong>Gebruiker nu uitloggen</strong>";
$textfield_not_logged_in			= "De Gebruiker is niet ingelogd";

//Admin-Mail
$info_mail 			   	= "Hier kunt u een Bericht naar Gebruikers verzenden.";
$textfield_mail_desc_1 	= "<strong>Groep</strong>";
$textfield_mail_desc_2 	= "<strong>Afzonderlijke Ontvanger</strong>";
$textfield_mail_desc_3 	= "<strong>Prioriteit</strong>";
$textfield_mail_desc_4 	= "<strong>Onderwerp</strong>";
$textfield_mail_desc_5 	= "<strong>Inhoud</strong>";
$select_priority_low	= "Laag";
$select_priority_normal = "Normaal";
$select_priority_high	= "Hoog";
$select_no_group		= "Verzend naar geen Groep";
$select_all_groups		= "Verzend naar alle Gebruikers";
$mail_header1			= "Hallo,<p>u ontvangt dit Bericht, omdat u een geregistreerde Gebruiker bent van";
$mail_header2			= ". Zie het Bericht van de Beheerder hieronder:";
$mail_footer			= "Vriendelijke groeten";
$info_mail_success		= "Het Bericht is met succes verzonden.";
$file_attachment		= "<strong>Attachment</strong>";
$info_mail_validation	= "<font color=\"#FF0000\">��n of meerdere vereiste velden zijn leeg. Gelieve de Informatie te voltooien.</font>";
$info_mail_no_group		= "<font color=\"#FF0000\">Het Bericht is niet verzonden. De geselecteerde Groep heeft geen Gebruikers.</font>";
$info_mail_no_group2	= "Het Bericht is slechts verzonden naar de Afzonderlijke Ontvanger. De geselecteerde Groep heeft geen Gebruikers.";
$progress_message_mail	= "De E-mail is verzonden.";

//Admin-Update
$info_install_update_1    = "<br><strong>De nieuwe Update kan worden ge�nstalleerd</strong><p>Een nieuwere Versie als u momenteel gebruikt, is ontdekt.<p>De Versie die u momenteel gebruikt is:";
$info_install_update_2    = "De Versie die u kunt bijwerken is:";
$info_install_update_3    = "Als u de Update nu wilt installeren, klik op \"Installeer\".";
$info_update_success      = "<br>De Update is met succes ge�nstalleerd.";
$info_update_error        = "<br><font color=\"#FF0000\">De Update is niet be�indigd.<p><strong>Fout</strong><br></font>";
$info_update_error1       = "<font color=\"#FF0000\">- Verbinding naar Database onderbroken. Controleer of de Database-Informatie correct is.</font>";
$info_update_error2       = "<font color=\"#FF0000\">- Kon Bestand niet cre�ren \"config.php\". Controleer of de Directory \"config\" en het Bestand \"config.php\" de juiste schrijf rechten hebben (777).</font>";
$info_update_error3       = "<font color=\"#FF0000\">- Kon de Directory niet aanmaken \"temp\". Controleer of de Directory \"files\" de juiste schrijf rechten heeft (777).</font>";
$info_no_update	          = "<br>Geen beschikbare Updates.";

//Admin-Uninstall
$info_uninstall  		  = "<br><strong>Aandacht</strong><br>Dit zal het Systeem verwijderen. Alle Gegevens zullen worden geschrapt. Klik op \"Desinstallatie\", als u het Systeem nu wilt verwijderen.";
$info_uninstall_success   = "<br>De-Installatie is met succes be�indigd. Verwijder manueel de Bestands-Directory. Klik op \"Sluit\", om het Systeem te verlaten.";
$uninstall_confirm		  = "Wilt u werkelijk het Systeem desinstalleren?";
$info_uninstall_error     = "<br><font color=\"#FF0000\">De-Installation is niet be�indigd.<p><strong>Fout</strong><br></font>";
$info_uninstall_error1    = "<font color=\"#FF0000\">- Bestand \"config.php\" niet gevonden.</font>";
$info_uninstall_error2    = "<font color=\"#FF0000\">- Verbinding naar Database onderbroken. Controleer als de Database-Informatie correct is.</font>";
$info_uninstall_no_action = "<br><font color=\"#FF0000\">Geen Actie gekozen.</font>";

//Buttons
$button_back			= "< Terug ";
$button_next			= " Volgende >";
$button_cancel			= "Annuleer";
$button_install			= "Installeer";
$button_start			= "Start";
$button_login			= "Login";
$button_upload			= "Upload";
$button_reset			= "Herstel";
$button_search			= "Zoek";
$button_save			= "Bewaar";
$button_edit 			= "Aanpassen";
$button_show_categories = "Toon Categori�en";
$button_search_files	= "Zoek Bestanden";
$button_show			= "Toon";
$button_delete			= "Wis";
$button_send			= "Stuur";
$button_zip				= " Zip ";
$button_per_site		= "Per Site";
$button_execute			= "Uitvoeren";
$button_ok				= "   OK   ";
$button_uninstall		= "Uninstall";
$button_close			= "Sluit";

//Links
$logout 	   	     = "Loguit";
$link_upload   	     = "Upload";
$link_search   	     = "Zoek";
$link_admin    	     = "Beheer";
$link_index 	     = "Index";
$link_sign_up 	     = "Register";
$link_new_password   = "Vergat Wachtwoord";
$link_check_update   = "Controleer nu voor Updates";
$link_install_update = "Installeer nu de Update";
$link_uninstall		 = "Desinstalleer het systeem nu";
$link_backup_config  = "Bewaar nu";
$link_download_now	 = "Download nu";
$link_show_uploads	 = "Toon alle Uploads van deze Gebruiker";
$link_userlist		 = "Gebruikerslijst";
$link_my_profil		 = "Mijn Profiel";
$link_user_image	 = "Toon gebruiker-Image";
$link_activation 	 = "<strong>Activeer nu</strong>";
$link_download_show  = "Toon nu";
$link_edit			 = "Aanpassen";
$link_public_area	 = "Openbaar Gebied";
$link_login			 = "Login";

//Link Title

//Admin-Menu
$link_desc_admin_menu_settings 	 = "Hier kunt u de systeem-Instellingen aanpassen";
$link_desc_admin_menu_db 		 = "Hier kunt u de Database-Instellingen aanpassen";
$link_desc_admin_menu_themes 	 = "Hier kunt u Thema's beheren";
$link_desc_admin_menu_files 	 = "Hier kunt u Bestanden beheren";
$link_desc_admin_menu_categories = "Hier kunt u Categori�en beheren";
$link_desc_admin_menu_users 	 = "Hier kunt u Gebruikers beheren";
$link_desc_admin_menu_mail 		 = "Hier kunt u E-Mails zenden";

//Categories
$link_desc_category_maincategory = "Sorteer op Maincategory";
$link_desc_category_subcategory  = "Sorteer op Subcategory";
$link_desc_category_description  = "Sorteer op Beschrijving";

//Files
$link_desc_file_subject 		= "Sorteer op Titel";
$link_desc_file_description 	= "Sorteer op Beschrijving";
$link_desc_file_name			= "Sorteer op Bestandsnaam";
$link_desc_file_size 			= "Sorteer op Bestands grote";
$link_desc_file_extension 		= "Sorteer op Bestandstype";
$link_desc_file_date 			= "Sorteer op Upload-Datum";
$link_desc_file_delete 			= "Selecteer veelvoudige Bestanden om te wissen";
$link_desc_file_zip 			= "Selecteer veelvoudige Bestanden om te Downloaden";
$link_desc_filetype_name		= "Sorteer op Bestandstype";
$link_desc_filetype_description	= "Sorteer op Beschrijving";
$link_desc_filetype_delete		= "Selecteer veelvoudige Bestandstypes om te wissen";
$link_desc_filetype_unlocked	= "Geopend";
$link_desc_filetype_locked		= "Gesloten";

//Users
$link_desc_user_name 	  = "Sorteer op Gebruikersnaam";
$link_desc_user_firstname = "Sorteer op Voornaam";
$link_desc_user_lastname  = "Sorteer op Achternaam";
$link_desc_user_email 	  = "Sorteer op E-Mail";
$link_desc_user_website   = "Sorteer op Website";
$link_desc_user_delete 	  = "Selecteer veelvoudige Gebruikers om te wissen";
$link_desc_user_online 	  = "Online";
$link_desc_user_offline	  = "Offline";
$link_desc_user_whois	  = "Whois";
$link_desc_user_ripe_ncc  = "RIPE NCC";
$link_desc_user_arin	  = "ARIN";
$link_desc_user_lapnic	  = "LAPNIC";
$link_desc_user_apnic	  = "APNIC";

?>