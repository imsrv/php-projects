<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

//Global
$yes = "Yes";
$no	 = "No";
$download  = "Download";
$downloads = "Downloads";
$info_browser_detection = "<font color=\"#FF0000\">You are using the wrong Browser.<br>This Sites have been optimized for Internet Explorer.</font>";

//Session
$info_login_error1 			 	= "<font color=\"#FF0000\">Error. Your Login-Information were incorrect.<br>Please try again.</font>";
$info_login_error2 		 	 	= "<font color=\"#FF0000\">Error. You are not logged in.<br>Please login now.</font>";
$info_login_error3			 	= "<font color=\"#FF0000\">Error. Your Account has not been activated.<br>Please activate your Account first.</font>";
$info_user_locked  			 	= "<font color=\"#FF0000\">Your Account has been locked by the Administrator.<p><strong>Message of the Administrator:</strong><br></font>";
$info_user_locked_no_reason  	= "<font color=\"#FF0000\">No Reason has been posted.</font>";
$info_logout	 			 	= "You have been successfully logged out. If you want to login again, click on \"Login\".";
$info_site_locked  			 	= "<font color=\"#FF0000\">The Site has been locked by the Administrator.<p><strong>Message of the Administrator:</strong><br></font>";
$info_site_locked_no_reason	 	= "<font color=\"#FF0000\">No Reason has been posted.</font>";
$info_register_locked		 	= "<font color=\"#FF0000\">The Registration has been locked by the Administrator.<p><strong>Message of the Administrator:</strong><br></font>";
$info_register_locked_reason 	= "<font color=\"#FF0000\">No Reason has been posted.</font>";
$info_upload_locked  		 	= "<font color=\"#FF0000\">The Uploading has been locked by the Administrator.<p><strong>Message of the Administrator:</strong><br></font>";
$info_upload_locked_no_reason 	= "<font color=\"#FF0000\">No Reason has been posted.</font>";
$info_download_locked  			= "<font color=\"#FF0000\">The Downloading has been locked by the Administrator.<p><strong>Message of the Administrator:</strong><br></font>";
$info_download_locked_no_reason = "<font color=\"#FF0000\">No Reason has been posted.</font>";
$info_admin					  	= "<font color=\"#FF0000\">Error. You don't have Permission to show this Sites.</font>";

//Fields
$field_logout 			 = "Logout";
$field_login  			 = "Login";
$field_as_1	  			 = "Settings";
$field_as_2	  			 = "Notification";
$field_as_3	  			 = "Installation";
$field_adb_1  			 = "Database-Connection";
$field_adb_2  			 = "Table-Information";
$field_adb_3			 = "Optimize";
$field_at_1	  			 = "Theme-Information";
$field_at_2	  			 = "Site-Layout";
$field_at_3	  			 = "Font-Settings";
$field_at_4	  			 = "Table-Layout";
$field_at_5	  			 = "Compatibility";
$field_at_6	  			 = "Delete";
$field_ti_1	  			 = "Action";
$field_ts_1	  			 = "Select";
$field_fi_1	  			 = "Action";
$field_search 			 = "Search";
$field_show	  			 = "Show";
$field_sf_1	  			 = "Download";
$field_sf_2	  			 = "File-Information";
$field_sf_3	  			 = "Action";
$field_fe_1	  			 = "Delete";
$field_eup_1  			 = "User-Information";
$field_user_pic 		 = "User-Image";
$field_maincategory 	 = "Create Maincategory";
$field_subcategory  	 = "Create Subcategory";
$field_maincategory_edit = "Edit Maincategory";
$field_subcategory_edit  = "Edit Subcategory";
$field_categories_edit	 = "Edit Category";
$field_receiver			 = "Message-Receiver";
$field_mail_content		 = "Message";
$field_options			 = "Options";
$field_information		 = "Information";
$field_lock			 	 = "Lock";
$field_delete  			 = "Delete";
$field_ue	  			 = "Action";
$field_install_update	 = "Install Update";
$field_ui_1				 = "Action";
$field_ci_1				 = "Action";
$field_filetype			 = "Filetype-Information";
$field_uninstall		 = "Uninstall";

//Files, Categories
$description_file_subject 	   = "<strong>Title</strong>";
$description_file_description  = "<strong>Description</strong>";
$description_file_name 		   = "<strong>Filename</strong>";
$description_file_size 		   = "<strong>Filesize</strong>";
$description_file_extension	   = "<strong>Filetype</strong>";
$description_file_date 		   = "<strong>Upload-Date</strong>";
$description_file_delete	   = "<strong>Delete</strong>";
$description_file_zip_download = "<strong>Zip-Download</strong>";
$description_maincategory	   = "<strong>Maincategory</strong>";
$description_subcategory	   = "<strong>Subcategory</strong>";
$description_description	   = "<strong>Description</strong>";
$description_downloads		   = "<strong>Downloads</strong>";
$zip_error					   = "<font color=\"#FF0000\">No Files have been selected.</font>";
$zip_error2	  				   = "<font color=\"#FF0000\">Error. The Zip-File could not be created.<br>The Directory \"temp\" maybe has not the necessary Rights to write (777) or the File is too big.<br>Call the Administrator.</font>";
$info_zip_download_locked	   = "<font color=\"#FF0000\">The Zip-Download-Function has been locked by the Administrator.<p><strong>Message of the Administrator:</strong><br></font>";
$info_zip_locked_no_reason	   = "<font color=\"#FF0000\">No Reason has been posted.</font>";
$user_id					   = "User-ID";

//Categories, Upload-Select, Show File, Upload-Edit, Edit User-Profile
$textfield_us_desc_1  	    = "<strong>Maincategory</strong>";
$textfield_us_desc_2  	    = "<strong>Subcategory</strong>";
$textfield_us_desc_3  	    = "<strong>Title</strong>";
$textfield_us_desc_4  	    = "<strong>Description</strong>";
$textfield_us_desc_5  	    = "<strong>Change File</strong>";
$textfield_us_desc_6   	    = "<strong>Current File</strong>";
$textfield_us_desc_7  	    = "<strong>Last Change</strong>";
$textfield_us_desc_8        = "<strong>Upload from User</strong>";
$textfield_us_desc_9  	    = "<strong>File</strong>";
$textfield_us_desc_10 	    = "<strong>Selection</strong>";
$textfield_us_desc_11	    = "<strong>Delete Upload</strong>";
$textfield_us_desc_12	    = "<strong>Show</strong>";
$textfield_us_dc			= "<strong>Number of Downloads</strong>";
$info_file_edit			    = "No Changes since the Upload";
$delete_file_success  	    = "The Upload has been successfully deleted.";
$no_user				    = "The User doesn't exist anymore";
$new_upload_report_subject  = "New Upload on";
$new_upload_report_content1 = "Hello";
$new_upload_report_content2 = "it has been uploaded a new File on";
$new_upload_report_content3 = "See the Information below:";
$info_upload_maincategory	= "Choose a Maincategory, in which you want to create a new Download.";
$info_upload_subcategory 	= "Choose a Subcategory, in which you want to create a new Download.";
$info_upload_error			= "<font color=\"#FF0000\">Error. The File you want to upload is too big.<br>The global Upload-Limit ist</font>";
$info_upload_error_user		= "<font color=\"#FF0000\">Error. The File you want to upload is too big.<br>Your Upload-Limit ist</font>";
$info_user_image_error1		= "<font color=\"#FF0000\">Error. The User-Image you want to upload is too big.<br>Permissible Size: 100 KB.</font>";
$info_user_image_error2		= "<font color=\"#FF0000\">Error. The User-Image you want to upload has the wrong Format.<br>Only JPEG allowed.</font>";
$info_user_image_error3		= "<font color=\"#FF0000\">Error. The User-Image you want to upload has the wrong Size.<br>Permissible Data: W: 190 x H: 220.</font>";
$info_no_maincategory_1		= "Welcome to";
$info_no_maincategory_2		= "No Maincategory is available.<br>To manage Files, the Administrator must create Categories in the Administration-Panel.";
$info_no_subcategory		= "No Subcategory is available in this Maincategory.<br>To manage Files, the Administrator must create a Subcategory in the Administration-Panel.";

//Login
$textfield_login_desc_1 = "<strong>Username</strong>";
$textfield_login_desc_2 = "<strong>Password</strong>";

//Upload
$info_upload	  		= "The Upload was successful.";
$info_upload_edit		= "The Changes have been successfully saved.";
$info_upload_validation = "<font color=\"#FF0000\">One ore more required Fields are empty. Please complete your Information.</font>";
$info_upload_error1		= "<font color=\"#FF0000\">Error. The Upload wasn't successful. The Directory \"files\" maybe has not the necessary Rights to write (777).<br>Call the Administrator.</font>";
$info_upload_error2		= "<font color=\"#FF0000\">Error. You don't have Permission to upload Files.</font>";
$info_upload_error3		= "<font color=\"#FF0000\">The File you want to upload or the Title you want to use, already exists.<br>Please correct your Information.</font>";
$info_upload_error4		= "<font color=\"#FF0000\">Error. The Filetype you want to upload is not permitted.</font>";
$progress_message		= "Saving Information.";

//Download
$info_download_error1 = "<font color=\"#FF0000\">Error. You don't have Permission to download Files.</font>";

//Search
$info_search		 	 = "Here you can search for Files.";
$textfield_search_desc_1 = "<strong>Show all</strong>";
$textfield_search_desc_2 = "<strong>Maincategory</strong>";
$textfield_search_desc_3 = "<strong>Subcategory</strong>";
$textfield_search_desc_4 = "<strong>Search-String</strong>";
$textfield_search_desc_5 = "<strong>Search-Option</strong>";
$textfield_search_desc_6 = "<strong>Not activated Accounts</strong>";
$textfield_search_desc_7 = "<strong>Show Groups</strong>";
$select_search_1_1		 = "Search all";
$select_search_1_2		 = "Search Title only";
$select_search_1_3		 = "Search Description only";
$select_search_1_4		 = "Search Filename only";
$select_search_1_5		 = "Search Filesize only";
$select_search_1_6		 = "Search Filetype only";
$select_search_1_7		 = "Search Date only";
$select_search_1_8		 = "Search Maincategory only";
$select_search_1_9		 = "Search Subcategory only";

//User
$textfield_user_name_desc	    	= "<strong>Username</strong>";
$textfield_user_pw			    	= "<strong>Password</strong>";
$textfield_user_pw_ch_desc	    	= "<strong>Change Password</strong>";
$textfield_user_pw_rep_desc     	= "<strong>Repeat Password</strong>";
$textfield_user_group_desc	    	= "<strong>User-Group</strong>";
$textfield_user_firstname_desc  	= "<strong>Firstname</strong>";
$textfield_user_lastname_desc   	= "<strong>Lastname</strong>";
$textfield_user_email_desc	    	= "<strong>E-Mail</strong>";
$textfield_user_website_desc    	= "<strong>Website</strong>";
$textfield_user_birthday_desc   	= "<strong>Birthday</strong>";
$textfield_user_gender_desc	    	= "<strong>Gender</strong>";
$textfield_user_country_desc    	= "<strong>Country</strong>";
$textfield_user_state_desc	    	= "<strong>State</strong>";
$textfield_user_zipcode_desc    	= "<strong>ZIP-Code</strong>";
$textfield_user_city_desc	    	= "<strong>City</strong>";
$textfield_user_street_desc	    	= "<strong>Street</strong>";
$textfield_user_phone_desc	    	= "<strong>Phone</strong>";
$textfield_user_fax_desc	    	= "<strong>Fax</strong>";
$textfield_user_register_desc  		= "<strong>Date of Registration</strong>";
$textfield_user_last_login_date 	= "<strong>Last Login</strong>";
$textfield_user_last_remote_address = "<strong>Last IP-Address</strong>";
$textfield_user_last_user_agent 	= "<strong>Last User-Agent</strong>";
$textfield_user_whois_ip_address	= "<strong>Whois IP-Address</strong>";
$textfield_user_activated_desc  	= "<strong>Account activated</strong>";
$textfield_user_mobile_desc	    	= "<strong>Mobile</strong>";
$textfield_user_status_desc	    	= "<strong>Status</strong>";
$textfield_user_online_desc	    	= "<font color=\"#008800\">Online</font>";
$textfield_user_offline_desc    	= "<font color=\"#FF0000\">Offline</font>";
$textfield_user_uploads_desc    	= "<strong>Uploads</strong>";
$info_user_list				    	= "Here you can search for Users.";
$textfield_user_email_pub_desc  	= "Public";
$textfield_delete_account_desc  	= "<strong>Delete Account</strong>";
$select_desc_gender_female	    	= "Female";
$select_desc_gender_male	    	= "Male";
$info_pw_validation			    	= "<font color=\"#FF0000\">The Passwords are not identical. Please check your Information.</font>";
$info_user_image			    	= "Permissible Data: W: 190 x H: 220, Size: 100 KB, JPEG";
$textfield_del_user_image_desc  	= "<strong>Delete Image</strong>";
$no_user_image				    	= "<strong><font color=\"#FFFFFF\">No Image available</font></strong>";
$no_user_email				    	= "Not public";
$no_data					    	= "No Information";
$info_sign_up				    	= "Here you can register. Fields marked with a Star are required Fields.";
$no_login							= "No Login since the Registration";

//Edit User-Profile
$info_upe_validation 	= "<font color=\"#FF0000\">One ore more required Fields are empty. Please complete your Information.</font>";
$delete_account_success = "Your Account has been successfully deleted.";

//Search User
$select_search_user_1_1	 = "Search all";
$select_search_user_1_2	 = "Search Username only";
$select_search_user_1_3	 = "Search Firstname only";
$select_search_user_1_4	 = "Search Lastname only";
$select_search_user_1_5	 = "Search E-Mail only";
$select_search_user_1_6	 = "Search Website only";
$select_search_user_1_7	 = "Search Birthday only";
$select_search_user_1_8	 = "Search City only";
$select_search_user_1_9	 = "Search Country only";
$select_search_user_1_10 = "Search not activated Accounts only";

//Header
$info_header1 = "Welcome to";
$info_header2 = "- The Filemanager";

//Sign Up
$info_sign_up_success	   	  = "Your User-Account has been successfully created.<br>You will receive an E-Mail with an Activation-Link. To login with your User-Data, you have to activate your Account first.<br>To do this, check your E-Mails and click on the Activation-Link in the Information-Mail.<br>Now you can login with your User-Data.<p>If you have activated your Account already, click on \"Login\".";
$activation_email_subject  	  = "Your Registration at";
$activation_email_content1 	  = "Hello";
$activation_email_content2 	  = "thank you for the Registration at";
$activation_email_content3 	  = "To login with your User-Data, you have to activate your Account first. Click on \"Activate now\" to activate your Account. Now you can login with your User-Data.";
$info_user_activation_success = "The Activation was successful. To login now, click on \"Login\".";
$info_user_activation_error	  = "<font color=\"#FF0000\">The Activation wasn't successful. The Activation-Code is invalid.<br>Call the Administrator.</font>";
$info_user_activated		  = "Your Account already has been activated. To login now, click on \"Login\".";
$info_su_validation			  = "<font color=\"#FF0000\">One ore more required Fields are empty. Please complete your Information.</font>";
$new_user_report_content1	  = "Hello";
$new_user_report_content2	  = "a new User has registered on";
$new_user_report_content3	  = "See the User-Information below:";
$new_user_report_subject	  = "New User at";
$info_user_exists			  = "<font color=\"#FF0000\">The Username you want to use already exists. Please choose another.</font>";

//New Password
$info_new_password		 	 	  = "If you forgot your Password you can send a new Password to your E-Mail-Address typing your Username and E-Mail-Address.<br>The new Password must be activated first, before you can use it.";
$info_np_validation		 		  = "<font color=\"#FF0000\">One ore more required Fields are empty. Please complete your Information.</font>";
$info_np_send_success	 	 	  = "The new Password has been sent to your E-Mail-Address. To make your new Password valid, you have to activate it first.<br>To do this, check your E-Mails and click on the Activation-Link in the Information-Mail.<p>To login now, click on \"Login\".";
$info_new_password_error 	 	  = "<font color=\"#FF0000\">Error. The User-Information were invalid.</font>";
$new_password_email_subject  	  = "Your new Password at";
$new_password_email_content1 	  = "Hello";
$new_password_email_content2 	  = "You have arranged to change your Password. Your new Password is";
$new_password_email_content3 	  = "To make your new Password valid, you have to activate it first. Click on \"Activate now\" to activate your Password.";
$new_password_email_content4 	  = "It's recommanded that you change your Password after the first Login.<br>If you don't want to change your Password or if you don't have arranged to change it, simply ignore this Message.";
$info_password_activation_success = "The Activation was successful. To login now, click on \"Login\".";
$info_password_activation_error	  = "<font color=\"#FF0000\">The Activation wasn't successful. The Username, the E-Mail-Address or the Password is invalid.<br>Call the Administrator.</font>";
$info_password_activated		  = "Your Password already has been activated or it hasn't been arranged to change it. To login now, click on \"Login\".";

//Admin-Get Document
$get_document_error = "<font color=\"#FF0000\">The requested File does not exist.</font>";

//Admin-Index
$admin_title 	 				   = "Administration";
$info_admin_index 				   = "Welcome to the Administrations-Panel. Please choose an Action from the Menu.";
$description_admin_menu_settings   = "Settings";
$description_admin_menu_db		   = "Database";
$description_admin_menu_themes	   = "Themes";
$description_admin_menu_files	   = "Manage Files";
$description_admin_menu_categories = "Manage Categories";
$description_admin_menu_users	   = "Manage Users";
$description_admin_menu_mail	   = "Send E-Mail";

//Admin-Settings
$textfield_as_desc_1 				 	 = "<strong>Site-Name</strong>";
$textfield_as_desc_2 				 	 = "<strong>URL</strong>";
$textfield_as_desc_3 				 	 = "<strong>Admin-E-Mail</strong>";
$textfield_as_desc_4 				 	 = "<strong>Theme</strong>";
$textfield_as_desc_5 				 	 = "<strong>Language</strong>";
$textfield_as_desc_6  				 	 = "<strong>New Users become</strong>";
$textfield_as_desc_7  				 	 = "<strong>Max. Filesize Uploads</strong>";
$textfield_as_desc_8  				 	 = "<strong>Report new User</strong>";
$textfield_as_desc_9				 	 = "<strong>Report new Uploads</strong>";
$textfield_as_desc_10				 	 = "<strong>Version-Number</strong>";
$textfield_as_desc_11				 	 = "<strong>Install-Date</strong>";
$textfield_as_desc_12 				 	 = "<strong>Check Update</strong>";
$textfield_as_desc_13 				 	 = "<strong>Install Update</strong>";
$textfield_as_desc_14 				 	 = "<strong>Uninstall</strong>";
$info_as_validation   				 	 = "<font color=\"#FF0000\">One ore more required Fields are empty. Please complete your Information.</font>";
$info_admin_settings  				 	 = "The Changes have been successfully saved.";
$textfield_site_public_desc			 	 = "<strong>Site is public</strong>";
$textfield_lock_site_desc			 	 = "<strong>Lock Site</strong>";
$textfield_lock_site_reason_desc	 	 = "<strong>Reason</strong>";
$textfield_lock_register_desc	 	 	 = "<strong>Lock Registrations</strong>";
$textfield_lock_register_reason_desc 	 = "<strong>Reason</strong>";
$textfield_lock_upload_desc		 	 	 = "<strong>Lock Uploads</strong>";
$textfield_lock_upload_reason_desc	 	 = "<strong>Reason</strong>";
$textfield_lock_download_desc		 	 = "<strong>Lock Downloads</strong>";
$textfield_lock_download_reason_desc 	 = "<strong>Reason</strong>";
$textfield_lock_zip_download_desc	 	 = "<strong>Lock Zip-Downloads</strong>";
$textfield_lock_zip_download_reason_desc = "<strong>Reason</strong>";
$select_file_size_byte				 	 = "Byte";
$select_file_size_kb				 	 = "KB (Kilobyte)";
$select_file_size_mb				 	 = "MB (Megabyte)";
$select_file_size_gb				 	 = "GB (Gigabyte)";
$select_file_size_tb				 	 = "TB (Terabyte)";
$select_file_size_pb				 	 = "PB (Petabyte)";
$select_file_size_eb				 	 = "EB (Exabyte)";

//Admin-DB
$textfield_adb_desc_1  = "<strong>Database-Hostname</strong>";
$textfield_adb_desc_2  = "<strong>Database-Name</strong>";
$textfield_adb_desc_3  = "<strong>Database-Username</strong>";
$textfield_adb_desc_4  = "<strong>Database-Password</strong>";
$textfield_adb_desc_5  = "<strong>Table-Prefix</strong>";
$textfield_adb_desc_6  = "<strong>Table Configuration</strong>";
$textfield_adb_desc_7  = "<strong>Table Themes</strong>";
$textfield_adb_desc_8  = "<strong>Table User</strong>";
$textfield_adb_desc_9  = "<strong>Table Categories</strong>";
$textfield_adb_desc_10 = "<strong>Table Files</strong>";
$textfield_adb_desc_11 = "<strong>Table Filetypes</strong>";
$textfield_adb_desc_12 = "<strong>Optimize Tables</strong>";
$info_db_validation    = "<font color=\"#FF0000\">One ore more required Fields are empty. Please complete your Information.</font>";
$info_db_error1 	   = "<font color=\"#FF0000\">Database-Connection failed. Check, if the Database-Information are correct.</font>";
$info_db_error2 	   = "<font color=\"#FF0000\">File \"config.php\" could not be created. Check if the Directory \"config\" has the necessary Rights to write (777).</font>";
$info_db 			   = "The Changes have been successfully saved.";
$info_db_optimize	   = "All Tables have been successfully optimized.";
$info_backup_config    = "<strong>Attention</strong><br>Be sure, that the Database-Information are correct. If the Information are invalid, it is possible that you cannot get a Connection to the System any more. To avoid this, you can save the Configuration-File first. Then, you can recover it by uploading the File to the Directory \"config\".";

//Admin-Themes
$select_themes_edit    = "Manage Themes";
$select_themes_new     = "Create new Theme";
$info_themes_index	   = "Choose an Action.";
$info_themes_select	   = "Choose a Theme, that you want to edit.";
$textfield_at_desc_1   = "<strong>Theme-Name</strong>";
$textfield_at_desc_2   = "<strong>Theme-Description</strong>";
$textfield_at_desc_3   = "<strong>Theme-Directory</strong>";
$textfield_at_desc_4   = "<strong>Logo</strong>";
$textfield_at_desc_5   = "<strong>Background-Color</strong>";
$textfield_at_desc_6   = "<strong>Background-Image</strong>";
$textfield_at_desc_7   = "<strong>Results per Site</strong>";
$textfield_at_desc_8   = "<strong>Font-Family</strong>";
$textfield_at_desc_9   = "<strong>Font-Size</strong>";
$textfield_at_desc_10  = "<strong>Font-Color</strong>";
$textfield_at_desc_11  = "<strong>Font-Size Hyperlinks</strong>";
$textfield_at_desc_12  = "<strong>Font-Color Hyperlinks</strong>";
$textfield_at_desc_13  = "<strong>Table-Width</strong>";
$textfield_at_desc_14  = "<strong>Table-Color 1</strong>";
$textfield_at_desc_15  = "<strong>Table-Color 2</strong>";
$textfield_at_desc_16  = "<strong>Table-Color 3</strong>";
$textfield_at_desc_17  = "<strong>Table-Color 4</strong>";
$textfield_at_desc_18  = "<strong>Highlight Table-Color 1</strong>";
$textfield_at_desc_19  = "<strong>Highlight Table-Color 2</strong>";
$textfield_at_desc_20  = "<strong>Only Internet Explorer</strong>";
$textfield_at_desc_21  = "<strong>Delete Theme</strong>";
$textfield_at_desc_22  = "<strong>Selection</strong>";
$themes_select_yes	   = "Yes";
$themes_select_no	   = "No";
$info_te_validation	   = "<font color=\"#FF0000\">One ore more required Fields are empty. Please complete your Information.</font>";
$info_themes_edit	   = "The Changes have been successfully saved.";
$info_tn_validation	   = "<font color=\"#FF0000\">One ore more required Fields are empty. Please complete your Information.</font>";
$info_tn_error1		   = "<font color=\"#FF0000\">The Field \"$textfield_at_desc_7\" contains an invalid Value. The Value must be numerically and not under 1.<br>Please correct your Information.</font>";
$info_tn_error2		   = "<font color=\"#FF0000\">The Theme-Name you want to use already exists. Please choose another.</font>";
$info_tn_error3		   = "<font color=\"#FF0000\">The Theme you want to delete is actively in use.<br>To delete the Theme, you first have to activate another Theme in the $description_admin_menu_settings.</font>";
$info_themes_new	   = "The Theme has been successfully created.";
$info_themes_deleted   = "The Theme has been successfully deleted.";
$info_cn_validation    = "<font color=\"#FF0000\">One ore more required Fields are empty. Please complete your Information.</font>";

//Admin-Files, Filetypes
$description_filetype_name 		  = "<strong>Filetype</strong>";
$description_filetype_description = "<strong>Description</strong>";
$description_filetype_status	  = "<strong>Status</strong>";
$description_filetype_delete	  = "<strong>Delete</strong>";
$select_manage_files 	  		  = "Manage Files";
$select_manage_filetypes  		  = "Manage Filetypes";
$select_filetype_unlocked 		  = "Locked";
$select_filetype_locked   		  = "Unlocked";
$select_filetype_new	  		  = "Create Filetypes";
$info_files_index 		  		  = "Choose an Action.";
$info_filetypes_index  	  		  = "Here you can search for Filetypes.";
$textfield_af_desc_1 	  		  = "<strong>Selection</strong>";
$delete_confirm	  		  		  = "Do you really want to delete the File/s?";
$delete_success	  		  		  = "The selected File/s has/have been successfully deleted.";
$delete_error	  		  		  = "<font color=\"#FF0000\">No Files have been selected.</font>";
$info_new_filetype		  		  = "Here you can create a new Filetype.";
$textfield_filetypes_1	  		  = "<strong>Filetype</strong>";
$textfield_filetypes_2	  		  = "<strong>Description</strong>";
$textfield_filetypes_3	  		  = "<strong>Disallow Upload</strong>";
$textfield_filetypes_4	  		  = "<strong>Filetype-Status</strong>";
$textfield_filetypes_5	  		  = "<strong>Delete Filetype</strong>";
$filetype_status_unlocked		  = "<font color=\"#008800\">Unlocked</font>";
$filetype_status_locked			  = "<font color=\"#FF0000\">Locked</font>";
$info_filetypes_new	 	  		  = "The Filetype has been successfully created.";
$info_filetype_exists			  = "<font color=\"#FF0000\">The Filetype you want to create already exists.</font>";
$info_filetype_exists_2			  = "<font color=\"#FF0000\">The Filetype you want to use already exists.</font>";
$info_ft_validation   	  		  = "<font color=\"#FF0000\">One ore more required Fields are empty. Please complete your Information.</font>";
$delete_filetypes_success		  = "The selected Filetype/s has/have been successfully deleted.";
$delete_filetype_success  	      = "The Filetype has been successfully deleted.";
$delete_filetype_error 	  		  = "<font color=\"#FF0000\">No Filetypes have been selected.</font>";
$edit_filetype_success			  = "The Changes have been successfully saved.";
$delete_filetype_confirm		  = "Do you really want to delete the Filetype/s?";
$textfield_fe_lock				  = "<strong>Lock</strong>";

//Admin-Categories
$select_category_edit   = "Manage Categories";
$select_category_new    = "Create new Category";
$textfield_ac_desc_1	= "<strong>Selection</strong>";
$info_new_categories	= "Here you can create new Categories.";
$textfield_categories_1 = "<strong>Name</strong>";
$textfield_categories_2 = "<strong>Description</strong>";
$textfield_categories_3 = "<strong>In Maincategory</strong>";
$textfield_categories_4 = "<strong>Delete Category</strong>";
$info_categories_new	= "The Category has been successfully created.";
$info_categories_select	= "Choose a Category, that you want to edit.";
$info_category_deleted	= "The Category has been successfully deleted.";
$info_ce_validation		= "<font color=\"#FF0000\">One ore more required Fields are empty. Please complete your Information.</font>";
$info_cn_error			= "<font color=\"#FF0000\">The Category-Name you want to use already exists. Please choose another.</font>";
$info_cn_error2			= "<font color=\"#FF0000\">The Subcategory-Name you want to use in this Maincategory already exists. Please choose another.</font>";

//Admin-Users
$select_manage_users				= "Manage Users";
$select_new_user					= "Create new User";
$info_users_index 					= "Choose an Action.";
$textfield_au_desc_1				= "<strong>Selection</strong>";
$info_new_user						= "Here you can create a new User.";
$info_new_user_success				= "The User-Account has been successfully created.";
$delete_users_success 		  	 	= "The selected User/s has/have been successfully deleted.";
$delete_user_success				= "The User has been successfully deleted.";
$delete_users_error	  		  		= "<font color=\"#FF0000\">No Users have been selected.</font>";
$delete_user_confirm		  		= "Do you really want to delete the User/s?";
$textfield_lock_account_desc  		= "<strong>Lock Account</strong>";
$textfield_lock_account_reason_desc = "<strong>Reason</strong>";
$select_desc_admin					= "Admin";
$select_desc_downloader		  		= "Downloader";
$select_desc_downloader_uploader	= "Downloader/Uploader";
$select_desc_uploader				= "Uploader";
$select_desc_user					= "User";
$textfield_user_limit_file_size		= "<strong>Max. Filesize Uploads</strong>";
$textfield_logout_user				= "<strong>Logout User now</strong>";
$textfield_not_logged_in			= "The User is not logged in";

//Admin-Mail
$info_mail 			   	= "Here you can send a Message to Users.";
$textfield_mail_desc_1 	= "<strong>Group</strong>";
$textfield_mail_desc_2 	= "<strong>Separate Receiver</strong>";
$textfield_mail_desc_3 	= "<strong>Priority</strong>";
$textfield_mail_desc_4 	= "<strong>Subject</strong>";
$textfield_mail_desc_5 	= "<strong>Content</strong>";
$select_priority_low	= "Low";
$select_priority_normal = "Normal";
$select_priority_high	= "High";
$select_no_group		= "Send to no Group";
$select_all_groups		= "Send to all Users";
$mail_header1			= "Hello,<p>you receive this Message, because you are a registered User of";
$mail_header2			= ". See the Message of the Administrator below:";
$mail_footer			= "Best Regards";
$info_mail_success		= "The Message has been successfully sent.";
$file_attachment		= "<strong>Attachment</strong>";
$info_mail_validation	= "<font color=\"#FF0000\">One ore more required Fields are empty. Please complete your Information.</font>";
$info_mail_no_group		= "<font color=\"#FF0000\">The Message has not been sent. The selected Group doesn't have any Users.</font>";
$info_mail_no_group2	= "The Message has been sent to the Separate Receiver only. The selected Group doesn't have any Users.";
$progress_message_mail	= "The E-Mail is being send.";

//Admin-Update
$info_install_update_1    = "<br><strong>New Update can be installed</strong><p>A newer Version as the one you currently use, has been detected.<p>The Version you currently use is:";
$info_install_update_2    = "The Version you can update to is:";
$info_install_update_3    = "If you want to install the Update now, click on \"Install\".";
$info_update_success      = "<br>The Update has been successfully installed.";
$info_update_error        = "<br><font color=\"#FF0000\">The Update has not been finished.<p><strong>Error</strong><br></font>";
$info_update_error1       = "<font color=\"#FF0000\">- Connection to Database failed. Check if the Database-Information are correct.</font>";
$info_update_error2       = "<font color=\"#FF0000\">- Could not create \"config.php\". Check if the Directory \"config\" and the File \"config.php\" have the neccessary Rights to write (777).</font>";
$info_update_error3       = "<font color=\"#FF0000\">- Could not create the Directory \"temp\". Check if the Directory \"files\" has the neccessary Rights to write (777).</font>";
$info_no_update	          = "<br>No Updates available.";

//Admin-Uninstall
$info_uninstall  		  = "<br><strong>Attention</strong><br>This will remove the System. All Data will be deleted. Click on \"Uninstall\", if you want to remove the System now.";
$info_uninstall_success   = "<br>The De-Installation has been successfully finished. Remove the File-Directory manually. Click on \"Close\", to leave the System.";
$uninstall_confirm		  = "Do you really want to uninstall the System?";
$info_uninstall_error     = "<br><font color=\"#FF0000\">The De-Installation has not been finished.<p><strong>Error</strong><br></font>";
$info_uninstall_error1    = "<font color=\"#FF0000\">- File \"config.php\" not found.</font>";
$info_uninstall_error2    = "<font color=\"#FF0000\">- Connection to Database failed. Check if the Database-Information are correct.</font>";
$info_uninstall_no_action = "<br><font color=\"#FF0000\">No Action has been choosen.</font>";

//Buttons
$button_back			= "< Back ";
$button_next			= " Next >";
$button_cancel			= "Cancel";
$button_install			= "Install";
$button_start			= "Start";
$button_login			= "Login";
$button_upload			= "Upload";
$button_reset			= "Reset";
$button_search			= "Search";
$button_save			= "Save";
$button_edit 			= "Edit";
$button_show_categories = "Show Categories";
$button_search_files	= "Search Files";
$button_show			= "Show";
$button_delete			= "Delete";
$button_send			= "Send";
$button_zip				= " Zip ";
$button_per_site		= "Per Site";
$button_execute			= "Execute";
$button_ok				= "   OK   ";
$button_uninstall		= "Uninstall";
$button_close			= "Close";

//Links
$logout 	   	     = "Logout";
$link_upload   	     = "Upload";
$link_search   	     = "Search";
$link_admin    	     = "Administration";
$link_index 	     = "Index";
$link_sign_up 	     = "Register";
$link_new_password   = "Forgot Password";
$link_check_update   = "Check for Updates now";
$link_install_update = "Install Update now";
$link_uninstall		 = "Uninstall System now";
$link_backup_config  = "Save now";
$link_download_now	 = "Download now";
$link_show_uploads	 = "Show all Uploads of this User";
$link_userlist		 = "Userlist";
$link_my_profil		 = "My Profile";
$link_user_image	 = "Show User-Image";
$link_activation 	 = "<strong>Activate now</strong>";
$link_download_show  = "Show now";
$link_edit			 = "Edit";
$link_public_area	 = "Public Area";
$link_login			 = "Login";

//Link Title

//Admin-Menu
$link_desc_admin_menu_settings 	 = "Here you can edit the System-Settings";
$link_desc_admin_menu_db 		 = "Here you can edit the Database-Settings";
$link_desc_admin_menu_themes 	 = "Here you can manage Themes";
$link_desc_admin_menu_files 	 = "Here you can manage Files";
$link_desc_admin_menu_categories = "Here you can manage Categories";
$link_desc_admin_menu_users 	 = "Here you can manage Users";
$link_desc_admin_menu_mail 		 = "Here you can send E-Mails";

//Categories
$link_desc_category_maincategory = "Sort by Maincategory";
$link_desc_category_subcategory  = "Sort by Subcategory";
$link_desc_category_description  = "Sort by Description";

//Files
$link_desc_file_subject 		= "Sort by Title";
$link_desc_file_description 	= "Sort by Description";
$link_desc_file_name			= "Sort by Filename";
$link_desc_file_size 			= "Sort by Filesize";
$link_desc_file_extension 		= "Sort by Filetype";
$link_desc_file_date 			= "Sort by Upload-Date";
$link_desc_file_delete 			= "Select multiple Files for Deletion";
$link_desc_file_zip 			= "Select multiple Files for Downloading";
$link_desc_filetype_name		= "Sort by Filetype";
$link_desc_filetype_description	= "Sort by Description";
$link_desc_filetype_delete		= "Select multiple Filetypes for Deletion";
$link_desc_filetype_unlocked	= "Unlocked";
$link_desc_filetype_locked		= "Locked";

//Users
$link_desc_user_name 	  = "Sort by Username";
$link_desc_user_firstname = "Sort by Firstname";
$link_desc_user_lastname  = "Sort by Lastname";
$link_desc_user_email 	  = "Sort by E-Mail";
$link_desc_user_website   = "Sort by Website";
$link_desc_user_delete 	  = "Select multiple Users for Deletion";
$link_desc_user_online 	  = "Online";
$link_desc_user_offline	  = "Offline";
$link_desc_user_whois	  = "Whois";
$link_desc_user_ripe_ncc  = "RIPE NCC";
$link_desc_user_arin	  = "ARIN";
$link_desc_user_lapnic	  = "LAPNIC";
$link_desc_user_apnic	  = "APNIC";

?>