<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

//Global
$yes = "Ja";
$no	 = "Nein";
$download  = "Download";
$downloads = "Downloads";
$info_browser_detection = "<font color=\"#FF0000\">Sie verwenden den falschen Browser.<br>Diese Seiten wurden f&uuml;r Internet Explorer optimiert.</font>";

//Session
$info_login_error1 				= "<font color=\"#FF0000\">Fehler. Ihre Anmeldeinformationen waren nicht korrekt.<br>Bitte versuchen Sie es erneut.</font>";
$info_login_error2 		 		= "<font color=\"#FF0000\">Fehler. Sie sind nicht angemeldet.<br>Bitte loggen Sie sich ein.</font>";
$info_login_error3				= "<font color=\"#FF0000\">Fehler. Ihr Account wurde noch nicht aktiviert.<br>Bitte aktivieren Sie diesen zuerst.</font>";
$info_user_locked  				= "<font color=\"#FF0000\">Ihr Account wurde vom Administrator gesperrt.<p><strong>Hinweis des Administrators:</strong><br></font>";
$info_user_locked_no_reason 	= "<font color=\"#FF0000\">Es wurde keine Begr&uuml;ndung angegeben.</font>";
$info_logout	 				= "Sie wurden erfolgreich abgemeldet. Um sich erneut anzumelden, klicken Sie auf \"Anmelden\".";
$info_site_locked  				= "<font color=\"#FF0000\">Die Site wurde vom Administrator gesperrt.<p><strong>Hinweis des Administrators:</strong><br></font>";
$info_site_locked_no_reason		= "<font color=\"#FF0000\">Es wurde keine Begr&uuml;ndung angegeben.</font>";
$info_register_locked			= "<font color=\"#FF0000\">Das Registrieren wurde vom Administrator gesperrt.<p><strong>Hinweis des Administrators:</strong><br></font>";
$info_register_locked_reason	= "<font color=\"#FF0000\">Es wurde keine Begr&uuml;ndung angegeben.</font>";
$info_upload_locked  			= "<font color=\"#FF0000\">Das Uploaden wurde vom Administrator gesperrt.<p><strong>Hinweis des Administrators:</strong><br></font>";
$info_upload_locked_no_reason	= "<font color=\"#FF0000\">Es wurde keine Begr&uuml;ndung angegeben.</font>";
$info_download_locked  			= "<font color=\"#FF0000\">Das Downloaden wurde vom Administrator gesperrt.<p><strong>Hinweis des Administrators:</strong><br></font>";
$info_download_locked_no_reason = "<font color=\"#FF0000\">Es wurde keine Begr&uuml;ndung angegeben.</font>";
$info_admin						= "<font color=\"#FF0000\">Fehler. Sie haben nicht die erforderlichen Rechte, um diese Seite anzuzeigen.</font>";

//Fields
$field_logout 			 = "Logout";
$field_login  			 = "Anmeldung";
$field_as_1	  			 = "Einstellungen";
$field_as_2	  			 = "Benachrichtigung";
$field_as_3	  			 = "Installation";
$field_adb_1  			 = "Datenbank-Verbindung";
$field_adb_2  			 = "Tabellen-Informationen";
$field_adb_3			 = "Optimieren";
$field_at_1	  			 = "Theme-Informationen";
$field_at_2	  			 = "Site-Layout";
$field_at_3	  			 = "Schriftoptionen";
$field_at_4	  			 = "Tabellen-Layout";
$field_at_5	  			 = "Kompatibilit&auml;t";
$field_at_6	  			 = "L&ouml;schen";
$field_ti_1	  			 = "Aktion";
$field_ts_1	  			 = "Auswahl";
$field_fi_1	  			 = "Aktion";
$field_search 			 = "Suche";
$field_show	  			 = "Anzeige";
$field_sf_1	  			 = "Download";
$field_sf_2	  			 = "Dateiangaben";
$field_sf_3	  			 = "Aktion";
$field_fe_1	  			 = "L&ouml;schen";
$field_eup_1  			 = "Benutzerangaben";
$field_user_pic 		 = "Benutzerbild";
$field_maincategory 	 = "Hauptkategorie anlegen";
$field_subcategory  	 = "Subkategorie anlegen";
$field_maincategory_edit = "Hauptkategorie bearbeiten";
$field_subcategory_edit  = "Subkategorie bearbeiten";
$field_categories_edit	 = "Kategorie bearbeiten";
$field_receiver			 = "Nachrichtenempf&auml;nger";
$field_mail_content		 = "Nachricht";
$field_options			 = "Optionen";
$field_information		 = "Informationen";
$field_lock			 	 = "Sperren";
$field_delete  			 = "L&ouml;schen";
$field_ue	  			 = "Aktion";
$field_install_update	 = "Update installieren";
$field_ui_1				 = "Aktion";
$field_ci_1				 = "Aktion";
$field_filetype			 = "Dateityp-Informationen";
$field_uninstall		 = "De-Installation";

//Files, Categories
$description_file_subject 	   = "<strong>Titel</strong>";
$description_file_description  = "<strong>Beschreibung</strong>";
$description_file_name 		   = "<strong>Dateiname</strong>";
$description_file_size 		   = "<strong>Dateigr&ouml;&szlig;e</strong>";
$description_file_extension	   = "<strong>Dateityp</strong>";
$description_file_date 		   = "<strong>Upload-Datum</strong>";
$description_file_delete	   = "<strong>L&ouml;schen</strong>";
$description_file_zip_download = "<strong>Zip-Download</strong>";
$description_maincategory	   = "<strong>Hauptkategorie</strong>";
$description_subcategory	   = "<strong>Subkategorie</strong>";
$description_description	   = "<strong>Beschreibung</strong>";
$description_downloads		   = "<strong>Downloads</strong>";
$zip_error	  				   = "<font color=\"#FF0000\">Es wurden keine Dateien ausgew&auml;hlt.</font>";
$zip_error2	  				   = "<font color=\"#FF0000\">Fehler. Die Zip-Datei konnte nicht erstellt werden.<br>Das Verzeichnis \"temp\" besitzt m&ouml;glicherweise nicht die erforderlichen Schreibrechte (777) oder die Datei ist zu gro�.<br>Wenden Sie sich an den Administrator.</font>";
$info_zip_download_locked	   = "<font color=\"#FF0000\">Die Zip-Download-Funktion wurde vom Administrator gesperrt.<p><strong>Hinweis des Administrators:</strong><br></font>";
$info_zip_locked_no_reason     = "<font color=\"#FF0000\">Es wurde keine Begr&uuml;ndung angegeben.</font>";
$user_id					   = "User-ID";

//Categories, Upload-Select, Show File, Upload-Edit, Edit User-Profile
$textfield_us_desc_1  	    = "<strong>Hauptkategorie</strong>";
$textfield_us_desc_2  	    = "<strong>Subkategorie</strong>";
$textfield_us_desc_3  	    = "<strong>Titel</strong>";
$textfield_us_desc_4  	    = "<strong>Beschreibung</strong>";
$textfield_us_desc_5  	    = "<strong>Datei austauschen</strong>";
$textfield_us_desc_6   	    = "<strong>Datei aktuell</strong>";
$textfield_us_desc_7  	    = "<strong>Zuletzt ge&auml;ndert</strong>";
$textfield_us_desc_8        = "<strong>Upload von User</strong>";
$textfield_us_desc_9  	    = "<strong>Datei</strong>";
$textfield_us_desc_10 	    = "<strong>Auswahl</strong>";
$textfield_us_desc_11	    = "<strong>Upload l&ouml;schen</strong>";
$textfield_us_desc_12	    = "<strong>Anzeige</strong>";
$textfield_us_dc			= "<strong>Bisherige Downloads</strong>";
$info_file_edit			    = "Keine &Auml;nderungen seit dem Upload";
$delete_file_success  	    = "Der Upload wurde erfolgreich gel&ouml;scht.";
$no_user				    = "Der User existiert nicht mehr";
$new_upload_report_subject  = "Neuer Upload auf";
$new_upload_report_content1 = "Hallo";
$new_upload_report_content2 = "es wurde eine neue Datei auf";
$new_upload_report_content3 = "hochgeladen. Hier die Daten:";
$info_upload_maincategory	= "W&auml;hlen Sie eine Hauptkategorie, unter welcher Sie den neuen Download erstellen m&ouml;chten.";
$info_upload_subcategory 	= "W&auml;hlen Sie eine Subtkategorie, unter welcher Sie den neuen Download erstellen m&ouml;chten.";
$info_upload_error			= "<font color=\"#FF0000\">Fehler. Die Datei die Sie hochladen m&ouml;chten ist zu gro&szlig;.<br>Das globale Upload-Limit betr&auml;gt</font>";
$info_upload_error_user		= "<font color=\"#FF0000\">Fehler. Die Datei die Sie hochladen m&ouml;chten ist zu gro&szlig;.<br>Ihr Upload-Limit betr&auml;gt</font>";
$info_user_image_error1		= "<font color=\"#FF0000\">Fehler. Das Benutzerbild das Sie hochladen m&ouml;chten ist zu gro&szlig;.<br>Zul&auml;ssige Gr&ouml;&szlig;e: 100 KB.</font>";
$info_user_image_error2		= "<font color=\"#FF0000\">Fehler. Das Benutzerbild das Sie hochladen m&ouml;chten hat das falsche Format.<br>Es ist nur das JPEG-Format zugelassen.</font>";
$info_user_image_error3		= "<font color=\"#FF0000\">Fehler. Das Benutzerbild das Sie hochladen m&ouml;chten hat die falschen Ma&szlig;e.<br>Zul&auml;ssige Maximal-Daten: B: 190 x H: 220.</font>";
$info_no_maincategory_1		= "Willkommen auf";
$info_no_maincategory_2		= "Es steht keine Hauptkategorie zur Verf&uuml;gung.<br>Damit Dateien verwaltet werden k&ouml;nnen, muss der Administrator Kategorien im Administrationsmen&uuml; erstellen.";
$info_no_subcategory		= "Es steht keine Subkategorie in dieser Hauptkategorie zur Verf&uuml;gung.<br>Damit Dateien verwaltet werden k&ouml;nnen, muss der Administrator eine Subkategorie im Administrationsmen&uuml; erstellen.";

//Login
$textfield_login_desc_1 = "<strong>Benutzername</strong>";
$textfield_login_desc_2 = "<strong>Passwort</strong>";

//Upload
$info_upload	  		= "Der Upload war erfolgreich.";
$info_upload_edit		= "Die &Auml;nderungen wurden erfolgreich gespeichert.";
$info_upload_validation = "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";
$info_upload_error1		= "<font color=\"#FF0000\">Fehler. Der Upload war nicht erfolgreich. Das Verzeichnis \"files\" besitzt m&ouml;glicherweise nicht die erforderlichen Schreibrechte (777).<br>Wenden Sie sich an den Administrator.</font>";
$info_upload_error2		= "<font color=\"#FF0000\">Fehler. Sie haben nicht die erforderlichen Rechte, um Dateien hoch zu laden.</font>";
$info_upload_error3		= "<font color=\"#FF0000\">Die Datei die Sie hochladen m&ouml;chten oder der Titel den Sie angegeben haben existiert bereits.<br>Bitte korrigieren Sie Ihre Angaben.</font>";
$info_upload_error4		= "<font color=\"#FF0000\">Fehler. Der Dateityp den Sie hochladen m&ouml;chten ist nicht zugelassen.</font>";
$progress_message		= "Die Informationen werden gespeichert.";

//Download
$info_download_error1 = "<font color=\"#FF0000\">Fehler. Sie haben nicht die erforderlichen Rechte, um Dateien herunter zu laden.</font>";

//Search
$info_search		 	 = "Hier k&ouml;nnen Sie nach Dateien suchen.";
$textfield_search_desc_1 = "<strong>Alles anzeigen</strong>";
$textfield_search_desc_2 = "<strong>Hauptkategorie</strong>";
$textfield_search_desc_3 = "<strong>Subkategorie</strong>";
$textfield_search_desc_4 = "<strong>Suchbegriff</strong>";
$textfield_search_desc_5 = "<strong>Suchoption</strong>";
$textfield_search_desc_6 = "<strong>Nicht aktivierte Accounts</strong>";
$textfield_search_desc_7 = "<strong>Gruppen anzeigen</strong>";
$select_search_1_1		 = "Alles durchsuchen";
$select_search_1_2		 = "Nur nach Titel durchsuchen";
$select_search_1_3		 = "Nur nach Beschreibung durchsuchen";
$select_search_1_4		 = "Nur nach Dateinamen durchsuchen";
$select_search_1_5		 = "Nur nach Dateigr&ouml;&szlig;e durchsuchen";
$select_search_1_6		 = "Nur nach Dateityp durchsuchen";
$select_search_1_7		 = "Nur nach Datum durchsuchen";
$select_search_1_8		 = "Nur nach Hauptkategorie durchsuchen";
$select_search_1_9		 = "Nur nach Subkategorie durchsuchen";

//User
$textfield_user_name_desc	    	= "<strong>Username</strong>";
$textfield_user_pw			    	= "<strong>Passwort</strong>";
$textfield_user_pw_ch_desc	    	= "<strong>Passwort &auml;ndern</strong>";
$textfield_user_pw_rep_desc     	= "<strong>Passwort wiederholen</strong>";
$textfield_user_group_desc	    	= "<strong>Benutzergruppe</strong>";
$textfield_user_firstname_desc  	= "<strong>Vorname</strong>";
$textfield_user_lastname_desc   	= "<strong>Nachname</strong>";
$textfield_user_email_desc	    	= "<strong>E-Mail</strong>";
$textfield_user_website_desc    	= "<strong>Website</strong>";
$textfield_user_birthday_desc   	= "<strong>Geburtsdatum</strong>";
$textfield_user_gender_desc	    	= "<strong>Geschlecht</strong>";
$textfield_user_country_desc    	= "<strong>Land</strong>";
$textfield_user_state_desc	    	= "<strong>Bundesland</strong>";
$textfield_user_zipcode_desc    	= "<strong>Postleitzahl</strong>";
$textfield_user_city_desc	    	= "<strong>Stadt</strong>";
$textfield_user_street_desc	    	= "<strong>Strasse</strong>";
$textfield_user_phone_desc	    	= "<strong>Telefon</strong>";
$textfield_user_fax_desc	    	= "<strong>Fax</strong>";
$textfield_user_register_desc   	= "<strong>Registrierungsdatum</strong>";
$textfield_user_last_login_date 	= "<strong>Letzter Login</strong>";
$textfield_user_last_remote_address = "<strong>Letzte IP-Adresse</strong>";
$textfield_user_last_user_agent 	= "<strong>Letzter User-Agent</strong>";
$textfield_user_whois_ip_address	= "<strong>Whois IP-Adresse</strong>";
$textfield_user_activated_desc  	= "<strong>Account aktiviert</strong>";
$textfield_user_mobile_desc	    	= "<strong>Mobil</strong>";
$textfield_user_status_desc	    	= "<strong>Status</strong>";
$textfield_user_online_desc	    	= "<font color=\"#008800\">Online</font>";
$textfield_user_offline_desc    	= "<font color=\"#FF0000\">Offline</font>";
$textfield_user_uploads_desc    	= "<strong>Uploads</strong>";
$info_user_list				    	= "Hier k&ouml;nnen Sie nach Usern suchen.";
$textfield_user_email_pub_desc  	= "&Ouml;ffentlich";
$textfield_delete_account_desc  	= "<strong>Account l&ouml;schen</strong>";
$select_desc_gender_female	    	= "Weiblich";
$select_desc_gender_male	    	= "M&auml;nnlich";
$info_pw_validation			    	= "<font color=\"#FF0000\">Die Passw&ouml;rter stimmen nicht &uuml;berein. Bitte &uuml;berpr&uuml;fen Sie Ihre Angaben.</font>";
$info_user_image			    	= "Maximal-Daten: B: 190 x H: 220, Gr&ouml;&szlig;e: 100 KB, JPEG";
$textfield_del_user_image_desc  	= "<strong>Bild l&ouml;schen</strong>";
$no_user_image				    	= "<strong><font color=\"#FFFFFF\">Kein Bild vorhanden</font></strong>";
$no_user_email				    	= "Nicht &ouml;ffentlich";
$no_data					    	= "Keine Angaben";
$info_sign_up				    	= "Hier k&ouml;nnen Sie sich registrieren. Die mit einem Stern markierten Felder sind Pflichtfelder.";
$no_login							= "Kein Login seit der Registrierung";

//Edit User-Profile
$info_upe_validation 	= "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";
$delete_account_success = "Ihr Account wurde erfolgreich gel&ouml;scht.";

//Search User
$select_search_user_1_1	 = "Alles durchsuchen";
$select_search_user_1_2	 = "Nur nach Usernamen durchsuchen";
$select_search_user_1_3	 = "Nur nach Vornamen durchsuchen";
$select_search_user_1_4	 = "Nur nach Nachnamen durchsuchen";
$select_search_user_1_5	 = "Nur nach E-Mail durchsuchen";
$select_search_user_1_6	 = "Nur nach Website durchsuchen";
$select_search_user_1_7	 = "Nur nach Geburtstag durchsuchen";
$select_search_user_1_8	 = "Nur nach Stadt durchsuchen";
$select_search_user_1_9	 = "Nur nach Land durchsuchen";
$select_search_user_1_10 = "Nur nicht aktivierte Accounts durchsuchen";

//Header
$info_header1 = "Willkommen auf";
$info_header2 = "- Dem Filemanager";

//Sign Up
$info_sign_up_success	   	  = "Ihr User-Account wurde erfolgreich angelegt.<br>Sie erhalten eine E-Mail mit einem Aktivierungs-Link. Damit Sie sich mit Ihren Benutzerdaten anmelden k&ouml;nnen, m&uuml;ssen Sie den Account zuerst aktivieren.<br>Rufen Sie dazu Ihre E-Mails ab und klicken in der Benachrichtigungs-E-Mail auf den Aktivierungslink.<br>Anschlie&szlig;end k&ouml;nnen Sie sich mit Ihren Benutzerdaten anmelden.<p>Haben Sie Ihren Account bereits aktiviert, klicken Sie unten auf \"Anmelden\".";
$activation_email_subject  	  = "Ihre Anmeldung bei";
$activation_email_content1 	  = "Hallo";
$activation_email_content2 	  = "vielen Dank f&uuml;r die Registrierung bei";
$activation_email_content3 	  = "Damit Sie sich mit Ihren Benutzerdaten anmelden k&ouml;nnen, m&uuml;ssen Sie den Account zuerst aktivieren. Klicken Sie auf \"Jetzt aktivieren\" um Ihren Account zu aktivieren. Anschlie&szlig;end k&ouml;nnen Sie sich mit Ihren Benutzerdaten anmelden.";
$info_user_activation_success = "Die Aktivierung war erfolgreich. Um sich anzumelden, klicken Sie auf \"Anmelden\".";
$info_user_activation_error	  = "<font color=\"#FF0000\">Die Aktivierung war nicht erfolgreich. Der Aktivierungscode ist ung&uuml;ltig.<br>Wenden Sie sich an den Administrator.</font>";
$info_user_activated		  = "Ihr Account wurde bereits aktiviert. Um sich anzumelden, klicken Sie auf \"Anmelden\".";
$info_su_validation			  = "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";
$new_user_report_content1	  = "Hallo";
$new_user_report_content2	  = "ein neuer User hat sich auf";
$new_user_report_content3	  = "registriert. Hier die Daten des Users:";
$new_user_report_subject	  = "Neuer User auf";
$info_user_exists			  = "<font color=\"#FF0000\">Der Benutzername den Sie verwenden m&ouml;chten wird bereits verwendet. Bitte w&auml;hlen Sie einen anderen.</font>";

//New Password
$info_new_password		 	 	  = "Wenn Sie Ihr Passwort vergessen haben, k&ouml;nnen Sie sich hier ein neues zuschicken lassen indem Sie Ihren Benutzernamen und Ihre E-Mail-Adresse angeben.<br>Das neue Passwort muss zuerst aktiviert werden, bevor es verwendet werden kann.";
$info_np_validation		 		  = "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";
$info_np_send_success	 	 	  = "Das neue Passwort wurde Ihnen zugeschickt. Damit dieses g&uuml;ltig wird, m&uuml;ssen Sie es zuerst aktivieren.<br>Rufen Sie dazu Ihre E-Mails ab und klicken auf den Aktivierungslink.<p>Um sich anzumelden, klicken Sie auf \"Anmelden\".";
$info_new_password_error 	 	  = "<font color=\"#FF0000\">Fehler. Die Benutzerangaben sind nicht korrekt.</font>";
$new_password_email_subject  	  = "Ihr neues Passwort bei";
$new_password_email_content1 	  = "Hallo";
$new_password_email_content2 	  = "Sie haben veranlasst, dass Ihr Passwort ge&auml;ndert werden soll. Ihr neues Passwort lautet:";
$new_password_email_content3 	  = "Damit Ihr neues Passwort g&uuml;ltig wird, m&uuml;ssen Sie es zuerst aktivieren. Klicken Sie auf \"Jetzt aktivieren\" um Ihr neues Passwort zu aktivieren.";
$new_password_email_content4 	  = "Es wird empfohlen, dass Sie Ihr Passwort nach der ersten Anmeldung wieder &auml;ndern.<br>M&ouml;chten Sie Ihr Passwort doch nicht &auml;ndern oder Sie haben nicht veranlasst, dass Ihr Passwort ge&auml;ndert werden soll, ignorieren Sie diese Nachricht einfach.";
$info_password_activation_success = "Die Aktivierung war erfolgreich. Um sich anzumelden, klicken Sie auf \"Anmelden\".";
$info_password_activation_error	  = "<font color=\"#FF0000\">Die Aktivierung war nicht erfolgreich. Der Benutzername, die E-Mail-Adresse oder das Passwort ist ung&uuml;ltig.<br>Wenden Sie sich an den Administrator.</font>";
$info_password_activated		  = "Ihr Paswort wurde bereits ge&auml;ndert oder es wurde nicht veranlasst es zu &auml;ndern. Um sich anzumelden, klicken Sie auf \"Anmelden\".";

//Admin-Get Document
$get_document_error = "<font color=\"#FF0000\">Die angeforderte Datei existiert nicht.</font>";

//Admin-Index
$admin_title 	 				   = "Administration";
$info_admin_index 				   = "Willkommen im Administrationsbereich. Bitte w&auml;hlen Sie eine Aktion aus dem Men&uuml;.";
$description_admin_menu_settings   = "Einstellungen";
$description_admin_menu_db		   = "Datenbank";
$description_admin_menu_themes	   = "Themes";
$description_admin_menu_files	   = "Dateien verwalten";
$description_admin_menu_categories = "Kategorien verwalten";
$description_admin_menu_users	   = "User verwalten";
$description_admin_menu_mail	   = "E-Mail senden";

//Admin-Settings
$textfield_as_desc_1 				 	 = "<strong>Site-Name</strong>";
$textfield_as_desc_2 				 	 = "<strong>URL</strong>";
$textfield_as_desc_3 				 	 = "<strong>Admin-E-Mail</strong>";
$textfield_as_desc_4 				 	 = "<strong>Theme</strong>";
$textfield_as_desc_5 				 	 = "<strong>Sprache</strong>";
$textfield_as_desc_6  				 	 = "<strong>Neue User werden</strong>";
$textfield_as_desc_7  				 	 = "<strong>Max. Dateigr&ouml;&szlig;e Uploads</strong>";
$textfield_as_desc_8  				 	 = "<strong>Neue User melden</strong>";
$textfield_as_desc_9				 	 = "<strong>Neue Uploads melden</strong>";
$textfield_as_desc_10				 	 = "<strong>Versionsnummer</strong>";
$textfield_as_desc_11				 	 = "<strong>Installationsdatum</strong>";
$textfield_as_desc_12 				 	 = "<strong>Update pr&uuml;fen</strong>";
$textfield_as_desc_13 				 	 = "<strong>Neues Update</strong>";
$textfield_as_desc_14 				 	 = "<strong>De-Installieren</strong>";
$info_as_validation   				 	 = "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";
$info_admin_settings  				 	 = "Die &Auml;nderungen wurden erfolgreich gespeichert.";
$textfield_site_public_desc			 	 = "<strong>Site ist &ouml;ffentlich</strong>";
$textfield_lock_site_desc			 	 = "<strong>Site sperren</strong>";
$textfield_lock_site_reason_desc	 	 = "<strong>Begr&uuml;ndung</strong>";
$textfield_lock_register_desc	 	 	 = "<strong>Registrierungen sperren</strong>";
$textfield_lock_register_reason_desc 	 = "<strong>Begr&uuml;ndung</strong>";
$textfield_lock_upload_desc		 	 	 = "<strong>Uploads sperren</strong>";
$textfield_lock_upload_reason_desc	 	 = "<strong>Begr&uuml;ndung</strong>";
$textfield_lock_download_desc		 	 = "<strong>Downloads sperren</strong>";
$textfield_lock_download_reason_desc 	 = "<strong>Begr&uuml;ndung</strong>";
$textfield_lock_zip_download_desc	 	 = "<strong>Zip-Downloads sperren</strong>";
$textfield_lock_zip_download_reason_desc = "<strong>Begr&uuml;ndung</strong>";
$select_file_size_byte				 	 = "Byte";
$select_file_size_kb				 	 = "KB (Kilobyte)";
$select_file_size_mb				 	 = "MB (Megabyte)";
$select_file_size_gb				 	 = "GB (Gigabyte)";
$select_file_size_tb				 	 = "TB (Terabyte)";
$select_file_size_pb				 	 = "PB (Petabyte)";
$select_file_size_eb				 	 = "EB (Exabyte)";

//Admin-DB
$textfield_adb_desc_1  = "<strong>Datenbank-Hostname</strong>";
$textfield_adb_desc_2  = "<strong>Datenbank-Name</strong>";
$textfield_adb_desc_3  = "<strong>Datenbank-Username</strong>";
$textfield_adb_desc_4  = "<strong>Datenbank-Passwort</strong>";
$textfield_adb_desc_5  = "<strong>Tabellen-Prefix</strong>";
$textfield_adb_desc_6  = "<strong>Tabelle Konfiguration</strong>";
$textfield_adb_desc_7  = "<strong>Tabelle Themes</strong>";
$textfield_adb_desc_8  = "<strong>Tabelle User</strong>";
$textfield_adb_desc_9  = "<strong>Tabelle Kategorien</strong>";
$textfield_adb_desc_10 = "<strong>Tabelle Dateien</strong>";
$textfield_adb_desc_11 = "<strong>Tabelle Dateitypen</strong>";
$textfield_adb_desc_12 = "<strong>Tabellen optimieren</strong>";
$info_db_validation    = "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";
$info_db_error1 	   = "<font color=\"#FF0000\">Verbindung zur Datenbank fehlgeschlagen. Pr&uuml;fen Sie, ob Sie die Datenbank-Informationen korrekt angegeben haben.</font>";
$info_db_error2 	   = "<font color=\"#FF0000\">Datei \"config.php\" konnte nicht angelegt werden. Pr&uuml;fen Sie, ob das Verzeichnis \"config\" die erforderlichen Schreibrechte besitzt (777).</font>";
$info_db 			   = "Die &Auml;nderungen wurden erfolgreich gespeichert.";
$info_db_optimize	   = "Alle Tabellen wurden erfolgreich optimiert.";
$info_backup_config    = "<strong>Achtung</strong><br>Achten Sie darauf, dass die Datenbank-Inforamtionen korrekt sind. Werden falsche Angaben gemacht kann es sein, dass Sie keine Verbindung mehr bekommen. Um dies zu vermeiden, k&ouml;nnen Sie die Konfigurationsdatei vorher sichern. Sie k&ouml;nnen diese anschlie&szlig;end wieder herstellen, indem Sie die Datei per FTP in das Verzeichnis \"config\" hochladen.";

//Admin-Themes
$select_themes_edit	   = "Themes verwalten";
$select_themes_new	   = "Neues Theme erstellen";
$info_themes_index	   = "W&auml;hlen Sie eine Aktion.";
$info_themes_select	   = "W&auml;hlen Sie ein Theme, das Sie bearbeiten m&ouml;chten.";
$textfield_at_desc_1   = "<strong>Theme-Name</strong>";
$textfield_at_desc_2   = "<strong>Theme-Beschreibung</strong>";
$textfield_at_desc_3   = "<strong>Theme-Verzeichnis</strong>";
$textfield_at_desc_4   = "<strong>Logo</strong>";
$textfield_at_desc_5   = "<strong>Hintergrundfarbe</strong>";
$textfield_at_desc_6   = "<strong>Hintergrundbild</strong>";
$textfield_at_desc_7   = "<strong>Ergebnisse pro Seite</strong>";
$textfield_at_desc_8   = "<strong>Schriftart</strong>";
$textfield_at_desc_9   = "<strong>Schriftgr&ouml;&szlig;e</strong>";
$textfield_at_desc_10  = "<strong>Schriftfarbe</strong>";
$textfield_at_desc_11  = "<strong>Schriftgr&ouml;&szlig;e Hyperlinks</strong>";
$textfield_at_desc_12  = "<strong>Schriftfarbe Hyperlinks</strong>";
$textfield_at_desc_13  = "<strong>Tabellenbreite</strong>";
$textfield_at_desc_14  = "<strong>Tabellenfarbe 1</strong>";
$textfield_at_desc_15  = "<strong>Tabellenfarbe 2</strong>";
$textfield_at_desc_16  = "<strong>Tabellenfarbe 3</strong>";
$textfield_at_desc_17  = "<strong>Tabellenfarbe 4</strong>";
$textfield_at_desc_18  = "<strong>Highlight Tabellenfarbe 1</strong>";
$textfield_at_desc_19  = "<strong>Highlight Tabellenfarbe 2</strong>";
$textfield_at_desc_20  = "<strong>Nur Internet Explorer</strong>";
$textfield_at_desc_21  = "<strong>Theme l&ouml;schen</strong>";
$textfield_at_desc_22  = "<strong>Auswahl</strong>";
$themes_select_yes	   = "Ja";
$themes_select_no	   = "Nein";
$info_te_validation	   = "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";
$info_themes_edit	   = "Die &Auml;nderungen wurden erfolgreich gespeichert.";
$info_tn_validation	   = "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";
$info_tn_error1		   = "<font color=\"#FF0000\">Das Feld \"$textfield_at_desc_7\" enth&auml;lt einen falschen Wert. Der Wert muss numerisch sein und darf nicht unter 1 liegen.<br>Bitte korrigieren Sie Ihre Angaben.</font>";
$info_tn_error2		   = "<font color=\"#FF0000\">Der Theme-Name den Sie verwenden m&ouml;chten wird bereits verwendet. Bitte w&auml;hlen Sie einen anderen.</font>";
$info_tn_error3		   = "<font color=\"#FF0000\">Das Theme das Sie l&ouml;schen m&ouml;chten wird aktiv verwendet.<br>Damit das Theme gel&ouml;scht werden kann, aktivieren Sie zun&auml;chst ein anderes Theme unter den $description_admin_menu_settings.</font>";
$info_themes_new	   = "Das Theme wurde erfolgreich angelegt.";
$info_themes_deleted   = "Das Theme wurde erfolgreich gel&ouml;scht.";
$info_cn_validation    = "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";

//Admin-Files, Filetypes
$description_filetype_name 		  = "<strong>Dateityp</strong>";
$description_filetype_description = "<strong>Beschreibung</strong>";
$description_filetype_status	  = "<strong>Status</strong>";
$description_filetype_delete	  = "<strong>L&ouml;schen</strong>";
$select_manage_files 	  		  = "Dateien verwalten";
$select_manage_filetypes  		  = "Dateitypen verwalten";
$select_filetype_unlocked 		  = "Nicht gesperrt";
$select_filetype_locked   		  = "Gesperrt";
$select_filetype_new	  		  = "Dateitypen erstellen";
$info_files_index  	 	  		  = "W&auml;hlen Sie eine Aktion.";
$info_filetypes_index  	  		  = "Hier k&ouml;nnen Sie nach Dateitypen suchen.";
$textfield_af_desc_1 	  		  = "<strong>Auswahl</strong>";
$delete_confirm	   	 	  		  = "Wollen Sie die Datei/en wirklich l&ouml;schen?";
$delete_success	   	 	  		  = "Die ausgew&auml;hlte/n Datei/en wurde/n erfolgreich gel&ouml;scht.";
$delete_error	  	 	  		  = "<font color=\"#FF0000\">Es wurden keine Dateien ausgew&auml;hlt.</font>";
$info_new_filetype		  		  = "Hier k&ouml;nnen Sie einen neuen Dateityp anlegen.";
$textfield_filetypes_1	  		  = "<strong>Dateityp</strong>";
$textfield_filetypes_2	  		  = "<strong>Beschreibung</strong>";
$textfield_filetypes_3	  		  = "<strong>Upload nicht erlauben</strong>";
$textfield_filetypes_4	  		  = "<strong>Dateityp-Status</strong>";
$textfield_filetypes_5	  		  = "<strong>Dateityp l&ouml;schen</strong>";
$filetype_status_unlocked		  = "<font color=\"#008800\">Nicht gesperrt</font>";
$filetype_status_locked			  = "<font color=\"#FF0000\">Gesperrt</font>";
$info_filetypes_new		  		  = "Der Dateityp wurde erfolgreich angelegt.";
$info_filetype_exists			  = "<font color=\"#FF0000\">Der Dateityp den Sie anlegen m&ouml;chten existiert bereits.</font>";
$info_filetype_exists_2			  = "<font color=\"#FF0000\">Der Dateityp den Sie verwenden m&ouml;chten existiert bereits.</font>";
$info_ft_validation    	  		  = "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";
$delete_filetypes_success		  = "Der/die ausgew&auml;hlte/n Dateityp/en wurde/n erfolgreich gel&ouml;scht.";
$delete_filetype_success  	   	  = "Der Dateityp wurde erfolgreich gel&ouml;scht.";
$delete_filetype_error 	  		  = "<font color=\"#FF0000\">Es wurden keine Dateitypen ausgew&auml;hlt.</font>";
$edit_filetype_success			  = "Die &Auml;nderungen wurden erfolgreich gespeichert.";
$delete_filetype_confirm		  = "Wollen Sie den/die Dateityp/en wirklich l&ouml;schen?";
$textfield_fe_lock				  = "<strong>Sperren</strong>";

//Admin-Categories
$select_category_edit   = "Kategorien verwalten";
$select_category_new    = "Neue Kategorie erstellen";
$textfield_ac_desc_1	= "<strong>Auswahl</strong>";
$info_new_categories	= "Hier k&ouml;nnen Sie neue Kategorien anlegen.";
$textfield_categories_1 = "<strong>Name</strong>";
$textfield_categories_2 = "<strong>Beschreibung</strong>";
$textfield_categories_3 = "<strong>Unter Hauptkategorie</strong>";
$textfield_categories_4 = "<strong>Kategorie l&ouml;schen</strong>";
$info_categories_new	= "Die Kategorie wurde erfolgreich angelegt.";
$info_categories_select	= "W&auml;hlen Sie eine Kategorie, die Sie bearbeiten m&ouml;chten.";
$info_category_deleted	= "Die Kategorie wurd erfolgreich gel&ouml;scht.";
$info_ce_validation		= "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";
$info_cn_error			= "<font color=\"#FF0000\">Der Kategorie-Name den Sie verwenden m&ouml;chten wird bereits verwendet. Bitte w&auml;hlen Sie einen anderen.</font>";
$info_cn_error2			= "<font color=\"#FF0000\">Der Subkategorie-Name den Sie in dieser Hauptkategorie verwenden m&ouml;chten wird bereits verwendet. Bitte w&auml;hlen Sie einen anderen.</font>";

//Admin-Users
$select_manage_users				= "User verwalten";
$select_new_user					= "Neuen User erstellen";
$info_users_index 					= "W&auml;hlen Sie eine Aktion.";
$textfield_au_desc_1				= "<strong>Auswahl</strong>";
$info_new_user						= "Hier k&ouml;nnen Sie einen neuen User anlegen.";
$info_new_user_success				= "Der User-Account wurde erfolgreich angelegt.";
$delete_users_success 		  	 	= "Der/die ausgew&auml;hlte/n User wurde/n erfolgreich gel&ouml;scht.";
$delete_user_success				= "Der User wurde erfolgreich gel&ouml;scht.";
$delete_users_error	  		  		= "<font color=\"#FF0000\">Es wurden keine User ausgew&auml;hlt.</font>";
$delete_user_confirm		  		= "Wollen Sie den/die User wirklich l&ouml;schen?";
$textfield_lock_account_desc  		= "<strong>Account sperren</strong>";
$textfield_lock_account_reason_desc = "<strong>Begr&uuml;ndung</strong>";
$select_desc_admin					= "Admin";
$select_desc_downloader		  		= "Downloader";
$select_desc_downloader_uploader	= "Downloader/Uploader";
$select_desc_uploader				= "Uploader";
$select_desc_user					= "User";
$textfield_user_limit_file_size		= "<strong>Max. Dateigr&ouml;&szlig;e Uploads</strong>";
$textfield_logout_user				= "<strong>User jetzt ausloggen</strong>";
$textfield_not_logged_in			= "Der User ist nicht eingeloggt";

//Admin-Mail
$info_mail 			   	= "Hier k&ouml;nnen Sie Nachrichten an User versenden.";
$textfield_mail_desc_1 	= "<strong>Gruppe</strong>";
$textfield_mail_desc_2 	= "<strong>Einzelempf&auml;nger</strong>";
$textfield_mail_desc_3 	= "<strong>Priorit&auml;t</strong>";
$textfield_mail_desc_4 	= "<strong>Betreff</strong>";
$textfield_mail_desc_5 	= "<strong>Inhalt</strong>";
$select_priority_low	= "Niedrig";
$select_priority_normal = "Normal";
$select_priority_high	= "Hoch";
$select_no_group		= "An keine Gruppe senden";
$select_all_groups		= "An alle User senden";
$mail_header1			= "Hallo,<p>Sie erhalten diese Nachricht, weil Sie registrierter User von";
$mail_header2			= " sind. Nachfolgend die Nachricht des Administrators:";
$mail_footer			= "Mit freundlichem Gru&szlig;";
$info_mail_success		= "Die Nachricht wurde erfolgreich gesendet.";
$file_attachment		= "<strong>Dateianhang</strong>";
$info_mail_validation	= "<font color=\"#FF0000\">Eines oder mehrere Pflichtfelder sind leer. Bitte vervollst&auml;ndigen Sie Ihre Angaben.</font>";
$info_mail_no_group		= "<font color=\"#FF0000\">Die Nachricht wurde nicht gesendet. In der ausgew&auml;hlten Gruppe sind keine User vorhanden.</font>";
$info_mail_no_group2	= "Die Nachricht wurde nur an den Einzelempf&auml;nger gesendet. In der ausgew&auml;hlten Gruppe sind keine User vorhanden.";
$progress_message_mail	= "Die E-Mail wird gesendet.";

//Admin-Update
$info_install_update_1 = "<br><strong>Neues Update kann installiert werden</strong><p>Es wurde eine neuere Version gefunden als die, die Sie im Moment verwenden.<p>Die Versionsnummer die Sie im Moment verwenden:";
$info_install_update_2 = "Die Versionsnummer auf die aktualisiert werden kann:";
$info_install_update_3 = "Wenn Sie das Update jetzt installieren m&ouml;chten, klicken Sie auf \"Installieren\".";
$info_update_success   = "<br>Das Update wurde erfolgreich installiert.";
$info_update_error     = "<br><font color=\"#FF0000\">Das Update wurde nicht abgeschlossen.<p><strong>Fehler</strong><br></font>";
$info_update_error1    = "<font color=\"#FF0000\">- Verbindung zur Datenbank fehlgeschlagen. Pr&uuml;fen Sie, ob Sie die Datenbank-Informationen korrekt angegeben haben.</font>";
$info_update_error2    = "<font color=\"#FF0000\">- Datei \"config.php\" konnte nicht angelegt werden. Pr&uuml;fen Sie, ob das Verzeichnis \"config\" und die Datei \"config.php\" die erforderlichen Schreibrechte besitzen (777).</font>";
$info_update_error3    = "<font color=\"#FF0000\">- Das Verzeichnis \"temp\" konnte nicht angelegt werden. Pr&uuml;fen Sie, ob das Verzeichnis \"files\" die erforderlichen Schreibrechte besitzt (777).</font>";
$info_no_update	       = "<br>Es stehen keine neuen Updates zur Verf&uuml;gung.";

//Admin-Uninstall
$info_uninstall			  = "<br><strong>Achtung</strong><br>Hiermit wird das System entfernt. Alle Daten werden gel&ouml;scht. Klicken Sie auf \"De-Installieren\", wenn Sie das System jetzt entfernen m&ouml;chten.";
$info_uninstall_success   = "<br>Die De-Installation wurde erfolgreich abgeschlossen. L&ouml;schen Sie das Dateiverzeichnis manuell. Klicken Sie auf \"Schliessen\", um das System zu verlassen.";
$uninstall_confirm		  = "Wollen Sie das System wirklich de-installieren?";
$info_uninstall_error     = "<br><font color=\"#FF0000\">Die De-Installation wurde nicht abgeschlossen.<p><strong>Fehler</strong><br></font>";
$info_uninstall_error1    = "<font color=\"#FF0000\">- Datei \"config.php\" wurde nicht gefunden.</font>";
$info_uninstall_error2    = "<font color=\"#FF0000\">- Verbindung zur Datenbank fehlgeschlagen. Pr&uuml;fen Sie, ob die Datenbank-Informationen korrekt sind.</font>";
$info_uninstall_no_action = "<br><font color=\"#FF0000\">Es wurde keine Aktion ausgew&auml;hlt.</font>";

//Buttons
$button_back			= "< Zur&uuml;ck ";
$button_next			= " Weiter >";
$button_cancel			= "Abbrechen";
$button_install			= "Installieren";
$button_start			= "Starten";
$button_login			= "Anmelden";
$button_upload			= "Hochladen";
$button_reset			= "Zur&uuml;cksetzen";
$button_search			= "Suchen";
$button_save			= "Speichern";
$button_edit 			= "Bearbeiten";
$button_show_categories = "Kategorien anzeigen";
$button_search_files	= "Dateien suchen";
$button_show			= "Anzeigen";
$button_delete			= "L&ouml;schen";
$button_send			= "Senden";
$button_zip				= " Zip ";
$button_per_site		= "Pro Seite";
$button_execute			= "Ausf&uuml;hren";
$button_ok				= "   OK   ";
$button_uninstall		= "De-Installieren";
$button_close			= "Schliessen";

//Links
$logout 	   	     = "Ausloggen";
$link_upload   	     = "Upload";
$link_search   	     = "Suchen";
$link_admin    	     = "Administration";
$link_index 	     = "Index";
$link_sign_up 	     = "Registrieren";
$link_new_password   = "Passwort vergessen";
$link_check_update   = "Jetzt auf Updates pr&uuml;fen";
$link_install_update = "Update jetzt installieren";
$link_uninstall		 = "System jetzt de-installieren";
$link_backup_config  = "Jetzt sichern";
$link_download_now	 = "Jetzt herunterladen";
$link_show_uploads	 = "Alle Uploads dieses Users anzeigen";
$link_userlist		 = "Userliste";
$link_my_profil		 = "Mein Profil";
$link_user_image	 = "Benutzerbild anzeigen";
$link_activation 	 = "<strong>Jetzt aktivieren</strong>";
$link_download_show  = "Jetzt anzeigen";
$link_edit			 = "Bearbeiten";
$link_public_area	 = "&Ouml;ffentlicher Bereich";
$link_login			 = "Login";

//Link Title

//Admin-Menu
$link_desc_admin_menu_settings 	 = "Hier k&ouml;nnen Sie die System-Einstellungen bearbeiten";
$link_desc_admin_menu_db 		 = "Hier k&ouml;nnen Sie die Datenbank-Einstellungen bearbeiten";
$link_desc_admin_menu_themes 	 = "Hier k&ouml;nnen Sie Themes verwalten";
$link_desc_admin_menu_files 	 = "Hier k&ouml;nnen Sie Dateien verwalten";
$link_desc_admin_menu_categories = "Hier k&ouml;nnen Sie Kategorien verwalten";
$link_desc_admin_menu_users 	 = "Hier k&ouml;nnen Sie User verwalten";
$link_desc_admin_menu_mail 		 = "Hier k&ouml;nnen Sie E-Mails versenden";

//Categories
$link_desc_category_maincategory = "Nach Hauptkategorie sortieren";
$link_desc_category_subcategory  = "Nach Subkategorie sortieren";
$link_desc_category_description  = "Nach Beschreibung sortieren";

//Files
$link_desc_file_subject 		= "Nach Titel sortieren";
$link_desc_file_description 	= "Nach Beschreibung sortieren";
$link_desc_file_name			= "Nach Dateiname sortieren";
$link_desc_file_size 			= "Nach Dateigr&ouml;&szlig;e sortieren";
$link_desc_file_extension 		= "Nach Dateityp sortieren";
$link_desc_file_date 			= "Nach Upload-Datum sortieren";
$link_desc_file_delete 			= "Mehrere Dateien zum L&ouml;schen markieren";
$link_desc_file_zip 			= "Mehrere Dateien zum Downloaden markieren";
$link_desc_filetype_name		= "Nach Dateityp sortieren";
$link_desc_filetype_description	= "Nach Beschreibung sortieren";
$link_desc_filetype_delete		= "Mehrere Dateitypen zum L&ouml;schen markieren";
$link_desc_filetype_unlocked	= "Nicht gesperrt";
$link_desc_filetype_locked		= "Gesperrt";

//Users
$link_desc_user_name 	  = "Nach Username sortieren";
$link_desc_user_firstname = "Nach Vorname sortieren";
$link_desc_user_lastname  = "Nach Nachname sortieren";
$link_desc_user_email 	  = "Nach E-Mail sortieren";
$link_desc_user_website   = "Nach Website sortieren";
$link_desc_user_delete 	  = "Mehrere User zum L&ouml;schen markieren";
$link_desc_user_online 	  = "Online";
$link_desc_user_offline	  = "Offline";
$link_desc_user_whois	  = "Whois";
$link_desc_user_ripe_ncc  = "RIPE NCC";
$link_desc_user_arin	  = "ARIN";
$link_desc_user_lapnic	  = "LAPNIC";
$link_desc_user_apnic	  = "APNIC";

?>