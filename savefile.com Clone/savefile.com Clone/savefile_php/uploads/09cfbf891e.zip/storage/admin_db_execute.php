<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

$set_dbtable_sep	= "_";

$content = "<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

\$dbhost = \"$set_dbhost\"; //Hostname of the MySQL-Server
\$dbname = \"$set_dbname\"; //Database-Name
\$dbuser = \"$set_dbuser\"; //Database-Username
\$dbpass = \"$set_dbpass\"; //Database-Password

\$dbtable_prefix = \"$set_dbtable_prefix\"; //Table-Prefix
\$dbtable1 = \"$set_dbtable_prefix$set_dbtable_sep$set_dbtable1\"; //Table 1
\$dbtable2 = \"$set_dbtable_prefix$set_dbtable_sep$set_dbtable2\"; //Table 2
\$dbtable3 = \"$set_dbtable_prefix$set_dbtable_sep$set_dbtable3\"; //Table 3
\$dbtable4 = \"$set_dbtable_prefix$set_dbtable_sep$set_dbtable4\"; //Table 4
\$dbtable5 = \"$set_dbtable_prefix$set_dbtable_sep$set_dbtable5\"; //Table 5
\$dbtable6 = \"$set_dbtable_prefix$set_dbtable_sep$set_dbtable6\"; //Table 6

?>";

$file = "library/config/config_temp.php";

if ((empty ($set_dbhost)) || (empty ($set_dbname)) || (empty ($set_dbuser)) || (empty ($set_dbpass)) || (empty ($set_dbtable_prefix)) || (empty ($set_dbtable1)) || (empty ($set_dbtable2)) || (empty ($set_dbtable3)) || (empty ($set_dbtable4)) || (empty ($set_dbtable5))) {
	$info_db_output = "$info_db_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif (@!mysql_connect ($set_dbhost, $set_dbuser, $set_dbpass)) {
	$info_db_output = "$info_db_error1<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif (@!fopen ($file, "w+")) {
	$info_db_output = "$info_db_error2<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
else {
	$sql3 = "ALTER TABLE `$dbtable1` RENAME `$set_dbtable_prefix$set_dbtable_sep$set_dbtable1`";
	mysql_query ($sql3, $dbconnect);	
	$sql4 = "ALTER TABLE `$dbtable2` RENAME `$set_dbtable_prefix$set_dbtable_sep$set_dbtable2`";
	mysql_query ($sql4, $dbconnect);	
	$sql5 = "ALTER TABLE `$dbtable3` RENAME `$set_dbtable_prefix$set_dbtable_sep$set_dbtable3`";
	mysql_query ($sql5, $dbconnect);	
	$sql6 = "ALTER TABLE `$dbtable4` RENAME `$set_dbtable_prefix$set_dbtable_sep$set_dbtable4`";
	mysql_query ($sql6, $dbconnect);
	$sql7 = "ALTER TABLE `$dbtable5` RENAME `$set_dbtable_prefix$set_dbtable_sep$set_dbtable5`";
	mysql_query ($sql7, $dbconnect);
	$sql9 = "ALTER TABLE `$dbtable6` RENAME `$set_dbtable_prefix$set_dbtable_sep$set_dbtable6`";
	mysql_query ($sql9, $dbconnect);
	$resource = @fopen ($file, "w+");
	fopen ($file, "w+");
	fwrite ($resource, $content);
	fclose ($resource);
	include ("library/config/config_temp.php");
	unlink ("library/config/config.php");
	$file2 = "library/config/config.php";
	$resource = @fopen ($file2, "w+");
	fopen ($file2, "w+");
	fwrite ($resource, $content);
	fclose ($resource);
	include ("library/config/config.php");
	unlink ("library/config/config_temp.php");
	$info_db_output = "$info_db";
	if ($optimize_tables == "optimize") {
		$sql8 = array();
		$sql8[] = 'OPTIMIZE TABLE `'.$dbtable1.'`';
		$sql8[] = 'OPTIMIZE TABLE `'.$dbtable2.'`';
		$sql8[] = 'OPTIMIZE TABLE `'.$dbtable3.'`';
		$sql8[] = 'OPTIMIZE TABLE `'.$dbtable4.'`';
		$sql8[] = 'OPTIMIZE TABLE `'.$dbtable5.'`';
		$sql8[] = 'OPTIMIZE TABLE `'.$dbtable6.'`';
		foreach ($sql8 as $query8) {
			mysql_query ($query8);
			}
		$info_db_output = "$info_db $info_db_optimize";		
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>
		<br>
        <?php echo $info_db_output ?></div>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
