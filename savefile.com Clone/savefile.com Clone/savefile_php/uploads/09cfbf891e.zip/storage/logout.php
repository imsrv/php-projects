<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

session_start();

include ("library/config/config.php");
include ("library/session.php");
include ("library/js.php");

logout();

$dbconnect = mysql_connect ($dbhost, $dbuser, $dbpass);
mysql_select_db ($dbname, $dbconnect);

$sql2 = "SELECT * FROM `$dbtable1` LIMIT 0, 30"; 
$query2 = mysql_query ($sql2, $dbconnect);
$array2 = mysql_fetch_array ($query2);

$sql3 = "SELECT * FROM `$dbtable2` WHERE `theme_name` = '".$array2[theme]."' LIMIT 0, 30"; 
$query3 = mysql_query ($sql3, $dbconnect);
$array3 = mysql_fetch_array ($query3);

include ("themes/".$array3[theme_directory]."/library/css.php");
include ("library/languages/".$array2[language].".php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <p><img src="themes/<?php echo $array3[theme_directory] ?>/images/<?php echo $array3[logo] ?>" border="0"></p>
  <table width="800"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array3[theme_directory] ?>/images/table_corner_left_head.gif">&nbsp;</td>
      <td width="552" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="210" bgcolor="<?php echo $array3[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array3[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="800"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="303" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="552" valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
        <tr align="center">
          <td width="5" background="themes/<?php echo $array3[theme_directory] ?>/images/table_corner_left_head2.gif"></td>
          <td bgcolor="<?php echo $array3[site_bgcolor] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
        </tr>
      </table>
        <table width="100%"  border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td rowspan="9" align="left"><br>
                <img src="themes/<?php echo $array3[theme_directory] ?>/images/storage.jpg" width="186" height="289"></td>
          </tr>
          <tr>
            <td height="12" align="left" valign="top"><p>&nbsp;</p>
            <fieldset>
                      <legend><?php echo $field_logout ?></legend>
                      <br><span class="Stil4">
                      <?php echo $info_logout ?>
					  </span>
                      <div align="right">
                      <br>
                      <br>
                      <input name="Login" type="button" id="Login" onClick="window.location.href='index.php'" value="<?php echo $button_login ?>">
                      </div>
            </fieldset></td>
          </tr>
          <tr>
            <td height="12" align="center" valign="top"><span class="Stil2">
            </span></td>
          </tr>
          <tr>
            <td height="12" class="Stil2">&nbsp;</td>
          </tr>
          <tr>
            <td height="12" align="left" valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td height="12" align="left" valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td height="12" align="left" valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td height="12" align="left" valign="top">&nbsp;</td>
          </tr>
        </table></td>
      <td width="210" background="themes/<?php echo $array3[theme_directory] ?>/images/table_back.gif" bgcolor="<?php echo $array3[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="303" bgcolor="<?php echo $array3[table_bgcolor1] ?>">&nbsp;</td>
    </tr>
  </table>
  <table width="800"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array3[theme_directory] ?>/images/table_corner_left_foot.gif">&nbsp;</td>
      <td width="552" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="210" bgcolor="<?php echo $array3[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array3[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
