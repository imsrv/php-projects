<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_progress_bar $js_progress_message $js_browser_detection"; ?>
</head>

<body onLoad="javascript:bar1.hideBar();<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
          <br>
        <?php echo $info_new_user ?><br>
        <br>
        </div>
        <form action="admin_users_new_execute.php" method="post" enctype="multipart/form-data" name="form1">
          <table width="100%"  border="0" cellspacing="1">
            <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
              <td align="center" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                  <br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                      <legend><?php echo $field_login ?></legend>
					  <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
					    <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
					      <td align="left"><?php echo $textfield_user_name_desc ?></td>
					      <td width="70%" align="left"><input name="dbusers_user_name" type="text" id="dbusers_user_name" size="61" maxlength="30"> 
					      * </td>
				        </tr>
					    <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_user_pw ?></td>
                          <td align="left"><input name="dbusers_password" type="password" id="dbusers_password" size="61" maxlength="30"> 
                          * </td>
				        </tr>
					    <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_user_pw_rep_desc ?></td>
                          <td align="left"><input name="dbusers_password_rep" type="password" id="dbusers_password_rep" size="61" maxlength="30"> 
                          * </td>
					    </tr>
					</table>
                      </fieldset></td>
                    </tr>
                </table>
                  <br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                        <legend><?php echo $field_eup_1 ?></legend>
                        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_firstname_desc ?></td>
                            <td width="70%" align="left"><input name="dbusers_user_firstname" type="text" id="dbusers_user_firstname" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_lastname_desc ?></td>
                            <td align="left"><input name="dbusers_user_lastname" type="text" id="dbusers_user_lastname" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_email_desc ?></td>
                            <td align="left"><input name="dbusers_user_email" type="text" id="dbusers_user_email" size="61" maxlength="200">
                            *
                            <input name="email_public" type="checkbox" id="email_public" value="public"> 
                            <?php echo $textfield_user_email_pub_desc ?></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_website_desc ?></td>
                            <td align="left"><input name="dbusers_user_website" type="text" id="dbusers_user_website" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_birthday_desc ?></td>
                            <td align="left"><input name="dbusers_user_birthday" type="text" id="dbusers_user_birthday" size="61" maxlength="10"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_gender_desc ?></td>
                            <td align="left"><select name="dbusers_user_gender" id="dbusers_user_gender" style="width:321px">
							<option value="" selected></option>
							<option value="2"><?php echo $select_desc_gender_female ?></option>
							<option value="1"><?php echo $select_desc_gender_male ?></option>
							</select>
							</td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_street_desc ?></td>
                            <td align="left"><input name="dbusers_user_street" type="text" id="dbusers_user_street" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_zipcode_desc ?></td>
                            <td align="left"><input name="dbusers_user_zipcode" type="text" id="dbusers_user_zipcode" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_city_desc ?></td>
                            <td align="left"><input name="dbusers_user_city" type="text" id="dbusers_user_city" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_state_desc ?></td>
                            <td align="left"><input name="dbusers_user_state" type="text" id="dbusers_user_state" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_country_desc ?></td>
                            <td align="left"><input name="dbusers_user_country" type="text" id="dbusers_user_country" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_phone_desc ?></td>
                            <td align="left"><input name="dbusers_user_phone" type="text" id="dbusers_user_phone" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_fax_desc ?></td>
                            <td align="left"><input name="dbusers_user_fax" type="text" id="dbusers_user_fax" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_mobile_desc ?></td>
                            <td align="left"><input name="dbusers_user_mobile" type="text" id="dbusers_user_mobile" size="61" maxlength="200"></td>
                          </tr>
                      </table>
                      </fieldset></td>
                    </tr>
                </table>
                  <br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                        <legend><?php echo $field_user_pic ?></legend>
                        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left" valign="top"><?php echo $textfield_us_desc_9 ?></td>
                            <td width="70%" align="left"><input name="file" type="file" size="61">
                            <br>
                            <?php echo $info_user_image ?></td>
                          </tr>
                      </table>
                      </fieldset></td>
                    </tr>
                  </table>
                  <br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                        <legend><?php echo $field_options ?></legend>
                        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_group_desc ?></td>
                            <td width="70%" align="left"><select name="dbusers_user_group" id="dbusers_user_group" style="width:150px">
                                <option value="1"><?php echo $select_desc_admin ?></option>
                                <option value="2"><?php echo $select_desc_downloader ?></option>
                                <option value="3"><?php echo $select_desc_downloader_uploader ?></option>
                                <option value="4"><?php echo $select_desc_uploader ?></option>
                                <option value="5" selected><?php echo $select_desc_user ?></option>
                              </select>
                            </td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_limit_file_size ?></td>
                            <td align="left"><input name="dbusers_limit_file_size" type="text" id="dbusers_limit_file_size" style="width:144px">
                                <select name="dbusers_file_size" id="dbusers_file_size" style="width:167px">
                                  <option value="Byte" selected><?php echo $select_file_size_byte ?></option>
                                  <option value="KB"><?php echo $select_file_size_kb ?></option>
                                  <option value="MB"><?php echo $select_file_size_mb ?></option>
                                  <option value="GB"><?php echo $select_file_size_gb ?></option>
                                  <option value="TB"><?php echo $select_file_size_tb ?></option>
                                  <option value="PB"><?php echo $select_file_size_pb ?></option>
                                  <option value="EB"><?php echo $select_file_size_eb ?></option>
                                </select>
                            </td>
                          </tr>
                        </table>
                      </fieldset></td>
                    </tr>
                  </table>
                  <br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                        <legend><?php echo $field_lock ?></legend>
                        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_lock_account_desc ?></td>
                            <td width="70%" align="left"><input name="lock_account" type="checkbox" id="lock_account" value="lock"></td>
                          </tr>
                          <tr valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_lock_account_reason_desc ?></td>
                            <td align="left"><textarea name="dbusers_user_lock_account_reason" cols="60" rows="3" id="dbusers_user_lock_account_reason"></textarea></td>
                          </tr>
                        </table>
                      </fieldset></td>
                    </tr>
                  </table>
                  <br>
                  <br>
              <input name="id" type="hidden" value="<?php echo $array3[id] ?>"></td>
            </tr>
            <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
              <td align="left"><div align="center">
                <input type="submit" name="Submit" value="<?php echo $button_save ?>" onClick="javascript:bar1.showBar(); showMessage(); this.disabled=true; window.document['form1'].submit();">
              </div></td>
            </tr>
            <tr>
              <td align="left">&nbsp;</td>
            </tr>
            <tr>
              <td align="center"><table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="left">&nbsp;</td>
                  <td width="70%" align="left"><?php echo $js_progress_bar_output ?></td>
                </tr>
                <tr>
                  <td align="left">&nbsp;</td>
                  <td width="70%" align="left">&nbsp;</td>
                </tr>
                <tr>
                  <td align="left">&nbsp;</td>
                  <td width="70%" align="left"><div id="invisible" style="visibility:hidden;"><?php echo $progress_message ?></div></td>
                </tr>
              </table></td>
            </tr>
          </table>
        </form>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
