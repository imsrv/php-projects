<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

if ($dbconfig_file_size == "Byte") {
	$dbconfig_limit_file_size = $dbconfig_limit_file_size;
	}
elseif ($dbconfig_file_size == "KB") {
	$dbconfig_limit_file_size = $dbconfig_limit_file_size * 1024;
	}
elseif ($dbconfig_file_size == "MB") {
	$dbconfig_limit_file_size = $dbconfig_limit_file_size * 1048576;
	}
elseif ($dbconfig_file_size == "GB") {
	$dbconfig_limit_file_size = $dbconfig_limit_file_size * 1073741824;
	}
elseif ($dbconfig_file_size == "TB") {
	$dbconfig_limit_file_size = $dbconfig_limit_file_size * 1099511627776;
	}
elseif ($dbconfig_file_size == "PB") {
	$dbconfig_limit_file_size = $dbconfig_limit_file_size * 1125899906842624;
	}
elseif ($dbconfig_file_size == "EB") {
	$dbconfig_limit_file_size = $dbconfig_limit_file_size * 1152921504606847000;
	}

if (empty ($dbconfig_limit_file_size)) {
	$dbconfig_limit_file_size = "";
	$dbconfig_file_size = "";
	}

if ($public_site == "public") {
	$public_site = "true";
	}
else {
	$public_site = "false";
	}

if ($lock_site == "lock") {
	$lock_site = "true";
	}
else {
	$lock_site = "false";
	}

if ($lock_register == "lock") {
	$lock_register = "true";
	}
else {
	$lock_register = "false";
	}

if ($lock_upload == "lock") {
	$lock_upload = "true";
	}
else {
	$lock_upload = "false";
	}

if ($lock_download == "lock") {
	$lock_download = "true";
	}
else {
	$lock_download = "false";
	}

if ($lock_zip_download == "lock") {
	$lock_zip_download = "true";
	}
else {
	$lock_zip_download = "false";
	}

if ($new_user_report == "report") {
	$new_user_report ="true";
	}
else {
	$new_user_report ="false";
	}

if ($new_upload_report == "report") {
	$new_upload_report ="true";
	}
else {
	$new_upload_report ="false";
	}

if ((empty ($dbconfig_site_name)) || (empty ($dbconfig_site_url)) || (empty ($dbconfig_admin_email)) || (empty ($dbconfig_theme)) || (empty ($dbconfig_language))) {
	$info_as_output = "$info_as_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
else {
	$sql = "UPDATE `$dbtable1` SET `site_name` = '$dbconfig_site_name', `site_url` = '$dbconfig_site_url' , `admin_email` = '$dbconfig_admin_email', `theme` = '$dbconfig_theme', `language` = '$dbconfig_language', `new_user_group` = '$dbconfig_new_user_group', `limit_file_size` = '$dbconfig_limit_file_size', `file_size` = '$dbconfig_file_size', `site_locked` = '$lock_site', `site_public` = '$public_site', `site_locked_reason` = '$dbconfig_lock_site_reason', `register_locked` = '$lock_register', `register_locked_reason` = '$dbconfig_lock_register_reason', `upload_locked` = '$lock_upload', `upload_locked_reason` = '$dbconfig_lock_upload_reason', `download_locked` = '$lock_download', `download_locked_reason` = '$dbconfig_lock_download_reason', `zip_download_locked` = '$lock_zip_download', `zip_download_locked_reason` = '$dbconfig_lock_zip_download_reason', `new_user_report` = '$new_user_report', `new_upload_report` = '$new_upload_report' WHERE `id` = '1' LIMIT 1"; 
	mysql_query ($sql, $dbconnect);
	$info_as_output = "$info_admin_settings";
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>
		<br>
        <?php echo $info_as_output ?></div>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
