<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

if (!empty ($file)) {
	$fd = fopen ($file, "r");
	$attachment = chunk_split(base64_encode(fread($fd, filesize($file))));
	fclose ($fd);
	if ($file_size < 1024) {
		$limit_file_size_output = "$select_file_size_byte";
		}
	elseif (($file_size > 1024) && ($file_size < 1048576)) {
		$get_file_size = $file_size / 1024;
		$file_size = round ($get_file_size,2);
		$limit_file_size_output = "$select_file_size_kb";
		}
	elseif (($file_size > 1048576) && ($file_size < 1073741824)) {
		$get_file_size = $file_size / 1048576;
		$file_size = round ($get_file_size,2);
		$limit_file_size_output = "$select_file_size_mb";
		}
	elseif (($file_size > 1073741824) && ($file_size < 1099511627776)) {
		$get_file_size = $file_size / 1073741824;
		$file_size = round ($get_file_size,2);
		$limit_file_size_output = "$select_file_size_gb";
		}
	elseif (($file_size > 1099511627776) && ($file_size < 1125899906842624)) {
		$get_file_size = $file_size / 1099511627776;
		$file_size = round ($get_file_size,2);
		$limit_file_size_output = "$select_file_size_tb";
		}
	elseif (($file_size > 1125899906842624) && ($file_size < 1152921504606847000)) {
		$get_file_size = $file_size / 1125899906842624;
		$file_size = round ($get_file_size,2);
		$limit_file_size_output = "$select_file_size_pb";
		}
	elseif ($file_size > 1152921504606847000) {
		$get_file_size = $file_size / 1152921504606847000;
		$file_size = round ($get_file_size,2);
		$limit_file_size_output = "$select_file_size_eb";
		}
	$dot = strrpos ($file_name, ".") + 1;
	$file_extension = substr ($file_name, $dot, strlen ($file_name) - $dot);
	$show_attachment = "<p><br><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td><hr size=\"1\" noshade color=\"#FFFFFF\"><span class=\"Stil2\">$file_attachment: $file_name | $description_file_size: $file_size $limit_file_size_output | $description_file_extension: $file_extension</span></td></tr></table>";
	}

if ($priority == "1") {
	$set_priority = "X-Priority: 5 (Lowest)\n"."Importance: Low\n";
	}
if ($priority == "3") {
	$set_priority = "X-Priority: 1 (Highest)\n"."Importance: High\n";
	}

$content = stripslashes ($content);
$content = htmlspecialchars ($content);
$content = nl2br ($content);

$xtra .= "From: ".$array2[site_name]." <".$array2[admin_email].">\n";
$xtra .= "MIME-Version: 1.0\nContent-Type: multipart/mixed; boundary=\"========1234567\"";
$xtra .= "X-Mailer: PHP ".phpversion()."\n";
$xtra .= "$set_priority";

$xtra2 .= "From: ".$array2[site_name]." <".$array2[admin_email].">\n";
$xtra2 .= "Content-Type: text/html\nContent-Transfer-Encoding: 8bit\n";
$xtra2 .= "X-Mailer: PHP ".phpversion()."\n";
$xtra2 .= "$set_priority";

$mail = "
$css
<img src=\"".$array2[site_url]."/themes/".$array4[theme_directory]."/images/".$array4[logo]."\"><p>
<span class=\"Stil2\">$mail_header1 <strong><a href=\"".$array2[site_url]."\" target=\"_blank\">".$array2[site_name]."</a></strong>$mail_header2<p>$content<p><br>$mail_footer<br><strong><a href=\"".$array2[site_url]."\" target=\"_blank\">".$array2[site_name]."</a><br><a href=\"mailto:".$array2[site_name]." %3C".$array2[admin_email]."%3E\">".$array2[admin_email]."</a></strong></span>$show_attachment
";

$mail_content = "--========1234567\nContent-Type: text/html\nContent-Transfer-Encoding: 8bit\n".$mail."\n--========1234567\nContent-Type: $file_type; name=$file_name\nContent-Transfer-Encoding: base64\nContent-Disposition: attachment; filename=\"$file_name\"\n\n".$attachment;

if (!empty ($file)) {
	if ((empty ($subject)) || (empty ($content))) {
		$info_mail_output = "$info_mail_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	elseif ((!empty ($user_group)) && (!empty ($to))) {
		if ($user_group == "all_groups") {
			$sql3 = "SELECT * FROM `$dbtable3";
			}
		elseif ($user_group == "1") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '1'";
			}
		elseif ($user_group == "2") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '2'";
			}
		elseif ($user_group == "3") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '3'";
			}
		elseif ($user_group == "4") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '4'";
			}
		elseif ($user_group == "5") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '5'";
			}
		$query3 = mysql_query ($sql3, $dbconnect);
		$query0 = mysql_query ($sql3, $dbconnect);
		$array0 = mysql_fetch_array ($query0);
		if (empty ($array0[user_email])) {
			$xtra .= "Bcc: ".$to."\r\n";
			mail ("".$array2[site_name]." <".$array2[admin_email].">", $subject, $mail_content, $xtra);
			$info_mail_output = "$info_mail_no_group2";
			}
		else {
			while ($row = mysql_fetch_array ($query3)) {
				$xtra .= "Bcc: ".$row[user_email]."\r\n";
				}
			$xtra .= "Bcc: ".$to."\r\n";
			mail ("".$array2[site_name]." <".$array2[admin_email].">", $subject, $mail_content, $xtra);
			$info_mail_output = "$info_mail_success";
			}
		}
	elseif (!empty ($user_group)) {
		if ($user_group == "all_groups") {
			$sql3 = "SELECT * FROM `$dbtable3";
			}
		elseif ($user_group == "1") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '1'";
			}
		elseif ($user_group == "2") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '2'";
			}
		elseif ($user_group == "3") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '3'";
			}
		elseif ($user_group == "4") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '4'";
			}
		elseif ($user_group == "5") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '5'";
			}
		$query3 = mysql_query ($sql3, $dbconnect);
		$query0 = mysql_query ($sql3, $dbconnect);
		$array0 = mysql_fetch_array ($query0);
		if (empty ($array0[user_email])) {
			$info_mail_output = "$info_mail_no_group<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
			}
		else {
			while ($row = mysql_fetch_array ($query3)) {
				$xtra .= "Bcc: ".$row[user_email]."\r\n";
				}
			mail ("".$array2[site_name]." <".$array2[admin_email].">", $subject, $mail_content, $xtra);
			$info_mail_output = "$info_mail_success";
			}
		}
	elseif (!empty ($to)) {
		$xtra .= "Bcc: ".$to."\r\n";
		mail ("".$array2[site_name]." <".$array2[admin_email].">", $subject, $mail_content, $xtra);
		$info_mail_output = "$info_mail_success";
		}
	else {
		$info_mail_output = "$info_mail_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	}
else  {
	if ((empty ($subject)) || (empty ($content))) {
		$info_mail_output = "$info_mail_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	elseif ((!empty ($user_group)) && (!empty ($to))) {
		if ($user_group == "all_groups") {
			$sql3 = "SELECT * FROM `$dbtable3";
			}
		elseif ($user_group == "1") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '1'";
			}
		elseif ($user_group == "2") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '2'";
			}
		elseif ($user_group == "3") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '3'";
			}
		elseif ($user_group == "4") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '4'";
			}
		elseif ($user_group == "5") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '5'";
			}
		$query3 = mysql_query ($sql3, $dbconnect);
		$query0 = mysql_query ($sql3, $dbconnect);
		$array0 = mysql_fetch_array ($query0);
		if (empty ($array0[user_email])) {
			$xtra2 .= "Bcc: ".$to."\r\n";
			mail ("".$array2[site_name]." <".$array2[admin_email].">", $subject, $mail, $xtra2);
			$info_mail_output = "$info_mail_no_group2";
			}
		else {
			while ($row = mysql_fetch_array ($query3)) {
				$xtra2 .= "Bcc: ".$row[user_email]."\r\n";
				}
			$xtra2 .= "Bcc: ".$to."\r\n";
			mail ("".$array2[site_name]." <".$array2[admin_email].">", $subject, $mail, $xtra2);
			$info_mail_output = "$info_mail_success";
			}
		}
	elseif (!empty ($user_group)) {
		if ($user_group == "all_groups") {
			$sql3 = "SELECT * FROM `$dbtable3";
			}
		elseif ($user_group == "1") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '1'";
			}
		elseif ($user_group == "2") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '2'";
			}
		elseif ($user_group == "3") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '3'";
			}
		elseif ($user_group == "4") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '4'";
			}
		elseif ($user_group == "5") {
			$sql3 = "SELECT * FROM `$dbtable3` WHERE `user_group` = '5'";
			}
		$query3 = mysql_query ($sql3, $dbconnect);
		$query0 = mysql_query ($sql3, $dbconnect);
		$array0 = mysql_fetch_array ($query0);
		if (empty ($array0[user_email])) {
			$info_mail_output = "$info_mail_no_group<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
			}
		else {
			while ($row = mysql_fetch_array ($query3)) {
				$xtra2 .= "Bcc: ".$row[user_email]."\r\n";
				}
			mail ("".$array2[site_name]." <".$array2[admin_email].">", $subject, $mail, $xtra2);
			$info_mail_output = "$info_mail_success";
			}
		}
	elseif (!empty ($to)) {
		$xtra2 .= "Bcc: ".$to."\r\n";
		mail ("".$array2[site_name]." <".$array2[admin_email].">", $subject, $mail, $xtra2);
		$info_mail_output = "$info_mail_success";
		}
	else {
		$info_mail_output = "$info_mail_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" align="center" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>
		<br>
            <?php echo $info_mail_output ?>
	    </div>
        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
            <tr>
        </table>
      </td></tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
