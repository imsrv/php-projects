<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

$sql3 = "SELECT * FROM `$dbtable2` WHERE `id` = '$theme_select' LIMIT 0, 30"; 
$query3 = mysql_query ($sql3, $dbconnect);
$array3 = mysql_fetch_array ($query3);

$theme_dir = dir ("themes");
$theme_files = array();
	while ($theme_file = $theme_dir -> read()) {
		if ($theme_file != "." and $theme_file != "..") {
		$theme_files[] = $theme_file;
		}
	}
$theme_dir -> close();
natcasesort ($theme_files);
foreach ($theme_files as $theme_file) {
	if ($theme_file == $array3[theme_directory]) {
		$show_themes .= "<option value=\"$theme_file\" selected>$theme_file</option><br>";
		}
	else {
		$show_themes .= "<option value=\"$theme_file\">$theme_file</option><br>";
		}
	}

if ($array3[font_family] == "Arial, Helvetica, sans-serif") {
	$font_family_select = "
	<option value=\"Arial, Helvetica, sans-serif\" selected>Arial, Helvetica, sans-serif</option>
	<option value=\"Times New Roman, Times, serif\">Times New Roman, Times, serif</option>
	<option value=\"Courier New, Courier, mono\">Courier New, Courier, mono</option>
	<option value=\"Georgia, Times New Roman, Times, serif\">Georgia, Times New Roman, Times, serif</option>
	<option value=\"Verdana, Arial, Helvetica, sans-serif\">Verdana, Arial, Helvetica, sans-serif</option>
	<option value=\"Geneva, Arial, Helvetica, sans-serif\">Geneva, Arial, Helvetica, sans-serif</option>";
	}
elseif ($array3[font_family] == "Times New Roman, Times, serif") {
	$font_family_select = "
	<option value=\"Arial, Helvetica, sans-serif\">Arial, Helvetica, sans-serif</option>
	<option value=\"Times New Roman, Times, serif\" selected>Times New Roman, Times, serif</option>
	<option value=\"Courier New, Courier, mono\">Courier New, Courier, mono</option>
	<option value=\"Georgia, Times New Roman, Times, serif\">Georgia, Times New Roman, Times, serif</option>
	<option value=\"Verdana, Arial, Helvetica, sans-serif\">Verdana, Arial, Helvetica, sans-serif</option>
	<option value=\"Geneva, Arial, Helvetica, sans-serif\">Geneva, Arial, Helvetica, sans-serif</option>";
	}
elseif ($array3[font_family] == "Courier New, Courier, mono") {
	$font_family_select = "
	<option value=\"Arial, Helvetica, sans-serif\">Arial, Helvetica, sans-serif</option>
	<option value=\"Times New Roman, Times, serif\">Times New Roman, Times, serif</option>
	<option value=\"Courier New, Courier, mono\" selected>Courier New, Courier, mono</option>
	<option value=\"Georgia, Times New Roman, Times, serif\">Georgia, Times New Roman, Times, serif</option>
	<option value=\"Verdana, Arial, Helvetica, sans-serif\">Verdana, Arial, Helvetica, sans-serif</option>
	<option value=\"Geneva, Arial, Helvetica, sans-serif\">Geneva, Arial, Helvetica, sans-serif</option>";
	}
elseif ($array3[font_family] == "Georgia, Times New Roman, Times, serif") {
	$font_family_select = "
	<option value=\"Arial, Helvetica, sans-serif\">Arial, Helvetica, sans-serif</option>
	<option value=\"Times New Roman, Times, serif\">Times New Roman, Times, serif</option>
	<option value=\"Courier New, Courier, mono\">Courier New, Courier, mono</option>
	<option value=\"Georgia, Times New Roman, Times, serif\" selected>Georgia, Times New Roman, Times, serif</option>
	<option value=\"Verdana, Arial, Helvetica, sans-serif\">Verdana, Arial, Helvetica, sans-serif</option>
	<option value=\"Geneva, Arial, Helvetica, sans-serif\">Geneva, Arial, Helvetica, sans-serif</option>";
	}
elseif ($array3[font_family] == "Verdana, Arial, Helvetica, sans-serif") {
	$font_family_select = "
	<option value=\"Arial, Helvetica, sans-serif\">Arial, Helvetica, sans-serif</option>
	<option value=\"Times New Roman, Times, serif\">Times New Roman, Times, serif</option>
	<option value=\"Courier New, Courier, mono\">Courier New, Courier, mono</option>
	<option value=\"Georgia, Times New Roman, Times, serif\">Georgia, Times New Roman, Times, serif</option>
	<option value=\"Verdana, Arial, Helvetica, sans-serif\" selected>Verdana, Arial, Helvetica, sans-serif</option>
	<option value=\"Geneva, Arial, Helvetica, sans-serif\">Geneva, Arial, Helvetica, sans-serif</option>";
	}
elseif ($array3[font_family] == "Geneva, Arial, Helvetica, sans-serif") {
	$font_family_select = "
	<option value=\"Arial, Helvetica, sans-serif\">Arial, Helvetica, sans-serif</option>
	<option value=\"Times New Roman, Times, serif\">Times New Roman, Times, serif</option>
	<option value=\"Courier New, Courier, mono\">Courier New, Courier, mono</option>
	<option value=\"Georgia, Times New Roman, Times, serif\">Georgia, Times New Roman, Times, serif</option>
	<option value=\"Verdana, Arial, Helvetica, sans-serif\">Verdana, Arial, Helvetica, sans-serif</option>
	<option value=\"Geneva, Arial, Helvetica, sans-serif\" selected>Geneva, Arial, Helvetica, sans-serif</option>";
	}
else {
	$font_family_select = "
	<option value=\"Arial, Helvetica, sans-serif\" selected>Arial, Helvetica, sans-serif</option>
	<option value=\"Times New Roman, Times, serif\">Times New Roman, Times, serif</option>
	<option value=\"Courier New, Courier, mono\">Courier New, Courier, mono</option>
	<option value=\"Georgia, Times New Roman, Times, serif\">Georgia, Times New Roman, Times, serif</option>
	<option value=\"Verdana, Arial, Helvetica, sans-serif\">Verdana, Arial, Helvetica, sans-serif</option>
	<option value=\"Geneva, Arial, Helvetica, sans-serif\">Geneva, Arial, Helvetica, sans-serif</option>";
	}

if ($array3[site_bgimage] == "true") {
	$site_bgimage_select = "
	<option value=\"true\" selected>$themes_select_yes</option>
	<option value=\"false\">$themes_select_no</option>";
	}
else {
	$site_bgimage_select = "
	<option value=\"false\" selected>$themes_select_no</option>
	<option value=\"true\">$themes_select_yes</option>";
	}

if ($array3[ie_compatible] == "true") {
	$ie_compatible_checkbox = "<input name=\"dbthemes_ie_compatible\" type=\"checkbox\" id=\"dbthemes_ie_compatible\" value=\"true\" checked>";
	}
else {
	$ie_compatible_checkbox = "<input name=\"dbthemes_ie_compatible\" type=\"checkbox\" id=\"dbthemes_ie_compatible\" value=\"true\">";
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>        
        </div>
        <form action="admin_themes_edit_execute.php" method="post" name="form1">
          <table width="100%"  border="0" cellspacing="1">
            <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
              <td align="center" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                  <br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                      <legend><?php echo $field_at_1 ?></legend>
					  <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
					    <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
					      <td align="left"><?php echo $textfield_at_desc_1 ?></td>
					      <td width="70%" align="left"><input name="dbthemes_name" type="text" id="dbthemes_name" value="<?php echo $array3[theme_name] ?>" size="61"></td>
				        </tr>
					    <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_at_desc_2 ?></td>
                          <td align="left"><input name="dbthemes_description" type="text" id="dbthemes_description" value="<?php echo $array3[theme_description] ?>" size="61"></td>
				        </tr>
					    <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_at_desc_3 ?></td>
                          <td align="left"><select name="dbthemes_directory" id="dbthemes_directory" style="width:150px">
                            <?php echo $show_themes ?>
                          </select></td>
					    </tr>
					</table>
                      </fieldset></td>
                    </tr>
                </table>
                  <br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                        <legend><?php echo $field_at_2 ?></legend>
                        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_at_desc_4 ?></td>
                            <td width="70%" align="left"><input name="dbthemes_logo" type="text" id="dbthemes_logo" value="<?php echo $array3[logo] ?>" size="61"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_at_desc_5 ?></td>
                            <td align="left"><input name="dbthemes_site_bgcolor" type="text" id="dbthemes_site_bgcolor" value="<?php echo $array3[site_bgcolor] ?>" size="61"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_at_desc_6 ?></td>
                            <td align="left"><select name="dbthemes_site_bgimage" id="dbthemes_site_bgimage" style="width:150px">
                              <?php echo $site_bgimage_select ?>
                            </select></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_at_desc_7 ?></td>
                            <td align="left"><input name="dbthemes_number_result" type="text" id="dbthemes_number_result" style="width:144px" value="<?php echo $array3[number_result] ?>"></td>
                          </tr>
                      </table>
                      </fieldset></td>
                    </tr>
                </table>
                  <br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                        <legend><?php echo $field_at_3 ?></legend>
                        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_at_desc_8 ?></td>
                            <td width="70%" align="left"><select name="dbthemes_font_family" id="dbthemes_font_family" style="width:321px">
							<?php echo $font_family_select ?> 
							</select>                                                                                                                                                                 </select></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_at_desc_9 ?></td>
                            <td width="70%" align="left"><input name="dbthemes_font_size" type="text" id="dbthemes_font_size" value="<?php echo $array3[font_size] ?>" size="61"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_at_desc_10 ?></td>
                            <td width="70%" align="left"><input name="dbthemes_font_color" type="text" id="dbthemes_font_color" value="<?php echo $array3[font_color] ?>" size="61"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_at_desc_11 ?></td>
                            <td width="70%" align="left"><input name="dbthemes_link_size" type="text" id="dbthemes_link_size" value="<?php echo $array3[link_size] ?>" size="61"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_at_desc_12 ?></td>
                            <td width="70%" align="left"><input name="dbthemes_link_color" type="text" id="dbthemes_link_color" value="<?php echo $array3[link_color] ?>" size="61"></td>
                          </tr>
                      </table>
                      </fieldset></td>
                    </tr>
                </table>
                <br>
              <table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><fieldset>
                    <legend><?php echo $field_at_4 ?></legend>
                    <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_at_desc_13 ?></td>
                        <td width="70%" align="left"><input name="dbthemes_table_width" type="text" id="dbthemes_table_width" value="<?php echo $array3[table_width] ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_at_desc_14 ?></td>
                        <td width="70%" align="left"><input name="dbthemes_table_bgcolor1" type="text" id="dbthemes_table_bgcolor1" value="<?php echo $array3[table_bgcolor1] ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_at_desc_15 ?></td>
                        <td width="70%" align="left"><input name="dbthemes_table_bgcolor2" type="text" id="dbthemes_table_bgcolor2" value="<?php echo $array3[table_bgcolor2] ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_at_desc_16 ?></td>
                        <td align="left"><input name="dbthemes_table_bgcolor3" type="text" id="dbthemes_table_bgcolor3" value="<?php echo $array3[table_bgcolor3] ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_at_desc_17 ?></td>
                        <td align="left"><input name="dbthemes_table_bgcolor4" type="text" id="dbthemes_table_bgcolor4" value="<?php echo $array3[table_bgcolor4] ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_at_desc_18 ?></td>
                        <td width="70%" align="left"><input name="dbthemes_table_hlcolor1" type="text" id="dbthemes_table_hlcolor1" value="<?php echo $array3[table_hlcolor1] ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_at_desc_19 ?></td>
                        <td align="left"><input name="dbthemes_table_hlcolor2" type="text" id="dbthemes_table_hlcolor2" value="<?php echo $array3[table_hlcolor2] ?>" size="61"></td>
                      </tr>
                    </table>
                  </fieldset></td>
                </tr>
              </table>
              <br>
              <table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><fieldset>
                    <legend><?php echo $field_at_5 ?></legend>
                    <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_at_desc_20 ?></td>
                        <td width="70%" align="left"><?php echo $ie_compatible_checkbox ?>&nbsp;</td>
                      </tr>
                    </table>
                  </fieldset></td>
                </tr>
              </table>
              <br>
              <table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><fieldset>
                    <legend><?php echo $field_at_6 ?></legend>
                    <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_at_desc_21 ?></td>
                        <td width="70%" align="left"><input name="delete_theme" type="checkbox" id="delete_theme" value="delete"></td>
                      </tr>
                    </table>
                  </fieldset></td>
                </tr>
              </table>
              <br>
              <input name="id" type="hidden" value="<?php echo $array3[id] ?>">
              <input name="dbthemes_name_actual" type="hidden" id="dbthemes_name_actual" value="<?php echo $array3[theme_name] ?>"></td>
            </tr>
            <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
              <td align="left" bgcolor="<?php echo $array4[table_bgcolor4] ?>"><div align="center">
                <input type="submit" name="Submit" value="<?php echo $button_save ?>">
              </div></td>
            </tr>
            <tr>
              <td align="left">&nbsp;</td>
            </tr>
            <tr>
              <td align="center"><table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="left">&nbsp;
                  </td>
                </tr>
              </table>
              </td>
            </tr>
          </table>
        </form>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
