<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

ob_start();

include ("login_validation.php");
include_once ("library/pclzip.lib.php");

ob_end_clean();

$sql = "SELECT * FROM `$dbtable3` WHERE user_session='".session_id()."' LIMIT 1";
$result = mysql_query ($sql);
$array = mysql_fetch_array ($result);

$file_date = date ("d-m-Y");

if (($array2[download_locked] == "true") && (!empty ($array2[download_locked_reason]))) {
	$info_download_locked_reason_output = "<font color=\"#FF0000\">".$array2[download_locked_reason]."</font>";
	$info_download_locked_reason_output = nl2br ($info_download_locked_reason_output);
	}
else {
	$info_download_locked_reason_output = "$info_download_locked_no_reason";
	}
if (($array2[zip_download_locked] == "true") && (!empty ($array2[zip_download_locked_reason]))) {
	$info_zip_download_locked_reason_output = "<font color=\"#FF0000\">".$array2[zip_download_locked_reason]."</font>";
	$info_zip_download_locked_reason_output = nl2br ($info_zip_download_locked_reason_output);
	}
else {
	$info_zip_download_locked_reason_output = "$info_zip_locked_no_reason";
	}
if ((empty ($select)) || ($array2[download_locked] == "true") && ($array[user_name] !== "admin") || ($array2[zip_download_locked] == "true") && ($array[user_name] !== "admin")) {
	if (empty ($select)) {
		$info_zf_output = "$zip_error";
		}
	elseif ($array2[download_locked] == "true") {
		$info_zf_output = "$info_download_locked $info_download_locked_reason_output";
		}
	elseif ($array2[zip_download_locked] == "true") {
		$info_zf_output = "$info_zip_download_locked $info_zip_download_locked_reason_output";
		}
	echo "
	<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">
	<html>
	<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">
	<title>".$array2[site_name]."</title>
	$js_highlight_menu
	$css $js_browser_detection
	</head>
	
	<body onLoad=\"$js_browser_detection_onload\">
	<div align=\"center\">
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td width=\"16\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_left_head_b.gif\">&nbsp;</td>
		  <td align=\"center\" bgcolor=\"".$array4[table_bgcolor1]."\"><span class=\"Stil1\">$info_header1 ".$array2[site_name]." $info_header2</span></td>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_right_head.gif\">&nbsp;</td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr align=\"center\">
		  <td height=\"15\" align=\"center\" bgcolor=\"".$array4[table_bgcolor2]."\"><span class=\"Stil1\"><strong>$menu</strong></span></td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td height=\"303\" valign=\"top\" bgcolor=\"#FFFFFF\"><table width=\"100%\"  border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
			  <tr>
			  <br><br><div align=\"center\">$info_zf_output<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\"></div>
			</table>
		  </td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr align=\"center\">
		  <td height=\"15\" align=\"center\" bgcolor=\"".$array4[table_bgcolor2]."\"><strong><span class=\"Stil2\"></span></strong></td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_left_foot_b.gif\">&nbsp;</td>
		  <td bgcolor=\"".$array4[table_bgcolor1]."\">&nbsp;</td>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_right_foot.gif\">&nbsp;</td>
		</tr>
	  </table>
	  <p>".$array2[company_footer]."</p>
	</div>
	</body>
	</html>";
	die();
	}

if (($array[user_group] == "4") || ($array[user_group] == "5")) {
	$info_download_error_output = "$info_download_error1";
	echo "
	<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">
	<html>
	<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">
	<title>".$array2[site_name]."</title>
	$css $js_browser_detection
	</head>
	
	<body onLoad=\"$js_browser_detection_onload\">
	<div align=\"center\">
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td width=\"16\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_left_head_b.gif\">&nbsp;</td>
		  <td align=\"center\" bgcolor=\"".$array4[table_bgcolor1]."\"><span class=\"Stil1\">$info_header1 ".$array2[site_name]." $info_header2</span></td>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_right_head.gif\">&nbsp;</td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr align=\"center\">
		  <td height=\"15\" align=\"center\" bgcolor=\"".$array4[table_bgcolor2]."\"><span class=\"Stil1\"><strong>$menu</strong></span></td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td height=\"303\" valign=\"top\" bgcolor=\"#FFFFFF\"><table width=\"100%\"  border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
			  <tr>
			  <br><br><div align=\"center\">$info_download_error_output<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\"></div>
			</table>
		  </td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr align=\"center\">
		  <td height=\"15\" align=\"center\" bgcolor=\"".$array4[table_bgcolor2]."\"><strong><span class=\"Stil2\"></span></strong></td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_left_foot_b.gif\">&nbsp;</td>
		  <td bgcolor=\"".$array4[table_bgcolor1]."\">&nbsp;</td>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_right_foot.gif\">&nbsp;</td>
		</tr>
	  </table>
	  <p>".$array2[company_footer]."</p>
	</div>
	</body>
	</html>";
	die();
	}

if ($action == "zip") {
	for ($i = 0; $i < count ($select); $i++) {
		$sql3 = "SELECT * FROM `$dbtable5` WHERE `id` = '".$select[$i]."'"; 
		$query3 = mysql_query ($sql3, $dbconnect);
		$array3 = mysql_fetch_array ($query3);
		$zip_files .= "files/".$array3[maincategory]."/".$array3[subcategory]."/".$array3[file_name].",";
		$sql4 = "UPDATE `$dbtable5` SET `download_counter` = `download_counter`+1 WHERE `id` = '".$select[$i]."'"; 
		mysql_query ($sql4, $dbconnect);
		}
	$archive = new PclZip ("files/temp/".$user_id."-".$array[id]."-".$file_date.".zip");
	$v_list = $archive -> create ("$zip_files", PCLZIP_OPT_REMOVE_ALL_PATH);
	}

if ($v_list !== 0) {
	header ("Content-Type: application/x-zip-compressed\n");
	header ("Content-Disposition: attachment; filename=\"".$user_id."-".$array[id]."-".$file_date.".zip\";");
	readfile ("files/temp/".$user_id."-".$array[id]."-".$file_date.".zip");
	unlink ("files/temp/".$user_id."-".$array[id]."-".$file_date.".zip");
	}
else {
	$info_zf_output = "$zip_error2";
	echo "
	<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">
	<html>
	<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">
	<title>".$array2[site_name]."</title>
	$js_highlight_menu
	$css $js_browser_detection
	</head>
	
	<body onLoad=\"$js_browser_detection_onload\">
	<div align=\"center\">
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td width=\"16\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_left_head_b.gif\">&nbsp;</td>
		  <td align=\"center\" bgcolor=\"".$array4[table_bgcolor1]."\"><span class=\"Stil1\">$info_header1 ".$array2[site_name]." $info_header2</span></td>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_right_head.gif\">&nbsp;</td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr align=\"center\">
		  <td height=\"15\" align=\"center\" bgcolor=\"".$array4[table_bgcolor2]."\"><span class=\"Stil1\"><strong>$menu</strong></span></td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td height=\"303\" valign=\"top\" bgcolor=\"#FFFFFF\"><table width=\"100%\"  border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
			  <tr>
			  <br><br><div align=\"center\">$info_zf_output<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\"></div>
			</table>
		  </td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr align=\"center\">
		  <td height=\"15\" align=\"center\" bgcolor=\"".$array4[table_bgcolor2]."\"><strong><span class=\"Stil2\"></span></strong></td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_left_foot_b.gif\">&nbsp;</td>
		  <td bgcolor=\"".$array4[table_bgcolor1]."\">&nbsp;</td>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_right_foot.gif\">&nbsp;</td>
		</tr>
	  </table>
	  <p>".$array2[company_footer]."</p>
	</div>
	</body>
	</html>";
	}

?>