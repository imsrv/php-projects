<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

$sql0 = "SELECT * FROM `$dbtable1` WHERE `theme` = '$dbthemes_name_actual' LIMIT 0, 30"; 
$query0 = mysql_query ($sql0, $dbconnect);
$array0 = mysql_fetch_array ($query0);

admin();

if ($dbthemes_ie_compatible == "true") {
	$dbthemes_ie_compatible = "true";
	}
else {
	$dbthemes_ie_compatible = "false";
	}

if ($delete_theme == "delete") {
	if ($array0[theme] == $dbthemes_name_actual) {
		$info_te_output = "$info_tn_error3<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	else {
		$sql3 = "DELETE FROM `$dbtable2` WHERE `id` = '$id' LIMIT 1";
		mysql_query ($sql3, $dbconnect);
		$info_te_output = "$info_themes_deleted";
		}
	}
elseif ((empty ($dbthemes_name)) || (empty ($dbthemes_description)) || (empty ($dbthemes_directory)) || (empty ($dbthemes_logo)) || (empty ($dbthemes_site_bgcolor)) || (empty ($dbthemes_site_bgimage)) || (empty ($dbthemes_font_family)) || (empty ($dbthemes_font_size)) || (empty ($dbthemes_font_color)) || (empty ($dbthemes_link_size)) || (empty ($dbthemes_link_color)) || (empty ($dbthemes_table_width)) || (empty ($dbthemes_table_bgcolor1)) || (empty ($dbthemes_table_bgcolor2)) || (empty ($dbthemes_table_bgcolor3)) || (empty ($dbthemes_table_bgcolor4)) || (empty ($dbthemes_table_hlcolor1)) || (empty ($dbthemes_table_hlcolor2))) {
	$info_te_output = "$info_te_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif ((!is_numeric ($dbthemes_number_result)) || ($dbthemes_number_result < 1)) {
	$info_te_output = "$info_tn_error1<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
else {
	if ($dbthemes_name !== $dbthemes_name_actual) {
		$sql3 = "SELECT * FROM `$dbtable2` WHERE `theme_name` = '$dbthemes_name'"; 
		$query3 = mysql_query ($sql3, $dbconnect);
		$array3 = mysql_fetch_array ($query3);
		}
	if ($array3[theme_name] == $dbthemes_name) {
		$info_te_output = "$info_tn_error2";
		}
	else {
		$sql = "UPDATE `$dbtable1` SET `theme` = '$dbthemes_name' WHERE `theme` = '$dbthemes_name_actual' LIMIT 1"; 
		mysql_query ($sql, $dbconnect);
		$sql = "UPDATE `$dbtable2` SET `theme_name` = '$dbthemes_name', `theme_description` = '$dbthemes_description', `theme_directory` = '$dbthemes_directory', `logo` = '$dbthemes_logo', `site_bgcolor` = '$dbthemes_site_bgcolor', `site_bgimage` = '$dbthemes_site_bgimage', `number_result` = '$dbthemes_number_result', `font_family` = '$dbthemes_font_family', `font_size` = '$dbthemes_font_size', `font_color` = '$dbthemes_font_color', `link_size` = '$dbthemes_link_size', `link_color` = '$dbthemes_link_color', `table_width` = '$dbthemes_table_width', `table_bgcolor1` = '$dbthemes_table_bgcolor1', `table_bgcolor2` = '$dbthemes_table_bgcolor2', `table_bgcolor3` = '$dbthemes_table_bgcolor3', `table_bgcolor4` = '$dbthemes_table_bgcolor4', `table_hlcolor1` = '$dbthemes_table_hlcolor1', `table_hlcolor2` = '$dbthemes_table_hlcolor2', `ie_compatible` = '$dbthemes_ie_compatible' WHERE `id` = '$id' LIMIT 1"; 
		mysql_query ($sql, $dbconnect);
		$info_te_output = "$info_themes_edit";
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>
		<br>
        <?php echo $info_te_output ?></div>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
