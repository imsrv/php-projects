<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

$sql = "SELECT * FROM `$dbtable3` WHERE `user_session` = '".session_id()."'";
$result = mysql_query ($sql);
$array = mysql_fetch_array ($result);

not_public();

if ($array[email_public] == "true") {
	$email_public_checkbox = "<input name=\"email_public\" type=\"checkbox\" id=\"email_public\" value=\"public\" checked>";
	}
else {
	$email_public_checkbox = "<input name=\"email_public\" type=\"checkbox\" id=\"email_public\" value=\"public\">";
	}

if (!empty ($array[user_gender])) {
	if ($array[user_gender] == "1") {
		$user_gender_select = "
		<option value=\"\"></option>
		<option value=\"2\">$select_desc_gender_female</option>
		<option value=\"1\" selected>$select_desc_gender_male</option>";
		}
	else {
		$user_gender_select = "
		<option value=\"\"></option>
		<option value=\"2\" selected>$select_desc_gender_female</option>
		<option value=\"1\">$select_desc_gender_male</option>";
		}
	}
else {
	$user_gender_select = "
	<option value=\"\" selected></option>
	<option value=\"2\">$select_desc_gender_female</option>
	<option value=\"1\">$select_desc_gender_male</option>";
	}

if ($array[user_image] == "true") {
	$textfield_desc_file = "$textfield_us_desc_5";
	$image_info = "
	<tr bgcolor=\"".$array4[table_bgcolor4]."\">
	<td align=\"left\">$textfield_us_desc_6</td>
	<td align=\"left\"><a href=\"show_user_image.php?id=".$array[id]."\" target=\"_blank\"><font color=\"#0000FF\">$link_user_image</font></a></td>
	</tr>
	<tr bgcolor=\"".$array4[table_bgcolor4]."\">
	<td align=\"left\">$textfield_del_user_image_desc</td>
	<td align=\"left\"><input name=\"delete_user_image\" type=\"checkbox\" id=\"delete_user_image\" value=\"delete\"></td>
	</tr>";
	}
else {
	$textfield_desc_file = "$textfield_us_desc_9";
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_progress_bar $js_progress_message $js_browser_detection"; ?>
</head>

<body onLoad="javascript:bar1.hideBar(); <?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
	  <br>
        <form action="user_profile_edit_execute.php" method="post" enctype="multipart/form-data" name="form1">
          <table width="100%"  border="0" cellspacing="1">
            <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
              <td align="center" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                  <br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                      <legend><?php echo $field_login ?></legend>
					  <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
					    <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
					      <td align="left"><?php echo $textfield_user_name_desc ?></td>
					      <td width="70%" align="left"><input name="dbusers_user_name" type="text" id="dbusers_user_name" value="<?php echo $array[user_name] ?>" size="61" maxlength="30"></td>
				        </tr>
					    <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_user_pw_ch_desc ?></td>
                          <td align="left"><input name="dbusers_password_ch" type="password" id="dbusers_password_ch" size="61" maxlength="30"></td>
				        </tr>
					    <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_user_pw_rep_desc ?></td>
                          <td align="left"><input name="dbusers_password_rep" type="password" id="dbusers_password_rep" size="61" maxlength="30"></td>
					    </tr>
					</table>
                      </fieldset></td>
                    </tr>
                </table>
                  <br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                        <legend><?php echo $field_eup_1 ?></legend>
                        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_firstname_desc ?></td>
                            <td width="70%" align="left"><input name="dbusers_user_firstname" type="text" id="dbusers_user_firstname" value="<?php echo $array[user_firstname] ?>" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_lastname_desc ?></td>
                            <td align="left"><input name="dbusers_user_lastname" type="text" id="dbusers_user_lastname" value="<?php echo $array[user_lastname] ?>" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_email_desc ?></td>
                            <td align="left"><input name="dbusers_user_email" type="text" id="dbusers_user_email" value="<?php echo $array[user_email] ?>" size="61" maxlength="200">
                            <?php echo "$email_public_checkbox $textfield_user_email_pub_desc"; ?></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_website_desc ?></td>
                            <td align="left"><input name="dbusers_user_website" type="text" id="dbusers_user_website" value="<?php echo $array[user_website] ?>" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_birthday_desc ?></td>
                            <td align="left"><input name="dbusers_user_birthday" type="text" id="dbusers_user_birthday" value="<?php echo $array[user_birthday] ?>" size="61" maxlength="10"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_gender_desc ?></td>
                            <td align="left"><select name="dbusers_user_gender" id="dbusers_user_gender" style="width:321px">
							<?php echo $user_gender_select ?>
							</select>
							</td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_street_desc ?></td>
                            <td align="left"><input name="dbusers_user_street" type="text" id="dbusers_user_street" value="<?php echo $array[user_street] ?>" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_zipcode_desc ?></td>
                            <td align="left"><input name="dbusers_user_zipcode" type="text" id="dbusers_user_zipcode" value="<?php echo $array[user_zipcode] ?>" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_city_desc ?></td>
                            <td align="left"><input name="dbusers_user_city" type="text" id="dbusers_user_city" value="<?php echo $array[user_city] ?>" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_state_desc ?></td>
                            <td align="left"><input name="dbusers_user_state" type="text" id="dbusers_user_state" value="<?php echo $array[user_state] ?>" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_country_desc ?></td>
                            <td align="left"><input name="dbusers_user_country" type="text" id="dbusers_user_country" value="<?php echo $array[user_country] ?>" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_phone_desc ?></td>
                            <td align="left"><input name="dbusers_user_phone" type="text" id="dbusers_user_phone" value="<?php echo $array[user_phone] ?>" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_fax_desc ?></td>
                            <td align="left"><input name="dbusers_user_fax" type="text" id="dbusers_user_fax" value="<?php echo $array[user_fax] ?>" size="61" maxlength="200"></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_user_mobile_desc ?></td>
                            <td align="left"><input name="dbusers_user_mobile" type="text" id="dbusers_user_mobile" value="<?php echo $array[user_mobile] ?>" size="61" maxlength="200"></td>
                          </tr>
                      </table>
                      </fieldset></td>
                    </tr>
                </table>
                  <br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                        <legend><?php echo $field_user_pic ?></legend>
                        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left" valign="top"><?php echo $textfield_desc_file ?></td>
                            <td width="70%" align="left"><input name="file" type="file" size="61">
                            <br>
                            <?php echo $info_user_image ?></td>
                          </tr>
						  <?php echo $image_info ?>
                      </table>
                      </fieldset></td>
                    </tr>
                  </table>
                  <br>
              <table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><fieldset>
                    <legend><?php echo $field_delete ?></legend>
                    <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_delete_account_desc ?></td>
                        <td width="70%" align="left"><input name="delete_account" type="checkbox" id="delete_account" value="delete"></td>
                      </tr>
                    </table>
                  </fieldset></td>
                </tr>
              </table>
              <br>
              <input name="id" type="hidden" value="<?php echo $array3[id] ?>">
              <input name="dbusers_user_name_old" type="hidden" id="dbusers_user_name_old" value="<?php echo $array[user_name] ?>"></td>
            </tr>
            <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
              <td align="left" bgcolor="<?php echo $array4[table_bgcolor4] ?>"><div align="center">
                <input type="submit" name="Submit" value="<?php echo $button_save ?>" onClick="javascript:bar1.showBar(); showMessage(); this.disabled=true; window.document['form1'].submit();">
              </div></td>
            </tr>
            <tr>
              <td align="left">&nbsp;</td>
            </tr>
            <tr>
              <td align="center"><table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="left">&nbsp;</td>
                  <td width="70%" align="left"><?php echo $js_progress_bar_output ?></td>
                </tr>
                <tr>
                  <td align="left">&nbsp;</td>
                  <td width="70%" align="left">&nbsp;</td>
                </tr>
                <tr>
                  <td align="left">&nbsp;</td>
                  <td width="70%" align="left"><div id="invisible" style="visibility:hidden;"><?php echo $progress_message ?></div></td>
                </tr>
              </table></td>
            </tr>
          </table>
        </form>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
