<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

$remove_prefix1 = strrpos ($dbtable1, "_") + 1;
$dbtable1 = substr ($dbtable1, $remove_prefix1, strlen ($dbtable1) - $remove_prefix1);

$remove_prefix2 = strrpos ($dbtable2, "_") + 1;
$dbtable2 = substr ($dbtable2, $remove_prefix2, strlen ($dbtable2) - $remove_prefix2);

$remove_prefix3 = strrpos ($dbtable3, "_") + 1;
$dbtable3 = substr ($dbtable3, $remove_prefix3, strlen ($dbtable3) - $remove_prefix3);

$remove_prefix4 = strrpos ($dbtable4, "_") + 1;
$dbtable4 = substr ($dbtable4, $remove_prefix4, strlen ($dbtable4) - $remove_prefix4);

$remove_prefix5 = strrpos ($dbtable5, "_") + 1;
$dbtable5 = substr ($dbtable5, $remove_prefix5, strlen ($dbtable5) - $remove_prefix5);

$remove_prefix6 = strrpos ($dbtable6, "_") + 1;
$dbtable6 = substr ($dbtable6, $remove_prefix6, strlen ($dbtable6) - $remove_prefix6);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>        
        </div>
        <form action="admin_db_execute.php" method="post" name="form1">
          <table width="100%"  border="0" cellspacing="1">
            <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
              <td align="center" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                  <br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                      <legend><?php echo $field_adb_1 ?></legend>
					  <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
					  <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
						<td align="left"><?php echo $textfield_adb_desc_1 ?></td>
						<td width="70%" align="left"><input name="set_dbhost" type="text" id="set_dbhost" value="<?php echo $dbhost ?>" size="61"></td>
					  </tr>
					  <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
						<td align="left"><?php echo $textfield_adb_desc_2 ?></td>
						<td width="70%" align="left"><input name="set_dbname" type="text" id="set_dbname" value="<?php echo $dbname ?>" size="61"></td>
					  </tr>
					  <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
						<td align="left"><?php echo $textfield_adb_desc_3 ?></td>
						<td width="70%" align="left"><input name="set_dbuser" type="text" id="set_dbuser" value="<?php echo $dbuser ?>" size="61"></td>
					  </tr>
					  <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
						<td align="left"><?php echo $textfield_adb_desc_4 ?></td>
						<td width="70%" align="left"><input name="set_dbpass" type="password" id="set_dbpass" value="<?php echo $dbpass ?>" size="61"></td>
					  </tr>
					</table></fieldset></td>
                    </tr>
                </table>
                <br>
              <table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><fieldset>
                    <legend><?php echo $field_adb_2 ?></legend>
                    <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_adb_desc_5 ?></td>
                        <td width="70%" align="left"><input name="set_dbtable_prefix" type="text" id="set_dbtable_prefix" value="<?php echo $dbtable_prefix ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_adb_desc_6 ?></td>
                        <td width="70%" align="left"><input name="set_dbtable1" type="text" id="set_dbtable1" value="<?php echo $dbtable1 ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_adb_desc_7 ?></td>
                        <td width="70%" align="left"><input name="set_dbtable2" type="text" id="set_dbtable2" value="<?php echo $dbtable2 ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_adb_desc_8 ?></td>
                        <td width="70%" align="left"><input name="set_dbtable3" type="text" id="set_dbtable3" value="<?php echo $dbtable3 ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_adb_desc_9 ?></td>
                        <td width="70%" align="left"><input name="set_dbtable4" type="text" id="set_dbtable4" value="<?php echo $dbtable4 ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_adb_desc_10 ?></td>
                        <td width="70%" align="left"><input name="set_dbtable5" type="text" id="set_dbtable5" value="<?php echo $dbtable5 ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_adb_desc_11 ?></td>
                        <td align="left"><input name="set_dbtable6" type="text" id="set_dbtable6" value="<?php echo $dbtable6 ?>" size="61"></td>
                      </tr>
                    </table>
                  </fieldset></td>
                </tr>
              </table>
              <br>
              <table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><fieldset>
                    <legend><?php echo $field_adb_3 ?></legend>
                    <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_adb_desc_12 ?></td>
                        <td width="70%" align="left"><input name="optimize_tables" type="checkbox" id="optimize_tables" value="optimize"></td>
                      </tr>
                    </table>
                  </fieldset></td>
                </tr>
              </table>
              <br></td>
            </tr>
            <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
              <td align="left" bgcolor="<?php echo $array4[table_bgcolor4] ?>"><div align="center">
                <input type="submit" name="Submit" value="<?php echo $button_save ?>">
              </div></td>
            </tr>
            <tr>
              <td align="left">&nbsp;</td>
            </tr>
            <tr>
              <td align="center"><table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="left">
                    <?php echo "$info_backup_config <a href=\"backup_config.php\"><p><font color=\"#0000FF\">$link_backup_config</font></a>"; ?>
                  </td>
                </tr>
              </table>
              </td>
            </tr>
          </table>
        </form>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
