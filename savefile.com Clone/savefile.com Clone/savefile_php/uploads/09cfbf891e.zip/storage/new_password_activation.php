<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("library/config/config.php");
include ("library/js.php");

$sql2 = "SELECT * FROM `$dbtable1` LIMIT 0, 30"; 
$query2 = mysql_query ($sql2, $dbconnect);
$array2 = mysql_fetch_array ($query2);

$sql0 = "SELECT * FROM `$dbtable3` WHERE `user_name` = '$user_name' AND `user_email` = '$user_email'"; 
$query0 = mysql_query ($sql0, $dbconnect);
$array0 = mysql_fetch_array ($query0);

$sql4 = "SELECT * FROM `$dbtable2` WHERE `theme_name` = '".$array2[theme]."' LIMIT 0, 30"; 
$query4 = mysql_query ($sql4, $dbconnect);
$array4 = mysql_fetch_array ($query4);

include ("themes/".$array4[theme_directory]."/library/css.php");
include ("library/languages/".$array2[language].".php");

if (empty ($array0[user_password_temp])) {
	$info_password_activated_output = "$info_password_activated<p><input name=\"Login\" type=\"button\" id=\"Login\" onClick=\"window.location.href='index.php'\" value=\"$button_login\">";
	}
elseif (($array0[user_name] == $user_name) && ($array0[user_email] == $user_email) && ($array0[user_password_temp] == $user_password)) {
	$sql = "UPDATE `$dbtable3` SET `user_password` = '$user_password', `user_password_temp` = '' WHERE `user_name` = '$user_name'";
	mysql_query ($sql, $dbconnect);
	$info_password_activated_output = "$info_password_activation_success<p><input name=\"Login\" type=\"button\" id=\"Login\" onClick=\"window.location.href='index.php'\" value=\"$button_login\">";
	}
else {
	$info_password_activated_output = "$info_password_activation_error";
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" align="center" valign="top" bgcolor="#FFFFFF"><br>
        <br>
          <?php echo $info_password_activated_output ?>
      </td></tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
