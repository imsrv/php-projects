<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

if ($get_order == "asc") {
	$query_order = "ASC";
	$sort_order = "desc";
	}
if ($get_order == "desc") {
	$query_order = "DESC";
	$sort_order = "asc";
	}

if (($sort_order == "") || ($sort_order == "asc")) {
	$query_order = "DESC";
	$sort_order = "desc";	//Same Value like $query_order because of Splitting Pages and reading from Table-End
	}
elseif ($sort_order == "desc") {
	$query_order = "ASC";
	$sort_order = "asc";	//Same Value like $query_order because of Splitting Pages and reading from Table-End
	}
else {
	$query_order = "DESC";
	$sort_order = "desc";	//Same Value like $query_order because of Splitting Pages and reading from Table-End
	}

//Search-Type=All
if (($select_select == "select_all") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_name` LIKE \"%$search%\" OR `user_firstname` LIKE \"%$search%\" OR `user_lastname` LIKE \"%$search%\"  OR `user_email` LIKE \"%$search%\"  OR `user_website` LIKE \"%$search%\" OR `user_birthday` LIKE \"%$search%\" OR `user_city` LIKE \"%$search%\"  OR `user_country` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_all") && ($order == "user_name")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_name` LIKE \"%$search%\" OR `user_firstname` LIKE \"%$search%\" OR `user_lastname` LIKE \"%$search%\"  OR `user_email` LIKE \"%$search%\"  OR `user_website` LIKE \"%$search%\" OR `user_birthday` LIKE \"%$search%\" OR `user_city` LIKE \"%$search%\"  OR `user_country` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_all") && ($order == "user_firstname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_name` LIKE \"%$search%\" OR `user_firstname` LIKE \"%$search%\" OR `user_lastname` LIKE \"%$search%\"  OR `user_email` LIKE \"%$search%\"  OR `user_website` LIKE \"%$search%\" OR `user_birthday` LIKE \"%$search%\" OR `user_city` LIKE \"%$search%\"  OR `user_country` LIKE \"%$search%\" ORDER BY `user_firstname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_all") && ($order == "user_lastname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_name` LIKE \"%$search%\" OR `user_firstname` LIKE \"%$search%\" OR `user_lastname` LIKE \"%$search%\"  OR `user_email` LIKE \"%$search%\"  OR `user_website` LIKE \"%$search%\" OR `user_birthday` LIKE \"%$search%\" OR `user_city` LIKE \"%$search%\"  OR `user_country` LIKE \"%$search%\" ORDER BY `user_lastname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_all") && ($order == "user_email")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_name` LIKE \"%$search%\" OR `user_firstname` LIKE \"%$search%\" OR `user_lastname` LIKE \"%$search%\"  OR `user_email` LIKE \"%$search%\"  OR `user_website` LIKE \"%$search%\" OR `user_birthday` LIKE \"%$search%\" OR `user_city` LIKE \"%$search%\"  OR `user_country` LIKE \"%$search%\" ORDER BY `user_email` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_all") && ($order == "user_website")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_name` LIKE \"%$search%\" OR `user_firstname` LIKE \"%$search%\" OR `user_lastname` LIKE \"%$search%\"  OR `user_email` LIKE \"%$search%\"  OR `user_website` LIKE \"%$search%\" OR `user_birthday` LIKE \"%$search%\" OR `user_city` LIKE \"%$search%\"  OR `user_country` LIKE \"%$search%\" ORDER BY `user_website` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=Username
if (($select_select == "select_user_name") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_name` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_name") && ($order == "user_name")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_name` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_name") && ($order == "user_firstname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_name` LIKE \"%$search%\" ORDER BY `user_firstname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_name") && ($order == "user_lastname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_name` LIKE \"%$search%\" ORDER BY `user_lastname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_name") && ($order == "user_email")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_name` LIKE \"%$search%\" ORDER BY `user_email` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_name") && ($order == "user_website")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_name` LIKE \"%$search%\" ORDER BY `user_website` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=User-Firstname
if (($select_select == "select_user_firstname") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_firstname` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_firstname") && ($order == "user_name")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_firstname` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_firstname") && ($order == "user_firstname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_firstname` LIKE \"%$search%\" ORDER BY `user_firstname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_firstname") && ($order == "user_lastname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_firstname` LIKE \"%$search%\" ORDER BY `user_lastname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_firstname") && ($order == "user_email")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_firstname` LIKE \"%$search%\" ORDER BY `user_email` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_firstname") && ($order == "user_website")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_firstname` LIKE \"%$search%\" ORDER BY `user_website` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=User-Lastname
if (($select_select == "select_user_lastname") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_lastname` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_lastname") && ($order == "user_name")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_lastname` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_lastname") && ($order == "user_firstname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_lastname` LIKE \"%$search%\" ORDER BY `user_firstname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_lastname") && ($order == "user_lastname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_lastname` LIKE \"%$search%\" ORDER BY `user_lastname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_lastname") && ($order == "user_email")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_lastname` LIKE \"%$search%\" ORDER BY `user_email` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_lastname") && ($order == "user_website")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_lastname` LIKE \"%$search%\" ORDER BY `user_website` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=User-E-Mail
if (($select_select == "select_user_email") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_email` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_email") && ($order == "user_name")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_email` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_email") && ($order == "user_firstname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_email` LIKE \"%$search%\" ORDER BY `user_firstname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_email") && ($order == "user_lastname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_email` LIKE \"%$search%\" ORDER BY `user_lastname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_email") && ($order == "user_email")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_email` LIKE \"%$search%\" ORDER BY `user_email` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_email") && ($order == "user_website")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_email` LIKE \"%$search%\" ORDER BY `user_website` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=User-Website
if (($select_select == "select_user_website") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_website` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_website") && ($order == "user_name")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_website` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_website") && ($order == "user_firstname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_website` LIKE \"%$search%\" ORDER BY `user_firstname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_website") && ($order == "user_lastname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_website` LIKE \"%$search%\" ORDER BY `user_lastname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_website") && ($order == "user_email")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_website` LIKE \"%$search%\" ORDER BY `user_email` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_website") && ($order == "user_website")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_website` LIKE \"%$search%\" ORDER BY `user_website` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=User-Birthday
if (($select_select == "select_user_birthday") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_birthday` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_birthday") && ($order == "user_name")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_birthday` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_birthday") && ($order == "user_firstname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_birthday` LIKE \"%$search%\" ORDER BY `user_firstname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_birthday") && ($order == "user_lastname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_birthday` LIKE \"%$search%\" ORDER BY `user_lastname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_birthday") && ($order == "user_email")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_birthday` LIKE \"%$search%\" ORDER BY `user_email` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_birthday") && ($order == "user_website")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_birthday` LIKE \"%$search%\" ORDER BY `user_website` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=User-City
if (($select_select == "select_user_city") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_city` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_city") && ($order == "user_name")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_city` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_city") && ($order == "user_firstname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_city` LIKE \"%$search%\" ORDER BY `user_firstname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_city") && ($order == "user_lastname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_city` LIKE \"%$search%\" ORDER BY `user_lastname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_city") && ($order == "user_email")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_city` LIKE \"%$search%\" ORDER BY `user_email` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_city") && ($order == "user_website")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_city` LIKE \"%$search%\" ORDER BY `user_website` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=User-Country
if (($select_select == "select_user_country") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_country` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_country") && ($order == "user_name")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_country` LIKE \"%$search%\" ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_country") && ($order == "user_firstname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_country` LIKE \"%$search%\" ORDER BY `user_firstname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_country") && ($order == "user_lastname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_country` LIKE \"%$search%\" ORDER BY `user_lastname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_country") && ($order == "user_email")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_country` LIKE \"%$search%\" ORDER BY `user_email` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_country") && ($order == "user_website")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_country` LIKE \"%$search%\" ORDER BY `user_website` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=User-Group
if (($select_select == "select_user_group") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_group` = '$search' ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_group") && ($order == "user_name")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_group` = '$search' ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_group") && ($order == "user_firstname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_group` = '$search' ORDER BY `user_firstname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_group") && ($order == "user_lastname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_group` = '$search' ORDER BY `user_lastname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_group") && ($order == "user_email")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_group` = '$search' ORDER BY `user_email` $query_order";
	$query0 = mysql_query ("SELECT * FROM `$dbtable3` WHERE `user_group` = '$search' ORDER BY `user_email` $query_order");
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_group") && ($order == "user_website")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_group` = '$search' ORDER BY `user_website` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=User-Account not activated
if (($select_select == "select_user_not_activated") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_country` LIKE \"%$search%\" AND `activated` = 'false' ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_not_activated") && ($order == "user_name")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_country` LIKE \"%$search%\" AND `activated` = 'false' ORDER BY `user_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_not_activated") && ($order == "user_firstname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_country` LIKE \"%$search%\" AND `activated` = 'false' ORDER BY `user_firstname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_not_activated") && ($order == "user_lastname")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_country` LIKE \"%$search%\" AND `activated` = 'false' ORDER BY `user_lastname` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_not_activated") && ($order == "user_email")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_country` LIKE \"%$search%\" AND `activated` = 'false' ORDER BY `user_email` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_user_not_activated") && ($order == "user_website")) {
	$sql = "SELECT * FROM `$dbtable3` WHERE `user_country` LIKE \"%$search%\" AND `activated` = 'false' ORDER BY `user_website` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}

if ((empty ($array4[number_result])) || (($array4[number_result] == "0")) || (!is_numeric ($array4[number_result]))) {
	$number_result = 30;
	}
else {
	$number_result = $array4[number_result];
	}

if ((!empty ($user_number_result)) && (is_numeric ($user_number_result))) {
	$number_result = $user_number_result;
	}

$count = mysql_num_rows ($query1);

$c = 0;
while ($count > 0) {
	$c++;
	$count = $count - $number_result;
	}

if (!isset ($page)) {
   $page = 1;
   $pag = $page - 1;
   }

if ($page > 1) {
	$navigation .= "<a href=\"".$PHP_SELF."?page=1&search=$search&select_select=$select_select&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">&laquo;</a>&nbsp;";
	$navigation .= "<a href=\"".$PHP_SELF."?page=".$pag."&search=$search&select_select=$select_select&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">&lsaquo;</a>&nbsp;";
	}

for ($b = 1; $b <= $c; $b++) {
   $site = $b;
	if (isset ($page) && $page == $site) {
		$navigation .= "<font color=\"".$array_cs3[table_bgcolor3]."\">".$b."</font>&nbsp;";
		}
	else {
		$navigation .= "<a href=\"".$PHP_SELF."?page=$site&search=$search&select_select=$select_select&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">$b</a>&nbsp;";
		}
	}

$pag = $page + 1;
if ($page < $c) {
	$navigation .= "<a href=\"".$PHP_SELF."?page=".$pag."&search=$search&select_select=$select_select&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">&rsaquo;</a>&nbsp;";
	$navigation .= "<a href=\"".$PHP_SELF."?page=$c&search=$search&select_select=$select_select&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">&raquo;</a>&nbsp;";
	}

$array = array();
while ($l = mysql_fetch_array ($query1)) {
	array_push ($array, $l);
	}

$count_2 = mysql_num_rows ($query1);

if ($count_2 > $number_result) {
	$navigation_output = $navigation;
	}

for ($i = ($count_2 - $number_result * $page + $number_result) - 1; $i > ($count_2 - $number_result * $page) - 1; $i--) {
	if ($i >= 0) {
		if (!empty ($array[$i][user_session])) {
			$user_status = "$textfield_user_online_desc";
			$user_status_desc = "$link_desc_user_online";
			}
		else {
			$user_status = "$textfield_user_offline_desc";
			$user_status_desc = "$link_desc_user_offline";
			}
		$show_users .= "
		<tr>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" onClick=\"location.href='admin_users_edit.php?id=".$array[$i][id]."'\" class=\"Element1\" onmouseover=\"this.className='Element1A_hover'\" onmouseout=\"this.className='Element1'\" title=\"".$array[$i][user_name]."\"><strong>".(strlen ($array[$i][user_name]) > 22 ? substr ($array[$i][user_name], 0, 22) . '...' : $array[$i][user_name])."</strong></td></a>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$array[$i][user_firstname]."\">".(strlen ($array[$i][user_firstname]) > 25 ? substr ($array[$i][user_firstname], 0, 25) . '...' : $array[$i][user_firstname])."</td>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$array[$i][user_lastname]."\">".(strlen ($array[$i][user_lastname]) > 25 ? substr ($array[$i][user_lastname], 0, 25) . '...' : $array[$i][user_lastname])."</td>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$array[$i][user_email]."\"><a href=\"mailto:".$array[$i][user_email]."\"><font color=\"#0000FF\">".(strlen ($array[$i][user_email]) > 25 ? substr ($array[$i][user_email], 0, 25) . '...' : $array[$i][user_email])."</font></a></td>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$array[$i][user_website]."\"><a href=\"".$array[$i][user_website]."\" target=\"_blank\"><font color=\"#0000FF\">".(strlen ($array[$i][user_website]) > 25 ? substr ($array[$i][user_website], 0, 25) . '...' : $array[$i][user_website])."</font></a></td>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$user_status_desc."\">$user_status</td>
		<td align=\"center\" bgcolor=\"".$array4[table_bgcolor4]."\"><input name=\"select[]\" type=\"checkbox\" id=\"select[]\" value=\"".$array[$i][id]."\"></td>
		</tr>";
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_select_checkbox $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>        
        </div>
        <form action="admin_users_delete.php" method="post" name="results">
          <table width="100%" border="0" cellspacing="1">
            <tr bgcolor="<?php echo $array4[table_bgcolor3] ?>">
			  <td align="left" width="17%"><span class="Stil2"><a href="<?php echo "".$PHP_SELF."?search=$search&select_select=$select_select&order=user_name&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_user_name ?>"><?php echo $textfield_user_name_desc ?></a></span></td>
			  <td align="left" width="17%"><span class="Stil2"><a href="<?php echo "".$PHP_SELF."?search=$search&select_select=$select_select&order=user_firstname&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_user_firstname ?>"><?php echo $textfield_user_firstname_desc ?></a></span></td>
			  <td align="left" width="17%"><span class="Stil2"><a href="<?php echo "".$PHP_SELF."?search=$search&select_select=$select_select&order=user_lastname&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_user_lastname ?>"><?php echo $textfield_user_lastname_desc ?></a></span></td>
			  <td align="left" width="17%"><span class="Stil2"><a href="<?php echo "".$PHP_SELF."?search=$search&select_select=$select_select&order=user_email&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_user_email ?>"><?php echo $textfield_user_email_desc ?></a></span></td>
			  <td align="left" width="17%"><span class="Stil2"><a href="<?php echo "".$PHP_SELF."?search=$search&select_select=$select_select&order=user_website&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_user_website ?>"><?php echo $textfield_user_website_desc ?></a></span></td>
			  <td align="left" width="10%"><span class="Stil2"><?php echo $textfield_user_status_desc ?></span></td>
			  <td align="center" width="5%"><span class="Stil2"><a href="javascript:CheckAll()" class="menulink" title="<?php echo $link_desc_user_delete ?>"><?php echo $description_file_delete ?></a></span></td>
            </tr>
		    <?php echo $show_users; ?>
            <tr align="left">
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td><input name="action" type="hidden" id="action" value="delete"></td>
              <td align="center"><input type="submit" name="Submit" value="  X  " onClick="javascript:return confirm('<?php echo $delete_user_confirm ?>');"></td>
            </tr>
          </table>
        </form>
	  <center>
		<form name="form_user_results" method="post" action="<?php echo "".$PHP_SELF."?search=$search&select_select=$select_select&order=$order&get_order=$sort_order" ?>">
			<input name="user_number_result" type="text" id="user_number_result" value="<?php echo $user_number_result ?>" size="4">				  
			<input type="submit" name="Submit" value="<?php echo $button_per_site ?>">
		</form>
	  </center>
      </td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"><?php echo $navigation_output ?></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
