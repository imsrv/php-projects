<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

if ($get_order == "asc") {
	$query_order = "ASC";
	$sort_order = "desc";
	}
if ($get_order == "desc") {
	$query_order = "DESC";
	$sort_order = "asc";
	}

if (($sort_order == "") || ($sort_order == "asc")) {
	$query_order = "DESC";
	$sort_order = "desc";	//Same Value like $query_order because of Splitting Pages and reading from Table-End
	}
elseif ($sort_order == "desc") {
	$query_order = "ASC";
	$sort_order = "asc";	//Same Value like $query_order because of Splitting Pages and reading from Table-End
	}
else {
	$query_order = "DESC";
	$sort_order = "desc";	//Same Value like $query_order because of Splitting Pages and reading from Table-End
	}

//Search-Type=All
if (($select_select == "select_all") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_name` LIKE \"%$search%\" OR `filetype_description` LIKE \"%$search%\" ORDER BY `filetype_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_all") && ($order == "filetype_name")) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_name` LIKE \"%$search%\" OR `filetype_description` LIKE \"%$search%\" ORDER BY `filetype_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_all") && ($order == "filetype_description")) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_name` LIKE \"%$search%\" OR `filetype_description` LIKE \"%$search%\" ORDER BY `filetype_description` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=Name
if (($select_select == "select_filetype_name") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_name` LIKE \"%$search%\" ORDER BY `filetype_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_filetype_name") && ($order == "filetype_name")) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_name` LIKE \"%$search%\" ORDER BY `filetype_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_filetype_name") && ($order == "filetype_description")) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_name` LIKE \"%$search%\" ORDER BY `filetype_description` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=Description
if (($select_select == "select_filetype_description") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_description` LIKE \"%$search%\" ORDER BY `filetype_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_filetype_description") && ($order == "filetype_name")) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_description` LIKE \"%$search%\" ORDER BY `filetype_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_filetype_description") && ($order == "filetype_description")) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_description` LIKE \"%$search%\" ORDER BY `filetype_description` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=Filetype unlocked
if (($select_select == "select_filetype_unlocked") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_locked` = 'false' ORDER BY `filetype_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_filetype_unlocked") && ($order == "filetype_name")) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_locked` = 'false' ORDER BY `filetype_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_filetype_unlocked") && ($order == "filetype_description")) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_locked` = 'false' ORDER BY `filetype_description` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
//Search-Type=Filetype locked
if (($select_select == "select_filetype_locked") && (empty ($order))) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_locked` = 'true' ORDER BY `filetype_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_filetype_locked") && ($order == "filetype_name")) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_locked` = 'true' ORDER BY `filetype_name` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}
if (($select_select == "select_filetype_locked") && ($order == "filetype_description")) {
	$sql = "SELECT * FROM `$dbtable6` WHERE `filetype_locked` = 'true' `filetype_description` $query_order";
	$query1 = mysql_query ($sql, $dbconnect);
	}

if ((empty ($array4[number_result])) || (($array4[number_result] == "0")) || (!is_numeric ($array4[number_result]))) {
	$number_result = 30;
	}
else {
	$number_result = $array4[number_result];
	}

if ((!empty ($user_number_result)) && (is_numeric ($user_number_result))) {
	$number_result = $user_number_result;
	}

$count = mysql_num_rows ($query1);

$c = 0;
while ($count > 0) {
	$c++;
	$count = $count - $number_result;
	}

if (!isset ($page)) {
   $page = 1;
   $pag = $page - 1;
   }

if ($page > 1) {
	$navigation .= "<a href=\"".$PHP_SELF."?page=1&search=$search&select_select=$select_select&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">&laquo;</a>&nbsp;";
	$navigation .= "<a href=\"".$PHP_SELF."?page=".$pag."&search=$search&select_select=$select_select&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">&lsaquo;</a>&nbsp;";
	}

for ($b = 1; $b <= $c; $b++) {
   $site = $b;
	if (isset ($page) && $page == $site) {
		$navigation .= "<font color=\"".$array_cs3[table_bgcolor3]."\">".$b."</font>&nbsp;";
		}
	else {
		$navigation .= "<a href=\"".$PHP_SELF."?page=$site&search=$search&select_select=$select_select&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">$b</a>&nbsp;";
		}
	}

$pag = $page + 1;
if ($page < $c) {
	$navigation .= "<a href=\"".$PHP_SELF."?page=".$pag."&search=$search&select_select=$select_select&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">&rsaquo;</a>&nbsp;";
	$navigation .= "<a href=\"".$PHP_SELF."?page=$c&search=$search&select_select=$select_select&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">&raquo;</a>&nbsp;";
	}

$array = array();
while ($l = mysql_fetch_array ($query1)) {
	array_push ($array, $l);
	}

$count_2 = mysql_num_rows ($query1);

if ($count_2 > $number_result) {
	$navigation_output = $navigation;
	}

for ($i = ($count_2 - $number_result * $page + $number_result) - 1; $i > ($count_2 - $number_result * $page) - 1; $i--) {
	if ($i >= 0) {
		if ($array[$i][filetype_locked] == "false") {
			$checkbox_lock_output = "<input name=\"select2[]\" type=\"checkbox\" id=\"select2[]\" value=\"".$array[$i][id]."\">";
			$filetype_status_output = "$filetype_status_unlocked";
			$filetype_status_desc = "$link_desc_filetype_unlocked";
			}
		else {
			$checkbox_lock_output = "<input name=\"select2[]\" type=\"checkbox\" id=\"select2[]\" value=\"".$array[$i][id]."\" checked>";
			$filetype_status_output = "$filetype_status_locked";
			$filetype_status_desc = "$link_desc_filetype_locked";
			}
		$show_filetypes .= "
		<tr>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" onClick=\"location.href='admin_filetypes_edit.php?id=".$array[$i][id]."'\" class=\"Element1\" onmouseover=\"this.className='Element1A_hover'\" onmouseout=\"this.className='Element1'\" title=\"".$array[$i][filetype_name]."\"><strong>".(strlen ($array[$i][filetype_name]) > 30 ? substr ($array[$i][filetype_name], 0, 30) . '...' : $array[$i][filetype_name])."</strong></td>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$array[$i][filetype_description]."\">".(strlen ($array[$i][filetype_description]) > 95 ? substr ($array[$i][filetype_description], 0, 95) . '...' : $array[$i][filetype_description])."</td>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$filetype_status_desc."\">$filetype_status_output</td>
		<td align=\"center\" bgcolor=\"".$array4[table_bgcolor4]."\"><input name=\"select[]\" type=\"checkbox\" id=\"select[]\" value=\"".$array[$i][id]."\"></td>
		</tr>";
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_select_checkbox $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>        
        </div>
        <form action="admin_filetypes_delete.php" method="post" name="results">
        <table width="100%" border="0" cellspacing="1">
        <tr bgcolor="<?php echo $array4[table_bgcolor3] ?>">
          <td align="left" width="20%"><span class="Stil1"><a href="<?php echo "".$PHP_SELF."?search=$search&select_select=$select_select&order=filetype_name&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_filetype_name ?>"><?php echo $description_filetype_name ?></a></span></td>
          <td align="left" width="55%"><span class="Stil1"><a href="<?php echo "".$PHP_SELF."?search=$search&select_select=$select_select&order=filetype_description&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_filetype_description ?>"><?php echo $description_filetype_description ?></a></span></td>
          <td align="left" width="20%"><span class="Stil2"><?php echo $description_filetype_status ?></span></td>
          <td align="center" width="5%"><span class="Stil2"><a href="javascript:CheckAll()" class="menulink" title="<?php echo $link_desc_filetype_delete ?>"><?php echo $description_filetype_delete ?></a></span></td>
      	</tr>
		<?php echo $show_filetypes; ?>
        <tr align="left">
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><input name="action" type="hidden" id="action" value="delete"></td>
          <td align="center"><input type="submit" name="delete" value="  X  " onClick="javascript:return confirm('<?php echo $delete_filetype_confirm ?>');"></td>
        </tr>
      </table>
      </form>
	  <center>
		<form name="form_user_results" method="post" action="<?php echo "".$PHP_SELF."?search=$search&select_select=$select_select&order=$order&get_order=$sort_order" ?>">
			<input name="user_number_result" type="text" id="user_number_result" value="<?php echo $user_number_result ?>" size="4">				  
			<input type="submit" name="Submit" value="<?php echo $button_per_site ?>">
		</form>
	  </center>
	  </td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"><?php echo $navigation_output ?></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
