<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

$dot = strrpos ($file_name, ".") + 1;
$file_extension = substr ($file_name, $dot, strlen ($file_name) - $dot);
$file_date = date ("d.m.Y - H:i:s");

$sql0 = "SELECT * FROM `$dbtable5` WHERE `file_subject` = '$dbfiles_file_subject' OR `file_name` = '$file_name'"; 
$query0 = mysql_query ($sql0, $dbconnect);
$array0 = mysql_fetch_array ($query0);

$sql = "SELECT * FROM `$dbtable3` WHERE user_session='".session_id()."'";
$query = mysql_query ($sql);
$array = mysql_fetch_array ($query);

$sql6 = "SELECT * FROM `$dbtable6` WHERE `filetype_name` = '$file_extension' AND `filetype_locked` = 'true'"; 
$query6 = mysql_query ($sql6);
$array6 = mysql_fetch_array ($query6);

if (($array2[upload_locked] == "true") && (!empty ($array2[upload_locked_reason]))) {
	$info_upload_locked_reason_output = "<font color=\"#FF0000\">".$array2[upload_locked_reason]."</font>";
	$info_upload_locked_reason_output = nl2br ($info_upload_locked_reason_output);
	}
else {
	$info_upload_locked_reason_output = "$info_upload_locked_no_reason";
	}
if (($array2[upload_locked] == "true") && ($array[user_name] !== "admin")) {
	$info_upload_locked_output = "$info_upload_locked";
	echo "
	<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">
	<html>
	<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">
	<title>".$array2[site_name]."</title>
	$css $js_browser_detection
	</head>
	
	<body onLoad=\"$js_browser_detection_onload\">
	<div align=\"center\">
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td width=\"16\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_left_head_b.gif\">&nbsp;</td>
		  <td align=\"center\" bgcolor=\"".$array4[table_bgcolor1]."\"><span class=\"Stil1\">$info_header1 ".$array2[site_name]." $info_header2</span></td>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_right_head.gif\">&nbsp;</td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr align=\"center\">
		  <td height=\"15\" align=\"center\" bgcolor=\"".$array4[table_bgcolor2]."\"><span class=\"Stil1\"><strong>$menu</strong></span></td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td height=\"303\" valign=\"top\" bgcolor=\"#FFFFFF\"><table width=\"100%\"  border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
			  <tr>
			  <br><br><div align=\"center\">$info_upload_locked_output$info_upload_locked_reason_output<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\"></div>
			</table>
		  </td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr align=\"center\">
		  <td height=\"15\" align=\"center\" bgcolor=\"".$array4[table_bgcolor2]."\"><strong><span class=\"Stil2\"></span></strong></td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_left_foot_b.gif\">&nbsp;</td>
		  <td bgcolor=\"".$array4[table_bgcolor1]."\">&nbsp;</td>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_right_foot.gif\">&nbsp;</td>
		</tr>
	  </table>
	  <p>".$array2[company_footer]."</p>
	</div>
	</body>
	</html>";
	die();
	}

if (($array[user_group] == "2") || ($array[user_group] == "5")) {
	$info_upload_error_output = "$info_upload_error2";
	echo "
	<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">
	<html>
	<head>
	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">
	<title>".$array2[site_name]."</title>
	$css $js_browser_detection
	</head>
	
	<body onLoad=\"$js_browser_detection_onload\">
	<div align=\"center\">
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td width=\"16\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_left_head_b.gif\">&nbsp;</td>
		  <td align=\"center\" bgcolor=\"".$array4[table_bgcolor1]."\"><span class=\"Stil1\">$info_header1 ".$array2[site_name]." $info_header2</span></td>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_right_head.gif\">&nbsp;</td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr align=\"center\">
		  <td height=\"15\" align=\"center\" bgcolor=\"#638BC7\"><span class=\"Stil1\"><strong>$menu</strong></span></td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td height=\"303\" valign=\"top\" bgcolor=\"#FFFFFF\"><table width=\"100%\"  border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
			  <tr>
			  <br><br><div align=\"center\">$info_upload_error_output<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\"></div>
			</table>
		  </td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
		<tr align=\"center\">
		  <td height=\"15\" align=\"center\" bgcolor=\"#638BC7\"><strong><span class=\"Stil2\"></span></strong></td>
		</tr>
	  </table>
	  <table width=\"".$array4[table_width]."\"  border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
		<tr>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_left_foot_b.gif\">&nbsp;</td>
		  <td bgcolor=\"".$array4[table_bgcolor1]."\">&nbsp;</td>
		  <td width=\"19\" height=\"19\" background=\"themes/".$array4[theme_directory]."/images/table_corner_right_foot.gif\">&nbsp;</td>
		</tr>
	  </table>
	  <p>".$array2[company_footer]."</p>
	</div>
	</body>
	</html>";
	die();
	}

if ((empty ($maincategory)) || (empty ($subcategory)) || (empty ($dbfiles_file_subject)) || (empty ($dbfiles_file_description)) || (empty ($file))) {
	$info_upload_output = "$info_upload_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif ($array6[filetype_name] == $file_extension) {
	$info_upload_output = "$info_upload_error4<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif (($array0[file_subject] == $dbfiles_file_subject) || ($array0[file_name] == $file_name)) {
	$info_upload_output = "$info_upload_error3<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif (@!copy ($file, "files/$maincategory_id/$subcategory_id/$file_name")) {
	$info_upload_output = "$info_upload_error1<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
else {
	if ((!empty ($array2[limit_file_size])) && ($file_size > $array2[limit_file_size])) {
		if ($array2[file_size] == "Byte") {
			$limit_file_size = $array2[limit_file_size];
			$limit_file_size_output = "$limit_file_size $select_file_size_byte";
			}
		elseif ($array2[file_size] == "KB") {
			$limit_file_size = $array2[limit_file_size] / 1024;
			$limit_file_size_output = "$limit_file_size $select_file_size_kb";
			}
		elseif ($array2[file_size] == "MB") {
			$limit_file_size = $array2[limit_file_size] / 1048576;
			$limit_file_size_output = "$limit_file_size $select_file_size_mb";
			}
		elseif ($array2[file_size] == "GB") {
			$limit_file_size = $array2[limit_file_size] / 1073741824;
			$limit_file_size_output = "$limit_file_size $select_file_size_gb";
			}
		elseif ($array2[file_size] == "TB") {
			$limit_file_size = $array2[limit_file_size] / 1099511627776;
			$limit_file_size_output = "$limit_file_size $select_file_size_tb";
			}
		elseif ($array2[file_size] == "PB") {
			$limit_file_size = $array2[limit_file_size] / 1125899906842624;
			$limit_file_size_output = "$limit_file_size $select_file_size_pb";
			}
		elseif ($array2[file_size] == "EB") {
			$limit_file_size = $array2[limit_file_size] / 1152921504606847000;
			$limit_file_size_output = "$limit_file_size $select_file_size_eb";
			}
		$info_upload_output = "$info_upload_error <font color=\"#FF0000\">$limit_file_size_output.</font><p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	elseif ((!empty ($array[limit_file_size])) && ($file_size > $array[limit_file_size])) {
			if ($array[file_size] == "Byte") {
			$limit_file_size = $array[limit_file_size];
			$limit_file_size_output = "$limit_file_size $select_file_size_byte";
			}
		elseif ($array[file_size] == "KB") {
			$limit_file_size = $array[limit_file_size] / 1024;
			$limit_file_size_output = "$limit_file_size $select_file_size_kb";
			}
		elseif ($array[file_size] == "MB") {
			$limit_file_size = $array[limit_file_size] / 1048576;
			$limit_file_size_output = "$limit_file_size $select_file_size_mb";
			}
		elseif ($array[file_size] == "GB") {
			$limit_file_size = $array[limit_file_size] / 1073741824;
			$limit_file_size_output = "$limit_file_size $select_file_size_gb";
			}
		elseif ($array[file_size] == "TB") {
			$limit_file_size = $array[limit_file_size] / 1099511627776;
			$limit_file_size_output = "$limit_file_size $select_file_size_tb";
			}
		elseif ($array[file_size] == "PB") {
			$limit_file_size = $array[limit_file_size] / 1125899906842624;
			$limit_file_size_output = "$limit_file_size $select_file_size_pb";
			}
		elseif ($array[file_size] == "EB") {
			$limit_file_size = $array[limit_file_size] / 1152921504606847000;
			$limit_file_size_output = "$limit_file_size $select_file_size_eb";
			}
		$info_upload_output = "$info_upload_error_user <font color=\"#FF0000\">$limit_file_size_output.</font><p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	else {
		$sql = "INSERT INTO `$dbtable5` (`file_subject`, `file_description`, `file_name`, `file_size`, `file_extension`, `file_date`, `maincategory`, `subcategory`, `mime_type`, `upload_user_id`) VALUES ('$dbfiles_file_subject', '$dbfiles_file_description', '$file_name', '$file_size', '$file_extension', '$file_date', '$maincategory_id', '$subcategory_id', '$file_type', '".$array[id]."')";
		mysql_query ($sql, $dbconnect);
		copy ($file, "files/$maincategory_id/$subcategory_id/$file_name");
		$sql3 = "SELECT * FROM `$dbtable5` WHERE `file_name` = '$file_name' AND `file_date` = '$file_date' LIMIT 1"; 
		$query3 = mysql_query ($sql3, $dbconnect);
		$array3 = mysql_fetch_array ($query3);
		$sql5 = "SELECT * FROM `$dbtable3` WHERE `id` = '".$array3[upload_user_id]."' LIMIT 1"; 
		$query5 = mysql_query ($sql5, $dbconnect);
		$array5 = mysql_fetch_array ($query5);
		if ($array2[new_upload_report] == "true") {
			if ($array3[file_size] > 1152921504606847000) {
				$array3[file_size] = round (($array3[file_size]/1152921504606847000),2);
				$file_size_output = "".$array3[file_size]." EB";
				}
			elseif ($array3[file_size] > 1125899906842624) {
				$array3[file_size] = round (($array3[file_size]/1125899906842624),2);
				$file_size_output = "".$array3[file_size]." PB";
				}
			elseif ($array3[file_size] > 1099511627776) {
				$array3[file_size] = round (($array3[file_size]/1099511627776),2);
				$file_size_output = "".$array3[file_size]." TB";
				}
			elseif ($array3[file_size] > 1073741824) {
				$array3[file_size] = round (($array3[file_size]/1073741824),2);
				$file_size_output = "".$array3[file_size]." GB";
				}
			elseif ($array3[file_size] > 1048576) {
				$array3[file_size] = round (($array3[file_size]/1048576),2);
				$file_size_output = "".$array3[file_size]." MB";
				}
			elseif ($array3[file_size] > 1024) {
				$array3[file_size] = round (($array3[file_size]/1024),2);
				$file_size_output = "".$array3[file_size]." KB";
				}
			else {
				$array3[file_size] = round ($array3[file_size],2);
				$file_size_output = "".$array3[file_size]." Byte";
				}
			$xtra_report .= "From: ".$array2[site_name]." <".$array2[admin_email].">\n";
			$xtra_report .= "Content-Type: text/html\nContent-Transfer-Encoding: 8bit\n";
			$xtra_report .= "X-Mailer: PHP ".phpversion()."\n";
			$mail_content_report = "
			$css		
			<img src=\"".$array2[site_url]."/themes/".$array4[theme_directory]."/images/".$array4[logo]."\"><p>
			<span class=\"Stil2\">
			$new_upload_report_content1,
			<p>$new_upload_report_content2 <a href=\"".$array2[site_url]."\" target=\"_blank\"><strong>".$array2[site_name]."</strong></a> $new_upload_report_content3</span><p>
			<table width=\"100%\"  border=\"0\" cellspacing=\"1\">
			  <tr bgcolor=\"".$array4[table_bgcolor4]."\">
				<td align=\"center\"><br>
					<table width=\"650\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
					  <tr>
						<td><fieldset>
						  <legend><font color=\"#0046D5\">$field_sf_1</font></legend>
						  <table width=\"100%\"  border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
							<tr bgcolor=\"".$array4[table_bgcolor4]."\" valign=\"top\">
							  <td align=\"left\"><span class=\"Stil3\">$textfield_us_desc_9</span></td>
							  <td width=\"70%\" align=\"left\"><span class=\"Stil3\"><a href=\"".$array2[site_url]."/download.php?maincategory=".$array3[maincategory]."&subcategory=".$array3[subcategory]."&file=".$array3[file_name]."\" target=\"_blank\"><font color=\"#0000FF\">".wordwrap ($link_download_now, 70, "<br>", 1)."</font></a></span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_us_desc_12</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\"><a href=\"".$array2[site_url]."/show_file.php?id=".$array3[id]."\" target=\"_blank\"><font color=\"#0000FF\">".wordwrap ($link_download_show, 70, "<br>", 1)."</font></a></span></td>
							</tr>
						  </table>
						</fieldset></td>
					  </tr>
					</table>
					<br>
					<table width=\"650\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
					  <tr>
						<td><fieldset>
						  <legend><font color=\"#0046D5\">$field_sf_2</font></legend>
						  <table width=\"100%\"  border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
							<tr bgcolor=\"".$array4[table_bgcolor4]."\" valign=\"top\">
							  <td align=\"left\"><span class=\"Stil3\">$textfield_us_desc_3</span></td>
							  <td width=\"70%\" align=\"left\"><span class=\"Stil3\">".wordwrap ($array3[file_subject], 70, "<br>", 1)."</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$description_file_name</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">".wordwrap ($array3[file_name], 70, "<br>", 1)."</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$description_file_size</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">".wordwrap ($file_size_output, 70, "<br>", 1)."</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$description_file_extension</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">".wordwrap ($array3[file_extension], 70, "<br>", 1)."</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$description_file_date</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">".wordwrap ($array3[file_date], 70, "<br>", 1)."</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_us_desc_1</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">".wordwrap ($maincategory, 70, "<br>", 1)."</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_us_desc_2</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">".wordwrap ($subcategory, 70, "<br>", 1)."</span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">$textfield_us_desc_8</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\"><a href=\"".$array2[site_url]."/user_profile.php?id=".$array5[id]."\" target=\"_blank\"><font color=\"#0000FF\">".wordwrap ($array5[user_name], 70, "<br>", 1)."</font></a></span></td>
							</tr>
							<tr align=\"left\" valign=\"top\">
							  <td bgcolor=\"".$array4[table_bgcolor4]."\" valign=\"top\"><span class=\"Stil3\">$textfield_us_desc_4</span></td>
							  <td bgcolor=\"".$array4[table_bgcolor4]."\"><span class=\"Stil3\">".$array3[file_description] = nl2br (wordwrap ($array3[file_description], 70, "<br>", 1))."</span></td>
							</tr>
						  </table>
						</fieldset></td>
					  </tr>
					</table>
					<br>
					<table width=\"650\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
					  <tr>
						<td><fieldset>
						  <legend><font color=\"#0046D5\">$field_sf_3</font></legend>
						  <table width=\"100%\"  border=\"0\" cellspacing=\"1\" bgcolor=\"#FFFFFF\">
							<tr bgcolor=\"".$array4[table_bgcolor4]."\" valign=\"top\">
							  <td align=\"left\"><span class=\"Stil3\">$textfield_us_desc_10</span></td>
							  <td width=\"70%\" align=\"left\">
							  <span class=\"Stil3\"><a href=\"".$array2[site_url]."/edit_file.php?id=".$array3[id]."\" target=\"_blank\"><font color=\"#0000FF\">".wordwrap ($link_edit, 70, "<br>", 1)."</font></a></span>
							</tr>
						  </table>
						</fieldset></td>
					  </tr>
					</table>
					<br>
				</td>
			  </tr>
			</table>
			<p><br><span class=\"Stil2\">$mail_footer<br><strong><a href=\"".$array2[site_url]."\" target=\"_blank\">".$array2[site_name]."</a><br><a href=\"mailto:".$array2[site_name]." %3C".$array2[admin_email]."%3E\">".$array2[admin_email]."</strong></span></a>
			";
			mail ("".$array2[site_name]." <".$array2[admin_email].">", "".$new_upload_report_subject." ".$array2[site_name]."", $mail_content_report, $xtra_report);
			}
		$info_upload_output = "$info_upload";
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" align="center" valign="top" bgcolor="#FFFFFF"><br>
        <br>
        <?php echo $info_upload_output ?>
      </td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
