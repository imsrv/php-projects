<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

$content = "deny from all";

if ($action == "maincategory") {
	$sql0 = "SELECT * FROM `$dbtable4` WHERE `category` = '$dbcategories_maincategory_name' AND `category_id` = '0'"; 
	$query0 = mysql_query ($sql0, $dbconnect);
	$array0 = mysql_fetch_array ($query0);
	if ((empty ($dbcategories_maincategory_name)) || (empty ($dbcategories_maincategory_description))) {
		$info_cn_output = "$info_cn_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	elseif ($array0[category] == $dbcategories_maincategory_name) {
		$info_cn_output = "$info_cn_error";
		}
	else {
		$sql = "INSERT INTO `$dbtable4` (`category`, `category_description`, `category_id`) VALUES ('$dbcategories_maincategory_name', '$dbcategories_maincategory_description', '0')";
		mysql_query ($sql, $dbconnect);
		$sql5 = "SELECT * FROM `$dbtable4` WHERE `category` = '$dbcategories_maincategory_name' LIMIT 0, 30"; 
		$query5 = mysql_query ($sql5, $dbconnect);
		$array5 = mysql_fetch_array ($query5);
		mysql_query ($sql5, $dbconnect);
		mkdir ("files/".$array5[id]."", 0777);
		$info_cn_output = "$info_categories_new";
		}
	}
if ($action == "subcategory") {
	$sql0 = "SELECT * FROM `$dbtable4` WHERE `category` = '$dbcategories_subcategory_name' AND `category_id` = '$dbcategories_maincategory_select'"; 
	$query0 = mysql_query ($sql0, $dbconnect);
	$array0 = mysql_fetch_array ($query0);
	if ((empty ($dbcategories_maincategory_select)) || (empty ($dbcategories_subcategory_name)) || (empty ($dbcategories_subcategory_description))) {
		$info_cn_output = "$info_cn_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
		}
	elseif ($array0[category] == $dbcategories_subcategory_name) {
		$info_cn_output = "$info_cn_error2";
		}
	else {
		$sql3 = "SELECT * FROM `$dbtable4` WHERE `id` = '$dbcategories_maincategory_select' LIMIT 0, 30"; 
		$query3 = mysql_query ($sql3, $dbconnect);
		$array3 = mysql_fetch_array ($query3);
		$sql = "INSERT INTO `$dbtable4` (`category`, `category_description`, `category_id`) VALUES ('$dbcategories_subcategory_name', '$dbcategories_subcategory_description', '$dbcategories_maincategory_select')";
		mysql_query ($sql, $dbconnect);
		$sql5 = "SELECT * FROM `$dbtable4` WHERE `category` = '$dbcategories_subcategory_name' AND `category_id` = '$dbcategories_maincategory_select'"; 
		$query5 = mysql_query ($sql5, $dbconnect);
		$array5 = mysql_fetch_array ($query5);
		mysql_query ($sql5, $dbconnect);
		mkdir ("files/".$array3[id]."/".$array5[id]."", 0777);
		$file = "files/".$array3[id]."/".$array5[id]."/.htaccess";
		$resource = fopen ($file, "w+");
		fopen ($file, "w+");
		fwrite ($resource, $content);
		fclose ($resource);
		$info_cn_output = "$info_categories_new";
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>
		<br>
        <?php echo $info_cn_output ?></div>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
