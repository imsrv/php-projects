<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

if ($get_order == "asc") {
	$query_order = "ASC";
	$sort_order = "desc";
	}
if ($get_order == "desc") {
	$query_order = "DESC";
	$sort_order = "asc";
	}

if (($sort_order == "") || ($sort_order == "asc")) {
	$query_order = "DESC";
	$sort_order = "desc";	//Same Value like $query_order because of Splitting Pages and reading from Table-End
	}
elseif ($sort_order == "desc") {
	$query_order = "ASC";
	$sort_order = "asc";	//Same Value like $query_order because of Splitting Pages and reading from Table-End
	}
else {
	$query_order = "DESC";
	$sort_order = "desc";	//Same Value like $query_order because of Splitting Pages and reading from Table-End
	}

if (empty ($order)) {
	$sql = "SELECT * FROM `$dbtable4` WHERE `category_id` = '$id' ORDER BY `category` $query_order"; 
	$query1 = mysql_query ($sql, $dbconnect);
	}
if ($order == "category") {
	$sql = "SELECT * FROM `$dbtable4` WHERE `category_id` = '$id' ORDER BY `category` $query_order"; 
	$query1 = mysql_query ($sql, $dbconnect);
	}
if ($order == "category_description") {
	$sql = "SELECT * FROM `$dbtable4` WHERE `category_id` = '$id' ORDER BY `category_description` $query_order"; 
	$query1 = mysql_query ($sql, $dbconnect);
	}

if ((empty ($array4[number_result])) || (($array4[number_result] == "0")) || (!is_numeric ($array4[number_result]))) {
	$number_result = 30;
	}
else {
	$number_result = $array4[number_result];
	}

$count = mysql_num_rows ($query1);

$c = 0;
while ($count > 0) {
	$c++;
	$count = $count - $number_result;
	}

if (!isset ($page)) {
   $page = 1;
   $pag = $page - 1;
   }

if ($page > 1) {
	$navigation .= "<a href=\"".$PHP_SELF."?page=1&id=$id&order=$order&get_order=$sort_order\">&laquo;</a>&nbsp;";
	$navigation .= "<a href=\"".$PHP_SELF."?page=".$pag."&id=$id&order=$order&get_order=$sort_order\">&lsaquo;</a>&nbsp;";
	}

for ($b = 1; $b <= $c; $b++) {
   $site = $b;
	if (isset ($page) && $page == $site) {
		$navigation .= "<font color=\"".$array_cs3[table_bgcolor3]."\">".$b."</font>&nbsp;";
		}
	else {
		$navigation .= "<a href=\"".$PHP_SELF."?page=$site&id=$id&order=$order&get_order=$sort_order\">$b</a>&nbsp;";
		}
	}

$pag = $page + 1;
if ($page < $c) {
	$navigation .= "<a href=\"".$PHP_SELF."?page=".$pag."&id=$id&order=$order&get_order=$sort_order\">&rsaquo;</a>&nbsp;";
	$navigation .= "<a href=\"".$PHP_SELF."?page=$c&id=$id&order=$order&get_order=$sort_order\">&raquo;</a>&nbsp;";
	}

$array = array();
while ($l = mysql_fetch_array ($query1)) {
	array_push ($array, $l);
	}

$count_2 = mysql_num_rows ($query1);

if ($count_2 > $number_result) {
	$navigation_output = $navigation;
	}

if ($count_2 == "0") {
	$show_categories = "<p><br><div align=\"center\">$info_no_subcategory<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\"></div>";
	}
else {
	$show_categories .= "
		<table width=\"100%\" border=\"0\" cellspacing=\"1\">
		<tr align=\"left\" bgcolor=\"".$array4[table_bgcolor3]."\">
		<td width=\"30%\"><span class=\"Stil2\"><a href=\"".$PHP_SELF."?id=$id&order=category&sort_order=$sort_order\" class=\"menulink\" title=\"$link_desc_category_subcategory\">$description_subcategory</a></span></td>
		<td width=\"50%\"><span class=\"Stil2\"><a href=\"".$PHP_SELF."?id=$id&order=category_description&sort_order=$sort_order\" class=\"menulink\" title=\"$link_desc_category_description\">$description_description</a></span></td>
		<td width=\"15%\"><span class=\"Stil2\">$description_downloads</span></td>
		</tr>";

	for ($i = ($count_2 - $number_result * $page + $number_result) - 1; $i > ($count_2 - $number_result * $page) - 1; $i--) {
		if ($i >= 0) {
			$sql7 = "SELECT * FROM `$dbtable5` WHERE `subcategory` = '".$array[$i][id]."'";
			$query7 = mysql_query ($sql7, $dbconnect);
			$num_rows7 = mysql_num_rows ($query7);
			if ($num_rows7 == "1") {
				$downloads_output = "$num_rows7 $download";
				}
			else {
				$downloads_output = "$num_rows7 $downloads";
				}
			$show_categories .= "
			<tr>
			<td width=\"30%\" align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" onClick=\"location.href='files.php?subcategory_id=".$array[$i][id]."'\" class=\"Element1\" onmouseover=\"this.className='Element1A_hover'\" onmouseout=\"this.className='Element1'\" title=\"".$array[$i][category]."\"><strong>".(strlen ($array[$i][category]) > 50 ? substr ($array[$i][category], 0, 50) . '...' : $array[$i][category])."</strong></td>
			<td width=\"55%\" align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$array[$i][category_description]."\">".(strlen ($array[$i][category_description]) > 95 ? substr ($array[$i][category_description], 0, 95) . '...' : $array[$i][category_description])."</td>
			<td width=\"15%\" align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$downloads_output."\">".(strlen ($num_rows7) > 18 ? substr ($num_rows7, 0, 18) . '...' : $num_rows7)."</td>
			</tr>";
			}
		}
		$show_categories .= "</table>";
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
		<?php echo $show_categories; ?>
      </td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"><?php echo $navigation_output ?></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
