<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("library/config/config.php");
include ("library/js.php");

$dbconnect = mysql_connect ($dbhost, $dbuser, $dbpass);
mysql_select_db ($dbname, $dbconnect);

$sql2 = "SELECT * FROM `$dbtable1` LIMIT 0, 30"; 
$query2 = mysql_query ($sql2, $dbconnect);
$array2 = mysql_fetch_array ($query2);

$sql3 = "SELECT * FROM `$dbtable2` WHERE `theme_name` = '".$array2[theme]."' LIMIT 0, 30"; 
$query3 = mysql_query ($sql3, $dbconnect);
$array3 = mysql_fetch_array ($query3);

include ("themes/".$array3[theme_directory]."/library/css.php");
include ("library/languages/".$array2[language].".php");

$sql4 = "SELECT * FROM `$dbtable5`"; 
$query4 = mysql_query ($sql4, $dbconnect);
$num_rows = mysql_num_rows ($query4);

$sql5 = "SELECT SUM(`file_size`) AS file_size_all FROM `$dbtable5`"; 
$query5 = mysql_query ($sql5, $dbconnect);
$array5 = mysql_fetch_array ($query5);
$file_size_all = $array5[file_size_all];

if ($array2[site_public] == "true") {
	$public_area_output = " <span class =\"Stil4\">|</span> <a href=\"categories.php\"><font color=\"#0000FF\">$link_public_area</font></a>";
	}

if ($num_rows == "1") {
	$downloads_output = "<strong>$num_rows</strong> $download";
	}
else {
	$downloads_output = "<strong>$num_rows</strong> $downloads";
	}

if ($file_size_all > 1152921504606847000) {
	$file_size_all = round (($file_size_all/1152921504606847000),2);
	$file_size_all_output = "<strong>$file_size_all</strong> EB";
	}
elseif ($file_size_all > 1125899906842624) {
	$file_size_all = round (($file_size_all/1125899906842624),2);
	$file_size_all_output = "<strong>$file_size_all</strong> PB";
	}
elseif ($file_size_all > 1099511627776) {
	$file_size_all = round (($file_size_all/1099511627776),2);
	$file_size_all_output = "<strong>$file_size_all</strong> TB";
	}
elseif ($file_size_all > 1073741824) {
	$file_size_all = round (($file_size_all/1073741824),2);
	$file_size_all_output = "<strong>$file_size_all</strong> GB";
	}
elseif ($file_size_all > 1048576) {
	$file_size_all = round (($file_size_all/1048576),2);
	$file_size_all_output = "<strong>$file_size_all</strong> MB";
	}
elseif ($file_size_all > 1024) {
	$file_size_all = round (($file_size_all/1024),2);
	$file_size_all_output = "<strong>$file_size_all</strong> KB";
	}
else {
	$file_size_all = round ($file_size_all,2);
	$file_size_all_output = "<strong>$file_size_all</strong> Byte";
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>; window.document.form1.dbusers_user_name.focus()">
<div align="center">
  <p><img src="<?php echo "themes/".$array3[theme_directory]."/images/".$array3[logo].""; ?>"></p>
  <table width="800"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array3[theme_directory] ?>/images/table_corner_left_head.gif">&nbsp;</td>
      <td width="552" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="210" bgcolor="<?php echo $array3[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array3[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="800"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="303" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="552" valign="top" bgcolor="#FFFFFF"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
        <tr align="center">
          <td width="5" background="themes/<?php echo $array3[theme_directory] ?>/images/table_corner_left_head2.gif"></td>
          <td bgcolor="<?php echo $array3[site_bgcolor] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
        </tr>
      </table>
        <table width="100%"  border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td rowspan="9" align="left"><br>
                <img src="themes/<?php echo $array3[theme_directory] ?>/images/storage.jpg" width="186" height="289"></td>
            <td align="center"><p>&nbsp;</p><form name="form1" method="post" action="categories.php">
                <table width="300" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td bgcolor="<?php echo $array3[table_bgcolor4] ?>"><fieldset>
                      <legend><?php echo $field_login ?></legend>
                      <div>
                        <table width="100%" cellspacing="0" cellpadding="1">
                          <tr>
                            <td><div align="left" class="Stil4"><?php echo $textfield_login_desc_1 ?></div></td>
                            <td><div align="left">
                                <input name="dbusers_user_name" type="text" id="dbusers_user_name">
                            </div></td>
                          </tr>
                          <tr>
                            <td><div align="left" class="Stil4"><?php echo $textfield_login_desc_2 ?></div></td>
                            <td><div align="left">
                                <input name="dbusers_user_password" type="password" id="dbusers_user_password">
                            </div></td>
                          </tr>
                          <tr>
                            <td><div align="left"></div></td>
                            <td><div align="left">
                                <input name="login" type="submit" id="login" value="<?php echo $button_login ?>">
                            </div></td>
                          </tr>
                        </table>
                      </div>
                    </fieldset></td>
                  </tr>
              </table></form></td>
          </tr>
          <tr>
            <td height="12" align="left" valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td height="12" align="center" valign="top"><?php echo "<a href=\"sign_up.php\"><font color=\"#0000FF\">$link_sign_up</font></a> <span class =\"Stil4\">|</span> <a href=\"new_password.php\"><font color=\"#0000FF\">$link_new_password</font></a>$public_area_output"; ?></td>
          </tr>
          <tr>
            <td height="12" align="left" valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td height="12" align="center" class="Stil4"><?php echo "$downloads_output - $file_size_all_output"; ?></td>
          </tr>
          <tr>
            <td height="12" align="left" valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td height="12" align="left" valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td height="12" align="left" valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td height="12" align="left" valign="top">&nbsp;</td>
          </tr>
        </table></td>
      <td width="210" background="themes/<?php echo $array3[theme_directory] ?>/images/table_back.gif" bgcolor="<?php echo $array3[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="303" bgcolor="<?php echo $array3[table_bgcolor1] ?>">&nbsp;</td>
    </tr>
  </table>
  <table width="800"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array3[theme_directory] ?>/images/table_corner_left_foot.gif">&nbsp;</td>
      <td width="552" bgcolor="#FFFFFF">&nbsp;</td>
      <td width="210" bgcolor="<?php echo $array3[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array3[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
