<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

$dot = strrpos ($file_name, ".") + 1;
$file_extension = substr ($file_name, $dot, strlen ($file_name) - $dot);
$file_date = date ("d.m.Y - H:i:s");

$sql3 = "SELECT * FROM `$dbtable5` WHERE `id` = '$id' LIMIT 1"; 
$query3 = mysql_query ($sql3, $dbconnect);
$array3 = mysql_fetch_array ($query3);

$sql6 = "SELECT * FROM `$dbtable6` WHERE `filetype_name` = '$file_extension' AND `filetype_locked` = 'true'"; 
$query6 = mysql_query ($sql6);
$array6 = mysql_fetch_array ($query6);

if ((empty ($maincategory)) || (empty ($subcategory)) || (empty ($dbfiles_file_subject)) || (empty ($dbfiles_file_description))) {
	$info_upload_edit_output = "$info_upload_validation<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif ($delete_file == "delete") {
	$sql = "DELETE FROM `$dbtable5` WHERE `id` = '$id' LIMIT 1";
	mysql_query ($sql, $dbconnect);
	unlink ("files/".$array3[maincategory]."/".$array3[subcategory]."/".$array3[file_name]."");
	$info_upload_edit_output = "$delete_file_success";
	}
elseif ((!empty ($array6[filetype_name])) && ($array6[filetype_name] == $file_extension)) {
	$info_upload_edit_output = "$info_upload_error4<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
	}
elseif (!empty ($file)) {
	$sql6 = "SELECT * FROM `$dbtable5` WHERE `file_name` = '$file_name'"; 
	$query6 = mysql_query ($sql6, $dbconnect);
	$array6 = mysql_fetch_array ($query6);
	if (($dbfiles_file_subject !== $dbfiles_file_subject_old) || ($array6[file_name] == $file_name) && ($file_name !== $file_name_old)) {
		$sql5 = "SELECT * FROM `$dbtable5` WHERE `file_subject` = '$dbfiles_file_subject'"; 
		$query5 = mysql_query ($sql5, $dbconnect);
		$array5 = mysql_fetch_array ($query5);
		}
	elseif (($array6[file_name] == $file_name) && ($file_name !== $file_name_old)) {
		$info_upload_edit_output = "$info_upload_error3";
		}
	elseif ($dbfiles_file_subject !== $dbfiles_file_subject_old) {
		$sql5 = "SELECT * FROM `$dbtable5` WHERE `file_subject` = '$dbfiles_file_subject'"; 
		$query5 = mysql_query ($sql5, $dbconnect);
		$array5 = mysql_fetch_array ($query5);
		}
	if ($array5[file_subject] == $dbfiles_file_subject) {
		$info_upload_edit_output = "$info_upload_error3";
		}
	else {
		if (@!copy ($file, "files/".$array3[maincategory]."/".$array3[subcategory]."/$file_name")) {
			$info_upload_edit_output = "$info_upload_error1<p><input name=\"Back\" type=\"button\" id=\"Back\" onClick=\"javascript:history.back();\" value=\"$button_back\">";
			}
		else {
			$sql = "UPDATE `$dbtable5` SET `file_subject` = '$dbfiles_file_subject', `file_description` = '$dbfiles_file_description', `file_name` = '$file_name', `file_size` = '$file_size', `file_extension` = '$file_extension', `file_date_edit` = '$file_date', `mime_type` = '$file_type' WHERE `id` = '$id' LIMIT 1";
			mysql_query ($sql, $dbconnect);
			unlink ("files/".$array3[maincategory]."/".$array3[subcategory]."/".$array3[file_name]."");
			copy ($file, "files/".$array3[maincategory]."/".$array3[subcategory]."/$file_name");
			$info_upload_edit_output = "$info_upload_edit $info_upload";
			}
		}
	}
else {
	if ($dbfiles_file_subject !== $dbfiles_file_subject_old) {
		$sql5 = "SELECT * FROM `$dbtable5` WHERE `file_subject` = '$dbfiles_file_subject'"; 
		$query5 = mysql_query ($sql5, $dbconnect);
		$array5 = mysql_fetch_array ($query5);
		}
	if ($array5[file_subject] == $dbfiles_file_subject) {
		$info_upload_edit_output = "$info_upload_error3";
		}
	else {
		$sql = "UPDATE `$dbtable5` SET `file_subject` = '$dbfiles_file_subject', `file_description` = '$dbfiles_file_description', `file_date_edit` = '$file_date' WHERE `id` = '$id' LIMIT 1";
		mysql_query ($sql, $dbconnect);
		$info_upload_edit_output = "$info_upload_edit";
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" align="center" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>
		<br>
          <?php echo $info_upload_edit_output ?>
	    </div>
        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
          <tr>
        </table>
      </td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
