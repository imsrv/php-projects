<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

if ($get_order == "asc") {
	$query_order = "ASC";
	$sort_order = "desc";
	}
if ($get_order == "desc") {
	$query_order = "DESC";
	$sort_order = "asc";
	}

if (($sort_order == "") || ($sort_order == "asc")) {
	$query_order = "DESC";
	$sort_order = "desc";	//Same Value like $query_order because of Splitting Pages and reading from Table-End
	}
elseif ($sort_order == "desc") {
	$query_order = "ASC";
	$sort_order = "asc";	//Same Value like $query_order because of Splitting Pages and reading from Table-End
	}
else {
	$query_order = "DESC";
	$sort_order = "desc";	//Same Value like $query_order because of Splitting Pages and reading from Table-End
	}
	
if (empty ($order)) {
	$sql = "SELECT * FROM `$dbtable5` WHERE `subcategory` = '$subcategory_id' ORDER BY `file_subject` $query_order"; 
	$query1 = mysql_query ($sql, $dbconnect);
	}
if ($order == "file_subject") {
	$sql = "SELECT * FROM `$dbtable5` WHERE `subcategory` = '$subcategory_id' ORDER BY `file_subject` $query_order"; 
	$query1 = mysql_query ($sql, $dbconnect);
	}
if ($order == "file_description") {
	$sql = "SELECT * FROM `$dbtable5` WHERE `subcategory` = '$subcategory_id' ORDER BY `file_description` $query_order"; 
	$query1 = mysql_query ($sql, $dbconnect);
	}
if ($order == "file_name") {
	$sql = "SELECT * FROM `$dbtable5` WHERE `subcategory` = '$subcategory_id' ORDER BY `file_name` $query_order"; 
	$query1 = mysql_query ($sql, $dbconnect);
	}
if ($order == "file_size") {
	$sql = "SELECT * FROM `$dbtable5` WHERE `subcategory` = '$subcategory_id' ORDER BY `file_size` $query_order"; 
	$query1 = mysql_query ($sql, $dbconnect);
	}
if ($order == "file_extension") {
	$sql = "SELECT * FROM `$dbtable5` WHERE `subcategory` = '$subcategory_id' ORDER BY `file_extension` $query_order"; 
	$query1 = mysql_query ($sql, $dbconnect);
	}
if ($order == "file_date") {
	$sql = "SELECT * FROM `$dbtable5` WHERE `subcategory` = '$subcategory_id' ORDER BY `file_date` $query_order"; 
	$query1 = mysql_query ($sql, $dbconnect);
	}

if ((empty ($array4[number_result])) || (($array4[number_result] == "0")) || (!is_numeric ($array4[number_result]))) {
	$number_result = 30;
	}
else {
	$number_result = $array4[number_result];
	}

if ((!empty ($user_number_result)) && (is_numeric ($user_number_result))) {
	$number_result = $user_number_result;
	}

$count = mysql_num_rows ($query1);

$c = 0;
while ($count > 0) {
	$c++;
	$count = $count - $number_result;
	}

if (!isset ($page)) {
   $page = 1;
   $pag = $page - 1;
   }

if ($page > 1) {
	$navigation .= "<a href=\"".$PHP_SELF."?page=1&subcategory_id=$subcategory_id&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">&laquo;</a>&nbsp;";
	$navigation .= "<a href=\"".$PHP_SELF."?page=".$pag."&subcategory_id=$subcategory_id&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">&lsaquo;</a>&nbsp;";
	}

for ($b = 1; $b <= $c; $b++) {
   $site = $b;
	if (isset ($page) && $page == $site) {
		$navigation .= "<font color=\"".$array_cs3[table_bgcolor3]."\">".$b."</font>&nbsp;";
		}
	else {
		$navigation .= "<a href=\"".$PHP_SELF."?page=$site&subcategory_id=$subcategory_id&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">$b</a>&nbsp;";
		}
	}

$pag = $page + 1;
if ($page < $c) {
	$navigation .= "<a href=\"".$PHP_SELF."?page=".$pag."&subcategory_id=$subcategory_id&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">&rsaquo;</a>&nbsp;";
	$navigation .= "<a href=\"".$PHP_SELF."?page=$c&subcategory_id=$subcategory_id&order=$order&get_order=$sort_order&user_number_result=$user_number_result\">&raquo;</a>&nbsp;";
	}

$array = array();
while ($l = mysql_fetch_array ($query1)) {
	array_push ($array, $l);
	}

$count_2 = mysql_num_rows ($query1);

if ($count_2 > $number_result) {
	$navigation_output = $navigation;
	}

for ($i = ($count_2 - $number_result * $page + $number_result) - 1; $i > ($count_2 - $number_result * $page) - 1; $i--) {
	if ($i >= 0) {
		if ($array[$i][file_size] > 1152921504606847000) {
			$array[$i][file_size] = round (($array[$i][file_size]/1152921504606847000),2);
			$file_size_output = "".$array[$i][file_size]." EB";
			}
		elseif ($array[$i][file_size] > 1125899906842624) {
			$array[$i][file_size] = round (($array[$i][file_size]/1125899906842624),2);
			$file_size_output = "".$array[$i][file_size]." PB";
			}
		elseif ($array[$i][file_size] > 1099511627776) {
			$array[$i][file_size] = round (($array[$i][file_size]/1099511627776),2);
			$file_size_output = "".$array[$i][file_size]." TB";
			}
		elseif ($array[$i][file_size] > 1073741824) {
			$array[$i][file_size] = round (($array[$i][file_size]/1073741824),2);
			$file_size_output = "".$array[$i][file_size]." GB";
			}
		elseif ($array[$i][file_size] > 1048576) {
			$array[$i][file_size] = round (($array[$i][file_size]/1048576),2);
			$file_size_output = "".$array[$i][file_size]." MB";
			}
		elseif ($array[$i][file_size] > 1024) {
			$array[$i][file_size] = round (($array[$i][file_size]/1024),2);
			$file_size_output = "".$array[$i][file_size]." KB";
			}
		else {
			$array[$i][file_size] = round ($array[$i][file_size],2);
			$file_size_output = "".$array[$i][file_size]." Byte";
			}
		$show_files .= "
		<tr>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" onClick=\"location.href='show_file.php?id=".$array[$i][id]."'\" class=\"Element1\" onmouseover=\"this.className='Element1A_hover'\" onmouseout=\"this.className='Element1'\" title=\"".$array[$i][file_subject]."\"><strong>".(strlen ($array[$i][file_subject]) > 30 ? substr ($array[$i][file_subject], 0, 30) . '...' : $array[$i][file_subject])."</strong></td>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$array[$i][file_description]."\">".(strlen ($array[$i][file_description]) > 50 ? substr ($array[$i][file_description], 0, 50) . '...' : $array[$i][file_description])."</td>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$array[$i][file_name]."\">".(strlen ($array[$i][file_name]) > 12 ? substr ($array[$i][file_name], 0, 12) . '...' : $array[$i][file_name])."</td>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$file_size_output."\">".(strlen ($array[$i][file_size]) > 10 ? substr ($file_size_output, 0, 10) . '...' : $file_size_output)."</td>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$array[$i][file_extension]."\">".(strlen ($array[$i][file_extension]) > 12 ? substr ($array[$i][file_extension], 0, 12) . '...' : $array[$i][file_extension])."</td>
		<td align=\"left\" bgcolor=\"".$array4[table_bgcolor4]."\" title=\"".$array[$i][file_date]."\">".(strlen ($array[$i][file_date]) > 21 ? substr ($array[$i][file_date], 0, 21) . '...' : $array[$i][file_date])."</td>
		<td align=\"center\" bgcolor=\"".$array4[table_bgcolor4]."\"><input name=\"select[]\" type=\"checkbox\" id=\"select[]\" value=\"".$array[$i][id]."\"></td>
		</tr>";
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_select_checkbox $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
	  <form action="zip_file.php" method="post" name="results">
      <table width="100%" border="0" cellspacing="1">
        <tr bgcolor="<?php echo $array4[table_bgcolor3] ?>">
          <td align="left" width="20%"><span class="Stil2"><a href="<?php echo "".$PHP_SELF."?subcategory_id=$subcategory_id&order=file_subject&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_file_subject ?>"><?php echo $description_file_subject ?></a></span></td>
          <td align="left" width="30%"><span class="Stil2"><a href="<?php echo "".$PHP_SELF."?subcategory_id=$subcategory_id&order=file_description&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_file_description ?>"><?php echo $description_file_description ?></a></span></td>
          <td align="left" width="10%"><span class="Stil2"><a href="<?php echo "".$PHP_SELF."?subcategory_id=$subcategory_id&order=file_name&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_file_name ?>"><?php echo $description_file_name ?></a></span></td>
          <td align="left" width="7%"><span class="Stil2"><a href="<?php echo "".$PHP_SELF."?subcategory_id=$subcategory_id&order=file_size&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_file_size ?>"><?php echo $description_file_size ?></a></span></td>
          <td align="left" width="10%"><span class="Stil2"><a href="<?php echo "".$PHP_SELF."?subcategory_id=$subcategory_id&order=file_extension&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_file_extension ?>"><?php echo $description_file_extension ?></a></span></td>
          <td align="left" width="14%"><span class="Stil2"><a href="<?php echo "".$PHP_SELF."?subcategory_id=$subcategory_id&order=file_date&sort_order=$sort_order&user_number_result=$user_number_result"; ?>" class="menulink" title="<?php echo $link_desc_file_date ?>"><?php echo $description_file_date ?></a></span></td>
          <td align="center" width="9%"><span class="Stil2"><a href="javascript:CheckAll()" class="menulink" title="<?php echo $link_desc_file_zip ?>"><?php echo $description_file_zip_download ?></a></span></td>
        </tr>
		<?php echo $show_files; ?>
		<tr align=\"left\">
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
		  <td><input name="action" type="hidden" id="action" value="zip"></td>
		  <td align="center"><input type="submit" name="Submit" value="<?php echo $button_zip ?>"></td>
		</tr>
      </table>
	  </form>
	  <center>
		<form name="form_user_results" method="post" action="<?php echo "".$PHP_SELF."?subcategory_id=$subcategory_id&order=$order&get_order=$sort_order" ?>">
			<input name="user_number_result" type="text" id="user_number_result" value="<?php echo $user_number_result ?>" size="4">				  
			<input type="submit" name="Submit" value="<?php echo $button_per_site ?>">
		</form>
	  </center>
	  </td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"><?php echo $navigation_output ?></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
