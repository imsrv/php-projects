<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

ob_start();

include ("login_validation.php");

not_public();

$sql = "SELECT * FROM `$dbtable5` WHERE `subcategory` = '$subcategory' ORDER BY `file_subject` ASC LIMIT 0, 30"; 
$query1 = mysql_query ($sql, $dbconnect);

$sql3 = "SELECT * FROM `$dbtable3` WHERE `id` = '$id' LIMIT 1"; 
$query3 = mysql_query ($sql3, $dbconnect);
$array3 = mysql_fetch_array ($query3);

if ($array3[user_group] == "1") {
	$user_group = wordwrap ($select_desc_admin, 80, "<br>", 1);
	}
elseif ($array3[user_group] == "2") {
	$user_group = wordwrap ($select_desc_downloader, 80, "<br>", 1);
	}
elseif ($array3[user_group] == "3") {
	$user_group = wordwrap ($select_desc_downloader_uploader, 80, "<br>", 1);
	}
elseif ($array3[user_group] == "4") {
	$user_group = wordwrap ($select_desc_uploader, 80, "<br>", 1);
	}
elseif ($array3[user_group] == "5") {
	$user_group = wordwrap ($select_desc_user, 80, "<br>", 1);
	}

if (!empty ($array3[user_session])) {
	$user_status = "$textfield_user_online_desc";
	}
else {
	$user_status = "$textfield_user_offline_desc";
	}

if ($array3[user_image] == "true") {
	$user_image_output = "<img src=\"show_user_image.php?id=$id\">";
	}
else {
	$user_image_output = "$no_user_image";
	}

if ($array3[user_gender] == "1") {
	$user_gender_output = wordwrap ($select_desc_gender_male, 80, "<br>", 1);
	}
elseif ($array3[user_gender] == "2") {
	$user_gender_output = wordwrap ($select_desc_gender_female, 80, "<br>", 1);
	}
else {
	$user_gender_output = wordwrap ($no_data, 80, "<br>", 1);
	}

if ($array3[email_public] == "true") {
	$user_email_output = "<a href=\"mailto:".$array3[user_email]."\"><font color=\"#0000FF\">".wordwrap ($array3[user_email], 80, "<br>", 1)."</font></a>";
	}
else {
	$user_email_output = "$no_user_email";
	}

if (empty ($array3[last_login_date])) {
	$last_login_output = "$no_login";
	}
else {
	$last_login_output = wordwrap ($array3[last_login_date], 80, "<br>", 1);
	}

if ($array3[activated] == "true") {
	$user_activated = wordwrap ($yes, 80, "<br>", 1);
	}
else {
	$user_activated = wordwrap ($no, 80, "<br>", 1);
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="31%" align="center" bgcolor="<?php echo $array4[table_bgcolor3] ?>"><strong> <span class="Stil2"> </span></strong>
        <table width="190" height="220" border="0" cellspacing="1" bgcolor="#FFFFFF">
          <tr>
            <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><?php echo $user_image_output ?></td>
          </tr>
      </table></td>
      <td width="69%" height="220" valign="top" bgcolor="#FFFFFF">
        <table width="100%" border="0" cellspacing="1">
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_name_desc ?></td>
            <td width="70%"><?php echo $array3[user_name] ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_group_desc ?></td>
            <td><?php echo $user_group ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_firstname_desc ?></td>
            <td width="70%"><?php if (!empty ($array3[user_firstname])) {$user_firstname_output = wordwrap ($array3[user_firstname], 80, "<br>", 1); echo $user_firstname_output;} else {echo $no_data;} ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_lastname_desc ?></td>
            <td width="70%"><?php if (!empty ($array3[user_lastname])) {$user_lastname_output = wordwrap ($array3[user_lastname], 80, "<br>", 1); echo $user_lastname_output;} else {echo $no_data;} ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_email_desc ?></td>
            <td width="70%"><?php echo $user_email_output ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_website_desc ?></td>
            <td width="70%"><?php if (!empty ($array3[user_website])) {echo "<a href=\"".$array3[user_website]."\" target=\"_blank\"><font color=\"#0000FF\">".wordwrap ($array3[user_website], 80, "<br>", 1)."</font></a>";} else {echo $no_data;} ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_birthday_desc ?></td>
            <td width="70%"><?php if (!empty ($array3[user_birthday])) {$user_birthday_output = wordwrap ($array3[user_birthday], 80, "<br>", 1); echo $user_birthday_output;} else {echo $no_data;} ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_gender_desc ?></td>
            <td width="70%"><?php echo $user_gender_output ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_street_desc ?></td>
            <td width="70%"><?php if (!empty ($array3[user_street])) {$user_street_output = wordwrap ($array3[user_street], 80, "<br>", 1); echo $user_street_output;} else {echo $no_data;} ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_zipcode_desc ?></td>
            <td><?php if (!empty ($array3[user_zipcode])) {$user_zipcode_output = wordwrap ($array3[user_zipcode], 80, "<br>", 1); echo $user_zipcode_output;} else {echo $no_data;} ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_city_desc ?></td>
            <td><?php if (!empty ($array3[user_city])) {$user_city_output = wordwrap ($array3[user_city], 80, "<br>", 1); echo $user_city_output;} else {echo $no_data;} ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_state_desc ?></td>
            <td><?php if (!empty ($array3[user_state])) {$user_state_output = wordwrap ($array3[user_state], 80, "<br>", 1); echo $user_state_output;} else {echo $no_data;} ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_country_desc ?></td>
            <td><?php if (!empty ($array3[user_country])) {$user_country_output = wordwrap ($array3[user_country], 80, "<br>", 1); echo $user_country_output;} else {echo $no_data;} ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_phone_desc ?></td>
            <td><?php if (!empty ($array3[user_phone])) {$user_phone_output = wordwrap ($array3[user_phone], 80, "<br>", 1); echo $user_phone_output;} else {echo $no_data;} ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_fax_desc ?></td>
            <td><?php if (!empty ($array3[user_fax])) {$user_fax_output = wordwrap ($array3[user_fax], 80, "<br>", 1); echo $user_fax_output;} else {echo $no_data;} ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_mobile_desc ?></td>
            <td><?php if (!empty ($array3[user_mobile])) {$user_mobile_output = wordwrap ($array3[user_mobile], 80, "<br>", 1); echo $user_mobile_output;} else {echo $no_data;} ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_register_desc ?></td>
            <td><?php echo wordwrap ($array3[user_register_date], 80, "<br>", 1) ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_last_login_date ?></td>
            <td><?php echo $last_login_output ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_activated_desc ?></td>
            <td><?php echo $user_activated ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_status_desc ?></td>
            <td><?php echo $user_status ?></td>
          </tr>
          <tr align="left" valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
            <td><?php echo $textfield_user_uploads_desc ?></td>
            <td><?php echo "<a href=\"search_result.php?search=$id&select_select=by_user\"><font color=\"#0000FF\">".wordwrap ($link_show_uploads, 80, "<br>", 1)."</font></a>"; ?></td>
          </tr>
        </table></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
