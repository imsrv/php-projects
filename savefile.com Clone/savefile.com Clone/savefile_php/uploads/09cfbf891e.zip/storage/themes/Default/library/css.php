<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

$dbconnect = mysql_connect ($dbhost, $dbuser, $dbpass);
mysql_select_db ($dbname, $dbconnect);

$sql_cs2 = "SELECT * FROM `$dbtable1` LIMIT 0, 30"; 
$query_cs2 = mysql_query ($sql_cs2, $dbconnect);
$array_cs2 = mysql_fetch_array ($query_cs2);

$sql_cs3 = "SELECT * FROM `$dbtable2` WHERE `theme_name` = '".$array_cs2[theme]."' LIMIT 0, 30"; 
$query_cs3 = mysql_query ($sql_cs3, $dbconnect);
$array_cs3 = mysql_fetch_array ($query_cs3);

if ($array_cs3[site_bgimage] == "true") {
	$site_bgimage = "background.jpg";
	}

$document_path_cs = basename ($PHP_SELF);

if (($document_path_cs == "admin_mail_send.php") || ($document_path_cs == "new_password_send.php") || ($document_path_cs == "sign_up_execute.php") || ($document_path_cs == "upload_execute.php")) {
	$bgimage_url = "".$array_cs2[site_url]."/themes/".$array_cs3[theme_directory]."/images/$site_bgimage";
	}
else {
	$bgimage_url = "themes/".$array_cs3[theme_directory]."/images/$site_bgimage";
	}

$css = "
<style type=\"text/css\">
<!--
body {
	background-color: ".$array_cs3[site_bgcolor].";
	background-image: url($bgimage_url);
}
body,td,th {
	font-family: ".$array_cs3[font_family].";
	font-size: ".$array_cs3[font_size].";
	color: ".$array_cs3[font_color].";
}
input, textarea, select {
	font-family: ".$array_cs3[font_family].";
	font-weight: normal;
	font-size: ".$array_cs3[font_size].";
}
.Stil1 {
	color: #FFFFFF;
	font-weight: bold;
}
a:link {
	color: ".$array_cs3[link_color].";
	text-decoration: none;
}
a:visited {
	color: ".$array_cs3[link_color].";
	text-decoration: none;
}
a:hover {
	color: ".$array_cs3[link_color].";
	text-decoration: underline;
}
a:active {
	color: ".$array_cs3[link_color].";
	text-decoration: none;
}
.Stil2 {
	color: #FFFFFF
}
.Stil3 {
	color: ".$array_cs3[font_family].";
}
.Stil4 {
	color: #000000
}
a.menulink {
	display: block;
	width: 100%;
	text-decoration: none;
	border: none;
}
a.menulink:hover {
	border: none;
	background-color: ".$array_cs3[table_hlcolor1].";
	text-decoration: none;
}
td.Element1A {
	background-color: ".$array_cs3[table_bgcolor4].";
}
td.Element1A_hover {
	background-color: ".$array_cs3[table_hlcolor2].";
	cursor: hand;
	cursor: pointer;
}
-->
</style>";

?>