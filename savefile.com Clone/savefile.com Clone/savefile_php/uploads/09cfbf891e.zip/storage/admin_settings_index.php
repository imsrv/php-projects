<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

$sql0 = "SELECT * FROM `$dbtable2` ORDER BY `theme_name` ASC LIMIT 0, 30"; 
$query0 = mysql_query ($sql0, $dbconnect);

for ($i1 = 0; $i1 < mysql_num_rows ($query0); $i1++) {
	$array0[$i1] = mysql_fetch_array ($query0);
	}

for ($i1 = 0; $i1 < count ($array0); $i1++) {
	if ($array0[$i1][theme_name] == $array2[theme]) {
		$show_themes .= "<option value=\"".$array0[$i1][theme_name]."\" selected>".$array0[$i1][theme_name]."</option>";
		}
	else {
		$show_themes .= "<option value=\"".$array0[$i1][theme_name]."\">".$array0[$i1][theme_name]."</option>";
		}
	}

$language_dir = dir ("library/languages");
$language_files = array();
	while ($language_file = $language_dir -> read()) {
		if ($language_file != "." and $language_file != "..") {
		$language_files[] = $language_file;
		}
	}
$language_dir -> close();
natcasesort ($language_files);
foreach ($language_files as $language_file) {
	if (substr ($language_file, 0, -4) == $array2[language]) {
		$show_language .= "<option value=\"".substr ($language_file, 0, -4)."\" selected>".substr ($language_file, 0, -4)."</option><br>";
		}
	else {
		$show_language .= "<option value=\"".substr ($language_file, 0, -4)."\">".substr ($language_file, 0, -4)."</option><br>";
		}
	}

if ($array2[file_size] == "Byte") {
	$dbconfig_limit_file_size = $array2[limit_file_size];
	$file_size_select = "
	<option value=\"Byte\" selected>$select_file_size_byte</option>
	<option value=\"KB\">$select_file_size_kb</option>
	<option value=\"MB\">$select_file_size_mb</option>
	<option value=\"GB\">$select_file_size_gb</option>
	<option value=\"TB\">$select_file_size_tb</option>
	<option value=\"PB\">$select_file_size_pb</option>
	<option value=\"EB\">$select_file_size_eb</option>";
	}
elseif ($array2[file_size] == "KB") {
	$dbconfig_limit_file_size = $array2[limit_file_size] / 1024;
	$file_size_select = "
	<option value=\"Byte\">$select_file_size_byte</option>
	<option value=\"KB\" selected>$select_file_size_kb</option>
	<option value=\"MB\">$select_file_size_mb</option>
	<option value=\"GB\">$select_file_size_gb</option>
	<option value=\"TB\">$select_file_size_tb</option>
	<option value=\"PB\">$select_file_size_pb</option>
	<option value=\"EB\">$select_file_size_eb</option>";
	}
elseif ($array2[file_size] == "MB") {
	$dbconfig_limit_file_size = $array2[limit_file_size] / 1048576;
	$file_size_select = "
	<option value=\"Byte\">$select_file_size_byte</option>
	<option value=\"KB\">$select_file_size_kb</option>
	<option value=\"MB\" selected>$select_file_size_mb</option>
	<option value=\"GB\">$select_file_size_gb</option>
	<option value=\"TB\">$select_file_size_tb</option>
	<option value=\"PB\">$select_file_size_pb</option>
	<option value=\"EB\">$select_file_size_eb</option>";
	}
elseif ($array2[file_size] == "GB") {
	$dbconfig_limit_file_size = $array2[limit_file_size] / 1073741824;
	$file_size_select = "
	<option value=\"Byte\">$select_file_size_byte</option>
	<option value=\"KB\">$select_file_size_kb</option>
	<option value=\"MB\">$select_file_size_mb</option>
	<option value=\"GB\" selected>$select_file_size_gb</option>
	<option value=\"TB\">$select_file_size_tb</option>
	<option value=\"PB\">$select_file_size_pb</option>
	<option value=\"EB\">$select_file_size_eb</option>";
	}
elseif ($array2[file_size] == "TB") {
	$dbconfig_limit_file_size = $array2[limit_file_size] / 1099511627776;
	$file_size_select = "
	<option value=\"Byte\">$select_file_size_byte</option>
	<option value=\"KB\">$select_file_size_kb</option>
	<option value=\"MB\">$select_file_size_mb</option>
	<option value=\"GB\">$select_file_size_gb</option>
	<option value=\"TB\" selected>$select_file_size_tb</option>
	<option value=\"PB\">$select_file_size_pb</option>
	<option value=\"EB\">$select_file_size_eb</option>";
	}
elseif ($array2[file_size] == "PB") {
	$dbconfig_limit_file_size = $array2[limit_file_size] / 1125899906842624;
	$file_size_select = "
	<option value=\"Byte\">$select_file_size_byte</option>
	<option value=\"KB\">$select_file_size_kb</option>
	<option value=\"MB\">$select_file_size_mb</option>
	<option value=\"GB\">$select_file_size_gb</option>
	<option value=\"TB\">$select_file_size_tb</option>
	<option value=\"PB\" selected>$select_file_size_pb</option>
	<option value=\"EB\">$select_file_size_eb</option>";
	}
elseif ($array2[file_size] == "EB") {
	$dbconfig_limit_file_size = $array2[limit_file_size] / 1152921504606847000;
	$file_size_select = "
	<option value=\"Byte\">$select_file_size_byte</option>
	<option value=\"KB\">$select_file_size_kb</option>
	<option value=\"MB\">$select_file_size_mb</option>
	<option value=\"GB\">$select_file_size_gb</option>
	<option value=\"TB\">$select_file_size_tb</option>
	<option value=\"PB\">$select_file_size_pb</option>
	<option value=\"EB\" selected>$select_file_size_eb</option>";
	}
else {
	$dbconfig_limit_file_size = $array2[limit_file_size];
	$file_size_select = "
	<option value=\"Byte\" selected>$select_file_size_byte</option>
	<option value=\"KB\">$select_file_size_kb</option>
	<option value=\"MB\">$select_file_size_mb</option>
	<option value=\"GB\">$select_file_size_gb</option>
	<option value=\"TB\">$select_file_size_tb</option>
	<option value=\"PB\">$select_file_size_pb</option>
	<option value=\"EB\">$select_file_size_eb</option>";
	}

if ($array2[new_user_group] == "1") {
	$user_group_select = "
	<option value=\"1\" selected>$select_desc_admin</option>
	<option value=\"2\">$select_desc_downloader</option>
	<option value=\"3\">$select_desc_downloader_uploader</option>
	<option value=\"4\">$select_desc_uploader</option>
	<option value=\"5\">$select_desc_user</option>";
	}
elseif ($array2[new_user_group] == "2") {
	$user_group_select = "
	<option value=\"1\">$select_desc_admin</option>
	<option value=\"2\" selected>$select_desc_downloader</option>
	<option value=\"3\">$select_desc_downloader_uploader</option>
	<option value=\"4\">$select_desc_uploader</option>
	<option value=\"5\">$select_desc_user</option>";
	}
elseif ($array2[new_user_group] == "3") {
	$user_group_select = "
	<option value=\"1\">$select_desc_admin</option>
	<option value=\"2\">$select_desc_downloader</option>
	<option value=\"3\" selected>$select_desc_downloader_uploader</option>
	<option value=\"4\">$select_desc_uploader</option>
	<option value=\"5\">$select_desc_user</option>";
	}
elseif ($array2[new_user_group] == "4") {
	$user_group_select = "
	<option value=\"1\">$select_desc_admin</option>
	<option value=\"2\">$select_desc_downloader</option>
	<option value=\"3\">$select_desc_downloader_uploader</option>
	<option value=\"4\" selected>$select_desc_uploader</option>
	<option value=\"5\">$select_desc_user</option>";
	}
elseif ($array2[new_user_group] == "5") {
	$user_group_select = "
	<option value=\"1\">$select_desc_admin</option>
	<option value=\"2\">$select_desc_downloader</option>
	<option value=\"3\">$select_desc_downloader_uploader</option>
	<option value=\"4\">$select_desc_uploader</option>
	<option value=\"5\" selected>$select_desc_user</option>";
	}
else {
	$user_group_select = "
	<option value=\"1\">$select_desc_admin</option>
	<option value=\"2\">$select_desc_downloader</option>
	<option value=\"3\">$select_desc_downloader_uploader</option>
	<option value=\"4\">$select_desc_uploader</option>
	<option value=\"5\" selected>$select_desc_user</option>";
	}

if ($array2[site_public] == "true") {
	$site_public_checkbox = "<input name=\"public_site\" type=\"checkbox\" id=\"public_site\" value=\"public\" checked>";
	}
else {
	$site_public_checkbox = "<input name=\"public_site\" type=\"checkbox\" id=\"public_site\" value=\"public\">";
	}

if ($array2[site_locked] == "true") {
	$lock_site_checkbox = "<input name=\"lock_site\" type=\"checkbox\" id=\"lock_site\" value=\"lock\" checked>";
	}
else {
	$lock_site_checkbox = "<input name=\"lock_site\" type=\"checkbox\" id=\"lock_site\" value=\"lock\">";
	}

if ($array2[register_locked] == "true") {
	$lock_register_checkbox = "<input name=\"lock_register\" type=\"checkbox\" id=\"lock_register\" value=\"lock\" checked>";
	}
else {
	$lock_register_checkbox = "<input name=\"lock_register\" type=\"checkbox\" id=\"lock_register\" value=\"lock\">";
	}

if ($array2[upload_locked] == "true") {
	$lock_upload_checkbox = "<input name=\"lock_upload\" type=\"checkbox\" id=\"lock_upload\" value=\"lock\" checked>";
	}
else {
	$lock_upload_checkbox = "<input name=\"lock_upload\" type=\"checkbox\" id=\"lock_upload\" value=\"lock\">";
	}

if ($array2[download_locked] == "true") {
	$lock_download_checkbox = "<input name=\"lock_download\" type=\"checkbox\" id=\"lock_download\" value=\"lock\" checked>";
	}
else {
	$lock_download_checkbox = "<input name=\"lock_download\" type=\"checkbox\" id=\"lock_download\" value=\"lock\">";
	}

if ($array2[zip_download_locked] == "true") {
	$lock_zip_download_checkbox = "<input name=\"lock_zip_download\" type=\"checkbox\" id=\"lock_zip_download\" value=\"lock\" checked>";
	}
else {
	$lock_zip_download_checkbox = "<input name=\"lock_zip_download\" type=\"checkbox\" id=\"lock_zip_download\" value=\"lock\">";
	}

if ($array2[new_user_report] == "true") {
	$new_user_report_checkbox = "<input name=\"new_user_report\" type=\"checkbox\" id=\"new_user_report\" value=\"report\" checked>";
	}
else {
	$new_user_report_checkbox = "<input name=\"new_user_report\" type=\"checkbox\" id=\"new_user_report\" value=\"report\">";
	}

if ($array2[new_upload_report] == "true") {
	$new_upload_report_checkbox = "<input name=\"new_upload_report\" type=\"checkbox\" id=\"new_upload_report\" value=\"report\" checked>";
	}
else {
	$new_upload_report_checkbox = "<input name=\"new_upload_report\" type=\"checkbox\" id=\"new_upload_report\" value=\"report\">";
	}

$update_file = "admin_update_version.php";

if (file_exists ($update_file)) {
	include ("admin_update_version.php");
	if ($array2[version] < $update_version) {
		$install_update_output = "
		<tr bgcolor=\"".$array4[table_bgcolor4]."\">
		<td align=\"left\">$textfield_as_desc_13</td>
		<td width=\"70%\" align=\"left\"><a href=\"admin_update.php\"><font color=\"#0000FF\">$link_install_update</font></a></td>
		</tr>";
		}
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>        
        </div>
        <form action="admin_settings_execute.php" method="post" name="form1">
          <table width="100%"  border="0" cellspacing="1">
            <tr bgcolor="<?php echo $array4[table_bgcolor1] ?>">
              <td align="center" bgcolor="<?php echo $array4[table_bgcolor4] ?>"><br>
                <table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td><fieldset>
                    <legend><?php echo $field_as_1 ?></legend>
                    <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_as_desc_1 ?></td>
                        <td width="70%" align="left"><input name="dbconfig_site_name" type="text" id="dbconfig_site_name" value="<?php echo $array2[site_name] ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_as_desc_2 ?></td>
                        <td width="70%" align="left"><input name="dbconfig_site_url" type="text" id="dbconfig_site_url" value="<?php echo $array2[site_url] ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_as_desc_3 ?></td>
                        <td width="70%" align="left"><input name="dbconfig_admin_email" type="text" id="dbconfig_admin_email" value="<?php echo $array2[admin_email] ?>" size="61"></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_as_desc_4 ?></td>
                        <td width="70%" align="left"><select name="dbconfig_theme" id="dbconfig_theme" style="width:150px">
                            <?php echo $show_themes ?>
                        </select></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_as_desc_5 ?></td>
                        <td width="70%" align="left"><select name="dbconfig_language" id="dbconfig_language" style="width:150px">
                            <?php echo $show_language ?>
                        </select></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_as_desc_6 ?></td>
                        <td width="70%" align="left"><select name="dbconfig_new_user_group" id="dbconfig_new_user_group" style="width:150px">
                            <?php echo $user_group_select ?>
						</select></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_as_desc_7 ?></td>
                        <td align="left"><input name="dbconfig_limit_file_size" type="text" id="dbconfig_limit_file_size" value="<?php echo $dbconfig_limit_file_size ?>" style="width:144px">
                          <select name="dbconfig_file_size" id="dbconfig_file_size" style="width:167px">
							<?php echo $file_size_select ?>
                          </select></td>
                      </tr>
                      <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                        <td align="left"><?php echo $textfield_site_public_desc ?></td>
                        <td align="left"><?php echo $site_public_checkbox ?></td>
                      </tr>
                    </table>
                  </fieldset></td>
                </tr>
              </table>
                <br>
                <table width="650" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><fieldset>
                      <legend><?php echo $field_lock ?></legend>
                      <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                        <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_lock_site_desc ?></td>
                          <td width="70%" align="left"><?php echo $lock_site_checkbox ?></td>
                        </tr>
                        <tr valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_lock_site_reason_desc ?></td>
                          <td align="left"><textarea name="dbconfig_lock_site_reason" cols="60" rows="3" id="dbconfig_lock_site_reason"><?php echo $array2[site_locked_reason] ?></textarea></td>
                        </tr>
                      </table>
                    </fieldset></td>
                  </tr>
                </table>
                <br>
                <table width="650" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><fieldset>
                      <legend><?php echo $field_lock ?></legend>
                      <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                        <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_lock_register_desc ?></td>
                          <td width="70%" align="left"><?php echo $lock_register_checkbox ?></td>
                        </tr>
                        <tr valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_lock_register_reason_desc ?></td>
                          <td align="left"><textarea name="dbconfig_lock_register_reason" cols="60" rows="3" id="dbconfig_lock_register_reason"><?php echo $array2[register_locked_reason] ?></textarea></td>
                        </tr>
                      </table>
                    </fieldset></td>
                  </tr>
                </table>
                <br>
                <table width="650" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><fieldset>
                      <legend><?php echo $field_lock ?></legend>
                      <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                        <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_lock_upload_desc ?></td>
                          <td width="70%" align="left"><?php echo $lock_upload_checkbox ?></td>
                        </tr>
                        <tr valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_lock_upload_reason_desc ?></td>
                          <td align="left"><textarea name="dbconfig_lock_upload_reason" cols="60" rows="3" id="dbconfig_lock_upload_reason"><?php echo $array2[upload_locked_reason] ?></textarea></td>
                        </tr>
                      </table>
                    </fieldset></td>
                  </tr>
                </table>
                <br>
                <table width="650" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><fieldset>
                      <legend><?php echo $field_lock ?></legend>
                      <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                        <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_lock_download_desc ?></td>
                          <td width="70%" align="left"><?php echo $lock_download_checkbox ?></td>
                        </tr>
                        <tr valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_lock_download_reason_desc ?></td>
                          <td align="left"><textarea name="dbconfig_lock_download_reason" cols="60" rows="3" id="dbconfig_lock_download_reason"><?php echo $array2[download_locked_reason] ?></textarea></td>
                        </tr>
                      </table>
                    </fieldset></td>
                  </tr>
                </table>
                <br>
                <table width="650" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><fieldset>
                      <legend><?php echo $field_lock ?></legend>
                      <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                        <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_lock_zip_download_desc ?></td>
                          <td width="70%" align="left"><?php echo $lock_zip_download_checkbox ?></td>
                        </tr>
                        <tr valign="top" bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_lock_zip_download_reason_desc ?></td>
                          <td align="left"><textarea name="dbconfig_lock_zip_download_reason" cols="60" rows="3" id="dbconfig_lock_zip_download_reason"><?php echo $array2[zip_download_locked_reason] ?></textarea></td>
                        </tr>
                      </table>
                    </fieldset></td>
                  </tr>
                </table>
                <br>
                <table width="650" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><fieldset>
                      <legend><?php echo $field_as_2 ?></legend>
                      <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                        <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_as_desc_8 ?></td>
                          <td align="left"><?php echo $new_user_report_checkbox ?></td>
                        </tr>
                        <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_as_desc_9 ?></td>
                          <td width="70%" align="left"><?php echo $new_upload_report_checkbox ?></td>
                        </tr>
                      </table>
                    </fieldset></td>
                  </tr>
                </table>
                <br>
                <table width="650" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><fieldset>
                      <legend><?php echo $field_as_3 ?></legend>
                      <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                        <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_as_desc_10 ?></td>
                          <td align="left"><?php echo $array2[version] ?></td>
                        </tr>
                        <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_as_desc_11 ?></td>
                          <td width="70%" align="left"><?php echo $array2[install_date] ?></td>
                        </tr>
                        <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_as_desc_12 ?></td>
                          <td width="70%" align="left"><?php echo "<a href=\"http://projects.quasars.de/storage/update.php?version=".$array2[version]."&language=".$array2[language]."\" target=\"_blank\"><font color=\"#0000FF\">$link_check_update</font></a>"; ?></td>
                        </tr>
						<?php echo $install_update_output ?>
                        <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                          <td align="left"><?php echo $textfield_as_desc_14 ?></td>
                          <td align="left"><?php echo "<a href=\"admin_uninstall.php\"><font color=\"#0000FF\">$link_uninstall</font></a>"; ?></td>
                        </tr>
                      </table>
                    </fieldset></td>
                  </tr>
                </table>  
              <br></td>
            </tr>
            <tr bgcolor="<?php echo $array4[table_bgcolor1] ?>">
              <td align="center" bgcolor="<?php echo $array4[table_bgcolor4] ?>"><input type="submit" name="Submit" value="<?php echo $button_save ?>"></td>
            </tr>
            <tr>
              <td align="center">&nbsp;</td>
            </tr>
            <tr>
              <td align="center"><table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="left">&nbsp; </td>
                </tr>
              </table></td>
            </tr>
          </table>
        </form>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
