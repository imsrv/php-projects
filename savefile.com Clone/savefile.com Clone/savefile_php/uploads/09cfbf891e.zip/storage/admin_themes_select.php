<?php

/****************************************************
*                                                   *
*   Quasars Storage - The Filemanager               *
*   _____________________________________________   *
*                                                   *
*   Copyright (c) 2005 by Quasars, Ralf Weiher      *
*   Developed as a Project of Quasars               *
*                                                   *
*   http://projects.quasars.de/storage              *
*   http://www.quasars.de                           *
*                                                   *
*   This Software is free for non-commercial use.   *
*                                                   *
****************************************************/

include ("login_validation.php");

admin();

$sql0 = "SELECT * FROM `$dbtable2` ORDER BY `theme_name` ASC LIMIT 0, 30"; 
$query0 = mysql_query ($sql0, $dbconnect);

for ($i1 = 0; $i1 < mysql_num_rows ($query0); $i1++) {
	$array0[$i1] = mysql_fetch_array ($query0);
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $array2[site_name] ?></title>
<?php echo "$css $js_browser_detection"; ?>
</head>

<body onLoad="<?php echo $js_browser_detection_onload ?>">
<div align="center">
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="16" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_head_b.gif">&nbsp;</td>
      <td align="center" bgcolor="<?php echo $array4[table_bgcolor1] ?>"><span class="Stil1"><?php echo "$info_header1 ".$array2[site_name]." $info_header2"; ?></span></td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_head.gif">&nbsp;</td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><span class="Stil1"><strong><?php echo $menu ?></strong></span></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="303" valign="top" bgcolor="#FFFFFF">
        <div align="center">
		<?php admin_menu(); ?>
		<br>
        <?php echo $info_themes_select ?><br>
        <br>
        <form action="admin_themes_edit.php" method="post" name="form1">
          <table width="100%"  border="0" cellspacing="1">
            <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
              <td align="center" bgcolor="<?php echo $array4[table_bgcolor4] ?>"><br>
                  <table width="650" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td><fieldset>
                        <legend><?php echo $field_ts_1 ?></legend>
                        <table width="100%"  border="0" cellspacing="1" bgcolor="#FFFFFF">
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left"><?php echo $textfield_at_desc_22 ?></td>
                            <td width="70%" align="left"><select name="theme_select" id="theme_select" style="width:321px">
                              <?php for ($i1 = 0; $i1 < count ($array0); $i1++) { echo "<option value=\"".$array0[$i1][id]."\">".$array0[$i1][theme_name]."</option>"; } ?>
                            </select></td>
                          </tr>
                          <tr bgcolor="<?php echo $array4[table_bgcolor4] ?>">
                            <td align="left">&nbsp;</td>
                            <td align="left"><input type="submit" name="Submit" value="<?php echo $button_edit ?>">
                            </td>
                          </tr>
                        </table>
                      </fieldset></td>
                    </tr>
                  </table>
                  <br>
                  <br></td>
            </tr>
            <tr>
              <td align="center">&nbsp;</td>
            </tr>
            <tr>
              <td align="center"><table width="650" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="left">&nbsp;</td>
                </tr>
              </table></td>
            </tr>
          </table>
        </form>
        </div>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellpadding="0" cellspacing="0">
    <tr align="center">
      <td height="15" align="center" bgcolor="<?php echo $array4[table_bgcolor2] ?>"><strong><span class="Stil2"></span></strong></td>
    </tr>
  </table>
  <table width="<?php echo $array4[table_width] ?>"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_left_foot_b.gif">&nbsp;</td>
      <td bgcolor="<?php echo $array4[table_bgcolor1] ?>">&nbsp;</td>
      <td width="19" height="19" background="themes/<?php echo $array4[theme_directory] ?>/images/table_corner_right_foot.gif">&nbsp;</td>
    </tr>
  </table>
  <p><?php echo $array2[company_footer] ?></p>
</div>
</body>
</html>
