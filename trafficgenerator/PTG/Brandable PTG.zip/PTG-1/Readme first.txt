========================================================

      Just a Quick Note before you get started!

========================================================


Thanks for picking up a copy of the Perpetual Traffic 
Generator,You have been now given the unlimited rights
to reprint / resell this resource with the web site and
graphics included.

The product may be sold for any price you wish but no 
less than $49.95, and you keep all the profits you make.

You MAY NOT give away the book. This is to protect the
all the netrepreneurs who have purchased this book, and 
the worth of the product. Selling the reprint rights is 
part of the viral marketing effect, so if you give it 
away, you lessen it's worth to YOU. 

IMPORTANT!-----

You may NOT make any changes to the web copy except to
insert your own name and details where indicated, and 
your own order information. 

All other changes are strictly dis-allowed!


Both the images and sales copy remain copyrighted to
Jo Han and Alex/Super Fast Profit Enterprise, and may be
used for promotion of the Perpetual Traffic Generator as 
specified above.


Thank you and best wishes online.