$in{'BackgroundColorText'}="FFFFFF";
$in{'DescriptionFace'}="verdana, helvetica, arial";
$in{'DescriptionSize'}="2";
$in{'DescriptionTableText'}="000000";
$in{'Height'}="480";
$in{'OpTitleFace'}="verdana, helvetica, arial";
$in{'OpTitleSize'}="5";
$in{'OpTitleTableColorText'}="CCCCCC";
$in{'OpTitleTableText'}="000000";
$in{'TitleFace'}="verdana, helvetica, arial";
$in{'TitleSize'}="2";
$in{'TitleTableText'}="000000";
$in{'Width'}="640";
$in{'adminemail'}="";
$in{'afrom'}="";
$in{'amessage'}="Thank you for your submission on FORM(Date). 
Your question was:
FORM(title)
FORM(message)  

We will respond to your shortly.";
$in{'asubject'}="New FAQ Submission";
$in{'disaut'}="checked";
$in{'disnot'}="checked";
$in{'dui'}="checked";
$in{'entryorder'}="FIRST";
$in{'fBodyFace'}="verdana, helvetica, arial";
$in{'fBodySize'}="2";
$in{'fBodyText'}="000000";
$in{'fDescriptionFace'}="verdana, helvetica, arial";
$in{'fDescriptionSize'}="2";
$in{'fDescriptionText'}="000000";
$in{'fTitleFace'}="verdana, helvetica, arial";
$in{'fTitleSize'}="2";
$in{'fTitleText'}="000000";
$in{'menubar'}="checked";
$in{'mpage'}="manager";
$in{'nmessage'}="FORM(name) FORM(email) has submitted the following question:
FORM(title)
FORM(message)
";
$in{'nsubject'}="FAQ Submission";
$in{'pbackgnd'}="";
$in{'pfooter'}="";
$in{'pheader'}="";
$in{'pleft'}="";
$in{'position'}="center";
$in{'ptop'}="";
$in{'resizable'}="checked";
$in{'scrollbar'}="checked";
$in{'security'}="none";
$in{'tCellPadding'}="5";
$in{'tCellSpacing'}="0";
$in{'tEvenCellColorText'}="EEEEEE";
$in{'tOddCellColorText'}="FFFFFF";
$in{'tTableBorder'}="1";
$in{'tTableWidth'}="100%";
$in{'tTitle'}="CGIScript.net FAQ";
$in{'userpass'}="";
1;
