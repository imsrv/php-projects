<?php 
/*

If you are going to upgrade from EasyForum 1.0 or 1.1
you should convert your 'data' files by running this file ONCE...

e.g. http://yoursite.com/forum_directory/upgrade1.php

Do not forget to upgrade the function f_inf() as well
if you use more than one forum or some info is displayed by f_inf() anywhere on your site.
The new f_inf() can be seen at the bottom of README.TXT.

*/


$entry='';$bg=0;
function opl($m){$fd=fopen($m,"r") or die('...');$fs=fread($fd,filesize($m));fclose($fd);return $fs;}
function wri($m,$n){$fd=fopen($m,"w") or die('...');$fout=fwrite($fd,$n);fclose($fd);}

$handle=opendir('data');
while($entry=readdir($handle)){
if(is_file("data/$entry")&&is_writeable("data/$entry")){
$file=opl("data/$entry");$text=explode("\n",$file);
for($i=0;$i<count($text);$i++){
$text[$i]=eregi_replace('([0-9]+)_([a-z]+)_([0-9]+)_([0-9]+)_([0-9]+)_([0-9]+)','\\3 \\2 \\1 \\4:\\5',$text[$i]);
}
$file=implode("\n",$text);wri("data/$entry",$file);$bg=1;}}
?>
<html><head></head><body><h3><?php if($bg!=0){print "DONE!";}?></h3></body></html>