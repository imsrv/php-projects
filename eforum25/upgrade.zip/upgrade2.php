<?php 
/*

If you are going to upgrade from EasyForum 1.4 or 1.5
you should convert your 'members' file by running this file ONLY ONCE...
If you run it more than once you'll lose your 'members' file!!!

e.g. http://yoursite.com/forum_directory/upgrade2.php

*/
$bg=0;
include "config.php";include "incl/mmbs.inc";
$fs=opl($memfile);$fs=explode("\n",$fs);for($i=1;$i<count($fs);$i++){
if(strlen($fs[$i])>9){$ttr=explode(":|:",$fs[$i]);
$ttr[1]=md5($ttr[1]);$fs[$i]=implode(":|:",$ttr);
}}$bg=1;$fs=implode("\n",$fs);wri($memfile,$fs,1);
?>
<html><head></head><body><h3><?php if($bg!=0){print "DONE!";}?></h3></body></html>