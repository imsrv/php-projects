<?php
//  ___  ____       _  ______ _ _        _   _           _   
//  |  \/  (_)     (_) |  ___(_) |      | | | |         | |  
//  | .  . |_ _ __  _  | |_   _| | ___  | |_| | ___  ___| |_ 
//  | |\/| | | '_ \| | |  _| | | |/ _ \ |  _  |/ _ \/ __| __|
//  | |  | | | | | | | | |   | | |  __/ | | | | (_) \__ \ |_ 
//  \_|  |_/_|_| |_|_| \_|   |_|_|\___| \_| |_/\___/|___/\__|
//
// by MiniFileHost.co.nr                  version 1.1
////////////////////////////////////////////////////////


include("./config.php");
$checkfiles=file("./files.txt");
foreach($checkfiles as $line)
{
$rand2 = $thisline[0];
$up = $descriptionoption;
if ($up=="false")
  $d = "";
else
  $d = ""; 

  $thisline = explode('|', $line);
$filelist = fopen("./files/". $thisline[0].".txt","w");
fwrite($filelist, $thisline[0] ."|". $thisline[1] ."|". $thisline[2] ."|". $thisline[3] ."|".$thisline[4]."|".$thisline[5]."|".$thisline[6]."||".$thisline[8]."|\n");
 
  $filesize = filesize("./storage/".$thisline[0]);
  $filesize = ($filesize / 1048576);

}
echo "</table></p>";

?>