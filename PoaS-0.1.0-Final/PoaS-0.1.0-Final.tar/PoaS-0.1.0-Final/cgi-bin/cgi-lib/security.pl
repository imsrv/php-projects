##########################
sub log_change_pass_req {
##########################

	if ($input{'username'} eq "") { error ("$err{'003'}"); }

	open(FILE, "$memberdir/$input{'username'}.dat") || error("$err{'010'}");
	chomp(@settings = <FILE>);
	close(FILE);

	$curr_time = time();
	$log_change_time = $curr_time + (3600 * 48);

	open(FILE, ">$datadir/temp/confirmation/$log_change_time.dat") || error("Can't create temporary file for password change");
	lock(FILE);
	print FILE "$input{'username'}|reserved|reserved\n";
	unlock(FILE);
	close(FILE);
}

##########################
sub change_pass_confirm {
##########################

	if(!open(FILE, "$datadir/temp/confirmation/$info{'code'}.dat")) { error("Can't open confirmation code file, probably you have runout change session time (you only have 2 days)"); }
	else {
		@confirm_change = <FILE>;
		close(FILE);
	}

	@fields_c = split(/\|/, $confirm_change[0]);

	$navbar = "$admin{'btn2'} Password Change";
	print_top();
	print qq~<center><big>Password Change for $fields_c[0]</big></center><p>
		<form action="$pageurl/$cgi?action=confirmpasschange" method="POST">
		<input type="hidden" name="code" value="$info{'code'}">
		Type new Password : <input type="text" name="newpass"><br>
		Type Password again : <input type="text" name="confirmnew"><br>
		<input type="submit" value="Submit"></form>
		~;
	print_bottom();
}

##########################
sub change_pass_confirm1 {
##########################

	if($input{'code'} eq "") { error("Input code are empty"); }
	elsif($input{'newpass'} eq "") { error("Password fields are empty"); }
	elsif($input{'confirmnew'} eq "") { error("Password confirmation are empty"); }
	elsif($input{'newpass'} ne $input{'confirmnew'}) { error("New Password are not the same, both must equal"); }
	else {
		if(!open(FILE, "$datadir/temp/confirmation/$input{'code'}.dat")) { error("Can't open confirmation code file, probably you have runout change session time (you only have 2 days)"); }
		else {
			@confirm_change = <FILE>;
			close(FILE);
		}

		$curr_time = time();
		if("$input{'code'}" lt "$curr_time") {
			unlink("$datadir/temp/confirmation/$input{'code'}.dat");
			error("You password change session are expire, you have only 2 day to use the link");
		}

		@fields_c = split(/\|/, $confirm_change[0]);

		open(FILE, "$memberdir/$fields_c[0].dat") || error("$err{'010'}");
		chomp(@settings = <FILE>);
		close(FILE);

		for ($i = 0; $i < @settings; $i++) { $settings[$i] =~ s~[\n\r]~~g;
			$newpasswrd = crypt($input{'newpass'}, substr($fields_c[0], 0, 2)); 

			open(FILE, ">$memberdir/$fields_c[0].dat");
			lock(FILE);
			print FILE "$newpasswrd\n";
			for ($i = 1; $i < @settings; $i++) { print FILE "$settings[$i]\n"; }
			unlock(FILE);
			close(FILE);

			unlink("$datadir/temp/confirmation/$input{'code'}.dat");
		}

		$navbar = "$admin{'btn2'} Password Change";
		print_top();
		print qq~ Password change for $fields_c[0] are successfully~;
		print_bottom();

	}
}

###################
sub check_hash {
###################

	my $parsed_hash = shift;
	if ($parsed_hash =~ /@/) { return $parsed_hash; }
	$parsed_hash =~ s/\%20/ /eg;
	if ($parsed_hash =~ /(\$+|\?+|\|+|\(+|\)+|\[+|\]+|\{+|\}+|\^+|\%+|\*+|\.+|\<)/) { hack_attempt(); error("Illegal character detected, action has been logged and marked as hack attempt"); exit; }
	$parsed_hash =~ s/ /\%20/eg;
	return $parsed_hash;
}

#######################
sub check_allowed_ip {
#######################

	if(!open(FILE, "$datadir/temp/ip/allowed.dat")) { return; }
	else {	
		chomp(@field_allow = <FILE>);
		close(FILE);
	}

	$verified_ip = 0;
	foreach $check_fields (@field_allow) {
		@fields = split(/\|/, $check_fields);
		next if ($fields[0] ne "$ENV{'REMOTE_ADDR'}");
		if ($fields[0] eq "$ENV{'REMOTE_ADDR'}") { $verified_ip = 1; }
	}

	if ($verified_ip eq 0) { hack_attempt(); error("Unauthorized access detected from $ENV{'REMOTE_ADDR'}! Get out from my system NOW!"); }
}

#######################
sub log_admin_access {
#######################
	open(FILE, ">>$datadir/adminaccess.log");
	lock(FILE);
	print FILE "$username|$ENV{'REMOTE_ADDR'}|$query|$input|$ENV{QUERY_STRING}|$ENV{'HTTP_REFERER'}\n";
	unlock(FILE);
	close(FILE);
}

####################
sub check_referer {
####################

	$length_domain = length($baseurl);
	$domain_from = substr(lc($ENV{'HTTP_REFERER'}), 0, $length_domain);
	if($domain_from ne lc($baseurl)) {
		$domain_from =~ s/http:\/\///eg;
		if($domain_from ne lc($baseurl)) {
			print "Location: pageurl/$cgi\n\n";
		}
	}

}

1;
