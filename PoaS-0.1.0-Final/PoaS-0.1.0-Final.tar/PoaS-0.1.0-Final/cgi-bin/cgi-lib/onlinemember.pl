sub view_online_members {

	$guests = 0;
	$users = 0;

	open(LOG, "$datadir/log.dat");
	chomp(@entries = <LOG>);
	close(LOG);

ONLINEUSER:	foreach $curentry (@entries) {
		($name, $value, $userlanguage) = split(/\|/, $curentry);
		next ONLINEUSER if($name =~ /\./);

		open(FILE, "$memberdir/$name.dat") || error("Can't open user $name database in sub view_online_member");
		chomp(@fields_user = <FILE>);
		close(FILE);

		$user_s_name = $fields_user[1];

		$onlineuserlist .= qq~ <option value="$pageurl/$cgi\?action=imsend\&to=$name">$user_s_name</option>\n~;
		}

print qq~<tr><td align=center><b>Online Members</b><br>
<script language="javascript" type="text/javascript">
<!--  Hide me please!
function SelectIt(){
        if (document.Links.Select.options[document.Links.Select.selectedIndex].value != "none"){ 
        location = document.Links.Select.options[document.Links.Select.selectedIndex].value}
}
//-->
</script><form name="Links">
<div align="center"><center><p>
<select onChange="SelectIt()" name="Select">
$onlineuserlist\n
</select></p></center></div></form></td></tr>~;

}
1;
