###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                      #
#-----------------------------------------------------------------------------#
# memberlist.pl - this code displays the memberlist                           #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)	                        #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: memberlist.pl, Last modified: 18:45 08/04/2002                        #
###############################################################################
###############################################################################


###########
sub mlist {
###########
    use File::stat;
    use Time::localtime;

	if ($username eq $anonuser) { error("$err{'011'}"); }
	undef @allmembers;

	open(FILE, "$memberdir/memberlist.dat");
	chomp(@memberlist = <FILE>);
	close(FILE);

	$thelatestmember = $memberlist[$#memberlist];

	open(FILE, "$memberdir/$thelatestmember.dat");
	chomp(@lmsettings = <FILE>);
	close(FILE);

	$tlmname = @lmsettings[1];

	$count = @memberlist;
	$users = "";

	open(FILE, "$datadir/log.dat");
	@entries = <FILE>;
	close(FILE);

	foreach $curentry (@entries) {
		$curentry =~ s/[\n\r]//g;
		($name, $value, $userlanguage) = split(/\|/, $curentry);
		if ($name =~ /\./) {  }
		else {
			open(FILE, "$memberdir/$name.dat");
			chomp(@msettings = <FILE>);
			close(FILE);

			$users = qq~$users <a href="$pageurl/$cgi?action=viewprofile&amp;username=$name">$msettings[1]</a>\n~;
		}
	}

	open(FILE, "$memberdir/membergroups.dat");
	@membergroups = <FILE>;
	close(FILE);

	foreach $member (@memberlist) {
		open(FILE, "$memberdir/$member.dat");
		chomp(@members = <FILE>);
		close(FILE);

		$id++;
		$searchname = lc $members[1];
		$posts = $members[6]+$members[11]+$members[12];

		$memberinfo = "$membergroups[2]";
		if ($posts > 25) { $memberinfo = "$membergroups[3]"; $rank = 6; }
		if ($posts > 50) { $memberinfo = "$membergroups[4]"; $rank = 5; }
		if ($posts > 75) { $memberinfo = "$membergroups[5]"; $rank = 4; }
		if ($posts > 100) { $memberinfo = "$membergroups[6]"; $rank = 3; }
		if ($posts > 250) { $memberinfo = "$membergroups[7]"; $rank = 2; }
		if ($posts > 500) { $memberinfo = "$membergroups[8]"; $rank = 1; }

		push (@allmembers, join ("\|", "$searchname|$members[1]|$members[2]|$members[10]|$members[8]|$memberinfo|$rank|$posts|$members[7]|$member|$id\n"));
	}

	for (0..$#allmembers) {
		@fields = split(/\|/, $allmembers[$_]);
		for $i (0..$#fields) {
			$data[$_][$i] = $fields[$i];
		}
	}

	if ($info{'sort'} == 0) {
		@sorted = sort { $a->[0] cmp $b->[0] } @data;
	}
	if ($info{'sort'} == 1) {
		@sorted = sort { $a->[2] cmp $b->[2] } @data;
	}
	if (($info{'sort'} == 2) || ($info{'sort'} eq "")) {
		@sorted = sort { $a->[10] <=> $b->[10] } @data;
	}
	if ($info{'sort'} == 3) {
		@sorted = sort { $a->[4] <=> $b->[4] } @data;
	}
	if ($info{'sort'} == 4) {
		@sorted = reverse sort { $a->[7] <=> $b->[7] } @data;
	}
	if ($info{'sort'} == 5) {
		@sorted = reverse sort { $a->[7] <=> $b->[7] } @data;
	}
	if ($info{'sort'} == 6) {
		@sorted = sort { $a->[8] cmp $b->[8] } @data;
	}

	for (@sorted) { 
		$sortedrow = join ("|", @$_);
		push (@sortedmembers, $sortedrow);
	}

	open(LOGC, "$datadir/log.dat");
	chomp(@entriesc = <LOGC>);
	close(LOGC);

	foreach $curentryc (@entriesc) {
		($namec, $valuec, $userclangc) = split(/\|/, $curentryc);
		if($namec =~ /\./) { ++$guestsc }
		else { ++$usersc	}
	}

	$navbar = "$admin{'btn2'} $nav{'019'}";
	print_top();
	print qq~<table border="0" width="100%" cellspacing="1">
<tr>
<td valign="top">$msg{'028'} <a href="$pageurl/$cgi?action=viewprofile&amp;username=$thelatestmember">$tlmname</a><br>
$msg{'029'} $count<br>
$msg{'030'} $usersc with current user status $settings[7]</td>
</tr>
</table>
<br><br>
<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td>
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td bgcolor="$windowbg"><a href="$pageurl/$cgi?action=memberlist&amp;sort=0"><b>$msg{'013'}</b></a></td>
<td bgcolor="$windowbg"><a href="$pageurl/$cgi?action=memberlist&amp;sort=1"><b>$msg{'007'}</b></a></td>
<td bgcolor="$windowbg"><a href="$pageurl/$cgi?action=memberlist&amp;sort=2"><b>$msg{'027'}</b></a></td>
<td bgcolor="$windowbg"><a href="$pageurl/$cgi?action=memberlist&amp;sort=3"><b>$msg{'016'}</b></a></td>
<td bgcolor="$windowbg"><a href="$pageurl/$cgi?action=memberlist&amp;sort=4"><b>$msg{'024'}</b></a></td>
<td bgcolor="$windowbg"><a href="$pageurl/$cgi?action=memberlist&amp;sort=5"><b>$msg{'031'}</b></a></td>
<td bgcolor="$windowbg"><a href="$pageurl/$cgi?action=memberlist&amp;sort=6"><b>$msg{'033'}</b></a></td>
<td bgcolor="$windowbg"><a href="$pageurl/$cgi?action=memberlist&amp;sort=6"><b>$msg{'173'}</b></a></td>
</tr>
~;

	if ($settings[7] eq "Administrator") { $curuserlvl = "2"; }
	elsif ($settings[7] eq "Moderator") { $curuserlvl = "1"; }
	else { $curuserlvl = "0"; }

	if (@allmembers == 0) { }

	if ($info{'start'} eq "") { $start = 0; }
	else { $start = "$info{'start'}"; }

	$count = 0;
	$second = "$windowbg3";
NUSER:	for ($i = $start; $i < @sortedmembers; $i++) {
		if ($second eq "$windowbg2") { $second="$windowbg3"; }
		else { $second="$windowbg2"; }
		($dummy, $mname, $memail, $msince, $micq, $mrank, $dummy, $mposts, $mfunct, $musername, $dummy) = split(/\|/, $sortedmembers[$i]);
		$count++;

#		if ($curuserlvl eq "0" && $mfunct eq "") { goto NEXTUSR; }
#		else { print qq~<tr><td bgcolor="$second">Blocked</td><td bgcolor="$second">Blocked</td><td bgcolor="$second">$msince</td>
#				<td bgcolor="$second">Blocked</td><td bgcolor="$second">$mrank</td><td bgcolor="$second">$mposts</td>
#				<td bgcolor="$second">$mfunct</td><td bgcolor="$second">Blocked</td></tr>~; next; 
#			}
#		if ($curuserlvl eq "1" && $mfunct eq "") { goto NEXTUSR; }
#		elsif ($muserlvl eq "1" && $mfunt eq "Moderator") { goto NEXTUSR; }
#		else { print qq~<tr><td bgcolor="$second">Blocked</td><td bgcolor="$second">Blocked</td><td bgcolor="$second">$msince</td>
#				<td bgcolor="$second">Blocked</td><td bgcolor="$second">$mrank</td><td bgcolor="$second">$mposts</td>
#				<td bgcolor="$second">$mfunct</td><td bgcolor="$second">Blocked</td></tr>~; next; 
#			}
#		if ($curuserlvl eq "2") { goto NEXTUSR; }
#		else { print qq~<tr><td bgcolor="$second">Blocked</td><td bgcolor="$second">Blocked</td><td bgcolor="$second">$msince</td>
#				<td bgcolor="$second">Blocked</td><td bgcolor="$second">$mrank</td><td bgcolor="$second">$mposts</td>
#				<td bgcolor="$second">$mfunct</td><td bgcolor="$second">Blocked</td></tr>~; next; 
#			}

NEXTUSR:	$icq = "";
		if ($micq ne "") {
			$icq = qq~<a href="http://www.icq.com/$micq" target="_blank"><img src="http://wwp.icq.com/scripts/online.dll?icq=$micq&amp;img=5" alt="$micq" border="0"></a>~;
		}
		$check_date = 1;
		$file_log_seen = "$datadir/members/$mname.log";
		if (!open (FILE, "$file_log_seen")) { $mseen = "$msg{'174'}"; $check_date = 0; $memberlog = 0; close (FILE); }
		else { close (FILE); $memberlog = 1;}
		if ($check_date eq 1) {

			if ($memberlog ne 0) {
				open(FILE, "$file_log_seen");
				@valueseen = <FILE>;
				close(FILE);

				($memaction, $actiondate) = split(/\|/, $valueseen);
				$mseen = "$actiondate - $memaction";
			}
		}

		print qq~<tr>
<td bgcolor=\"$second\"><a href=\"$pageurl/$cgi\?action=viewprofile&amp;username=$musername\">$mname</a></td>
<td bgcolor=\"$second\"><a href=\"mailto:$memail\">$memail</a></td>
<td bgcolor=\"$second\">$msince</td>
<td bgcolor=\"$second\">$icq</td>
<td bgcolor=\"$second\">$mrank</td>
<td bgcolor=\"$second\">$mposts</td>
<td bgcolor=\"$second\">$mfunct</td>
<td bgcolor=\"$second\">$mseen</td>
</tr>
~;
		if ($count >= $maxmessagedisplay) { $i = @allmembers; }
	}
	print qq~</table>
</td>
</tr>
</table>
<br>
~;

	print "<b>$msg{'039'}</b>";
	$nummembers = @allmembers;
	$count = 0;
	while (($count*$maxmessagedisplay) < $nummembers) {
		$view = $count+1;
		$offset = ($count*$maxmessagedisplay);
		if ($start == $offset) { print qq~[$view] ~; }
		elsif ($offset == 0) { print qq~<a href=\"$pageurl/$cgi\?action=memberlist&amp;sort=$info{'sort'}\">$view</a> ~; }
		else { print qq~<a href=\"$pageurl/$cgi\?action=memberlist&amp;sort=$info{'sort'}&amp;start=$offset\">$view</a> ~; }
		$count++;
	}
	print "\n";
	print_bottom();
	exit;
}



1; # return true
