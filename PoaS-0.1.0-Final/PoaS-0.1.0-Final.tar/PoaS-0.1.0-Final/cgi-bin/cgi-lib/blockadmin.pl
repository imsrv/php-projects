######################
sub edit_block_list {
######################
	require "$sourcedir/security.pl";
	check_user_permission();
	check_hash($info{'blockside'});

	open(FILE, "$datadir/blocks/$info{'blockside'}.dat");
	@sidecont = <FILE>;
	close(FILE);

	@fieldside = split(/\|/, $sidecont[0]);

	$navbar = "$admin{'btn2'} Administration $admin{'btn2'} Block";
	print_top();
	print qq~<form action="$pageurl/$admin&op=blockadmin&command=editlist1" method="post"><center><big>Block List For $info{'blockside'}</big></center><p>
		<table border=1 bordercolor="#57A6CC" align=center><tr bgcolor="#C6E7F7"><td>Position</td><td>Current Block ID</td><td>New Block ID</td></tr>~;
	$i = 0;
	foreach (@fieldside) {
		next if($i eq "10");
		$blocklisting .= qq~<tr><td>Level $i</td><td>$fieldside[$i]</td>
			<td><select name="newblockstat$i">~;
		if($fieldside[$i] eq "off") { $blocklisting .= qq~
			<option value="off" selected>Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "mainmenu") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu" selected>Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "search") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search" selected>Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "userpanel") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel" selected>User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "userstatus") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus" selected>User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "addonsleft") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft" selected>Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "addonsright") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright" selected>Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "language") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language" selected>Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "addonsmenu") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu" selected>Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "top10") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10" selected>Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "poll") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll" selected>Poll</option><option value="information">Information</option>
			<option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "information") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information" selected>Information</option>
			<option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "0") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0" selected>0</option>
			<option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "1") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option>
			<option value="1" selected>1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "2") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option>
			<option value="1">1</option><option value="2" selected>2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "3") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option>
			<option value="1">1</option><option value="2">2</option><option value="3" selected>3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "4") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option>
			<option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4" selected>4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "5") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option>
			<option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5" selected>5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "6") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option>
			<option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6" selected>6</option>
			<option value="7">7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "7") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option>
			<option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7" selected>7</option><option value="8">8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "8") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option>
			<option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8" selected>8</option><option value="9">9</option></option></td></tr>~;
		}
		if($fieldside[$i] eq "9") { $blocklisting .= qq~
			<option value="off">Off</option><option value="mainmenu">Main Menu</option><option value="search">Search</option>
			<option value="userpanel">User Panel</option><option value="userstatus">User Status</option><option value="addonsleft">Addons Left</option>
			<option value="addonsright">Addons Right</option><option value="language">Language</option><option value="addonsmenu">Addons Menu</option>
			<option value="top10">Top 10</option><option value="poll">Poll</option><option value="information">Information</option>
			<option value="0">0</option>
			<option value="1">1</option><option value="2">2</option><option value="3">3</option>
			<option value="4">4</option><option value="5">5</option><option value="6">6</option>
			<option value="7">7</option><option value="8">8</option><option value="9" selected>9</option></option></td></tr>~;
		}

		$i++
	}
	print qq~$blocklisting<tr><td><input type="hidden" name="blockside" value="$info{'blockside'}"></td></tr></table><center><input type=submit value="Change"></center></form>~;
	print_bottom();
}

######################
sub edit_block_list1 {
######################
	require "$sourcedir/security.pl";
	check_user_permission();
	check_hash($input{'blockside'});

	if($input{'newblockstat0'} eq "") { $input{'newblockstat0'} = "off"; }
	if($input{'newblockstat1'} eq "") { $input{'newblockstat1'} = "off"; }
	if($input{'newblockstat2'} eq "") { $input{'newblockstat2'} = "off"; }
	if($input{'newblockstat3'} eq "") { $input{'newblockstat3'} = "off"; }
	if($input{'newblockstat4'} eq "") { $input{'newblockstat4'} = "off"; }
	if($input{'newblockstat5'} eq "") { $input{'newblockstat5'} = "off"; }
	if($input{'newblockstat6'} eq "") { $input{'newblockstat6'} = "off"; }
	if($input{'newblockstat7'} eq "") { $input{'newblockstat7'} = "off"; }
	if($input{'newblockstat8'} eq "") { $input{'newblockstat8'} = "off"; }
	if($input{'newblockstat9'} eq "") { $input{'newblockstat9'} = "off"; }
	

	open(FILE, ">$datadir/blocks/$input{'blockside'}.dat");
	lock(FILE);
	print FILE "$input{'newblockstat0'}|$input{'newblockstat1'}|$input{'newblockstat2'}|$input{'newblockstat3'}|$input{'newblockstat4'}|$input{'newblockstat5'}|$input{'newblockstat6'}|$input{'newblockstat7'}|$input{'newblockstat8'}|$input{'newblockstat9'}|off\n";
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin&op=blockadmin&command=editlist&blockside=$input{'blockside'}\n\n";
}

####################
sub edit_block_id {
####################
	
	open(FILE, "$datadir/blocks/id/$info{'blockid'}.txt");
	@idcont = <FILE>;
	close(FILE);

	@cur_idcont = split(/\|/, $idcont[0]);

	$navbar = "$admin{'btn2'} Administration $admin{'btn2'} Block ID";
	print_top();
	check_user_permission();
	print qq~<center><big>Block ID $info{'blockid'} Administration</big></center><p>
		<form action="$pageurl/$admin&op=blockadmin&command=editid1" method="post">
		<table align=center><tr><td>Block Title : <input type=text name=idtitle value="$cur_idcont[0]"><p>
		Block Type : <select name="idtype">~;
	if($cur_idcont[1] eq "standard") { print qq~<option value="standard" selected>Standard</option><option value="pee">PEE</option><option value="ssi">SSI</option></select><br>~; }
	elsif($cur_idcont[1] eq "pee") { print qq~<option value="standard">Standard</option><option value="pee" selected>PEE</option><option value="ssi">SSI</option></select><br>~; }
	else { print qq~<option value="standard">Standard</option><option value="pee" selected>PEE</option><option value="ssi" selected>SSI</option></select><br>~; }
	print qq~Block Content : <br> <textarea name="idcontent" cols=40 rows=10>$cur_idcont[2]</textarea><p><input type="hidden" name="blockid" value="$info{'blockid'}"><input type=submit value="Change"></td></tr></table></form>~;
	print_bottom();
}

####################
sub edit_block_id1 {
####################
	check_user_permission();

	open(FILE, ">$datadir/blocks/id/$input{'blockid'}.txt");
	lock(FILE);
	print FILE "$input{'idtitle'}|$input{'idtype'}|$input{'idcontent'}\n";
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin&op=blockadmin&command=editid&blockid=$input{'blockid'}\n\n";
}

############################
sub display_block_id_list {
############################
	check_user_permission();

	$navbar ="$admin{'btn2'} Administration $admin{'btn2'} Block List";
	print_top();
	print qq~<center><big>Block List</big></center><p><table align=center border=1 bordercolor="#57A6CC"><tr bgcolor="#C6E7F7"><td bgcolor="#C6E7F7">Action</td><td bgcolor="#C6E7F7">ID</td><td bgcolor="#C6E7F7">Block Title</td><td>Block Type</td></tr>~;

	$i = 0;
	while ($i < 10) {
		open(FILE, "$datadir/blocks/id/$i.txt");
		@bid_content = <FILE>;
		close(FILE);

		@cur_bid_content = split(/\|/, $bid_content[0]);
		
		$combine_list .= qq~<tr><td><a href="$pageurl/$admin&op=blockadmin&command=editid&blockid=$i">Edit</a></td><td>$i</td><td>$cur_bid_content[0]</td><td>$cur_bid_content[1]</td></tr>~;
		$i++;
	}
	print qq~$combine_list</table>~;
	print_bottom();
}

########################
sub check_block_param {
########################

	if($info{'command'} eq "editlist") { edit_block_list(); }
	elsif($info{'command'} eq "editlist1") { edit_block_list1(); }

	elsif($info{'command'} eq "editid") { edit_block_id(); }
	elsif($info{'command'} eq "editid1") { edit_block_id1(); }

	elsif($info{'command'} eq "displaylist") { display_block_id_list(); }
	else { display_block_id_list(); }

}
1;


