

#################
sub addons_menu{
#################

	opendir(DIR, "$scriptdir/addons");
	@contents = readdir(DIR);
	closedir(DIR);

     	FILE: foreach $line (sort @contents) {

        next FILE if  ($line eq '.');
        next FILE if ($line eq '..');
        next FILE if ($line eq '.htaccess');

		($name, $extension) = split (/\./, $line);
		if (!open(ADDON, "$scriptdir/addons/$name/index.cgi")) { next FILE; }
		else {
			close(ADDON);
			$name_space = $name;
			$name_space =~ s/ /%20/g; 
			$daftar .= qq~<li> <a href=\"$pageurl/addons/$name_space/index.cgi\">$name</a><br>\n~;
		}
	}
	print qq~$top_block_separator~;
	boxheader(150, "$addon{'001'}", "#737b9c", "");
print qq~<tr><td><b><ul>$daftar</ul></b></td></tr>~;
	boxfooter();
	print qq~$bottom_block_separator~;
	print "$block_separator";

}

###################
sub addons_blockl {
###################

	opendir(DIR, "$scriptdir/addons");
	@contents = readdir(DIR);
	closedir(DIR);

     	FILEBL: foreach $lineb (sort @contents) {

        next FILEBL if  ($lineb eq '.');
        next FILEBL if ($lineb eq '..');
        next FILEBL if ($lineb eq '.htaccess');

		($namebl, $extensionb) = split (/\./, $lineb);
		if (!open(ADDON, "$scriptdir/addons/$namebl/block/blockl.pl")) { next FILEBL; }
		else {
			close (ADDON);

			print qq~$top_block_separator~;			
			boxheader(150, "$namebl", "#737b9c", "");
			require "$scriptdir/addons/$namebl/block/blockl.pl";
			blockleft();
			boxfooter();
			print "$bottom_block_separator";
			print "$block_separator";
		}
	}
}

###################
sub addons_blockr {
###################

	opendir(DIR, "$scriptdir/addons");
	@contents = readdir(DIR);
	closedir(DIR);

     	FILEBR: foreach $linebr (sort @contents) {

        next FILEBR if  ($linebr eq '.');
        next FILEBR if ($linebr eq '..');
        next FILEBR if ($linebr eq '.htaccess');

		($namebr, $extensionb) = split (/\./, $linebr);
		if (!open(ADDON, "$scriptdir/addons/$namebr/block/blockr.pl")) { next FILEBR; }
		else {
			close (ADDON);

			print qq~$top_block_separator~;
			boxheader(150, "$namebr", "#737b9c", "");
			require "$scriptdir/addons/$namebr/block/blockr.pl";
			blockright();
			boxfooter();
			print "$bottom_block_separator";
			print "$block_separator";
		}
	}
}

##################
sub addons_admin {
##################

	opendir(DIR, "$scriptdir/addons");
	@contents = readdir(DIR);
	closedir(DIR);

	FILE1: foreach $line (sort @contents) {

        next FILE1 if  ($line eq '.');
        next FILE1 if ($line eq '..');

		($name, $extension) = split (/\./, $line);
		if (!open(ADDON, "$scriptdir/addons/$name/admin/index.cgi")) { next FILE1; }
		else {
			close(ADDON);
			$name_space = $name;
			$name_space =~ s/ /%20/g;
			$daftarad .= qq~ <a href=\"$pageurl/addons/$name_space/admin/index.cgi\">$name</a><br>\n~;
		}
	}

print qq~<b>$daftarad</b>~;

}

########################
sub addons_main_admin {
########################
check_user_permission();
if ($info{'nameaddon'} ne "") {
	open(FILEAD, ">$scriptdir/addons/$info{'nameaddon'}/block/block.dat");
	lock(FILEAD);
	print FILEAD "$info{'poaddon'}|$info{'addonname'}\n";
	unlock(FILEAD);
	close(FILEAD);

	$change_status = "Addon $info{'nameaddon'} has been change! <br>";
}
else { $change_status = " <br>"; }

$navbar ="$admin{'btn2'} Addons $admin{'btn2'} Main Admin";
print_top();

	opendir(DIR, "$scriptdir/addons");
	@contents = readdir(DIR);
	closedir(DIR);

     	FILEBR: foreach $lineb (sort @contents) {

	        next FILEBR if  ($lineb eq '.');
	        next FILEBR if ($lineb eq '..');
	        next FILEBR if ($lineb eq '.htaccess');

		if (!open(ADDON, "$scriptdir/addons/$lineb/block/block.dat")) { next FILEBR; }
		else {
			@bufferaddon=<ADDON>;
			close (ADDON);

			($posaddon, $nameaddon) = split("/\|/",$bufferaddon);
			if ($posaddon eq "left") {
				$option1 = "<option value=\"left\" SELECTED>Left</option><option value=\"right\">Right</option>";
			}
			else {
				$option1 = "<option value=\"left\">Left</option><option value=\"right\" SELECTED>Right</option>";
			}
			$list_addons_change .= qq~$nameba :<form action=\"$pageurl/$cgi\?action=editaddons\">
						<input type=\"hidden\" name=\"nameaddon\" value=\"$lineb\">
						<select name=\"posaddon\">$option1</select> 
						<input name=\"addonname\" value=\"$nameaddon\"><input type=\"submit\" value=\"Change\"></form><br>~;
		}
	}

check_user_permission();
print qq~<center><b><big>Alien Addons Administration</big></b></center><br><p>
$change_status $list_addons_change~;
print_bottom();

}

1;
