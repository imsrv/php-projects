###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                       #
#-----------------------------------------------------------------------------#
# faqs.pl - this code of portal FAQ'ing system                                #
#                                                                             #
# Copyright (C) 2002 by XpyDi (XpyDi@ItsMyLife.ru)                            #
# Modified by Luck (perl_oas@yahoo.com)
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: faqs.pl, Last modified: 19:06 08/06/2002                              #
###############################################################################
###############################################################################

###############
sub fcatadmin {
###############
	open(FILE, "$faqsdir/cats.dat");
	chomp(@cats = <FILE>);
	close(FILE);

	$navbar = "$admin{'btn2'} $nav{'024'} $admin{'btn2'} $admin{'faq_admin'}";
	print_top();
	check_user_permission();
	print "<table>";
	foreach $line (@cats) {
		@item = split(/\|/, $line);
		print qq~<form action="$admin&amp;op=fcatadmin2" method="post">
<tr><td valign="top">
<table>
<td>$admin{'057'} :</td>
<td><input type="text" name="desc" value="$item[0]"></td>
</tr>
<tr>
<td>$admin{'081'} :</td>
<td><input type="text" name="cat" value="$item[1]"></td>
</tr>
</table>
</td>
<td valign="top"><input type="hidden" name="oldcat" value="$item[1]"><input type="submit" name="moda" value="$btn{'015'}"><br>
<input type="submit" name="moda" value="$btn{'016'}"><br>
</tr>
</form>~;

	}
	print qq~<form action="$pageurl/$admin&amp;op=fcatadmin2" method="post">
<tr>
<td colspan="2"><hr size="1">
<b>$admin{'087'}</b></td>
</tr>
<tr>
<td>$admin{'057'} :</td>
<td><input type="text" name="desc"></td>
</tr>
<tr>
<td>$admin{'081'} :</td>
<td><input type="text" name="cat"></td>
</tr>
<tr>
<td colspan="2"><input type="submit" name="moda" value="$admin{'044'}"></td>
</tr>
</form>
</table>~;

	print_bottom();
	exit;
};

################
sub fcatadmin2 {
################
	check_user_permission();

	open(FILE, "$faqsdir/cats.dat") || error("$err{'001'} $faqsdir/cats.dat");
	@cats = <FILE>;
	close(FILE);

	if ($input{'moda'} eq $btn{'015'}) {
		chomp($input{'oldcat'});

		open(FILE, ">$faqsdir/cats.dat") || error("$err{'016'} $faqsdir/cats.dat");
		lock(FILE);
		foreach $line (@cats) {
			chomp($line);
			($name, $link) = split(/\|/, $line);
			if ($input{'oldcat'} eq $link) { print FILE "$input{'desc'}|$input{'cat'}\n"; }
			else { print FILE "$line\n"; }
		}
		unlock(FILE);
		close(FILE);

#		open(FILE, "$faqsdir/$input{'oldcat'}.cat");
#		chomp(@topics = <FILE>);
#		close(FILE);

#		open(FILE, ">$faqsdir/$input{'cat'}.cat");
#		lock(FILE);
#		foreach $line (@topics) {
#			print FILE "$line\n";
#		}
#		unlock(FILE);
#		close(FILE);

		rename "$faqsdir/$input{'oldcat'}.cat", "$faqsdir/$input{'cat'}.cat"

#		unlink("$faqsdir/$input{'oldcat'}.cat");
	}
	if ($input{'moda'} eq $btn{'016'}) {
		open(FILE, "$faqsdir/$input{'cat'}.cat");
		@data = <FILE>;
		close(FILE);

		if (@data != 0) { error("$err{'025'}"); }
		chomp($input{'cat'});

		open(FILE, ">$faqsdir/cats.dat") || error("$err{'016'} $faqsdir/cats.dat");
		lock(FILE);
		foreach $line (@cats) {
			chomp($line);
			($name, $link) = split(/\|/, $line);
			if ($input{'cat'} eq $link) { }
			else { print FILE "$line\n"; }
		}
		unlock(FILE);
		close(FILE);

		unlink("$faqsdir/$input{'cat'}.cat");
	}
	if ($input{'moda'} eq $admin{'044'}) {
		open(FILE, ">>$faqsdir/cats.dat") || error("$err{'016'} $faqsdir/cats.dat");
		print FILE "$input{'desc'}|$input{'cat'}\n";
		close(FILE);

		open(FILE, ">$faqsdir/$input{'cat'}.cat");
		close(FILE);
	}

	print "Location: $pageurl/$admin&op=fcatadmin\n\n";
	exit;
};

##############
sub editfaqs {
##############
	check_user_permission();
	open(FILE, "$faqsdir/cats.dat") || error("$err{'001'} $faqsdir/cats.dat");
	@efaqcats = <FILE>;
	close(FILE);

	$navbar = "$admin{'btn2'} $admin{'faq_admin'} $admin{'btn2'} $admin{'edit_faq_cat'}";

	print_top();
	print qq~<table>
<tr>
<td valign="top">$admin{'choose_faq_item'} : </td>
<td valign="top"><form action="$cgi?action=admin&amp;op=editfaqs" method="post">
<select name="cat">
~;
	foreach $category (@efaqcats) {
		chomp($category);
		($name, $efaqs) = split(/\|/, $category);
#		chomp($efaqs);
		if ($info{'cat'} eq $efaqs) { 
			print qq~<option value="$efaqs" selected>$name</option>~; 
			$catname = $name;
		}
		else { print qq~<option value="$efaqs">$name</option>~; }
	}
	print qq~</select>
<input type="submit" value="$btn{'014'}">
</form></td>
</tr>
</table><br>
~;
	if ($input{'cat'} ne "") {
	open(FILE, "$faqsdir/$input{'cat'}.cat");
	chomp(@fq = <FILE>);
	close(FILE);

	print qq~<table width=100% border='1'>
		<td bgcolor="$windowbg"><b>ID</b></td>
		<td bgcolor="$windowbg"><b>$admin{'question'}</b></td>
		<td bgcolor="$windowbg"><b>$admin{'answer'}</b></td>
		<td bgcolor="$windowbg"><b>$admin{'053'}</b></td>~;
	foreach $line (@fq) {
		@item = split(/\|/, $line);
		print qq~
<tr><td>$item[0]</td><td>$item[1]</td><td>$item[2]</td>
<td><a href="$admin&amp;op=addfaqs&amp;cat=$input{'cat'}&amp;id=$item[0]">$admin{'069'}</a>
<a href="$admin&amp;op=delfaqs&amp;cat=$input{'cat'}&amp;id=$item[0]">$admin{'070'}</a></td>
</tr>~;
	}
	print "</table>";
	print qq~<a href="$admin&amp;op=addfaqs&amp;cat=$input{'cat'}&amp;id=last">$admin{'058'}</a>~;
	}
	print_bottom();
	exit;
};

#############
sub addfaqs {
#############
	check_user_permission();
	$navbar = "$admin{'btn2'} FAQ $admin{'btn2'} $admin{'add_question'}";
	print_top();

	if ($info{'id'} ne "last") {
		open(FILE, "$faqsdir/$info{'cat'}.cat");
		@qan = <FILE>;
		close(FILE);

		foreach $line(@qan){
			@it = split(/\|/, $line);
			if ($it[0] eq $info{'id'}) {@ln=@it};
		}
	}



	$ln[1]=~ s/<br>/\n/g;
	$ln[2]=~ s/<br>/\n/g;

	print qq~
<form action="$pageurl/$admin&op=addfaqs2&cat=$info{'cat'}" Method="POST">
<input type="hidden" name="id" value="$info{'id'}">
$admin{'question'}:<br>
<TEXTAREA NAME="questen" rows=15 wrap=virtual style="font-family: Arial; font-size: 8pt; width: 404; height: 60" cols="20">
$ln[1]</TEXTAREA><br>
$admin{'answer'}:<br>
<TEXTAREA NAME="answer" rows=15 wrap=virtual style="font-family: Arial; font-size: 8pt; width: 404; height: 307" cols="20">
$ln[2]</TEXTAREA><br><input type="submit" value="~;
	if ($info{'id'} ne "last") {
	print "$admin{'054'}"
	} else {print "$admin{'058'}"};
print qq~"></form>~;
	print_bottom();
	exit;
};

##############
sub addfaqs2 {
##############
	check_user_permission();
	open(FILE, "$faqsdir/$info{'cat'}.cat");
	chomp(@qan = <FILE>);
	close(FILE);

	$input{'questen'}=~ s/\n/<br>/g;
	$input{'questen'}=~ s/\r//g;    
	$input{'questen'}=~ s/\|/&brvbar/g;
	$input{'answer'}=~ s/\n/<br>/g;
	$input{'answer'}=~ s/\r//g;
	$input{'answer'}=~ s/\