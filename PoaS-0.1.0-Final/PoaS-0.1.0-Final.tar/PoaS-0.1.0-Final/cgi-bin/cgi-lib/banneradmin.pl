####################
sub verify_ads_db {
####################

	open(FILE, "$datadir/banners/data.txt");
	@adsbuf = <FILE>;
	close(FILE);

	@totads = split(/\|/, $adsbuf[0]);

	if(@totads eq 4) { $ads_stat_db = 1; } 
	elsif(@totads eq 3) { $ads_stat_db = 2; }
	else { $ads_stat_db = 3;  $recordedad = @totads; }

	$a = 0;
	while ($adsbuf[$a] ne '') { $a++; }
	$count = $a;
	$i = 0;

	if($ads_stat_db eq 3) { error("WARNING!! Your banner database are most probably corrupted detected $recordedad - $adsbuf[0], you must edit this manualy."); }
	if($ads_stat_db eq 2) {
		open(FILE, ">$datadir/banners/data.txt");
		lock(FILE);
		while ($i < $count) {
			@db_cont = split(/\|/, $adsbuf[$i]);
			print FILE "$i|$db_cont[0]|$db_cont[1]|$db_cont[2]\n";
			$i++;
		}
		unlock(FILE);
		close(FILE);
	}
}

#######################
sub display_ads_list {
#######################

	#verify_ads_db();
	open(FILE, "$datadir/banners/data.txt");
	@adsbuf = <FILE>;
	close(FILE);

	$navbar = "$admin{'btn2'} Administration $admin{'btn2'} Banner";
	print_top();
	check_user_permission();
	print qq~<center>Banner List</center><p><font face='Arial' size='2'><b><i>$banner{'011'}</i></b><table width='100%' border='1'>
		<tr><td bgcolor='#F2C973'><font size='2'>$banner{'012'}</font></td><td bgcolor='#F2C973'><font size='2'>$banner{'004'}</font></td><td bgcolor='#F2C973'><font size='2'>$banner{'003'}</font></td><td bgcolor='#F2C973'><font size='2'>$banner{'007'}</font></td></tr>
		~;
	foreach $recads (@adsbuf){
		chomp($recads);
		($numbansnow,$ibannow,$banurlnow,$altnow)=split(/\|/,$recads);
		print qq~<tr><td><font size="2">
			<a href="$pageurl/$admin&op=banneradmin&command=edit&adsid=$numbansnow">$banner{'013'}</a> - <a href="$pageurl/$admin&op=banneradmin&command=deleteads&num=$numbansnow">$banner{'014'}</a></font></td><td><font size="2">$ibannow</font></td><td><font size="2">$banurlnow</font></td><td><font size="2">$altnow</font></td></tr>\n
			~;
	}
	print qq~</table><p><a href="$pageurl/$admin&op=banneradmin&command=add">$banner{'002'}</a></p></font>~;
	print_bottom();
}

###################
sub a_ads_delete {
###################

	check_user_permission();
	open(FILE, "$datadir/banners/data.txt");
	@adsbuf = <FILE>;
	close(FILE);

	open(FILE, ">$datadir/banners/data.txt");
	lock(FILE);
	foreach $recads (@adsbuf){
		chomp($recads);
		($idads,$imgads,$urlads,$altads) = split(/\|/,$recads);
		if($idads ne $info{'num'}) {
			print FILE "$idads|$imgads|$urlads|$altads\n";
		}
		else {;}
	}
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin&op=banneradmin&command=view\n\n";
}

################
sub a_ads_add {
################

	$navbar = "$admin{'btn2'} $nav{'061'}";
	print_top();
	check_user_permission();

	print qq~
		<font face='Arial'><b><i>$banner{'002'}</i></b>
		<form action="$pageurl/$admin&op=banneradmin&command=add1" method='POST'>
		<table border='1'>
		<tr><td><font size='2'>$banner{'004'}</font></td><td><input type='text' name='adsimg'></td></tr>
		<tr><td><font size='2'>$banner{'003'}</font></td><td><input type='text' name='adsurl'></td></tr>
		<tr><td><font size='2'>$banner{'007'}</font></td><td><input type='text' name='adsalt'></td></tr>
		</table>
		<input type='Submit' value='$banner{'002'}'>
		</form>
		</font>
		</font>
		~;

	print_bottom();
}

##################
sub a_ads_add1 {
##################

	check_user_permission();
	open(FILE, "$datadir/banners/data.txt");
	@adsbuf = <FILE>;
	close(FILE);

	$idads = @adsbuf + 1;

	open(FILE, ">>$datadir/banners/data.txt");
	lock(FILE);
	print FILE "$idads|$input{'adsimg'}|$input{'adsurl'}|$input{'adsalt'}\n";
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin&op=banneradmin&command=view\n\n";
}

#################
sub a_ads_edit {
#################

	check_user_permission();
	verify_ads_db();
	open(FILE, "$datadir/banners/data.txt");
	@adsbuf = <FILE>;
	close(FILE);

	foreach $recads (@adsbuf){
		chomp($recads);
		($idads,$imgads,$urlads,$altads) = split(/\|/,$recads);
		if($idads eq $info{'adsid'}) { $dimgads = $imgads; $durlads = $urlads; $daltads = $altads; }
	}

	$navbar = "$admin{'btn2'} Administration $admin{'btn2'} Banner Edit";
	print_top();
	print qq~<font face='Arial'><b><i>$banner{'010'}</i></b>
		<form action="$pageurl/$admin&op=banneradmin&command=edit1" method='POST'>
		<table border='1'>
		<input type="hidden" name="adsid" value="$info{'adsid'}">
		<tr><td><font size='2'>$banner{'004'}</font></td><td><input type='text' name='adsimg' value="$dimgads"></td></tr>
		<tr><td><font size='2'>$banner{'003'}</font></td><td><input type='text' name='adsurl' value="$durlads"></td></tr>
		<tr><td><font size='2'>$banner{'007'}</font></td><td><input type='text' name='adsalt' value="$daltads"></td></tr>
		</table>
		<input type='Submit' value='$banner{'010'}'>
		</form>
		</font>
		</font>
	~;
	print_bottom();

}

##################
sub a_ads_edit1 {
##################

	check_user_permission();
	verify_ads_db();
	open(FILE, "$datadir/banners/data.txt");
	@adsbuf = <FILE>;
	close(FILE);

	open(FILE, ">$datadir/banners/data.txt");
	lock(FILE);
	foreach $recads (@adsbuf){
		chomp($recads);
		($idads,$imgads,$urlads,$altads) = split(/\|/,$recads);
		if($idads eq $input{'adsid'}) {
			print FILE "$idads|$input{'adsimg'}|$input{'adsurl'}|$input{'adsalt'}\n";
		}
		else { print FILE "$idads|$imgads|$urlads|$altads\n"; }
	}
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin&op=banneradmin&command=view\n\n";
}


#################
sub a_pads_edit {
#################

	check_user_permission();
	open(FILE, "$datadir/banners/setting.dat");
	@adsbuf = <FILE>;
	close(FILE);

	($posads1,$statads1) = split(/\|/,$adsbuf[0]);
	($posads2,$statads2) = split(/\|/,$adsbuf[1]);

	$navbar = "$admin{'btn2'} Administration $admin{'btn2'} Banner Edit";
	print_top();
	print qq~<font face='Arial'><b><i>$banner{'010'}</i></b>
		<form action="$pageurl/$admin&op=banneradmin&command=pedit1" method='POST'>
		<table border='1'>
		<tr><td><font size='2'>Top Banner</font></td><td><option name="topads">~;
	if($statads1 eq 1) { print qq~<select value=1 selected>On</select><select value=0>Off</select>~; }
	else { print qq~<select value=1>On</select><select value=0 selected>Off</select>~; }
	print qq~
		</option>
		</td></tr>
		<tr><td><font size='2'>Bottom Banner</font></td><td><option name="bottomads">~;
	if($statads2 eq 1) { print qq~<select value=1 selected>On</select><select value=0>Off</select>~; }
	else { print qq~<select value=1>On</select><select value=0 selected>Off</select>~; }
	print qq~
		</option</td></tr>
		</table>
		<input type='Submit' value='$banner{'010'}'>
		</form>
		</font>
		</font>
	~;
	print_bottom();

}

##################
sub a_pads_edit1 {
##################

	check_user_permission();
	open(FILE, ">$datadir/banners/setting.dat");
	lock(FILE);
	print FILE "Top|$input{'topads'}\n";
	print FILE "Bottom|$input{'bottomads'}\n";
	unlock(FILE);
	close(FILE);

	print "Location: $pageurl/$admin&op=banneradmin&command=pedit\n\n";
}

#########################
sub check_banner_param {
#########################

	check_user_permission();
	if ($info{'command'} eq "view") { display_ads_list(); }
	elsif ($info{'command'} eq "deleteads") { a_ads_delete(); }
	elsif ($info{'command'} eq "add") { a_ads_add(); }
	elsif ($info{'command'} eq "add1") { a_ads_add1(); }
	elsif ($info{'command'} eq "edit") { a_ads_edit(); }
	elsif ($info{'command'} eq "edit1") { a_ads_edit1(); }

	elsif ($info{'command'} eq "pedit") { a_pads_edit(); }
	elsif ($info{'command'} eq "pedit1") { a_pads_edit1(); }
	else { print "Location: $pageurl/$admin&op=siteadmin\n\n"; }
}
1;

