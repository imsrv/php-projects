##################
sub mailcenter {
##################

	if ($info{'send'} eq "start") { &mailsend(); }
	if ($info{'check'} eq "start") { &mailopen(); }

	&mailawal();
}

###############
sub mailawal {
###############

	print_top();
	print qq~
<center>
<h1>Welcome to $pagename Mail Center</h1>
</center>
<hr>
<center>
<form action="$pageurl/$cgi" method="GET">
<table>
<tr>
	<td valign="top">POPmail username:</td>
	<td>
	<input type="hidden" name="action" value="mailcenter">
	<input type="hidden" name="check" value="start">
	<input type="Text" name="username" size="25"> <br>
	</td>
	<input type="hidden" name="start" value="1">
	<input type="hidden" name="end" value="0">
</tr>
<tr>
	<td valign="top">POPmail server:</td>
	<td><input type="Text" name="server" size="25"> <br></td>
</tr>
<tr>
	<td valign="top">Password:</td>
	<td><input type="password" name="pass" size="25"> <br></td>
</tr>
</table>

<input type="Submit" name="popsub" value="Check Mail">
<input type="Reset" value="Clear Fields">
</form>
<center>
~;

	print_bottom();
	exit();

}

###############
sub mailopen {
###############

use Mail::POP3Client;	
require "$scriptdir/perlmodule/cgi-lib.pl";


#------- Variable for your website's url -------# 
$homeurl = "$pageurl/$cgi\?action=mailcenter";	
$simplePOPurl = "$pageurl/$cgi\?action=mailcenter";
$simpleSENDurl = "$pageurl/$cgi\?action=mailcenter\&send=start";												

#--------- assign form variables to local variables --------#
$Name=$info{'mcusername'};
$Pass=$info{'mcpass'};
$Serv=$info{'mcserver'};
$Num=$info{'mcNum'};
$Perform=$info{'mcstatus'};
$start=$info{'start'};
$end=$info{'end'};
$auth_mode="BEST";

#--------- Establish connection ---------#
&Connection;

#--------- Check for correct username and password ---------#
if ($thestate eq "AUTHORIZATION") {
	$navbar = "$admin{'btn2'} Mail Center $admin{'btn2'} Failed";
	print_top();
	print "<title>POPservices: Invalid username or password</title>\n";
	print "<center>";
	print "<h1>Please verify that you are using the correct username and password</h1>"; 
	print "<br><br>";
	print "<a href=\"http://$homeurl\">Return to homepage</a>";
	print "</center>";
	print_bottom();
	exit();
}

#--------- Check to see if valid pop3 server ---------#
elsif ($thestate eq "DEAD") 
{
	$navbar = "$admin{'btn2'} Mail Center $admin{'btn2'} Failed";
	print_top();	
	print "<title>POPservices: Invalid server - $Serv</title>";
    	print "<center>";
    	print "<h1>The server you entered is invalid. Try again</h1>\n";
    	print "<a href=\"http://$homeurl\">Return to homepage</a>";
    	print "</center>";
	print_bottom();
	exit();
}

#-------- Alert users of no messages if there arent any -------#
if ($count == 0)
{  &NoMessages; }

#------------ Check status to see what to do with form data  ------------#					
if ($Perform eq "Read")					# User just clicked on read message 
	{ 
		&CleanHead; 
		&ReadMsg;  
	}
elsif ($Perform eq "Delete") 			# Delete message
	{ &DeleteMsg; }	 	 			 
elsif ($Perform eq "Reply") 			# Reply to email
	{ 
		&CleanHead; 
		&Reply; 
	} 					
else									# Display the inbox of messages
	{ 
		&GetHeaders; 
		&Display; 
	}	

#------- SUBROUTINE FOR READING A MESSAGE ------#
sub ReadMsg
{ 		
	$c = $Num;				# message number
	print "<center><h2>Message # $Num</h2></center>";
  	&Buttons;				# Back,Reply,Delete buttons
	print "<hr>";
	
#------ PRINT ACTUAL HEADER OF MESSAGE ---------#	
	foreach $a (@reply) 
	{
		print "$a<br>";
	}

#------ PRINT ACTUAL EMAIL MESSAGE -------------#
	$body = $Client->Body($Num);		# Get body of email message
    @mailbody = split (/\r/, $body);	# Split each line into array
    foreach $mail (@mailbody)			# Now print each line
	{  print "$mail<br>"; 	}	
	print "<hr>";			
	print "<center><h2>Message # $Num</h2></center>";
	&Buttons;
}	

#---------- SUBROUTINE FOR DELETING MESSAGES ----------#
sub DeleteMsg
{
	$Client->Delete($Num);	# Get right one to delete
	$Client->Close;			# It's officially deleted
	sleep(1);				# Rest stop
	&Connection;			# Restablish connection to popserver
							# Since we lose it after recalling
							# This script
	&GetHeaders;			# Go get all headers
	&Display;				# Display Subject,From,To for user
}#-------------- END OF DELETING MESSAGE --------------#

#--------- SUBROUTINE FOR REPLYING TO MESSAGES --------#
sub Reply 
{
 	$replyto = $from;
	$replyfrom = $to;
	$replyfrom =~ s/ //;
	chomp($replyfrom);
	chop($subject);
	chop($to);
	print "<table><tr><td>\n";
	
	print "<FORM METHOD=POST ACTION=\"$simpleSENDurl\">\n";
	print "To:<input type='text' name='replyto' value=\"$replyto\" size='65'>\n<br>";
	print "Subject:<input type='text' name='resubject' value=\"Re: $subject\" size='65'>\n<br>";
	$body = $Client->Body($Num);
	print "<BR><B>Reply:</B><br>\n";
	print "<textarea name='rebody' rows='15' cols='70' wrap='soft'>\n";
	print "$body\n";
	print "</textarea><BR><BR>\n";
	print "</td></tr></table>\n";
	print "<table><tr><td>\n";

	#--------- Send email button ---------#
	print "<input type='submit' name='Send' value='Send'>\n";
	print "<input type='hidden' name='username' value=\"$Name\">\n";
 	print "<input type='hidden' name='pass' value=\"$Pass\">\n";
 	print "<input type='hidden' name='server' value=\"$Serv\">\n";
	print "<input type='hidden' name='Num' value=\"$Num\">\n";
	print "<input type='hidden' name='status' value=\"Reply\">\n";
	print "<input type='hidden' name='replyfrom' value=\"$replyfrom\">\n";
	print "<input type='hidden' name='replyto' value=\"$replyto\">\n";
	print "<input type='hidden' name='start' value=\"$start\">\n";
	print "</form>\n";
	print "</td><td>\n";
	
	#--------- Back button ---------#
	print "<form action=\"$simplePOPurl\" method='POST'>\n";
    print "<input type='submit' name='Display' value='Back'>\n";
    print "<input type='hidden' name='username' value=\"$Name\">\n";
    print "<input type='hidden' name='pass' value=\"$Pass\">\n";
    print "<input type='hidden' name='server' value=\"$Serv\">\n";
    print "<input type='hidden' name='Num' value=\"$Num\">\n";
    print "<input type='hidden' name='status' value='Display'>\n";
    print "<input type='hidden' name='start' value=\"$start\">\n";
    print "</form></td></tr></table>\n";
}

#---------- SUBROUTINE FOR GETTING HEADERS ----------#
sub GetHeaders 
{
	$i=$start;
	$x=1;
	while (($x<11) and ($i<=$count)) 
	{
		$Headers[$i]=$Client->Head($i); 		# get header one-by-one
		@Headlist = split(/\n/, $Headers[$i]); 	# split all its information up
					   
		foreach $Line (@Headlist) 
		{
  			if($Line =~ /^Subject:/)    	# check for Subject line
				{ $sub[$i]=$';};
  			if($Line =~ /^From:/)			# check for From line
				{ $from[$i]=$'; }
  			if($Line =~ /^Date:/) 	   		# check for Date line
				{ $date[$i]=$';};	
			if($Line =~ /^To:/)				# check for To line
				{ $to[$i]=$';};
		}
		$x++;
		$i++;
	}
}#--------- END GetHeaders ---------#

#------ SUBROUTINE FOR DISPLAYING MESSAGES ----------#
sub Display 
{
	$s=$start;

	#------------ LAY DOWN THE JAVASCRIPT ---------------#
	$navbar = "$admin{'btn2'} Mail Center";
	print_top();
	print "<script language=\"JavaScript\">\n";
	print "function closeThisWindow()\n";
	print " {\n";
	print "window.close()\n";
	print " }\n";
	print "</script>\n";

	#------- PRINT FROM, SUBJECT, DATE, SIZE, HEADINGS ------#
	print "<center><h3>You have a total of $count messages</h3>\n";
	print "<a href=\"$homeurl\">Return to home</a>\n";
	print "<table border=1><tr>\n";
	print "<td><b>From</b></td>\n";
	print "<td><b>Subject</b></td>\n";
	print "<td><b>Date</b></td>\n";
	print "<td><b>Size</b></td></tr>\n";
	
	$c = $start; 
	$x=1;
	while (($x <11) and ($c<=$count)) 
	{
		print "<tr><td>$from[$c]</td>\n";	#Where is the message from
		print "<td>$sub[$c]<br>\n";			#What isthis message's subject
		&Buttons;
		print "<center><b>Message #$c</b></center>\n";
		print "<td>$date[$c]</td>\n";		# When was thismessage sent
		if ($sizedisplay[$c] > 1023) 
			{ $messagesize=$sizedisplay[$c] / 1024; 
			  print "<td>";
			  printf ("%.1f", $messagesize);
			  print "K</td>\n";
			}
		else { print "<td>1K</td>"; }
		
		print "</tr>";
		$c++; 			# increment counter
		$x++;
	}

	$end=$c;

	print "</table>\n";
	print "<table><tr><td>\n";
	
	#------- Check Mail button -------#
	print "<FORM METHOD=POST ACTION=\"$simplePOPurl\">\n";
	print "<input type='submit' value='Check mail'>\n";
	print "<input type='hidden' name='username' value=\"$Name\">\n";
	print "<input type='hidden' name='pass' value=\"$Pass\">\n";
	print "<input type='hidden' name='server' value=\"$Serv\">\n";
	print "<input type='hidden' name='status' value='Display'>\n";
	print "<input type='hidden' name='start' value=\"$start\">\n";
	print "<input type='hidden' name='end' value=\"$end\">\n";
	print "</form></td>\n";
	print "<td>\n";
	
	#------- Compose Button -------#
	print "<FORM METHOD='POST' ACTION=\"$simpleSENDurl\">\n";
	print "<input type='submit' value='Compose'>\n";
	print "<input type='hidden' name='username' value=\"$Name\">\n";
	print "<input type='hidden' name='pass' value=\"$Pass\">\n";
	print "<input type='hidden' name='server' value=\"$Serv\">\n";
	print "<input type='hidden' name='status' value='Compose'>\n";
	print "<input type='hidden' name='start' value=\"$start\">\n";
	print "<input type='hidden' name='end' value=\"$end\">\n";
	print "</form></td>\n";
	print "<td>\n";

	#------- Logout Button -------#	
	print "<form method='POST'>\n";
	print "<input type='button' value='Logout' onClick='closeThisWindow()'>\n";
	$Client->Close;
	print "</form>";
	print_bottom();
	exit();
	
	#------- previous 10 ---------#
	$prevstart = $start-10;
	if ($prevstart > 0)
	{
		print "<td><form method='POST' action=\"$simplePOPurl\">\n";
		print "<input type='submit' value='Prev 10'>\n";
		print "<input type='hidden' name='username' value=\"$Name\">\n";
		print "<input type='hidden' name='pass' value=\"$Pass\">\n";
		print "<input type='hidden' name='server' value=\"$Serv\">\n";
		print "<input type='hidden' name='start' value=\"$prevstart\">\n";	
		print "</form></td>\n";
	}

	#------- Next 10 -------#
	if ($end <= $count) 
	{
		print "<td><form method='POST' action=\"$simplePOPurl\">\n";
		print "<input type='submit' value='Next 10'>\n";
		print "<input type='hidden' name='username' value=\"$Name\">\n";
		print "<input type='hidden' name='pass' value=\"$Pass\">\n";
		print "<input type='hidden' name='server' value=\"$Serv\">\n";
		print "<input type='hidden' name='start' value=\"$end\">\n";
		print "<input type='hidden' name='end' value=\"$end\">\n";
		print "</form></td>\n";
	}

	print "</tr></table>\n";
	print "</center>\n";
} #------- End Display soubroutine -------#
	

#------- Subroutine for cleaning up Headers -------#
sub CleanHead 
{
	$replyheader = $Client->Head($Num);
	@reply = split (/\n/, $replyheader);

	foreach $a (@reply) 
	{
		$a =~ s/</&lt\;/g;	
		$a =~ s/>/&gt\;/g;
 		$a =~ s/\"/&quot\;/g;

		if ($a =~ /^From:/) { 
			$from = $'; 
			$from =~ s/ //g;
		if ($from =~/&lt\;(.*\@.*)&gt\;/) {
			$from = $1;
		}
		else {
		#	$from =~ / (.*\@.*) /;
			$from = $';
		}
	}

	if ($a =~ /^Subject:/) { $subject = $'; }
	if ($a =~ /^To:/) { $to = $'; }
	if ($a =~ /^Reply-to:/) {$replyto = $'; }
	
	}
}

#--------- SUBROUTINE FOR SHOWING BUTTONS   ------------#
sub Buttons 
{
	print "<center>\n";
	print "<table><tr><td>\n";
	if ($Perform eq "Read") 				# Back button
	{
		print "<form action=\"$simplePOPurl\" method='POST'>\n";
		print "<input type='submit' name='Display' value='Back'>\n";	
		print "<input type='hidden' name='username' value=$Name>\n";	
		print "<input type='hidden' name='pass' value=\"$Pass\">\n";	
		print "<input type='hidden' name='server' value=\"$Serv\">\n";
		print "<input type='hidden' name='Num' value=\"$c\">\n";	
		print "<input type='hidden' name='status' value='Display'>\n";	
		print "<input type='hidden' name='start' value=\"$start\">\n";
		print "<input type='hidden' name='end' value=\"$end\">\n";	
		print "</form></td>\n";
	}
	else 
		#--------- Read button ---------#
	{								
		print "<td><form action=\"$simplePOPurl\" method='POST'\n>";
		print "<input type='Submit' name='submit' value='Read'>\n";
		print "<input type='hidden' name='username' value=\"$Name\">\n";
		print "<input type='hidden' name='pass' value=\"$Pass\">\n";
		print "<input type='hidden' name='server' value=\"$Serv\">\n";
		print "<input type='hidden' name='Num' value=\"$c\">\n";
		print "<input type='hidden' name='status' value='Read'>\n";
		print "<input type='hidden' name='start' value=\"$start\">\n";
		print "<input type='hidden' name='end' value=\"$end\">\n";
		print "</form></td>\n";
	}
	
	#--------- Delete button ---------#				
	print "<td><form action=\"$simplePOPurl\" method='POST'>\n";
    print "<input type='submit' name='Delete' value='Delete'>\n";
	print "<input type='hidden' name='username' value=\"$Name\">\n";
    print "<input type='hidden' name='pass' value=\"$Pass\">\n";
    print "<input type='hidden' name='server' value=\"$Serv\">\n";
    print "<input type='hidden' name='Num' value=\"$c\">\n";
    print "<input type='hidden' name='status' value='Delete'>\n";
	print "<input type='hidden' name='start' value=\"$start\">\n";
	print "<input type='hidden' name='end' value=\"$end\">\n";
	print "</form></td>\n";

	#--------- Reply button ---------#	
	print "<td><form action=\"$simplePOPurl\" method='POST'>\n";
    print "<input type='submit' name='Reply' value='Reply'>\n";
    print "<input type='hidden' name='username' value=$Name>\n";
    print "<input type='hidden' name='pass' value=$Pass>\n";
    print "<input type='hidden' name='server' value=$Serv>\n";
    print "<input type='hidden' name='Num' value=$c>\n";
    print "<input type='hidden' name='status' value='Reply'>\n";
	print "<input type='hidden' name='start' value=\"$start\">\n";
	print "<input type='hidden' name='end' value=\"$end\">\n";
    print "</form></td>\n";
	
	if (($Perform eq "Read") and ($c > 1)) 
	{
		$prevmsg=$c - 1;
		print "<td><form action=\"$simplePOPurl\" method='POST'>\n";
		print "<input type='submit' name='Previous' value='<< Previous'>\n";
		print "<input type='hidden' name='username' value=$Name>\n";
		print "<input type='hidden' name='pass' value=$Pass>\n";
		print "<input type='hidden' name='server' value=$Serv>\n";
		print "<input type='hidden' name='Num' value=$prevmsg>\n";
		print "<input type='hidden' name='status' value='Read'>\n";
		print "<input type='hidden' name='start' value=\"$start\">\n";
		print "<input type='hidden' name='end' value=\"$end\">\n";
		print "</form></td>\n";
	}

	if (($Perform eq "Read") and ($c < $count)) 
	{
		$nextmsg= $c + 1;
		print "<td><form action=\"$simplePOPurl\" method='POST'>\n";
		print "<input type=submit name='Next' value='Next >>'>\n";
		print "<input type='hidden' name='username' value=$Name>\n";
		print "<input type='hidden' name='pass' value=$Pass>\n";
		print "<input type='hidden' name='server' value=$Serv>\n";
		print "<input type='hidden' name='Num' value=$nextmsg>\n";		
		print "<input type='hidden' name='status' value='Read'>\n";  
		print "<input type='hidden' name='start' value=\"$start\">\n";
		print "<input type='hidden' name='end' value=\"$end\">\n";
		print "</form></td>\n";
	}	

	print "</tr></table></center>\n";
}

#----- No messages message ----#
sub NoMessages {
	$navbar = "$admin{'btn2'} Mail Center";
	print_top();
  	print "<script language=\"JavaScript\">\n";
	print "function closeThisWindow()\n";
	print "{\n"; 
	print "window.close()\n";
	print "}\n";
	print "</script>\n";
	print "<center><h2>You currently have no messages in your popmail account</h2>\n";
	print "<b>Popmail username: </b>$Name<br>\n";
	print "<b>Popmail server: </b>$Serv<br>\n";
	print "<form method='POST'>\n";
	print "<input type='button' value='Logout' onClick='closeThisWindow()'>\n";
	$Client->Close;	
	print "</form>\n";
	print "<a href=\"$homeurl\">Return to home</a>\n";
	print "</center>\n";
	print_bottom();
	exit(0);
}

#---- SUBROUTINE FOR MAKING CONNECTION TO POPSERVER ---#
sub Connection 
{
	#------ open connection to popmail server      ----#
	$Client = new Mail::POP3Client($Name, $Pass, $Serv, $auth_mode);
	$thestate = $Client->State;

	#--- Tally up how many messages are in mailbox ----#
	$count = $Client->Count;

	#--- 		Check to see if no messages	   	   ----#
	if ($count == 0) { &NoMessages; }
	
	#--- alright lets get the size (bytes) of each ----#
	$size_list = $Client->List;

	#--- split the list containing the sizes up   -----#
	@size = split(/[\t\n\r\f ]/, $size_list);
	
	$s=1;
	for ($d=1; $d<=$count; $d++) {
		$sizedisplay[$d] = $size[$s];
		$s=$s+3;
	}
$s=0;
}#--- END SUBROUTINE MAKING CONNECTION TO POPSERVE ---#

################
sub mailsend {
################

use Mail::POP3Client;
require "$scriptdir/perlmodule/cgi-lib.pl";

#---------------#
#	variables	#
#---------------#
$sendmailpath = "$mailprogram";							# This is the path for sendmail
$simplePOPurl = "$pageurl/$cgi\?action=mailcenter";		# simplePOP.cgi location 
$simpleSENDurl = "$pageurl/$cgi\?action=mailcenter\&send=start";	# simpleSEND.cgi location		
$errors = "$master_email";									# enter an email where if there are errors
																# it will be sent here

#------------------------------------------------#
#	assign form variables to local variables	 #
#------------------------------------------------#
$Name=$info{'username'};
$Pass=$info{'pass'};
$Serv=$info{'server'};
$Num=$info{'Num'};
$Perform=$info{'status'};
$rebody=$info{'rebody'};
$body=$info{'body'};
$from=$info{'from'};
$to=$info{'to'};
$subject=$info{'subject'};
$replyto=$info{'replyto'};
$replyfrom=$info{'replyfrom'};
$forward=$info{'Forward'};
$resubject=$info{'resubject'};
$sender=$info{'sender'};
$start=$info{'start'};
$auth_mode="BEST";

#------- Subroutine for establishing connection -------#
&Connection2;

#------- Check to see if user is replying to an email -------#
if ($Perform eq "Reply") 
{
	$recipient = $replyto;
	$to = $replyto;
	&Reply;
	print "<title>POPservices: Messsage sent</title>\n";
	print "<center><h1>Your message has been sent</h1></center>\n";
	print "<br><br><br>";
	print "<center>\n";

	#------- Thank You button -------#
	print "<form method='POST' action=\"$simplePOPurl\">\n";
	print "<input type=submit value='Thank You'>\n";
	print "<input type='hidden' name='status' value='Display'>\n";
	print "<input type='hidden' name='username' value=\"$Name\">\n";
	print "<input type='hidden' name='pass' value=\"$Pass\">\n";
	print "<input type='hidden' name='server' value=\"$Serv\">\n";
	print "<input type='hidden' name='status' value='Read'>\n";
	print "<input type='hidden' name='start' value=\"$start\">\n";
	print "</form>\n";
	print "</center>\n";
	print "<br><hr>\n";
}


#---------- Check to see if user wants to Compose ----------#
if ($Perform eq "Compose") 
{
	$sender = $Name . '@' . $Serv;
	&Compose;
}	

#-------- Check to see if user wants to send email --------#
if ($Perform eq  "Send") 
{
	open (MAILPIPE,"|$sendmailpath $to");
        print MAILPIPE "From: $sender\n";
        print MAILPIPE "To: $to\n";
        print MAILPIPE "Subject: $subject \n\n";
        print MAILPIPE "$body\n\n";
	close MAILPIPE;
    print "<title>POPservices: Messsage sent</title>\n";
    print "<center><h1>Your message has been sent</h1></center>\n";
    print "<br><br><br>";
    print "<center>\n";
 
 	#---------- Thank You button ----------#
	print "<form method='POST' action=\"$simplePOPurl\">\n";
	print "<input type=submit value='Thank You'>\n";
    print "<input type='hidden' name='status' value='Display'>\n";
    print "<input type='hidden' name='username' value=\"$Name\">\n";
    print "<input type='hidden' name='pass' value=\"$Pass\">\n";
    print "<input type='hidden' name='server' value=\"$Serv\">\n";
    print "<input type='hidden' name='status' value='Read'>\n";
    print "<input type='hidden' name='start' value=\"$start\">\n";
    print "</form>\n";
    print "</center>\n";
    print "<br><hr>\n";
}

#--------- Subroutine for replying to an email ---------#
sub Reply 
{
	$from =~ s/<//g;
	$from =~ s/>//g;
	$body = $Client->Body($Num);
	$sender = $Name . '@' . $Serv;

	open (MAILPIPE,"|$sendpath $recipient");
		print MAILPIPE "From: $sender\n";
		print MAILPIPE "To: $replyto\n";
		if ($Perform eq "Reply") 
		{ print MAILPIPE "Subject: $resubject \n\n"; }
		else
		{ print MAILPIPE "Subject: FWD: \[$subject\]\n\n"; }
		print MAILPIPE "$input{'rebody'}\n\n";
		print MAILPIPE "$body\n\n";
	close MAILPIPE;
}

#--------- Subroutine for making new message ---------#
sub Compose
{
	print "<form METHOD='POST' ACTION=\"$simpleSENDurl\">\n";
	print "<B>From: $Name\@$Serv</b><br>\n";
	$sender = $Name . '@' . $Serv;
	print "To: <input type='text' name='to'><BR>\n";
	print "Subject: <input type='text' name='subject'><BR>\n";
	print "Message: <br><textarea name='body' rows='15' cols='70' wrap='hard'>\n";
	print "</textarea><BR><BR>\n";
	print "<input type='Submit' name='popsub' value='Send Email'>\n";	
	print "<input type='Reset' value='Clear Fields'>\n";
	print "<input type='hidden' name='status' value='Send'>\n";
	print "<input type='hidden' name='sender' value=\"$sender\">\n";
    print "<input type='hidden' name='username' value=\"$Name\">\n";
    print "<input type='hidden' name='pass' value=\"$Pass\">\n";
    print "<input type='hidden' name='server' value=\"$Serv\">\n";
    print "<input type='hidden' name='start' value=\"$start\">\n";
	print "<input type='hidden' name='to' value=\"$to\">\n";
	print "<input type='hidden' name='from' value=\"$from\">\n";
	print "</form>";
}

#--------- Subroutine for establishing connection to popserver ---------#
sub Connection2 
{
	 	# open connection to popmail server              #
	 	$Client = new Mail::POP3Client($Name, $Pass, $Serv, $aut_mode);
	 	$thestate = $Client->State;
}

}

1;
