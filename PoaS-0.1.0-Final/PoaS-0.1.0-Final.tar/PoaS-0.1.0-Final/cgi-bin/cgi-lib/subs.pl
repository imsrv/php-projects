###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                        #
#-----------------------------------------------------------------------------#
# subs.pl - various subroutines                                               #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)	                         #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: subs.pl, Last modified: 19:03 09/15/2002                              #
###############################################################################
###############################################################################


################
sub loadcookie {
################
	$cookie_expdate = "Thu, 01-Jan-2099 00:00:00 GMT";
	foreach (split(/; /,$ENV{'HTTP_COOKIE'})) {
		($cookie, $value) = split(/=/);
		if ($cookie eq $cookieusername) { $username = $value; }
		if ($cookie eq $cookiepassword) { $password = $value; }
		if ($cookie eq $cookieusertheme) { $usertheme = $value; }
		if ($cookie eq $cookieuserclang) { $userclang = $value; }
	}
eval { require("$langsdir/$userclang"); };
}

##############
sub loaduser {
##############
	if ($username eq "") {
		$username = $anonuser;
		$usertheme = "standard";
	}
	if (!open(FILE, "$memberdir/$username.dat")) {
		$username = $anonuser;
		$usertheme = "standard";
	}
	else { close(FILE); }
	if ($username ne $anonuser) {
		open(FILE, "$memberdir/$username.dat");
		@settings = <FILE>;
		close(FILE);

		for( $i = 0; $i < @settings; $i++ ) {
			$settings[$i] =~ s~[\n\r]~~g;
		}

		if ($settings[0] ne $password && $action ne "logout") { error("$err{'002'}"); }
		else {
			$realname = $settings[1];
			$realemail = $settings[2];
		}
	}
	unless ($username) {
		print qq~Set-Cookie: $cookieusername=; path=/; expires=$cookie_expdate;\n~;
		print qq~Set-Cookie: $cookiepassword=; path=/; expires=$cookie_expdate;\n~;
		print qq~Set-Cookie: $cookieusertheme=; path=/; expires=$cookie_expdate;\n~;
		print qq~Set-Cookie: $cookieuserclang=; path=/; expires=$cookie_expdate;\n~;

		$username = $anonuser;
		$password = "";
		$usertheme = "standard";
		@settings = ();
		$realname = "";
		$realemail = "";
		$settings[7] = "";
		$ENV{'HTTP_COOKIE'} = "";
	}
	open(LOG, "$datadir/log.dat");
	chomp(@entries = <LOG>);
	close(LOG);

	$field = $username;
	if ($field eq $anonuser) { $field = "$ENV{'REMOTE_ADDR'}"; }

	foreach $currentry_user (@entries) {
		@current_user_field = split(/\|/, $currentry_user);
		$empty = "";
		if ($current_user_field[0] eq $field && $current_user_field[2] ne $empty) { eval { require("$langsdir/$current_user_field[2]"); }; }
	}
	
}

#################
sub logvisitors {
#################
	my $current_ulang = shift;

	open(LOG, "$datadir/log.dat");
	chomp(@entries = <LOG>);
	close(LOG);

	foreach $listentryuser (@entries) {
		@fielduserentry = split (/\|/, $listentryuser);
		chomp(@fielduserentry);
		$field = $username;
		if ($field eq $anonuser) { $field = "$ENV{'REMOTE_ADDR'}"; }
		if ($fielduserentry[0] eq $field) {
			$empty = "";
			if ($current_ulang ne $empty && $fielduserentry[2] ne $current_ulang) { $userclang = $current_ulang; }
			elsif ($fielduserentry[2] eq $empty) { $userclang eq "english.lng"; }
			else { $userclang = $fielduserentry[2]; }
		}	
	}

	open(LOG, ">$datadir/log.dat");
	lock(LOG);
	print LOG "$field|$date|$userclang\n";
	foreach $curentry (@entries) {
#		($name, $value, $userlanguage) = split(/\|/, $curentry);
#		$date1 = "$value";
#		$date2 = "$date";
		@field_log = split(/\|/, $curentry);
		chomp(@field_log);
		$date1 = "$field_log[1]";
		$date2 = "$date";
		calctime();
#		if ($name ne $field && $result <= 15 && $result >= 0) { print LOG "$curentry\n"; }
		if ($field_log[0] ne $field && $result <= 15 && $result >= 0) { print LOG "$curentry\n"; }

	}
	unlock(LOG);
	close(LOG);
}

################
sub print_main {
################
	open(FILE, "$datadir/welcomemsg.txt");
	chomp(@lines = <FILE>);
	close(FILE);

	$welcome = qq~<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td><p class="texttitle">$lines[0]</p>
$lines[1]<br>
<br><br></td>
</tr>
</table>
~;

	require "$sourcedir/block.pl";
	check_rb_setting();
	if ($middle_rb eq 1) {
	random_block();
	}

	require "$sourcedir/topics.pl";
	viewnews();
	exit;
}

###############
sub print_top {
###############

	require "$themesdir/$usertheme/theme.pl"; getvars();
	require "$themesdir/$usertheme/header.pl";
}

##################
sub print_bottom {
##################
	require "$themesdir/$usertheme/footer.pl";
}

##############
sub menuitem {
##############
	require "$themesdir/$usertheme/theme.pl"; menuitem();
}

###############
sub boxheader {
###############
	require "$themesdir/$usertheme/theme.pl"; boxheader();
}

###############
sub boxfooter {
###############
	require "$themesdir/$usertheme/theme.pl"; boxfooter();
}

###############
sub userpanel {
###############
	menuitem("help", "$nav{'010'}");
	menuitem("register", "$nav{'011'}");
	if ($username ne "$anonuser") { 
		menuitem("editprofile&amp;username=$username", "$nav{'016'}");
		menuitem("memberlist", "$nav{'019'}");
		if (($enable_userarticles) || ($username = "admin")) {
			menuitem("postnews", "$nav{'023'}");
		}
		if ($username ne "admin") {
			if ($giveuserspace eq 1) {
				menuitem1("$pageurl/admin/fileman/userfileman.cgi", "$admin{'004'}");
				print qq~<br>~;
				menuitem1("$pageurl/$cgi\?action=homepagetools", "$admin{'homepage_tools'}");
			}
		}
	}
	if ($username eq "admin") { 
		menuitem("admin\&amp\;op=siteadmin", "$nav{'042'}");
	}

	if ($username ne "$anonuser") {
		open(FILE, "$memberdir/$username.dat") || error("$err{'010'} $memberdir/$username.dat");
		chomp(@settings = <FILE>);
		close(FILE);

		for ($i = 0; $i < @settings; $i++) { $settings[$i] =~ s~[\n\r]~~g; }
		if ($settings[7] eq "Administrator") {
			if ($username ne "admin") {
				menuitem("admin\&amp\;op=siteadmin", "$nav{'042'}");
			}
 		}
	}

	if ($username eq "$anonuser") { menuitem("login", "$nav{'012'}"); }
	else { menuitem("logout", "$nav{'034'}"); }
}

################
sub userstatus {
################
	$guests = 0;
	$users = 0;

	open(LOG, "$datadir/log.dat");
	chomp(@entries = <LOG>);
	close(LOG);

	foreach $curentry (@entries) {
		($name, $value, $userlanguage) = split(/\|/, $curentry);
		if($name =~ /\./) { ++$guests }
		else { ++$users	}
	}
	if ($username eq "$anonuser") {
		print qq~<tr>
<td class="cat">$msg{'002'} '$username'</td>
</tr>
~;
	}
	else {
		open(MEM, "$memberdir/$username.dat");
		chomp(@sett = <MEM>);
		close(MEM);

		if ($username ne "$anonuser") { 
			open(IM, "$memberdir/$username.msg"); 
			@immessages = <IM>; 
			close(IM);

			$mnum = @immessages; 
			$messnum = "$mnum"; 
		}
		print qq~<tr>
<td class="cat">$msg{'002'} '$sett[1]'</td>
</tr>
<tr>
<td class="cat">$msg{'003'} <a href="$pageurl/$cgi?action=im" class="menu">$mnum</a></td>
</tr>
~;
	}

	opendir(DIRCO, "$datadir/autopage/chat/online");
	chomp(@contentsco = readdir(DIRCO));
	closedir(DIRCO);

     	FILECO: foreach $lineco (sort @contentsco) {

        	next FILECO if ($lineco eq '.');
        	next FILECO if ($lineco eq '..');
        	next FILECO if ($lineco eq '.htaccess');
		next FILECO if ($lineco eq 'online.cnt');

		($name, $extension) = split (/\./, $lineco);
		next FILECO if ($extension ne 'ol');

		open (CHATO, "$datadir/autopage/chat/online/$name.ol") || error ("Can't open file");
		chomp($chatocon = <CHATO>);
		close (CHATO);

		$ctimenowc = $mday.$min;
		$chatoconnow = $chatocon +5;			
		if ($chatocon+5 < $ctimenowc) {
			unlink ("$datadir/autopage/chat/online/$lineco");
			unlink ("$datadir/autopage/chat/privatemsg/$name.msg");

			open (CHATUMCNT, "$datadir/autopage/chat/online/online.cnt") || error("Can't open $datadir/autopage/chat/online/online.cnt");
			$chatucountm=<CHATUMCNT>;
			close (CHATUMCNT);

			$chatucountm--;

			if ($chatucountm < 0) { $chatucountm = 0; }

			open (CHATUMCNT,">$datadir/autopage/chat/online/online.cnt");
			lock (CHATUMCNT);
			print CHATUMCNT $chatucountm;
			unlock (CHATUMCNT);
			close (CHATUMCNT);

			open (CHAT, ">>$datadir/autopage/chat/chat.dat") || error("Can't open $datadir/autopage/chat/chat.dat [write message]");
			lock (CHAT);
			print CHAT "** System ** $name Has Left Chat Room (Timeout)<br>";
			unlock (CHAT);
			close (CHAT);

			open (CHATLOG, ">>$datadir/members/$name.log");
			lock (CHATLOG);
			print CHATLOG "chat|$date";
			unlock (CHATLOG);
			close (CHATLOG);

		}
	}
	open (CHATOCNT, "$datadir/autopage/chat/online/online.cnt") || error("Can't open $datadir/autopage/chat/online/online.cnt");
	$chatocount=<CHATOCNT>;
	close (CHATOCNT);

	print qq~<tr>
<td class="cat">$msg{'004'} $guests<br>
$msg{'005'} $users<br>
$msg{'user_chating'} $chatocount
</td>
</tr>
~;
}

#############
sub readlog {
#############
	local ($field) = @_;
	if($username ne "$anonuser") {
		open(LOG, "$memberdir/$username.log");
		@entries = <LOG>;
		close(LOG);

		foreach $curentry (@entries) {
			$curentry =~ s/[\n\r]//g;
			@fields_user = split(/\|/, $curentry);
			if ($fields_user[0] eq "$field") { return "$value"; }
		}
	}
}

##############
sub writelog {
##############
	local($field) = @_;
#	if ($username ne "$anonuser") {

 		if ($username eq "$anonuser" || $username eq "") { $elusuario = "$datadir/guest.log"; }
        	else { $elusuario = "$memberdir/$username.log";}

		open(LOG, "$elusuario");
		@entries = <LOG>;
		close(LOG);

		open(LOG, ">>$elusuario");
		lock(LOG);
		if ($elusuario eq "$datadir/guest.log" && $action eq "") {;}
		else {
			print LOG "$field|$date|$ENV{'REMOTE_ADDR'}|$ENV{'HTTP_USER_AGENT'}|$ENV{'QUERY_STRING'}|$ENV{'REFFERER'}\n";
			foreach $curentry (@entries) {
				$curentry =~ s/[\n\r]//g;
				($name, $value, $remoteaddr, $aksi, $asal) = split(/\|/, $curentry);
				$date1 = "$value";
				$date2 = "$date";
				calcdifference();
				if ($name ne "$field" && $result <= $max_log_days_old) { print LOG "$curentry\n"; }
			}
		}
		unlock(LOG);
		close(LOG);
}



############
sub logips {
############
	@skip = ('127.0.0.1');
	$ip_time = 5;
	$check = 0;

	if (@skip) {
		foreach $ips (@skip) {
			if ($ENV{'REMOTE_ADDR'} =~ /$ips/) {
				$check = 1;
				last;
			}
		}
	}
	if ($check == 0) { 
		my $this_time = time();

		open(FILE,"$logdir/ip.log");
		my @lines = <FILE>;
		close(FILE);

		open(FILE,">$logdir/ip.log");
		lock(FILE);
		foreach $visitor (@lines) {
			($ip_addr,$time_stamp) = split(/\|/, $visitor);
			if ($this_time < $time_stamp + (60*$ip_time)) {
				if ($ip_addr eq $ENV{'REMOTE_ADDR'}) { $check = 1; }
				else { print FILE "$ip_addr|$time_stamp"; }
			}
		}
		print FILE "$ENV{'REMOTE_ADDR'}|$this_time\n";
		unlock(FILE);
		close(FILE);
	}

	if ($check == 0) { 
		if ($ENV{'REMOTE_HOST'}) { $host = $ENV{'REMOTE_HOST'}; }
		else {
			$ip_address = $ENV{'REMOTE_ADDR'};
			@numbers = split(/\./, $ip_address);
			$ip_number = pack("C4", @numbers);
			$host = (gethostbyaddr($ip_number, 2))[0];
		}
		if ($host eq "") { $host = "$ENV{'REMOTE_ADDR'}"; }

		($value, $referer) = split(/=/, $query);
		if ($referer) {
			if ($referer =~ /(http:\/\/.*\.[a-z]{2,4}\/)/i) { $referer = $1; }
		}
		else { $referer = "-"; }

		open(DATA, ">>$logdir/stats.dat");
		lock(DATA);
		print DATA ("$logdate - $host - \"$ENV{'HTTP_USER_AGENT'}\" - \"$referer\"\n");
		unlock(DATA);
		close (DATA);
	}
}

################
sub htmlescape {
################
	my $text = shift;

	$text =~ s/\&/&amp;/g;
	$text =~ s/\"/&quot;/g;
#	$text =~ s~~&nbsp;~g;
	$text =~ s/</&lt;/gi;
	$text =~ s/>/&gt;/gi;
	$text =~ s/\t/&nbsp; &nbsp; &nbsp;/g;
	$text =~ s/\cM//g;
	$text =~ s/\n/<br>/g;

	return $text;
}

################
sub htmltotext {
################
	my $html = shift;

	$html =~ s~<br>~\n~gi;
	$html =~ s~<\/*(blockquote|ul|li|p)[^<>]*>~\n\n~gi;
	$html =~ s~<a href=\"*([^\s<>\"]+)\"*[^>]*>([\s\S]+?)<\/a>~$2 (link: $1)~gi;
	$html =~ s~<[^>]+>~~g;
	$html =~ s~\"~&quot;~g;

	return $html;
}

##############
sub showhtml {
##############
	my $text = shift;

	if ($allow_html == 1) {
		$text =~ s~(\<|&lt;?)(\>|&gt;?)(.+?)&lt;/b&gt;~<b>$1</b>~isg;
		$text =~ s~(\<|&lt;?)(\>|&gt;?)(.+?)&lt;/i&gt;~<i>$1</i>~isg;
		$text =~ s~(\<|&lt;?)(\>|&gt;?)(.+?)&lt;/u&gt;~<u>$1</u>~isg;
		$text =~ s~(\<|&lt;?)(\>|&gt;?)(.+?)&lt;/p&gt;~<p>$1</p>~isg;
		$text =~ s~(\<|&lt;?)(\>|&gt;?)(.+?)&lt;/br&gt;~<br>$1</br>~isg;

		$text =~ s~(\<|&lt;?)(.*?)color=([\w#]+)(\>|&gt;?)(.*?)(\<|&lt;?)/color(\>|&gt;?)~<font color="$2">$3</font>~isg;
		$text =~ s~(\<|&lt;?)(.*?)size=([\w#]+)(\>|&gt;?)(.*?)(\<|&lt;?)/size(\>|&gt;?)~<font>$3</font>~isg;

		$text =~ s~(\<|&lt;?)hr(\>|&gt;?)~<hr size="1">~g;
	}

	$text =~ s~([^\w\"\=\[\]]|[\n\b])\\*(\w+://[^<>\s\n\"\]\[]+)~$1<a href="$2" target="_blank">$2</a>~isg;
	$text =~ s~([^\"\=\[\]/\:]|[\n\b])\\*(www\.[^<>\s\n\]\[]+)~$1<a href="http://$2" target="_blank">$2</a>~isg;

	$text =~ s~([^\f\"\=\[\]]|[\n\b])\\*(\f+://[^<>\s\n\"\]\[]+)~$1<a href="$2" target="_blank">$2</a>~isg;
	$text =~ s~([^\"\=\[\]/\:]|[\n\b])\\*(ftp\.[^<>\s\n\]\[]+)~$1<a href="ftp://$2" target="_blank">$2</a>~isg;

	$text =~ s~(\S+?)\@(\S+)~<a href="mailto:$1\@$2">$1\@$2</a>~gi;

	return $text;
}

############
sub doubbc {
############
	if ($message =~ /^\#nosmileys/ ) { $message =~ s/^\#nosmileys//; }
	else { 
		$message =~ s~\[bones\]~<img src="$imagesurl/forum/smilies/bones.gif" alt="">~g;
		$message =~ s~\[bounce\]~<img src="$imagesurl/forum/smilies/bounce.gif" alt="">~g;
		$message =~ s~\:-\?~<img src="$imagesurl/forum/smilies/confused.gif" alt="">~g;
		$message =~ s~\[confused\]~<img src="$imagesurl/forum/smilies/confused.gif" alt="">~g;
		$message =~ s~\Q8)\E~<img src="$imagesurl/forum/smilies/cool.gif" alt="">~g;
		$message =~ s~\Q8-)\E~<img src="$imagesurl/forum/smilies/cool.gif" alt="">~g;
		$message =~ s~\[cool\]~<img src="$imagesurl/forum/smilies/cool.gif" alt="">~g;
		$message =~ s~\[cry\]~<img src="$imagesurl/forum/smilies/cry.gif" alt="">~g;
		$message =~ s~\:o~<img src="$imagesurl/forum/smilies/eek.gif" alt="">~g;
		$message =~ s~\:\-o~<img src="$imagesurl/forum/smilies/eek.gif" alt="">~g;
		$message =~ s~\[eek\]~<img src="$imagesurl/forum/smilies/eek.gif" alt="">~g;
		$message =~ s~\[evil\]~<img src="$imagesurl/forum/smilies/evil.gif" alt="">~g;
		$message =~ s~\:\(~<img src="$imagesurl/forum/smilies/frown.gif" alt="">~g;
		$message =~ s~\:-\(~<img src="$imagesurl/forum/smilies/frown.gif" alt="">~g;
		$message =~ s~\[frown\]~<img src="$imagesurl/forum/smilies.gif" alt="">~g;
		$message =~ s~\:D~<img src="$imagesurl/forum/smilies/grin.gif" alt="">~g;
		$message =~ s~\:-D~<img src="$imagesurl/forum/smilies/grin.gif" alt="">~g;
		$message =~ s~\[grin\]~<img src="$imagesurl/forum/smilies/grin.gif" alt="">~g;
		$message =~ s~\[lol\]~<img src="$imagesurl/forum/smilies/lol.gif" alt="">~g;
		$message =~ s~\:x~<img src="$imagesurl/forum/smilies/mad.gif" alt="">~g;
		$message =~ s~\:-x~<img src="$imagesurl/forum/smilies/mad.gif" alt="">~g;
		$message =~ s~\[mad\]~<img src="$imagesurl/forum/smilies/mad.gif" alt="">~g;
		$message =~ s~\[ninja\]~<img src="$imagesurl/forum/smilies/ninja.gif" alt="">~g;
		$message =~ s~\[nonsense\]~<img src="$imagesurl/forum/smilies/nonsense.gif" alt="">~g;
		$message =~ s~\[oops\]~<img src="$imagesurl/forum/smilies/oops.gif" alt="">~g;
		$message =~ s~\[razz\]~<img src="$imagesurl/forum/smilies/razz.gif" alt="">~g;
		$message =~ s~\[rolleyes\]~<img src="$imagesurl/forum/smilies/rolleyes.gif" alt="">~g;
		$message =~ s~\:\)~<img src="$imagesurl/forum/smilies/smile.gif" alt="">~g;
		$message =~ s~\:-\)~<img src="$imagesurl/forum/smilies/smile.gif" alt="">~g;
		$message =~ s~\[smile\]~<img src="$imagesurl/forum/smilies/smile.gif" alt="">~g;
		$message =~ s~\:P~<img src="$imagesurl/forum/smilies/tongue.gif" alt="">~g;
		$message =~ s~\:-P~<img src="$imagesurl/forum/smilies/tongue.gif" alt="">~g;
		$message =~ s~\[tongue\]~<img src="$imagesurl/forum/smilies/tongue.gif" alt="">~g;
#		$message =~ s~\;\)~<img src="$imagesurl/forum/smilies/wink.gif" alt="">~g;
		$message =~ s~\;-\)~<img src="$imagesurl/forum/smilies/wink.gif" alt="">~g;
		$message =~ s~\[wink\]~<img src="$imagesurl/forum/smilies/wink.gif" alt="">~g;
	}
	
	$message =~ s~\[\[~\{\{~g;
	$message =~ s~\]\]~\}\}~g;
	$message =~ s~\n\[~\[~g;
	$message =~ s~\]\n~\]~g;

	$message =~ s~\<br\>~ <br>~g;
	$message =~ s~\[hr\]\n~<hr size="1">~g;
	$message =~ s~\[hr\]~<hr size="1">~g;

	$message =~ s~\[b\]~<b>~isg;
	$message =~ s~\[\/b\]~</b>~isg;

	$message =~ s~\[i\]~<i>~isg;
	$message =~ s~\[\/i\]~</i>~isg;

	$message =~ s~\[u\]~<u>~isg;
	$message =~ s~\[\/u\]~</u>~isg;
	
	$message =~ s~\[img\](.+?)\[\/img\]~<img src="$1" alt="">~isg;
	
	$message =~ s~\[color=(\S+?)\]~<font color="$1">~isg;
	$message =~ s~\[\/color\]~</font>~isg;
	
	$message =~ s~\[quote\]<br>(.+?)<br>\[\/quote\]~<blockquote><hr>$1<hr></blockquote>~isg;
	$message =~ s~\[quote\](.+?)\[\/quote\]~<blockquote><hr><b>$1</b><hr></blockquote>~isg;

	$message =~ s~\[fixed\]~<font face="Courier New">~isg;
	$message =~ s~\[\/fixed\]~</font>~isg;

	$message =~ s~\[sup\]~<sup>~isg;
	$message =~ s~\[\/sup\]~</sup>~isg;

	$message =~ s~\[sub\]~<sub>~isg;
	$message =~ s~\[\/sub\]~</sub>~isg;

	$message =~ s~\[center\]~<center>~isg;
	$message =~ s~\[\/center\]~</center>~isg;

	$message =~ s~\[list\]~<ul>~isg;
	$message =~ s~\[\*\]~<li>~isg;
	$message =~ s~\[\/list\]~</ul>~isg;

	$message =~ s~\[p\]~<p>~isg;

#	$message =~ s~\[pre\]~<pre>~isg;
#	$message =~ s~\[\/pre\]~</pre>~isg;

#	$message =~ s~\[code\](.+?)\[\/code\]~<blockquote><font face="Courier New">code:</font><hr><font face="Courier New"><pre>$1</pre></font><hr></blockquote>~isg;

	$message =~ s~\[email\]\s*(\S+?\@\S+?)\s*\[/email\]~<a href="mailto:$1">$1</a>~isg;
	$message =~ s~\[email=\s*(\S+?\@\S+?)\]\s*(.*?)\s*\[/email\]~<a href="mailto:$1">$2</a>~isg;

	$message =~ s~\[url\]www\.\s*(.+?)\s*\[/url\]~<a href="http://www.$1" target="_blank">www.$1</a>~isg;
	$message =~ s~\[url=\s*(\w+\://.+?)\](.+?)\s*\[/url\]~<a href="$1" target="_blank">$2</a>~isg;
	$message =~ s~\[url=\s*(.+?)\]\s*(.+?)\s*\[/url\]~<a href="http://$1" target="_blank">$2</a>~isg;
	$message =~ s~\[url\]\s*(.+?)\s*\[/url\]~<a href="$1" target="_blank">$1</a>~isg;

	$message =~ s~([^\w\"\=\[\]]|[\n\b]|\A)\\*(\w+://[\w\~\.\;\:\,\$\-\+\!\*\?/\=\&\@\#\%]+[\w\~\.\;\:\$\-\+\!\*\?/\=\&\@\#\%])~$1<a href="$2" target="_blank">$2</a>~isg;
	$message =~ s~([^\"\=\[\]/\:\.]|[\n\b]|\A)\\*(www\.[\w\~\.\;\:\,\$\-\+\!\*\?/\=\&\@\#\%]+[\w\~\.\;\:\$\-\+\!\*\?/\=\&\@\#\%])~$1<a href="http://$2" target="_blank">$2</a>~isg;

	$message =~ s~\{\{~\[~g;
	$message =~ s~\}\}~\]~g;
}

############
sub getcgi {
############
require "$sourcedir/security.pl";

	sysread(STDIN, $input, $ENV{'CONTENT_LENGTH'});
	@pairs = split(/&/, $input);
	foreach $pair(@pairs) {

	        ($name, $value) = split(/=/, $pair);
	        $name =~ tr/+/ /;
	        $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	        $value =~ tr/+/ /;
	        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	        $input{$name} = $value;

		if(($pair =~ /members/) && ($pair =~ /admin/))  { log_admin_access();}
		if($pair =~ /\.\.\//) { hack_attempt(); error("Illegal character detected!!!"); }

	}
	@vars = split(/&/, $ENV{QUERY_STRING});
	foreach $var(@vars) {
	        ($v,$i) = split(/=/, $var);
	        $v =~ tr/+/ /;
	        $v =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	        $i =~ tr/+/ /;
	        $i =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	        $i =~ s/<!--(.|\n)*-->//g;
	        $info{$v} = $i;

		if(($var =~ /members/) && ($var =~ /admin/))  { log_admin_access();}
		if($var =~ /\.\.\//) { hack_attempt(); error("Illegal character detected!!!"); }

	}

	$action = $info{'action'};
	$currentboard = $info{'board'};
	$op = $info{'op'};
}

#############
sub getdate {
#############
	($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time + 3600*$timeoffset);
	$mon_num = $mon+1;
	$savehour = $hour;
	$hour = "0$hour" if ($hour < 10);
	$min = "0$min" if ($min < 10);
	$sec = "0$sec" if ($sec < 10);
	$saveyear = ($year % 100);
	$year = 1900 + $year;
	$mon_num = "0$mon_num" if ($mon_num < 10);
	$mday = "0$mday" if ($mday < 10);
	$saveyear = "0$saveyear" if ($saveyear < 10);
	$date = "$mday/$mon_num/$saveyear - $hour\:$min\:$sec";
	$shortdate = "$days[$wday], $mday.$mon_num.$year";
	$logdate = "$days[$wday] $mday-$months[$mon]-$year $hour:$min";
}


####################
sub calcdifference {
####################
	($dates, $times) = split(/ /, $date1);
	($month, $day, $year) = split(/\//, $dates);
	$number1 = ($year*365)+($month*30)+$day;
	($dates, $dummy) = split(/ /, $date2);
	($month, $day, $year) = split(/\//, $dates);
	$number2 = ($year*365)+($month*30)+$day;
	$result = $number2-$number1;
}

##############
sub calctime {
##############
	($dummy, $times) = split(/ - /, $date1);
	($hour, $min, $sec) = split(/:/, $times);
	$number1 = ($hour*60)+$min;
	($dummy, $times) = split(/ - /, $date2);
	($hour, $min, $sec) = split(/:/, $times);
	$number2 = ($hour*60)+$min;
	$result = $number2-$number1;
}

###########
sub error {
###########
	local($e) = @_;
	$navbar = "$admin{'btn2'} $nav{'001'}";
	print_top();
	print qq~<p>
<b>$msg{'001'}</b><br>
$e
</p>
~;
	print_bottom();
	exit;
}

#########
sub die {
#########
	local($e) = @_;
	print qq~<p>
<b>$msg{'001'}</b><br>
$e
~;
die $error;
}

##########
sub lock {
##########
	local($file) = @_;
	if ($use_flock) { flock($file, $LOCK_EX); }
}

############
sub unlock {
############
	local($file) = @_;
	if ($use_flock) { flock($file, $LOCK_UN); }
}

###############
sub sendemail {
###############
	my ($to, $subject, $message, $from) = @_;

	if ($from) { $webmaster_email = $from; }
	$to =~ s/[ \t]+/, /g;
	$webmaster_email =~ s/.*<([^\s]*?)>/$1/;
	$message =~ s/^\./\.\./gm;
	$message =~ s/\r\n/\n/g;
	$message =~ s/\n/\r\n/g;
	$smtp_server =~ s/^\s+//g;
	$smtp_server =~ s/\s+$//g;

	if ($mailtype == 3) {
		open(S3,"| $mailprogram -f") || error("$err{'008'}");

		print S3 "To: $to\n";
		print S3 "From: $webmaster_email\n";
		print S3 "Subject: =\?$charset\?Q\?$subject=\?\n";
		print S3 "$message";
		print S3 "\n.\n";

		$_ = <S>;
		($_ !~ /^success/) && (error("Sending Email: Message send failed - try again - 250")); 
		print S "QUIT\n";

		close(S);
		return(1);
	}

	if ($mailtype == 2) {

		$mailtempsession = time();
		$mailfilesession = $mailtempsession;

		open(FILE, ">$datadir/temp/mail/$mailfilesession.txt") || error("$err{'016'} $datadir/temp/mail/$mailfilesession.txt");
		lock(FILE);
		$message .= "\n.\n";
		print FILE "$message\n";
		unlock(FILE);
		close(FILE);

		$commandline = $mailprogram;
		$commandline .= " $datadir/temp/mail/$mailfilesession.txt";
		$commandline .= " -q -noh2";
		$commandline .= " -t $to";
		$commandline .= " -i $webmaster_email";
		$commandline .= " -s $subject";

		system($commandline);

		unlink ("$datadir/temp/mail/$mailfilesession.txt");

	}

 	if ($mailtype == 1) {
		($x, $x, $x, $x, $here) = gethostbyname($null);
		($x, $x, $x, $x, $there) = gethostbyname($smtp_server);
		$thisserver = pack('S n a4 x8', 2, 0, $here);
		$remoteserver = pack('S n a4 x8', 2, 25, $there);
		(!(socket(S, 2, 1, 6))) && (error("Connect error! socket"));
		(!(bind(S, $thisserver))) && (error("Connect error! bind"));
		(!(connect(S, $remoteserver))) && (error("!! connection to $smtp_server has failed!"));

		my ($oldfh) = select(S);
		$| = 1;
		select($oldfh);

		$_ = <S>; 
		($_ !~ /^220/) && (error("Sending Email: data in Connect error - 220")); 

		print S "HELO $smtp_server\r\n";
		$_ = <S>;
		($_ !~ /^250/) && (error("Sending Email: data in Connect error - 250")); 

		print S "MAIL FROM:<$webmaster_email>\n";
		$_ = <S>;
		($_ !~ /^250/) && (error("Sending Email: 'From' address not valid")); 

		print S "RCPT TO:<$to>\n";
		$_ = <S>;
		($_ !~ /^250/) && (error("Sending Email: 'Recipient' address not valid")); 

		print S "DATA\n";
		$_ = <S>;
		($_ !~ /^354/) && (error("Sending Email: Message send failed - 354")); 
	}

	if ($mailtype == 0) {
		open(S,"| $mailprogram -t") || error("$err{'008'}");
	}

	print S "To: $to\n";
	print S "From: $webmaster_email\n";
	print S "Subject: =\?$charset\?Q\?$subject =\?\n";
	print S "$message";
	print S "\n.\n";

	if ($mailtype == 1) {
		$_ = <S>;
		($_ !~ /^250/) && (error("Sending Email: Message send failed - try again - 250")); 
		print S "QUIT\n";
	}

	close(S);
	return(1);
}

###########################
sub check_user_permission {
###########################
require "$sourcedir/security.pl";

if ($username eq $anonuser) { error("$err{'011'}"); }

	open(FILE, "$memberdir/$username.dat") || error("$err{'010'}");
	chomp(@settings = <FILE>);
	close(FILE);

	for ($i = 0; $i < @settings; $i++) { $settings[$i] =~ s~[\n\r]~~g; }

if ($username ne "admin") 
	{
		if ($settings[7] ne "Administrator") { error("$err{'011'}"); }
		check_allowed_ip();
	}
if ($username eq "admin")
	{
		if ($admin_ip ne "") {
			if ($ENV{'REMOTE_ADDR'} ne "$admin_ip") { hack_attempt(); error("Unauthorized access from $ENV{'REMOTE_ADDR'} detected!! Get out from my system NOW!!!"); }
		}
	}
}

#######################
sub write_active_lang {
#######################

	$langa = $info{'activated'};
	print qq~Set-Cookie: $cookieusername=$username; path=/; expires=$cookie_expdate;\n~;
	print qq~Set-Cookie: $cookiepassword=$password; path=/; expires=$cookie_expdate;\n~;
	print qq~Set-Cookie: $cookieusertheme=$usertheme; path=/; expires=$cookie_expdate;\n~;
	print qq~Set-Cookie: $cookieuserclang=$langa; path=/; expires=$cookie_expdate;\n~;

	logvisitors($langa);

	print "Location: $pageurl/$cgi\n\n";
	exit;
}

###################
sub languages_menu{
###################

	opendir(DIR, "$scriptdir/lang");
	@contents = readdir(DIR);
	closedir(DIR);

     	FILE: foreach $line (sort @contents) {

        next FILE if  ($line eq '.');
        next FILE if ($line eq '..');
        next FILE if ($line eq '.htaccess');

		($name, $extension) = split (/\./, $line);
		$daf_lang .= qq~<a href=\"$pageurl/$cgi\?action=language\&activated=$line"><img src=\"$imagesurl/flags/$name.gif\" alt=\"$name\"></a>\n~;
	}

	boxheader(150, "$language{'Language'}", "#737b9c", "white");
print qq~<tr><td><b><center>$language{'Select_Lang'}<center></b><br>
<div align="center"><center><p>
$daf_lang\n
</p></center></div></td></tr>~;
	boxfooter();


}

##############
sub autopage {
##############
require "$sourcedir/security.pl";
check_hash($info{'page'});
check_hash($info{'pagedir'});

use Pee::FileRunner;
use CGI::SSI_Parser;

	if ($use_mtag eq "1") { $mtag = $new_mtag;}

	if (!open(FILE, "$datadir/autopage/$info{'pagedir'}/$info{'page'}.set")) { $auto_ctype = "pee"; }
	else { 
		$ctypeinfo = <FILE>;
		close(FILE);

		@fieldsauto = split (/\|/, $ctypeinfo);
		$auto_ctype = $fieldsauto[0];
	}	

	if ($auto_ctype eq "standard") {
		open(FILE, "$datadir/autopage/$info{'pagedir'}/$info{'page'}.dat");
		@contentsauto = <FILE>;
		close(FILE);

		$navbar = "$admin{'btn2'} $info{'page'}";
		print_top();
		print "$autopage_header<p>";
		print "@contentsauto";
		print "$autopage_footer<p>";
		print_bottom();
	}

	if($auto_ctype eq "pee") {
		my $runner = Pee::FileRunner->new("$datadir/autopage/$info{'pagedir'}/$info{'page'}.dat");

		$navbar = "$admin{'btn2'} $info{'page'}";
		print_top();
		print "$autopage_header <p>";
		if (!$runner->compile()) {
  			print "Error compiling template: $datadir/autopage/$info{'pagedir'}/$info{'page'}.dat\n";
  			print "<br>$runner->{errmsg}\n";
		}
		if (!$runner->run('main')) {
  			print "<p>Error running template: $datadir/autopage/$info{'pagedir'}/$info{'page'}.dat\n";
  			print "<br>$runner->{errmsg}\n";
		}
		print "$autopage_footer <p>";
		print_bottom();
	}
	if($auto_ctype eq "ssi") {
		$CGI::SSI_Parser::recursive = 1;
		$navbar = "$admin{'btn2'} $info{'page'}";
		print_top();
		fssi("$datadir/autopage/$info{'pagedir'}/$info{'page'}.dat");
		print_bottom();
	}
	if($auto_ctype eq "perl") {
		$navbar = "$admin{'btn2'} $info{'page'}";
		print_top();
		require "$datadir/autopage/$info{'pagedir'}/$info{'page'}.dat";
		print_bottom();
	}

$use_mtag = 0;
$autopage_header = " ";
$autopage_content = " ";
$autopage_footer = " ";

exit;
};

###################
sub new_menu_item {
###################

	opendir(DIRM, "$datadir/autopage/mainmenu");
	@contentsm = readdir(DIRM);
	closedir(DIRM);

     	FILEM: foreach $linem (sort @contentsm) {

	($namem, $extensionm) = split (/\./, $linem);
        next FILEM if ($linem eq '.');
        next FILEM if ($linem eq '..');
        next FILEM if ($linem eq '.htaccess');
	next FILEM if ($extensionm ne 'dat');

		$namem_space = $namem;
		$namem_space =~ s/ /%20/g;
		menuitem("autopage\&pagedir=mainmenu\&page=$namem_space", "$namem");
	}

}

##########
sub help {
##########

	opendir(DIRH, "$datadir/autopage/help");
	@contentsh = readdir(DIRH);
	closedir(DIRH);

     	FILEH: foreach $lineh (sort @contentsh) {

	($nameh, $extensionh) = split (/\./, $lineh);
        next FILEH if ($lineh eq '.');
        next FILEH if ($lineh eq '..');
        next FILEH if ($lineh eq '.htaccess');
	next FILEH if ($extensionh ne 'dat');

 		$nameh_space = $nameh;
		$nameh_space =~ s/ /\%20/g;
		$daf_help .= qq~<li> <a href="$pageurl/$cgi\?action=autopage\&pagedir=help\&page=$nameh_space">$nameh</a><br>~;
	}

	$navbar = "$admin{'btn2'} $help{'Help_Page'}";
	print_top();
	print qq~ <center><big><big>$help{'User_Help_Page'}</big></big></center><p> $daf_help ~;
	print_bottom();
}

#########################
sub check_extra_config {
#########################

	opendir(DIRC, "$scriptdir/config");
	@contentsc = readdir(DIRC);
	closedir(DIRC);

     	FILEC: foreach $linec (sort @contentsc) {

	        next FILEC if ($linec eq '.');
        	next FILEC if ($linec eq '..');
        	next FILEC if ($linec eq '.htaccess');

		($nameh, $extensionc) = split (/\./, $linec);
		next FILEC if ($extensionc ne 'pl');
		require "$scriptdir/config/$linec";
	}
}

#############
sub donate {
#############

print_top();
print qq~
<form name="form5" method="post" action="http://www.princesscard.com/servlet/OnlinePay">
  <p> </p>
  <p align="center"><font face="Verdana, Arial, Helvetica, sans-serif" color="Black" size="2">To Donate You must have PrincessCard<br><a href="http://www.princesscard.com/affiliate.jsp?ref=USP2001495">Click
    here to make a new PrincessCard.com account for FREE!</a></font></p>
  <table width="652" border="1" cellspacing="0" cellpadding="2" bordercolor="#003366" align="center">
  <tr align="center" valign="middle" bgcolor="#003366"> 
  <td height="4" colspan="3"><font face="Verdana, Arial, Helvetica, sans-serif" color="#FFFFFF"><b>
  <font face="Verdana, Arial, Helvetica, sans-serif" color="#FFFFFF" size="2">PAYMENT 
  ORDER To 'USP2001495 SITE' through PrincessCard</font> <a href="http://www.princesscard.com/affiliate.jsp?ref=USP2001495"><img src="http://www.princesscard.com/eng_version/images/pc_button1.gif" width="80" height="39" border="0" alt="PrincessCard.com" align="absmiddle"></a></b></font></td>
  </tr>
  <tr align="center">
  <td bgcolor="#CCCCCC" align="right" width="174" height="17"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Pay
  to Account No.:</font></td>
  <td height="17" align="left" valign="middle" colspan="2" width="464" bgcolor="#FFFFFF">
  <font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>USP2001495</b></font></td>
  </tr>
  <tr align="center">
  <td bgcolor="#CCCCCC" align="right" width="174" height="17"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Account
  Name:</font> </td>
  <td height="17" align="left" valign="middle" colspan="2" width="464" bgcolor="#FFFFFF"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>
  PoaS </b></font></td>
  </tr>
  <tr align="center">
  <td bgcolor="#CCCCCC" align="right" width="174"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Amount
  to pay:</font></td>
  <td align="left" colspan="2" width="464" bgcolor="#FFFFFF"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>USP</b></font>
  <font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
  <input type="text" name="PAY_AMOUNT" size="6" maxlength="4" value="0">
  (1USP=1USD)</font></td>
  </tr>
  <tr align="center">
  <td bgcolor="#CCCCCC" align="right" width="174"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">Memo
  <font size="1">(max. 250 characters):</font></font></td>
  <td align="left" colspan="2" width="464" bgcolor="#FFFFFF"> 
  <input type="text" name="PAY_MEMO" size="50" maxlength="150">
  </td>
  </tr>
  <tr align="center">
  <td colspan="3" bgcolor="#003366">
  <input type="hidden" name="PAY_TO_ACCOUNT" value="USP2001495">
  <input type="hidden" name="PAY_SUCCESS_URL" value="http://poas.netfirms.com/cgi-bin/index.cgi">
  <input type="hidden" name="PAY_CANCEL_URL" value="http://poas.netfirms.com/cgi-bin/index.cgi">
  <input type="hidden" name="CUSTOM_FIELD_1" value="">
  <input type="hidden" name="CUSTOM_FIELD_2" value="">
  <input type="hidden" name="CUSTOM_FIELD_3" value="">
  <input type="hidden" name="PAY_URL_METHOD" value="get">
  <input type="submit" name="Submit2" value="Submit">
  </td>
  </tr>
  </table>
  <p> </p>
</form>
~;
print_bottom();
}

###################
sub hack_attempt {
###################
		open(LOG, ">>$datadir/hacker.log");
		chomp(@entries = <LOG>);
		close(LOG);

		open(LOG, ">>$datadir/hacker.log");
		lock(LOG);
		$field = $username;
		if ($field eq $anonuser) { $field = "$ENV{'REMOTE_ADDR'}"; }
		print LOG "$field-$ENV{'REMOTE_ADDR'}|$date|$ENV{'HTTP_REFERER'}|$ENV{'QUERY_STRING'}\n";
		foreach $curentry (@entries) {
			($name, $value, $comefrom, $querystr) = split(/\|/, $curentry);
			$date1 = "$value";
			$date2 = "$date";
			calctime();
			$subject = "Hack attempt";
			$message = "$ENV{'REMOTE_ADDR'}|$date|$ENV{'HTTP_REFERER'}|$ENV{'QUERY_STRING'}\n";
			sendemail($master_email, $subject, $message, "Anonym\@hacker.org");
			if ($name ne $field && $result <= 15 && $result >= 0) { print LOG "$curentry\n"; }
		}
		unlock(LOG);
		close(LOG);
}

######################
sub latestforumposts {
######################
	open(FILE, "<$boardsdir/cats.txt");
	@fcats = <FILE>;
	close(FILE);

	%myforumdata= ();

	foreach $fcat (@fcats) {
		$fcat =~ s/[\n\r]//g;

		open(FILE, "<$boardsdir/$fcat.cat");
		@fcatinfo = <FILE>;
		close(FILE);

		$fcatinfo[1] =~ s/[\n\r]//g;
		foreach $selboard (@fcatinfo) {
			if ($selboard ne $fcatinfo[0] && $selboard ne $fcatinfo[1]) {
				$selboard =~ s/[\n\r]//g;

				open(FILE, "<$boardsdir/$selboard.txt");
				@fposts = <FILE>;
				close(FILE);

				for ($f = 0; $f < @fposts; $f++) {
					($fpnum, $fptitle, $dummy, $dummy, $dummy, $fpdate, $dummy, $dummy, $dummy, $dummy, $dummy) = split(/\|/, $fposts[$f]);
					chomp($dummy);

					$myforumlink = qq~<a href="$pageurl/$cgi?action=forum&amp;board=$selboard&amp;op=display&amp;num=$fpnum" class="menu">$fptitle</a>
~;
;

					($date, $time) = split(/ - /, $fpdate);
					($day, $month, $year) = split(/\//, $date);
					($hour, $min, $sec) = split (/:/, $time);
					$mytotaltime = (($year+2000)*365+$month*30+$day)*24*60*60+$hour*60*60+$min*60+$sec; 
					$myforumdata{$mytotaltime} = $myforumlink;
				}
			}
		}
	}
	@myforumnum = sort { $b <=> $a } keys %myforumdata;
}

##################
sub top10_block {
##################
require "$scriptdir/cgi-lib/top10.pl";

	@top_listing = ("forums", "links", "downloads", "polls", "users");
	$top_randlist = @top_listing;
	$toprand10 = int(rand($top_randlist));
	if ($top_listing[$toprand10] eq "forums") {
		print qq~<center><b>$msg{'most_read_forum'}</b></center><p><ul>~;
		&top10_forumposts(0, "block");
		print qq~</ul>~;
	}
	elsif ($top_listing[$toprand10] eq "links") {
		print qq~<center><b>$msg{'most_popular_links'}</b></center><p><ul>~;
		&top10_links(0, "block");
		print qq~</ul>~;
	}
	elsif ($top_listing[$toprand10] eq "downloads") {
		print qq~<center><b>$msg{'most_popular_downloads'}</b></center><p><ul>~;
		&top10_downloads(0, "block");
		print qq~</ul>~;
	}
	elsif ($top_lisitng[$toprand10] eq "polls") {
		print qq~<center><b>$msg{'most_voted_polls'}</b></center><p><ul>~;
		&top10_polls(0, "block");
		print qq~</ul>~;
	}
	elsif ($top_listing[$toprand10] eq "users") {
		print qq~<center><b>$msg{'most_active_user'}</b></center><p><ul>~;
		&top10_users(0, "block");
		print qq~</ul>~;
	}
	else {
		print qq~<center><b>$msg{'most_read_forum'}</b></center><p><ul>~;
		&top10_forumposts(0, "block");
		print qq~</ul>~;
	}
}

######################
sub system_cleanup {
######################

	opendir(CLEANREG, "$datadir/temp/register");
	@dbregdir = readdir(CLEANREG);
	closedir(CLEANDIR);

	foreach $dbregdircheck (@dbregdir) {
		$currentregtime = time();
		@fields = split(/\./, $dbregdircheck);
		if ($fields[0] < $currentregtime) {
			unlink("$datadir/temp/register/$dbregdircheck");
			unlink("$imagesdir/temp/$fields[0].gif");
		}
		else { next; }
	}
}

#####################
sub verify_referer {
#####################
require "$sourcedir/security.pl";
	check_referer();
}

1; # return true
