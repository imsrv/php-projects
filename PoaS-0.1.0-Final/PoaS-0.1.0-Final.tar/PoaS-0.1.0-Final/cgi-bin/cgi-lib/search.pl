####################################################################
# PoaS - Perlonall Site 
#
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com) 
#
# This program is free software; you can redistribute it and/or 
# modify it under the terms of the GNU General Public License 
# as published by the Free Software Foundation; either version 2 
# of the License, or (at your option) any later version. 
#
# This program is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
# GNU General Public License for more details. 
# 
# You should have received a copy of the GNU General Public License 
# along with this program; if not, write to the 
# Free Software Foundation, Inc.,
# 59 Temple Place - Suite 330, 
# Boston, MA  02111-1307, USA. 
#
#
# $Id: search.pl 2002/08/04 15:31:40 Based on YaWPS search.pl Exp $
####################################################################


############
sub search {
############
	if ($input{'keyword'} eq "") { error("$err{'006'}"); }

	@searchdirs = ("$messagedir", "$topicsdir/articles", "$linksdir", "$downloadsdir");
	$numero = 0;
	foreach $dir (@searchdirs) {
		opendir(DIR, "$dir");
		while ($file = readdir DIR) {
			next if ($file =~ /^\./);
			push(@searchfiles, "$dir/$file") if ($file =~ /\.txt/);
			push(@searchfiles, "$dir/$file") if ($file =~ /\.dat/);
		}
		closedir(DIR);
	}

	for ($i = 0; $i < @searchfiles; $i++) {
		$file = $searchfiles[$i];

		open(FILE, "$file");
		$contents = join('', <FILE>);
		close(FILE);

		$contents =~ tr/A-Z/a-z/;
		$contents =~ s/<[^>]+>/ /g;
		$contents =~ s/ - / /g;
		$contents =~ s/'//g;
		$contents =~ s/[\n\t\`\~\!\@\#\$\%\^\&\*\(\)\_\+\-\=\{\}\|\[\]\\\:\"\;\<\>\?\,\.\/0-9]/ /g;
		@tempwords = split(/ +/, $contents);

		foreach $word (@tempwords) {
			@letters = split(//, $word);
			next if (@letters <= 2);
			next if ($words{$word} =~ /$i /);
			next if ($word eq "");
#			next if ($word !~ /^[0-9a-z][0-9a-z]*$/);
			next if ($word !~ /$/);
			$words{$word} .= "$i ";
		}
	}

	for ($i = 0; $i < @searchfiles; $i++) {
		push(@searchidx, "$i|$searchfiles[$i]\n");
	}

	foreach $key (keys(%words)) {
		push(@searchdb, "$key|$words{$key}\n");
	}

	$input{'keyword'} =~ s/'//g;
	$input{'keyword'} =~ tr/A-Z/a-z/;
	@queries = split(/ /, $input{'keyword'});
	$totalqueries = @queries;
	$match = ($input{'match'} || "all");
	$max = 20;

	$navbar = "$admin{'btn2'} $nav{'039'}";
	print_top();

	foreach $line (@searchidx) { 
		@parts = split(/\|/, $line);
		push(@files, $parts[1]);
		$file = $parts[1];
		$matches{$file} = 0;
		$sizes{$file} = $parts[2];
	}

	for ($i = 0; $i < @words; $i++) {
		print qq~$words[$i]<br>~;
	}

	foreach (@searchdb) { 
		next unless s/^(.*?)\|\s*//;
		$words{$1} = [ split ];
	}

	foreach $query (@queries) { 
		if (@{$words{$query}}) { 
			foreach $index (@{$words{$query}}) {
				$potmatches{$files[$index]} += 1;
			}
		}
	}

	foreach $file (keys(%potmatches)) {
		next if ($match eq "any" && $potmatches{$file} == 0);
		next if ($match eq "all" && $potmatches{$file} < $totalqueries);
	
		push(@matches, $file);
	}

	$nummatches = @matches;

	$output .= qq~Search for : <b>"$input{'keyword'}"</b><br>
Matches: <b>$nummatches</b><br>
~;
#	if ($nummatches > $max) {
#		$output .= "Showing $max result.<br>";
#	}
#	$output .= qq~<hr size="1">~;

	if ($nummatches == 0) {
		$resultstr .= "<b>Sorry No Matches Found</b>";
	}
	else {
		for ($i = 0; $i < $nummatches && $i <= $max; $i++) {
			$file = $matches[$i];

#			if ($file =~ /$searchdirs[0]/ && $file =~ /(.*)\/(.*)\.txt/) {
#				open(FILE, "$boardsdir/cats.txt");
#				lock(FILE);
#				@forumcats = <FILE>;
#				unlock(FILE);
#				close(FILE);

#				foreach $forumcat (@forumcats) {
#					chomp($forumcat);

#					open(FILE, "$boardsdir/$forumcat.cat");
#					lock(FILE);
#					chomp(@forumcatinfo = <FILE>);
#					unlock(FILE);
#					close(FILE);

#					foreach $boardtosearch (@forumcatinfo) {
#						open(FILE, "$boardsdir/$boardtosearch.txt");
#						lock(FILE);
#						@fmessages = <FILE>;
#						unlock(FILE);
#						close(FILE);

#						for ($a = 0; $a < @fmessages; $a++) {
#							@item= split(/\|/, $fmessages[$a]);
#							chomp($item[10]);
#							if ($2 == $item[0]) {
#								$ititle = $item[1];
#								$iposter = $item[2];
#								$iposterid = $item[3];
#								$idate = $item[5];
#								$iboard = $boardtosearch;
#							}
#						}
#					}
#				}
#				$iurl = "$pageurl/$cgi?action=forum&amp;board=$iboard&amp;op=display&amp;num=$2";
#			}
			if ($file =~ /$searchdirs[1]/ && $file =~ /(.*)\/(.*)\.txt/) {
				open(FILE, "<$topicsdir/articles/$2.txt");
				chomp(@topicdata = <FILE>);
				close(FILE);

				for ($a = 0; $a < 1; $a++) {
					@item = split (/\|/, $topicdata[$a]);
					$ititle = $item[0];
					$iposter = $item[1];
					$iposterid = $item[2];
					$idate = $item[4];
					$idesc = $item[5];

					if (length($idesc) > 100) {
						$tmpmessagesearch = substr($idesc, 0, 100);
						$tmpmessagesearch =~ s/(.*)\s.*/$1/;
						$idesc = $tempmessagesearch;
					}
				}
				$iurl = "$pageurl/$cgi?action=viewnews&amp;id=$2";
#			}
#			if ($file =~ /$searchdirs[1]/ && $file =~ /(.*)\/(.*)\.txt/) {
#				open(FILE, "<$linksdir/$2.dat");
#				lock(FILE);
#				chomp(@linkdata = <FILE>);
#				unlock(FILE);
#				close(FILE);

#				for ($a = 0; $a < 1; $a++) {
#					@item = split (/\|/, $linkdata[$a]);
#					$ititle = $item[1];
#					$ilurl = $item[2];
#					$idesc = $item[3];
#					$idate = $item[4];
#					$iposter = $item[5];
#				}
#				$iurl = "$ilurl";
#			}
#			if ($file =~ /$searchdirs[1]/ && $file =~ /(.*)\/(.*)\.txt/) {
#				open(FILE, "<$downloadsdir/$2.dat");
#				lock(FILE);
#				chomp(@downloaddata = <FILE>);
#				unlock(FILE);
#				close(FILE);

#				for ($a = 0; $a < 1; $a++) {
#					@item = split (/\|/, $downloaddata[$a]);
#					$ititle = $item[1];
#					$idurl = $item[2];
#					$idesc = $item[3];
#					$idate = $item[4];
#					$iposter = $item[5];
#				}
#				$iurl = "$idurl";
#			}

			$resultstr .= qq~<img src="$imagesurl/urlgo.gif" border="0" alt="">&nbsp;&nbsp;<b><a href="$iurl">$ititle</a></b><br>
<b>Poster:</b> <a href="$pageurl/$cgi?action=viewprofile&amp;username=$iposterid">$iposter</a><br>
<b>Desc:</b> $idesc<br>
<b>Date:</b> $idate<br>
<br>
~;
$numero = $numero+1;
		}
		}


		for ($i = 0; $i < $nummatches && $i <= $max; $i++) {
			$file = $matches[$i];
# IT WAS A BUG ON THE SEARCHDIRS[X]- IT WAS ALWAYS 1. 
# ALSO CHANGED THE OLD .TXT KIND OF FILE FOR .DAT
			if ($file =~ /$searchdirs[3]/ && $file =~ /(.*)\/(.*)\.dat/) {
			if ($2 eq "downloadcats") {
				$max = $max+1
							}
			if ($2 ne "downloadcats") {

				open(FILE, "<$downloadsdir/$2.dat");
				@paso = <FILE>;
				close(FILE);
				@palabras= split(/ /, $input{'keyword'});
				foreach $palabra (@palabras) {
						for ($h = 0; $h < @paso; $h++) {
#print qq~ PASO $paso[$h]<BR> HACHEDOLAR $h<br>PALABRA $palabra<br>INPUTKEYWORD $input{'keyword'}<BR>~;
							@item= split(/\|/, $paso[$h]);
							chomp($item[0]);
							if ($paso[$h] =~ /$palabra/) {
								$ititle = $item[1];
								$iposter = $item[5];
								$iposterid = $item[5];
								$idate = $item[4];
								$iboard = $downloadsdir;
								$idesc = $item[3];
								$idurl = $item[2];
			$iurl = "$idurl";

			if ($resultstr !~ /$ititle/) {

			$resultstr .= qq~<img src="$imagesurl/urlgo.gif" border="0" alt="">&nbsp;&nbsp;<b><a href="$iurl" target="_blank">$ititle</a></b><br>
<b>Poster:</b> <a href="$pageurl/$cgi?action=viewprofile&amp;username=$iposterid">$iposter</a><br>
<b>Desc:</b> $idesc<br>
<b>Date:</b> $idate<br>
<br>
~;
$numero = $numero+1;
							}
							}
							}
							}


			}
			}

		}
		for ($i = 0; $i < $nummatches && $i <= $max; $i++) {
			$file = $matches[$i];
# IT WAS A BUG ON THE SEARCHDIRS[X]- IT WAS ALWAYS 1. OTHER IF ADDED TO HIDE LINKCATS.DAT
# ALSO CHANGED THE OLD .TXT KIND OF FILE FOR .DAT
			if ($file =~ /$searchdirs[2]/ && $file =~ /(.*)\/(.*)\.dat/) {
			if ($2 eq "linkcats") {
				$max = $max+1
							}
			if ($2 ne "linkcats") {

				open(FILE, "<$linksdir/$2.dat");
				@paso = <FILE>;
				close(FILE);

				@palabras= split(/ /, $input{'keyword'});
				foreach $palabra (@palabras) {
						for ($h = 0; $h < @paso; $h++) {
#print qq~ PASO $paso[$h]<BR> HACHEDOLAR $h<br>PALABRA $palabra<br>INPUTKEYWORD $input{'keyword'}<BR>~;
							@item= split(/\|/, $paso[$h]);
							chomp($item[0]);
							if ($paso[$h] =~ /$palabra/) {
								$ititle = $item[1];
								$idurl = $item[2];
								$idesc = $item[3];
								$idate = $item[4];
								$iposter = $item[5];
								$iposterid = $item[5];

			$iurl = "$idurl";

			if ($resultstr !~ /$ititle/) {

			$resultstr .= qq~<img src="$imagesurl/urlgo.gif" border="0" alt="">&nbsp;&nbsp;<b><a href="$iurl" target="_blank">$ititle</a></b><br>
<b>Poster:</b> <a href="$pageurl/$cgi?action=viewprofile&amp;username=$iposterid">$iposter</a><br>
<b>Desc:</b> $idesc<br>
<b>Date:</b> $idate<br>
<br>
~;
$numero = $numero+1;
							}
							}
							}
							}


			}
			}
			}

		for ($i = 0; $i < $nummatches && $i <= $max; $i++) {
			$file = $matches[$i];

			if ($file =~ /$searchdirs[0]/ && $file =~ /(.*)\/(.*)\.txt/) {

				open(FILE, "$boardsdir/cats.txt");
				@forumcats = <FILE>;
				close(FILE);

				foreach $forumcat (@forumcats) {
					chomp($forumcat);

					open(FILE, "$boardsdir/$forumcat.cat");
					chomp(@forumcatinfo = <FILE>);
					close(FILE);

					foreach $boardtosearch (@forumcatinfo) {
						open(FILE, "$boardsdir/$boardtosearch.txt");
						@fmessages = <FILE>;
						close(FILE);

						for ($a = 0; $a < @fmessages; $a++) {
							@item= split(/\|/, $fmessages[$a]);
							chomp($item[10]);
							if ($2 == $item[0]) {
								$ititle = $item[1];
								$iposter = $item[2];
								$iposterid = $item[3];
								$idate = $item[5];
								$iboard = $boardtosearch;
								$idesc = $item[1];
							}
						}
					}
				}
# ALL THIS LINES CHANGED IN ORDER TO PERSONALIZE EACH KIND OF FILE (DONWLOAD, LINK, AND SO ON)
				$iurl = "$pageurl/$cgi?action=forum&amp;board=$iboard&amp;op=display&amp;num=$2";
			$resultstr .= qq~<img src="$imagesurl/urlgo.gif" border="0" alt="">&nbsp;&nbsp;<b><a href="$iurl">$ititle</a></b><br>
<b>Poster:</b> <a href="$pageurl/$cgi?action=viewprofile&amp;username=$iposterid">$iposter</a><br>
<b>Desc:</b> $idesc<br>
<b>Date:</b> $idate<br>
<br>
~;
$numero = $numero+1;
			}
			}

	}

	$resultstr .= qq~<hr size="1">
<b>New Search:</b><br>
<form action="$pageurl/$cgi\?action=search" method="post">
<table cellspacing="0" cellpadding="2">
<tr>
<td><b>Search for:</b></td>
<td><input name="keyword" type="text" size="20" value="" maxlength="256"></td>
</tr>
<tr>
<td><b>Match:</b></td>
<td><select name="match">
<option value="all" selected>all words
<option value="any">any words
</select></td>
</tr>
<tr>
<td><input type="submit" value="$btn{'001'}"></td>
</tr>
</table>
</form>
~;

	$output .= qq~Number Match: <b>$numero</b><br>
~;
	if ($numero > $max) {
		$output .= "Showing max $numero result.<br>";
	}
	$output .= qq~<hr size="1">~;

	print "$output $resultstr";

	print_bottom();
	exit;
}

1; # return true
