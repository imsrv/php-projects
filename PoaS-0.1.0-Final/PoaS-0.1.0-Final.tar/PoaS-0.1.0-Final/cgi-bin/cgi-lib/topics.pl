###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                       #
#-----------------------------------------------------------------------------#
# news.pl - this code handles the whole news system                           #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)                             #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: topics.pl, Last modified: 19:06 05/18/2002                             #
###############################################################################
###############################################################################


##############
sub postnews {
##############
	if (($username eq $anonuser) || (($enable_userarticles == 0) && ($username ne "admin"))) { error("$err{'011'}"); }

	$navbar = "$admin{'btn2'} $nav{'023'}";
	print_top();
	print qq~<form action="$pageurl/$cgi?action=postnews2" method="post" name="creator">
<table border="0" cellspacing="1">
<tr>
<td><b>$msg{'013'}</b></td>
<td>$realname</td>
</tr>
<tr>
<td><b>$msg{'007'}</b></td>
<td>$realemail</td>
</tr>
<tr>
<td><b>$msg{'034'}</b></td>
<td><select name="cat">
~;
	open(FILE, "$topicsdir/cats.dat");
	chomp(@cats = <FILE>);
	close(FILE);

	foreach $line (@cats) {
		@item = split(/\|/, $line);
		print qq~<option value="$item[1]">$item[0]</option>\n~;
	}
	print qq~</select></td>
</tr>
<tr>
<td><b>Show article in front page?</b></td>
<td><select name=\"showfp\"><option value=\"yes\" SELECTED>Yes</option><option value=\"no\">No</option></select></td>
</tr>
<tr>
<td><b>$msg{'037'}</b></td>
<td><input type="text" name="subject" size="40" maxlength="50"></td>
</tr>
<tr>
<td valign="top"><b>$msg{'038'}</b></td>
<td>
<script language="javascript" type="text/javascript">
<!--
function addCode(anystr) { 
document.creator.message.value+=anystr;
} 
function showColor(color) { 
document.creator.message.value+="[color="+color+"][/color]";
}
// -->
</script>
<textarea name="message" rows="10" cols="40"></textarea></td>
</tr>
<tr>
<td><b>$msg{'156'}</b></td>
<td valign="top"><a href="javascript:addCode('[b][/b]')"><img src="$imagesurl/forum/bold.gif" align="bottom" width="23" height="22" alt="$msg{'117'}" border="0"></a>
<a href="javascript:addCode('[i][/i]')"><img src="$imagesurl/forum/italicize.gif" align="bottom" width="23" height="22" alt="$msg{'118'}" border="0"></a>
<a href="javascript:addCode('[u][/u]')"><img src="$imagesurl/forum/underline.gif" align="bottom" width="23" height="22" alt="$msg{'119'}" border="0"></a>
<a href="javascript:addCode('[center][/center]')"><img src="$imagesurl/forum/center.gif" align="bottom" width="23" height="22" alt="$msg{'120'}" border="0"></a>
<a href="javascript:addCode('[url][/url]')"><img src="$imagesurl/forum/url.gif" align="bottom" width="23" height="22" alt="$msg{'121'}" border="0"></a>
<a href="javascript:addCode('[email][/email]')"><img src="$imagesurl/forum/email2.gif" align="bottom" width="23" height="22" alt="$msg{'122'}" border="0"></a>
<a href="javascript:addCode('[quote][/quote]')"><img src="$imagesurl/forum/quote2.gif" align="bottom" width="23" height="22" alt="$msg{'124'}" border="0"></a>
<a href="javascript:addCode('[list][*][*][*][/list]')"><img src="$imagesurl/forum/list.gif" align="bottom" width="23" height="22" alt="$msg{'125'}" border="0"></a>
<a href="javascript:void(0)" onClick="window.open('$pageurl/$cgi?action=showsmilies','_blank','scrollbars=yes,toolbar=no,height=270,width=270')"><img src="$imagesurl/forum/smilie.gif" align="bottom" width="23" height="22" alt="$msg{'126'}" border="0"></a><br>
<select name="color" onChange="showColor(this.options[this.selectedIndex].value)">
<option value="Black" selected>$msg{'127'}</option>
<option value="Red">$msg{'128'}</option>
<option value="Yellow">$msg{'129'}</option>
<option value="Pink">$msg{'130'}</option>
<option value="Green">$msg{'131'}</option>
<option value="Orange">$msg{'132'}</option>
<option value="Purple">$msg{'133'}</option>
<option value="Blue">$msg{'134'}</option>
<option value="Beige">$msg{'135'}</option>
<option value="Brown">$msg{'136'}</option>
<option value="Teal">$msg{'137'}</option>
<option value="Navy">$msg{'138'}</option>
<option value="Maroon">$msg{'139'}</option>
<option value="LimeGreen">$msg{'140'}</option>
</select>
</td>
</tr>
~;
	if ($settings[7] eq "$root") { $approved = 1; }
	else { $approved = 0; }
	print qq~<tr>
<td colspan="2"><input type="hidden" name="approved" value="$approved">
<input type="submit" value="$btn{'008'}"><input type="reset" value="$btn{'009'}"></td>
</tr>
</table>
</form>
~;
	print_bottom();
	exit;
}

###############
sub postnews2 {
###############
	if (($username eq $anonuser) || (($enable_userarticles == 0) && ($username ne "admin"))) { error("$err{'011'}"); }
	error("$err{'014'}") unless ($input{'subject'});
	error("$err{'015'}") unless ($input{'message'});

	opendir (DIR, "$topicsdir/articles");
	@files = readdir(DIR);
	closedir (DIR);
	@files = grep(/txt/,@files);
	@files = reverse(sort { $a <=> $b } @files);
	$postnum = @files[0];
	$postnum =~ s/.txt//;
	$postnum++;

	chomp($input{'message'});
	chomp($input{'subject'});

	$subject = htmlescape($input{'subject'});
	$message = htmlescape($input{'message'});

	if ($username eq "admin") {
		open (FILE, "$topicsdir/$input{'cat'}.cat");
		@articles = <FILE>;
		close (FILE);

		open(FILE, ">$topicsdir/$input{'cat'}.cat");
		lock(FILE);
		print FILE "$postnum|$subject|$realname|$username|$realemail|$date|0\n";
		print FILE @articles;
		unlock(FILE);
		close(FILE);

		if ($input{'showfp'} ne "yes") { 
			open(FILE, ">$topicsdir/articles/$postnum.dat") || error("$err{'016'} $topicsdir/articles/$postnum.dat");
			lock(FILE);
			print FILE "0|0|0|0\n";
			unlock(FILE);
			close(FILE);	
		}
		else {
		open(FILE, ">$topicsdir/articles/$postnum.txt") || error("$err{'016'} $topicsdir/articles/$postnum.txt"); }
		lock(FILE);
		print FILE "$subject|$realname|$username|$realemail|$date|$message\n";
		unlock(FILE);
		close(FILE);

		open(FILE, "$memberdir/$username.dat") || error("$err{'010'}");
		chomp(@settings = <FILE>);
		close(FILE);

		$settings[11]++;

		open(FILE, ">$memberdir/$username.dat");
		lock(FILE);
		for ($i = 0; $i < @settings; $i++) {
			print FILE "$settings[$i]\n";
		}
		unlock(FILE);
		close(FILE);
	}

#	elsif ($username ne $anonuser) {
#	open(FILE, "$memberdir/$username.dat") || error("$err{'010'}");
#	lock(FILE);
#	chomp(@settings = <FILE>);
#	unlock(FILE);
#	close(FILE);

#	for ($i = 0; $i < @settings; $i++) { $settings[$i] =~ s~[\n\r]~~g; }
#	if ($settings[7] eq "Administrator") {

#		open (FILE, "$topicsdir/$input{'cat'}.cat");
#		lock(FILE);
#		@articles = <FILE>;
#		unlock(FILE);
#		close (FILE);

#		open(FILE, ">$topicsdir/$input{'cat'}.cat");
#		lock(FILE);
#		print FILE "$postnum|$subject|$realname|$username|$realemail|$date|0\n";
#		print FILE @articles;
#		unlock(FILE);
#		close(FILE);

#		open(FILE, ">$topicsdir/articles/$postnum.txt") || error("$err{'016'} $topicsdir/articles/$postnum.txt");
#		lock(FILE);
#		print FILE "$subject|$realname|$username|$realemail|$date|$message\n";
#		unlock(FILE);
#		close(FILE);

#		open(FILE, "$memberdir/$username.dat") || error("$err{'010'}");
#		lock(FILE);
#		chomp(@settings = <FILE>);
#		unlock(FILE);
#		close(FILE);

#		$settings[11]++;

#		open(FILE, ">$memberdir/$username.dat");
#		lock(FILE);
#		for ($i = 0; $i < @settings; $i++) {
#			print FILE "$settings[$i]\n";
#		}
#		unlock(FILE);
#		close(FILE);
#	}
#	}

	else {
		open (FILE, "$topicsdir/newarticles.dat");
		@articles = <FILE>;
		close (FILE);

		($num, $dummy, $dummy, $dummy, $dummy, $dummy, $dummy, $dummy, ) = split(/\|/, $articles[0]);
		$num++;

		open(FILE, ">$topicsdir/newarticles.dat");
		lock(FILE);
		print FILE "$num|$input{'cat'}|$subject|$realname|$username|$realemail|$date|$message|$input{'showfp'}\n";
		print FILE @articles;
		unlock(FILE);
		close(FILE);
	}

	writelog ("Post News");

	success();
}

##############
sub viewnews {
##############
	undef @catnames;
	undef @catlinks;

	open(FILE, "$topicsdir/cats.dat") || error("$err{'001'} $topicsdir/cats.dat");
	chomp(@cats = <FILE>);
	close(FILE);

	foreach (@cats) {
		@item = split(/\|/, $_);
		push(@catnames, $item[0]);
		push(@catlinks, $item[1]);
	}

	if ($info{'id'} eq "") {
		$navbar = " ";
		print_top();
		print $welcome;

		%data = ();

BLOCKED:	foreach $curcat (@catlinks) {
			if (-e("$topicsdir/$curcat.cat")) {
				foreach (@cats) {
					@item = split(/\|/, $_);
					if ($curcat eq "$item[1]") { $curcatname = "$item[0]"; }
				}

				open(FILE, "$topicsdir/$curcat.cat");
				chomp(@articles = <FILE>);
				close(FILE);

				for ($a = 0; $a < @articles && $a <= $maxnews; $a++) {
					($id, $subject, $nick, $poster, $email, $postdate, $comments) = split(/\|/, $articles[$a]);

					if ($comments == 1) { $commentscnt = "$comments $msg{'040'}"; }
					else { $commentscnt = "$comments $msg{'041'}"; }

					open (FILE, "$topicsdir/articles/$id.dat");
					@artconf = <FILE>;
					close (FILE);

					($showfp, $reserve1, $reserve2, $reserve3) = split(/\|/, $artconf[0]);
					if ($showfp eq 0) { next BLOCKED; }

					else {
						open (FILE, "$topicsdir/articles/$id.txt");
						chomp($text = <FILE>);
						close(FILE);
					}

					@text = split(/\|/, $text);
					$message = $text[5];
					if ($enable_ubbc) { doubbc(); }

					$post = qq~<hr noshade="noshade" size="1">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td class="texttitle"><b>$subject</b></td>
</tr>
<tr>
<td class="textsmall">$curcatname: $postdate $msg{'042'} <a href="mailto:$email">$nick</a></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td valign="top">
~;
					if (length($message) > 250) {
						$tmpmessage = substr($message, 0, 250);
						$tmpmessage =~ s/(.*)\s.*/$1/;
						$post = qq~$post<img src="$imagesurl/topics/$curcat.gif" border="0" align="right" vspace="5" alt="$curcatname">
$tmpmessage ...
</td>
</tr>
<tr>
<td align="right">[<a href="$pageurl/$cgi?action=viewnews&amp;id=$id">$nav{'025'}</a>] | [<a href="$pageurl/$cgi?action=viewnews&amp;id=$id">$commentscnt</a>]</td>
</tr>
</table>
~;
					}
					else {
						$post = qq~$post<img src="$imagesurl/topics/$curcat.gif" border="0" align="right" vspace="5" alt="$curcatname">
$message
</td>
</tr>
<tr>
<td align="right">[<a href="$pageurl/$cgi?action=viewnews&amp;id=$id">$commentscnt</a>]</td>
</tr>
</table>
~;
					}
					($date, $time) = split(/ - /, $postdate);
					($day, $month, $year) = split(/\//, $date);
					($hour, $min, $sec) = split (/:/, $time);
					$totaltime = (($year+2000)*365+$month*30+$day)*24*60*60+$hour*60*60+$min*60+$sec;
					$data{$totaltime} = $post;
				}
			}
		}
		@num = sort {$b <=> $a } keys %data;
		$j = 0;
		while ($j < $maxnews) {
			print "$data{$num[$j]}";
			$j++;
		}
		print_bottom();
		exit;
	}
	else {
		if ($info{'id'} !~ /^[0-9]+$/) { error("$err{'006'}" ); }

		foreach $curcat (@catlinks) {
			if (-e("$topicsdir/$curcat.cat")) {

				open(FILE, "$topicsdir/$curcat.cat");
				chomp(@articles = <FILE>);
				close(FILE);

				for ($a = 0; $a < @articles; $a++) {
					($id, $dummy, $dummy, $dummy, $dummy, $dummy, $comments) = split(/\|/, $articles[$a]);
					if ($info{'id'} eq $id) {
						foreach (@cats) {
							@item = split(/\|/, $_);
							if ($curcat eq "$item[1]") { $curcatname = "$item[0]"; }
							if ($curcat eq "$item[1]") { $curcatlink = "$item[1]"; }
						}
						if ($comments == 1) { $commentscnt = "$comments $msg{'040'}"; }
						else { $commentscnt = "$comments $msg{'041'}"; }
					}
				}
			}
		}

		open(FILE, "<$topicsdir/articles/$info{'id'}.txt")|| error("$err{'001'} $topicsdir/articles/$info{'id'}.txt");
		lock(FILE);
		chomp(@datas = <FILE>);
		unlock(FILE);
		close(FILE);

		$navbar = "$admin{'btn2'} $nav{'004'} $admin{'btn2'} $curcatname";
		print_top();

		foreach $line (@datas) { $numshown++; }

		for ($a = 0; $a < 1; $a++) {
			@item = split (/\|/, $datas[$a]);

			$message = $item[5];
			if ($enable_ubbc) { doubbc(); }

			print qq~<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td class="texttitle">$item[0]</td>
</tr>
<tr>
<td class="textsmall">$curcatname: $item[4] $msg{'042'} <a href="mailto:$item[3]">$item[1]</a></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td valign="top"><img src="$imagesurl/topics/$curcatlink.gif" border="0" align="right" vspace="5" alt="$curcatname">
$message</td>
</tr>
</table>
~;
		}
		if ($numshown > 1) {
			print qq~<p align="center" class="cat">$msg{'158'}</p>
$msg{'159'}
~;
			for ($a = 1; $a < @datas; $a++) {
				@item = split (/\|/, $datas[$a]);

				$message = $item[5];
				if ($enable_ubbc) { doubbc(); }

				if (@item == 0) { }
				else {
					print qq~<hr noshade="noshade" size="1">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td class="texttitle">$item[0]</td>
</tr>
<tr>
<td class="textsmall">$item[4] $msg{'042'} <a href="mailto:$item[3]">$item[1]</a></td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td valign="top">$message</td>
</tr>
</table>
~;
				}
			}
		}
		else {
			print qq~<p align="center" class="cat">$msg{'158'}</p>
$msg{'043'}
~;
		}
		if ($username ne "$anonuser") {
			print qq~<hr noshade="noshade" size="1">
<form action="$pageurl/$cgi?action=commentnews" method="post" name="creator">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td align="center" colspan="2" class="cat">$msg{'044'}</td>
</tr>
<tr>
<td>$msg{'013'}</td><td>$realname<input type="hidden" name="name" value="$realname"><input type="hidden" name="email" value="$realemail"></td>
</tr>
<tr>
<td>$msg{'037'}</td><td><input type="text" name="subject" size="40" maxlength="50"></td>
</tr>
<tr>
<td>$msg{'038'}</td><td>
<script language="javascript" type="text/javascript">
<!--
function addCode(anystr) { 
document.creator.message.value+=anystr;
} 
function showColor(color) { 
document.creator.message.value+="[color="+color+"][/color]";
}
// -->
</script>
<textarea name="message" rows="10" cols="40"></textarea></td>
</tr>
<tr>
<td><b>$msg{'156'}</b></td>
<td valign="top"><a href="javascript:addCode('[b][/b]')"><img src="$imagesurl/forum/bold.gif" align="bottom" width="23" height="22" alt="$msg{'117'}" border="0"></a>
<a href="javascript:addCode('[i][/i]')"><img src="$imagesurl/forum/italicize.gif" align="bottom" width="23" height="22" alt="$msg{'118'}" border="0"></a>
<a href="javascript:addCode('[u][/u]')"><img src="$imagesurl/forum/underline.gif" align="bottom" width="23" height="22" alt="$msg{'119'}" border="0"></a>
<a href="javascript:addCode('[center][/center]')"><img src="$imagesurl/forum/center.gif" align="bottom" width="23" height="22" alt="$msg{'120'}" border="0"></a>
<a href="javascript:addCode('[url][/url]')"><img src="$imagesurl/forum/url.gif" align="bottom" width="23" height="22" alt="$msg{'121'}" border="0"></a>
<a href="javascript:addCode('[email][/email]')"><img src="$imagesurl/forum/email2.gif" align="bottom" width="23" height="22" alt="$msg{'122'}" border="0"></a>
<a href="javascript:addCode('[quote][/quote]')"><img src="$imagesurl/forum/quote2.gif" align="bottom" width="23" height="22" alt="$msg{'124'}" border="0"></a>
<a href="javascript:addCode('[list][*][*][*][/list]')"><img src="$imagesurl/forum/list.gif" align="bottom" width="23" height="22" alt="$msg{'125'}" border="0"></a>
<a href="javascript:void(0)" onClick="window.open('$pageurl/$cgi?action=showsmilies','_blank','scrollbars=yes,toolbar=no,height=270,width=270')"><img src="$imagesurl/forum/smilie.gif" align="bottom" width="23" height="22" alt="$msg{'126'}" border="0"></a><br>
<select name="color" onChange="showColor(this.options[this.selectedIndex].value)">
<option value="Black" selected>$msg{'127'}</option>
<option value="Red">$msg{'128'}</option>
<option value="Yellow">$msg{'129'}</option>
<option value="Pink">$msg{'130'}</option>
<option value="Green">$msg{'131'}</option>
<option value="Orange">$msg{'132'}</option>
<option value="Purple">$msg{'133'}</option>
<option value="Blue">$msg{'134'}</option>
<option value="Beige">$msg{'135'}</option>
<option value="Brown">$msg{'136'}</option>
<option value="Teal">$msg{'137'}</option>
<option value="Navy">$msg{'138'}</option>
<option value="Maroon">$msg{'139'}</option>
<option value="LimeGreen">$msg{'140'}</option>
</select>
</td>
</tr>
<tr>
<td colspan="2"><input type="hidden" value="$info{'id'}" name="id">
<input type="hidden" value="$curcatlink" name="cat">
<input type="submit" value="$btn{'012'}"><input type="reset" value="$btn{'009'}"></td>
</tr>
</table>
</form>
~;
		}
		print_bottom();
		exit;
	}
}

#################
sub commentnews {
#################
	if($username eq "$anonuser") { error("$err{'011'}"); }
	error("$err{'014'}") unless ($input{'subject'});
	error("$err{'015'}") unless ($input{'message'});

	open(FILE, "$topicsdir/$input{'cat'}.cat") || error("$err{'001'} $topicsdir/$input{'cat'}.cat");
	lock(FILE);
	chomp(@datas = <FILE>);
	unlock(FILE);
	close(FILE);

	$a = 0;
	while ($datas[$a] ne '') { $a++; }
	$count = $a;
	$i = 0;

	chomp($input{'message'});
	chomp($input{'subject'});

	$subject = htmlescape($input{'subject'});
	$message = htmlescape($input{'message'});

	open(FILE, ">$topicsdir/$input{'cat'}.cat") || error("$err{'016'} $topicsdir/$input{'cat'}.cat");
	lock(FILE);
	while ($i < $count) {
		($id_temp, $subj, $nick, $poster, $email, $postdate, $comments) = split(/\|/, $datas[$i]);

		if ($id_temp eq $input{'id'}) {
			$comments++;
			print FILE "$id_temp|$subj|$nick|$poster|$email|$postdate|$comments\n";
		}
		else { print FILE "$id_temp|$subj|$nick|$poster|$email|$postdate|$comments\n"; }

		$i++;
	}
	unlock(FILE);
	close(FILE);

	open(FILE, ">>$topicsdir/articles/$input{'id'}.txt") || error("$err{'016'} $topicsdir/articles/$input{'id'}.txt");
	lock(FILE);
	print FILE "$subject|$realname|$username|$realemail|$date|$message\n";
	unlock(FILE);
	close(FILE);

	if ($username ne "$anonuser") {
		open(FILE, "$memberdir/$username.dat") || error("$err{'010'}");
		chomp(@settings = <FILE>);
		close(FILE);

		$settings[12]++;

		open(FILE, ">$memberdir/$username.dat");
		lock(FILE);
		for ($i = 0; $i < @settings; $i++) {
			print FILE "$settings[$i]\n";
		}
		unlock(FILE);
		close(FILE);
	}

	writelog ("Comment News");
	print "Location: $pageurl/$cgi?action=viewnews&id=$input{'id'}\n\n";
}

#############
sub success {
#############
	print_top();
	print qq~<b>$nav{'027'}</b><br>
$inf{'009'}
~;
	print_bottom();
	exit;
}

############
sub topics {
############
	open(FILE, "$topicsdir/cats.dat") || error("$err{'001'} $topicsdir/cats.dat");
	chomp(@cats = <FILE>);
	close(FILE);

	if ($info{'viewcat'} eq "") {
		$navbar = "$admin{'btn2'} $nav{'004'}";
		print_top();
		print qq~<table border="0" cellpadding="3" cellspacing="0" width="100%">
<tr>
<td align="center">$msg{'045'}</td>
</tr>
</table>
<br>
<table border="0" cellpadding="3" cellspacing="0" width="100%">
<tr>
~;
		for ($i = 0; $i < @cats; $i++) {
			@item = split (/\|/, $cats[$i]);
			print qq~<td align="center" valign="bottom"><a href="$pageurl/$cgi?action=topics&amp;viewcat=$item[1]"><img src="$imagesurl/topics/$item[1].gif" border="0" alt="$item[0]"></a><br><b>$item[0]</b></td>
~;
			$count++;
			if ($count == 3) {
				print "</tr>\n<tr>\n";
				$count = 0;
		
			}
		}
		print qq~<td colspan="3"></td>
</tr>
</table>
~;
		print_bottom();
		exit;
	}
	else {
		foreach (@cats) {
			@item = split(/\|/, $_);
			if ($info{'viewcat'} eq "$item[1]") { $curcatname = "$item[0]"; }
		}

		$navbar = "$admin{'btn2'} $nav{'004'} $admin{'btn2'} $curcatname";
		print_top();
			print qq~<table align="center" border="0" cellpadding="3" cellspacing="0">
<tr>
<td align="center"><b>$msg{'046'} "$curcatname"</b></td>
</tr>
</table>
<br>
~;

		if (-e("$topicsdir/$info{'viewcat'}.cat")) {
			open (FILE, "<$topicsdir/$info{'viewcat'}.cat");
			lock(FILE);
			chomp(@datas=<FILE>);
			unlock(FILE);
			close(FILE);

			for ($a = 0; $a < @datas; $a++) {
				($tnum[$a], $ttitle[$a], $tposter[$a], $tuser[$a], $temail[$a], $tdate[$a], $tcomments[$a]) = split(/\|/, $datas[$a]);
			}

			print qq~<table border="0" cellpadding="1" cellspacing="0" width="100%">~;
			if ($info{'start'} eq "") { $start = 0; }
			else { $start = "$info{'start'}"; }

			$numshown = 0;
			for ($b = $start; $b < @datas; $b++) {
				$numshown++;

				if ($tcomments[$b] == 1) { $commentscnt = "$tcomments[$b] $msg{'040'}"; }
				elsif ($tcomments[$b] == -1) { $commentscnt = "0 $msg{'041'}"; }
				else { $commentscnt = "$tcomments[$b] $msg{'041'}"; }

				print qq~<tr>
<td><img src="$imagesurl/urlgo.gif" border="0" alt="">&nbsp;&nbsp;<a href="$cgi?action=viewnews&amp;id=$tnum[$b]">$ttitle[$b]</a></td>
</tr>
<tr>
<td>$msg{'047'} $tposter[$b] $msg{'048'} $tdate[$b]</td>
</tr>
<tr>
<td>$curcatname ($commentscnt)</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
~;
				if ($numshown >= $maxtopics) { $b = @datas; }
			}
			print "</table>";
			if ($numshown >= $maxtopics) {
				print qq~<hr noshade="noshade" size="1">
$msg{'039'} 
~;
				$numtopics = @datas;
				$c = 0;
				while (($c*$maxtopics) < $numtopics) {
					$viewc = $c+1;
					$strt = ($c*$maxtopics);
					if ($start == $strt) { print "[$viewc] "; }
					elsif ($strt == 0) { print qq~<a href="$pageurl/$cgi">$viewc</a> ~; }
					else { print qq~<a href="$pageurl/$cgi?action=topics&amp;viewcat=$info{'viewcat'}&amp;start=$strt">$viewc</a> ~; }
					$c++;
				}
			}
		}
		else { }
		print_bottom();
		exit;
	}
}

1; # return true
