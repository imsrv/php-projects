###############################################################################
###############################################################################
# PoaS - Perlonall Site                                                      #
#-----------------------------------------------------------------------------#
# user.pl - handles user registration, login/logout and profile management    #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)                            #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: user.pl, Last modified: 19:11 08/10/2002                              #
###############################################################################
###############################################################################


##############
sub register {
##############
	system_cleanup();
	print_top();
	$navbar = "$admin{'btn2'} $nav{'011'}";
	print qq~<form action="$pageurl/$cgi" method="get">
<table border="0" cellspacing="1">
<tr>
<td><b>$msg{'006'}</b></td>
<td><input type="hidden" name="action" value="regverify"><input type="text" name="username" size="30" maxlength="20"></td>
</tr>
<tr>
<td><b>$msg{'007'}</b></td>
<td><input type="text" name="email" size="30" maxlength="100"></td>
</tr>
<tr>
<td><b>Enter Screen Name</b></td>
<td><input name="screenname" value="">
</td>
</tr>
<tr>
<td><b>Select Gender</b></td>
<td><select name="gender">
<option value="male">Male</option>
<option value="female">Female</option></select>
</td>
</tr>
<tr>
<td><b>Country Origin</b></td>
<td><input name="country" value="">
</td>
</tr>
<tr>
<td colspan="2"><input type="submit" value="$btn{'004'}">
</td>
</tr>
</table>
</form>
~;
	print_bottom();
	exit;
}

################
sub regverify {
################
	error("$err{'003'}") if ($info{'username'} eq "");
	error("$err{'004'}") if ($info{'username'} !~ /^[0-9A-Za-z#%+,-\.:=?@^_]+$/ || $info{'username'} eq "|" || $info{'username'} =~ " " || $info{'username'} =~ /$anonuser/i);
	error("$err{'005'}") if ($info{'email'} eq "");
	error("$err{'007'}") if (-e ("$memberdir/$info{'username'}.dat"));
	error("$err{'006'}") if ($info{'email'} !~ /^[0-9A-Za-z@\._\-]+$/ || $info{'email'} =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|(\.$)/) || ($info{'email'} !~ /\A.+@\[?(\w|[-.])+\.[a-zA-Z]{2,4}|[0-9]{1,4}\]?\Z/);
	error("You must Enter Screen Name") if ($info{'screenname'} eq "");

	$tempsession = time();
	$filesession = $tempsession;
	$dirsession = $tempsession;

	@imagereg = ("Luckie", "Aria", "Argathama", "Minda", "Ratnawulan", "Nur", "Komariah", "Rosada", "Ratri", "Natarini", "Menik", "Purwitasari");
	$imagesession = rand(@imagereg);
	@chooserand = ("0", "1", "2");
	$randsession = rand(@chooserand);
	if ($randsession eq 1) { @imageregrand = sort(@imagereg); }
	elsif ($randsession eq 2) { @imageregrand = reverse(@imagereg); }
	else { 	@imageregrand = @imagereg; }

	open(SESSION, ">$datadir/temp/register/$filesession.tmp");
	lock(SESSION);
	print SESSION "$info{'username'}|$info{'email'}|$info{'screenname'}|$info{'gender'}|$info{'country'}|@imageregrand[$imagesession]\n";
	unlock(SESSION);
	close(SESSION);

	open(SESSION, "$imagesdir/session/$imageregrand[$imagesession].gif") || error ("Can't open $imagesdir/session/$imageregrand[$imagesession].gif");
	@imageverify = <SESSION> ;
	close(SESSION);

	open(SESSION, ">$imagesdir/temp/$filesession.gif");
	lock(SESSION);
	print SESSION @imageverify;
	unlock(SESSION);
	close(SESSION);

	print "Location: $pageurl/$cgi\?action=regverify2\&code=$filesession\n\n";

}

#################
sub regverify2 {
#################
	if ($info{'code'} eq "") { error("You can't call this page directly!"); }
	$checktimereg = $info{'code'} + 1800;
	$currentregtime = time();
	if ($checktimereg < $currentregtime) {
		unlink("$datadir/temp/register/$info{'code'}.tmp");
		unlink("$imagesdir/temp/$info{'code'}.gif");
		error("You just run out this session, please try to register again");
	}
  
	if (!open(REGTEMP, "$datadir/temp/register/$info{'code'}.tmp")) {
		unlink("$imagesdir/temp/$info{'code'}.gif");
		error("Your session are broken, please try to register again (open data file temp)");
	}
	else { close(REGTEMP); }

	if (!open(REGTEMP, "$imagesdir/temp/$info{'code'}.gif")) {
		unlink("$datadir/temp/$info{'code'}.tmp");
		error("Your session are broken, please try to register again");
	}
	else { close(REGTEMP); }

	open(REG, "$datadir/temp/register/$info{'code'}.tmp");
	@regvalue = <REG>;
	close(REG);

	($uname, $umail,$usname, $ugender, $ucountry, $uregimage) = split(/\|/, $regvalue[0]);
	$navbar = "$admin{'btn2'} Register";

	print_top();
	print qq~ <center><b><big><big>USER REGISTRATION</big></big></b></center><p><br>
		This is user registration info you have entered :<br>
		Username : <b>$uname</b><br>
		Email	 : <b>$umail</b><br>
		Screen Name : <b>$usname</b><br>
		Gender	 : <b>$ugender</b><br>
		Country  : <b>$ucountry</b><p>
		Please enter verification word in the next image and press Verify button<br>
		<img src="$imagesurl/temp/$info{'code'}.gif" alt=""><br>
		<form action="$pageurl/$cgi\?action=register2" method="POST">
		<input type="hidden" name="code" value="$info{'code'}">
		<input name="verifycode" value=""><input type="submit" value="Verify"></form>
	~;
	print_bottom();
}

###############
sub register2 {
###############
#	error("$err{'003'}") if ($input{'username'} eq "");
#	error("$err{'004'}") if ($input{'username'} !~ /^[0-9A-Za-z#%+,-\.:=?@^_]+$/ || $input{'username'} eq "|" || $input{'username'} =~ " " || $input{'username'} =~ /$anonuser/i);
#	error("$err{'005'}") if ($input{'email'} eq "");
#	error("$err{'006'}") if ($input{'email'} !~ /^[0-9A-Za-z@\._\-]+$/ || $input{'email'} =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|(\.$)/) || ($input{'email'} !~ /\A.+@\[?(\w|[-.])+\.[a-zA-Z]{2,4}|[0-9]{1,4}\]?\Z/);
#	error("$err{'007'}") if (-e ("$memberdir/$input{'username'}.dat"));

	error("You can't call this page directly!") if ($input{'code'} eq "");
	$checktimereg = $input{'code'} + 1800;
	$currentregtime = time();
	if ($checktimereg < $currentregtime) {
		unlink("$datadir/temp/$input{'code'}.tmp");
		unlink("$imagesdir/temp/$input{'code'}.gif");
		print_top();
		error("You just run out this session, please try to register again");
		print_bottom();
	}

	if (!open(REGTEMP, "$datadir/temp/register/$input{'code'}.tmp")) {
		unlink("$imagesdir/temp/$input{'code'}.gif");
		print_top();
		error("Your session are broken, please try to register again (data file temp)");
		print_bottom();
	}
	else { close(REGTEMP); }

	if (!open(REGTEMP, "$imagesdir/temp/$input{'code'}.gif")) {
		unlink("$datadir/temp/register/$input{'code'}.tmp");
		print_top();
		error("Your session are broken, please try to register again (image file temp)");
		print_bottom();
	}
	else {unlink("$imagesdir/temp/$input{'code'}.gif"); close(REGTEMP); }

	open(REG, "$datadir/temp/register/$input{'code'}.tmp");
	chomp(@regvalue = <REG>);
	close(REG);

	($uname, $umail, $usname, $ugender, $ucountry, $uregimage) = split(/\|/, $regvalue[0]);

	if ($input{'verifycode'} ne $uregimage) { 
		unlink("$datadir/temp/register/$input{'code'}.tmp");
		unlink("$imagesdir/temp/$input{'code'}.gif");
		print_top();	
		error("Verification code entered : <b>$input{'verifycode'}</b>, needed: $uregimage doesn't match, registration failed!"); 
		print_bottom();
	}

	srand(time ^ $$);
	my @passset = ('a'..'k', 'm'..'n', 'p'..'z', '2'..'9');
	my $passwrd1 = "";
	for ($i=0; $i<8; $i++) { $passwrd1 .= $passset[int(rand($#passset + 1))]; }

	$passwrd = crypt($passwrd1, substr($uname, 0, 2));

	if ($giveuserspace eq 1) {
	    if (!mkdir("$userspacedir/$uname", 0777))
	      {
		print_top();
		error ("**Failed complete create root user space dir!<br>\n**Aborting.<br>\n");
		print_bottom();
	      };
	    if (!mkdir("$userspacedir/$uname/fileman", 0777))
	      {
		print_top();
		error ("**Failed complete create log user space dir!<br>\n**Aborting.<br>\n");
		print_bottom();
	      };
	    if (!mkdir("$userspacedir/$uname/fileman/pass", 0766))
	      {
		print_top();
		error ("**Failed complete create password user space dir!<br>\n**Aborting.<br>\n");
		print_bottom();
	      };
	    if (!mkdir("$userspacedir/$uname/logs", 0766))
	      {
		print_top();
		error ("**Failed complete create logs dir!<br>\n**Aborting.<br>\n");
		print_bottom();
	      };
	    if (!mkdir("$userspacedir/$uname/logs/counter", 0766))
	      {
		print_top();
		error ("**Failed complete create logs counter dir!<br>\n**Aborting.<br>\n");
		print_bottom();
	      };
	    if (!mkdir("$userspacedir/$uname/logs/stats", 0766))
	      {
		print_top();
		error ("**Failed complete create logs stats dir!<br>\n**Aborting.<br>\n");
		print_bottom();
	      };
	    open(HTML, ">$userspacedir/$uname/index.html") || error ("Failed creating index file");
	    lock(HTML);
	    print HTML "<html><head><title>$uname homepage</title></head>";
	    print HTML "<body><center><big><big>Welcome To My Homepage</big></big><p>";
	    print HTML "Currently I, <b>$uname</b> haven't move in yet.<p>";
	    print HTML "Visit My Homepage again in next few days</center></body></html>";
	    unlock(HTML);
	    close(HTML);

	    open(CNTLOGS, ">$userspacedir/$uname/logs/counter/counter.txt") || error ("Failed creating counter logs file");
            lock(CNTLOGS);
            print CNTLOGS "";
            unlock(CNTLOGS);
            close(CNTLOGS);

	    open(CNTIPLOGS, ">$userspacedir/$uname/logs/stats/ip.log") || error ("Failed creating stat logs file");
            lock(CNTIPLOGS);
            print CNTIPLOGS "";
            unlock(CNTIPLOGS);
            close(CNTIPLOGS);

	    open(CNTIPLOGS, ">$userspacedir/$uname/logs/stats/stats.dat") || error ("Failed creating stat logs file");
            lock(CNTIPLOGS);
            print CNTIPLOGS "";
            unlock(CNTIPLOGS);
            close(CNTIPLOGS);

	};

	open(FILE, ">$memberdir/$uname.dat");
	lock(FILE);
	print FILE "$passwrd\n";
	print FILE "$usname\n";
	print FILE "$umail\n";
	print FILE "\n";
	print FILE "\n";
	print FILE "$msg{'026'}\n";
	print FILE "0\n";
	print FILE "\n";
	print FILE "\n";
	print FILE "\n";
	print FILE "$date\n";
	print FILE "0\n";
	print FILE "0\n";
	print FILE "standard\n";
	print FILE "$ugender|$ucountry\n";
	unlock(FILE);
	close(FILE);

	open(FILE, "$memberdir/memberlist.dat");
	@members = <FILE>;
	close(FILE);

	open(FILE, ">$memberdir/memberlist.dat");
	lock(FILE);
	foreach $curmem (@members) { print FILE "$curmem"; }
	print FILE "$uname\n";
	unlock(FILE);
	close(FILE);

	writelog ("Newbie");

	$subject = "$msg{'008'} $pagename";
	$message = qq~$inf{'002'}
$msg{'006'} $uname
$msg{'009'} $passwrd1
~;
	sendemail($umail, $subject, $message, $master_email);

	$navbar = "$nav{'011'}";
	print_top();
	print qq~<table align="center" border="0" cellspacing="1">
<tr>
<td>
$inf{'003'} <b>$umail</b><br>
$inf{'004'}
</td>
</tr>
</table>
~;
	print_bottom();
	exit;
}

###########
sub login {
###########
	print_top();
	$navbar = "$admin{'btn2'} $nav{'012'}";
	print qq~<form method="post" action="$pageurl/$cgi?action=login2">
<table border="0" cellspacing="1">
<tr>
<td>$msg{'006'}</td>
<td><input type="text" name="username" size="8"></td>
</tr>
<tr>
<td>$msg{'009'}</td>
<td><input type="password" name="passwrd" size="8"></td>
</tr>
<tr>
<td colspan="2"><input type="submit" value="$btn{'017'}"></td>
</tr>
<tr>
<td colspan="2"><br><a href="$pageurl/$cgi?action=reminder">$nav{'014'}</a></td>
</tr>
</table>
</form>
~;
	print_bottom();
	exit;
}

############
sub login2 {
############
	error("$err{'003'}") if ($input{'username'} eq "");
	error("$err{'009'}") if ($input{'passwrd'} eq "");
	error("$err{'006'}") if ($input{'username'} !~ /^[0-9A-Za-z#%+,-\.:=?@^_]+$/ || $input{'passwrd'} !~ /^[0-9A-Za-z!@#$%\^&*\(\)_\+|`~\-=\\:;'",\.\/?\[\]\{\}]+$/);
	
	if (-e("$memberdir/$input{'username'}.dat")) {
		open(FILE, "$memberdir/$input{'username'}.dat");
		@settings = <FILE>;
		close(FILE);

		for( $i = 0; $i < @settings; $i++ ) {
			$settings[$i] =~ s~[\n\r]~~g;
		}
		$passwrd = crypt($input{'passwrd'}, substr($input{'username'}, 0, 2));
		if ($settings[0] ne $passwrd) { error("$err{'002'}"); }
	}
	else { error("$err{'010'}"); }

	print qq~Set-Cookie: $cookieusername=$input{'username'}; path=/; expires=$cookie_expdate;\n~;
	print qq~Set-Cookie: $cookiepassword=$passwrd; path=/; expires=$cookie_expdate;\n~;
	print qq~Set-Cookie: $cookieusertheme=$settings[13]; path=/; expires=$cookie_expdate;\n~;
	print qq~Set-Cookie: $cookieuserclang=$userclang; path=/; expires=$cookie_expdate;\n~;

	$username = $input{'username'};
	$password = $passwrd;
	$usertheme = $settings[13];
	loaduser();
	logvisitors();
	welcome($username);
	writelog ("Login");
}

############
sub logout {
############
        open(LOG, "$datadir/log.dat");
        @entries = <LOG>;
        close(LOG);

        open(LOG, ">$datadir/log.dat");
        lock(LOG);
	$field="$username";
        foreach $curentry (@entries) {
                $curentry =~ s/\n//g;
     		($name, $value, $userlanguage) = split(/\|/, $curentry);
                if($name ne "$field") {
                        print LOG "$curentry\n";
                }
        }
        unlock(LOG);
        close(LOG);

	print qq~Set-Cookie: $cookieusername=; path=/; expires=Tue, 01-Jan-1980 00:00:00 GMT;\n~;
	print qq~Set-Cookie: $cookiepassword=; path=/; expires=Tue, 01-Jan-1980 00:00:00 GMT;\n~;
	print qq~Set-Cookie: $cookieusertheme=; path=/; expires=Tue, 01-Jan-1980 00:00:00 GMT;\n~;
	print qq~Set-Cookie: $cookieuserclang=; path=/; expires=Tue, 01-Jan-1980 00:00:00 GMT;\n~;

	$username = "$anonuser";
	$password = "";
	$usertheme = "standard";
	@settings = ();
	$realname = "";
	$realemail = "";
	$ENV{'HTTP_COOKIE'} = "";

	writelog ("Logout");
	logvisitors();
	byebye();
}

##############
sub redirect {
##############
	my $username = @_;
	if ($username) { welcome($username); }
	else { print_main(); }
}

##############
sub reminder {
##############
	print_top();
	$navbar = "$admin{'btn2'} $nav{'015'}";
	print qq~<form method="post" action="$pageurl/$cgi?action=reminder2">
<table border="0" cellspacing="1">
<tr>
<td>$msg{'006'} <input type="text" name="username"><input type="submit" value="$btn{'005'}"></td>
</tr>
</table>
</form>
~;
	print_bottom();
	exit;
}

###############
sub reminder2 {
###############
#	if ($input{'username'} eq "") { error ("$err{'003'}"); }

#	open(FILE, "$memberdir/$input{'username'}.dat") || error("$err{'010'}");
#	chomp(@settings = <FILE>);
#	close(FILE);

#	for ($i = 0; $i < @settings; $i++) { $settings[$i] =~ s~[\n\r]~~g; }

#	srand(time ^ $$);
#	my @passset = ('a'..'k', 'm'..'n', 'p'..'z', '2'..'9');
#	my $passwrd1 = "";
#	for ($i=0; $i<8; $i++) { $passwrd1 .= $passset[int(rand($#passset + 1))]; }

#	$newpasswrd = crypt($passwrd1, substr($input{'username'}, 0, 2));

#	open(FILE, ">$memberdir/$input{'username'}.dat");
#	lock(FILE);
#	print FILE "$newpasswrd\n";
#	for ($i = 1; $i < @settings; $i++) { print FILE "$settings[$i]\n"; }
#	unlock(FILE);
#	close(FILE);
require "$sourcedir/security.pl";

	log_change_pass_req();

	$curr_time = time();
	$log_change_time = $curr_time + (3600 * 48);

	$subject = "$pagename - $msg{'010'} $settings[1]";
	$message = qq~Hai, \n you or someone from $ENV{'REMOTE_ADDR'}  \n
has requested for password change.
Use link/address bellow to change your password : \n
$pageurl/$cgi\?action=changepass&code=$log_change_time \n
You have 2 days to use link/address above for password changes

~;
	sendemail($settings[2], $subject, $message, $master_email);

	$navbar = "$admin{'btn2'} $nav{'015'}";
	print_top();
	print qq~Password change confirmation has been sent to <b>$settings[2]</b>~;
	print_bottom();
	exit;
}

#############
sub welcome {
#############
	open(FILE, "$memberdir/$username.dat") || error("$err{'010'} in sub welcome");
	chomp(@memsettings = <FILE>);
	close(FILE);

	if ($memsettings[9] eq "") { $memsettings[9] = "_nopic.gif"; }
	if ($memsettings[9] =~ /^\http:\/\// ) {
		if ($memberpic_width ne 0) { $tmp_width = qq~width="$memberpic_width"~; } 
		else { $tmp_width = ""; }
		if ($memberpic_height ne 0) { $tmp_height = qq~height="$memberpic_height"~; } 
		else { $tmp_height = ""; }
		$memberpic = qq~<img src="$memsettings[9]" $tmp_width $tmp_height border="0" alt=""></a>~;
	}
	else {
		$memberpic = qq~<img src="$imagesurl/avatars/$memsettings[9]" border="0" alt=""></a>~;
	}

	$navbar = "";
	print_top();
	print qq~<p class="texttitle">$memsettings[1], $msg{'163'}</p>
<b><u>$msg{'164'}</u></b><br>
<table>
<td valign="top">
<table>
<tr>
<td><b>$msg{'007'}</b></td>
<td><a href="mailto:$memsettings[2]">$memsettings[2]</a></td>
</tr>
<tr>
<td><b>$msg{'014'}</b></td>
<td><a href="$memsettings[4]" target="_blank">$memsettings[3]</a></td>
</tr>
<tr>
<td><b>$msg{'016'}</b></td>
<td>$memsettings[8]</td>
</tr>
<tr>
<td><b>$msg{'021'}</b></td>
<td>$memsettings[6]</td>
</tr>
<tr>
<td><b>$msg{'022'}</b></td>
<td>$memsettings[11]</td>
</tr>
<tr>
<td><b>$msg{'023'}</b></td>
<td>$memsettings[12]</td>
</tr>
</table>
</td>
<td>$memberpic</td>
</tr>
</table>
<br>
<b><u>$msg{'165'}</u></b><br>
<table>
<tr>
<td><a href="$pageurl/$cgi?action=editprofile&amp;username=$username">$nav{'016'}</a><br>
<a href="$pageurl/$cgi?action=uploadavatar&username=$username">Upload Avatar</a><br>
<a href="$pageurl/$cgi?action=logout">$nav{'034'}</a><br></td>
</tr>
</table>
~;
	print_bottom;
	exit;
}

############
sub byebye {
############
	print_top();
	$navbar = "$admin{'btn2'} User Logged Out";
	print qq~$inf{'017'}<br>
<a href="$pageurl/$cgi">$nav{'052'}</a>~;
	print_bottom;
	exit;
}

#################
sub editprofile {
#################
require "$sourcedir/security.pl";
	check_hash($info{'username'});
	if ($info{'username'} =~ /\\/){ error("$err{'004'}" ); }
	if ($username ne $info{'username'} && $settings[7] ne "$root") { hack_attempt(); }
	if ($info{'username'} eq "admin") 
		{
			if ($admin_ip ne "") {
				if ($ENV{'REMOTE_ADDR'} ne "$admin_ip") { hack_attempt(); error("Unauthorized access detected!! Get out from my system NOW!!!"); }
			}
		}

	open(FILE, "$memberdir/$info{'username'}.dat") || error("$err{'010'}");
	chomp(@memsettings = <FILE>);
	close(FILE);

	$signature = "$memsettings[5]";
	$signature =~ s/\&\&/\n/g;

	if ($settings[0] ne "$memsettings[0]" && $settings[7] ne "$root") { error("$err{'011'}"); }

	$navbar = "$admin{'btn2'} $nav{'016'}";
	print_top();
	print qq~<table border="0" cellspacing="1">
<tr>
<td><form action="$pageurl/$cgi?action=editprofile2" method="post" name="creator">
<table border="0">
<tr>
<td><b>$msg{'006'}</b></td>
<td><input type="hidden" name="username" value="$info{'username'}">$info{'username'}</td>
</tr>~;
	if ($username eq "admin") { print qq~
<tr>
<td><b>$msg{'009'}</b></td>
<td><input type="password" name="passwrd1" size="20" value="$memsettings[0]">*</td>
</tr>
<tr>
<td><b>$msg{'009'}</b></td>
<td><input type="password" name="passwrd2" size="20" value="$memsettings[0]">*</td>
</tr>~; }
	print qq~
<tr>
<td><b>$msg{'013'}</b></td>
<td><input type="text" name="name" size="40" value="$memsettings[1]">*</td>
</tr>
<tr>
<td><b>$msg{'007'}</b></td>
<td><input type="text" name="email" size="40" value="$memsettings[2]">*</td>
</tr>
<tr>
<td><b>$msg{'014'}</b></td>
<td><input type="text" name="websitetitle" size="40" value="$memsettings[3]"></td>
</tr>
<tr>
<td><b>$msg{'015'}</b></td>
<td><input type="text" name="websiteurl" size="40" value="$memsettings[4]"></td>
</tr>
<tr>
<td><b>$msg{'016'}</b></td>
<td><input type="text" name="icq" size="40" value="$memsettings[8]"></td>
</tr>
<tr>
<td valign="top"><b>$msg{'017'}</b></td>
<td><textarea name="signature" rows="4" cols="35" wrap="virtual">$signature</textarea></td>
</tr>
<tr>
<td valign="top"><b>$msg{'161'}</b></td>
<td><select name="theme">
~;
	opendir(TDIR, "$themesdir");
	@themes = readdir(TDIR);
	closedir(TDIR);
	chomp(@themes);

	foreach $line (@themes) {
		next if($line eq ".");
		next if($line eq "..");
		if(!opendir(TDIR, "$themesdir/$line")) { next; }
		else { closedir(TDIR); }

		$themename = uc($line);
		print qq~<option value="$line" selected>$themename</option>\n~;

	}

	print qq~<option value="$usertheme" selected>$usertheme</option>\n~;
	print qq~</select>
</td>
</tr>
~;
	opendir(DIR, "$imagesdir/avatars");
	@contents = readdir(DIR);
	closedir(DIR);

	$images = "";
	if ($memsettings[9] eq "") { $memsettings[9] = "_nopic.gif"; }
	foreach $line (sort @contents) {
		($name, $extension) = split (/\./, $line);
		$checked = "";
		if ($line eq $memsettings[9]) { $checked = " selected"; }
		if ($memsettings[9] =~ m~\Ahttp://~ && $line eq "") { $checked = " selected"; }
		if ($extension =~ /gif/i || $extension =~ /jpg/i || $extension =~ /jpeg/i || $extension =~ /png/i ) {
			if ($line eq "_nopic.gif") { 
				$name = ""; 
				$pic = "_nopic.gif";
			}
			$images .= qq~<option value="$line"$checked>$name</option>\n~;
		}
	}
	if ($memsettings[9] =~ m~\Ahttp://~) {
		$pic = "$memsettings[9]";
		$checked = " checked";
		$tmp = $memsettings[9];
	}
	else {
		$pic = "$imagesurl/avatars/$memsettings[9]";
		$tmp = "http://";
	}	

	opendir(DIRMPIC, "$imagesdir/memberpics");
	@contentsmpic = readdir(DIRMPIC);
	closedir(DIRMPIC);

	foreach $linempic (sort @contentsmpic) {
		($namempic, $extensionmpic) = split (/\./, $linempic);
		if ($namempic eq $username) {
			$pic = "$imagesurl/memberpics/$linempic";
		}
		else {}
	}

	print qq~<tr>
<td valign="top"><b>$msg{'018'}</b></td>
<td valign="top">
<table>
<tr>
<td>$msg{'012'}</td>
</tr>
<tr>
<td><script language="javascript" type="text/javascript">
<!--
function showImage() {
document.images.avatars.src="$imagesurl/avatars/"+document.creator.memberpic.options[document.creator.memberpic.selectedIndex].value;
}
// -->
</script>
<select name="memberpic" onChange="showImage()" size="6">
$images</select>
<img src="$pic" name="avatars" border="0" hspace="15"></td>
</tr>
<tr>
<td>$msg{'020'}</td>
</tr>
<tr>
<td><input type="checkbox" name="memberpicpersonalcheck"$checked>
<input type="text" name="memberpicpersonal" size="40" value="$tmp"><br>
$msg{'019'}</td>
</tr>
</table>
</td>
</tr>
~;

	open(FILE, "$memberdir/membergroups.dat");
	@groups = <FILE>;
	close(FILE);
	@userlevel = (Administrator, Moderator, User);
	my @levelusers = @userlevel[0..2];

	if ($settings[7] eq $root) {
		$position = "";
#		if ($memsettings[7] eq "") { $position = qq~$position<option value="$line" selected>$line</option>\n~; }
		if ($memsettings[7] eq "") {
		foreach $line (@levelusers) {
			$line =~ s/[\n\r]//g;
			if ($memsettings[7] eq $line) { $position .= qq~$position<option value="$line" selected>$line</option>\n~; }
			else { $position .= qq~$position<option value="$line">$line</option>\n~; }
		}
			$position .= qq~$position<option value="" selected>$levelusers[2]</option>\n~; 
		}
		else {
			foreach $line (@levelusers[0..2]) {
				$line =~ s/[\n\r]//g;
				if ($memsettings[7] eq $line) { $position = qq~$position<option value="$line" selected>$line</option>\n~; }
				else { $line = qq~$line<option value="$line">$line</option>\n~; }
			}
			$line = qq~$line<option value="">$levelusers[2]</option>\n~; 
		}		

		print qq~<tr>
<td><b>$msg{'021'}</b></td>
<td><input type="text" name="settings6" size="4" value="$memsettings[6]"></td>
</tr>
<tr>
<td><b>$msg{'022'}</b></td>
<td><input type="text" name="settings11" size="4" value="$memsettings[11]"></td>
</tr>
<tr>
<td><b>$msg{'023'}</b></td>
<td><input type="text" name="settings12" size="4" value="$memsettings[12]"></td>
</tr>
<tr>
<td><b>$msg{'024'}</b></td>
<td><select name="settings7">
$position</select></td>
</tr>
<tr>
<td colspan="2">* $msg{'025'}</td>
</tr>
<tr>
<td colspan="2"><input type="hidden" name="settings8" value="$memsettings[8]">
<input type="hidden" name="settings10" value="$memsettings[10]">
~;
	}
	else {
		print qq~<tr>
<td colspan="2">* $msg{'025'}</td>
</tr>
<tr>
<td colspan="2"><input type="hidden" name="settings6" value="$memsettings[6]">
<input type="hidden" name="settings7" value="$memsettings[7]">
<input type="hidden" name="settings8" value="$memsettings[8]">
<input type="hidden" name="settings10" value="$memsettings[10]">
<input type="hidden" name="settings11" value="$memsettings[11]">
<input type="hidden" name="settings12" value="$memsettings[12]">
<input type="hidden" name="settings13" value="$memsettings[13]">
<input type="hidden" name="settings14" value="$memsettings[14]">
~;
	}
	print qq~<input type="submit" name="moda" value="$btn{'006'}">
<input type="submit" name="moda" value="$btn{'007'}"></form> 
<form method="post" action="$pageurl/$cgi?action=uploadavatar">
<input type="submit" value="Upload Avatar"></form>
<form method="post" action="$pageurl/$cgi?action=reminder">
<input type="submit" value="Change Password"></form>
</td>
</tr>
</table>
</td>
</tr>
</table>
~;
	print_bottom();
	exit;
}

##################
sub editprofile2 {
##################
require "$sourcedir/security.pl";

	check_hash($input{'username'});
	if ($input{'username'} =~ /\\/) { error("$err{'004'}" ); }
	if (length($input{'name'}) > 20) { hack_attempt(); error("User Screen name must not more than 20 char"); }
	if ($username eq "admin") {
		if ($input{'passwrd1'} ne "$input{'passwrd2'}") { error("$err{'012'}"); }
		if ($input{'passwrd1'} eq "") { error("$err{'009'}"); }
	}
	if ($input{'name'} eq "") { error("$err{'013'}"); }
	if ($input{'username'} eq $input{'name'}) { error("Screen name must not equal to login name"); }
	if ($input{'name'} !~ /^[0-9A-Za-z#%+,-\.:=?@^_]+$/ || $input{'name'} eq "|" || $input{'name'} =~ " " || $input{'name'} =~ /$anonuser/i) { error("$err{'006'}"); }
	if ($input{'email'} eq "") { error("$err{'005'}"); }

	if ($input{'username'} eq "admin") { 
		if($admin_ip ne "") {
			if ($ENV{'REMOTE_ADDR'} ne $admin_ip) {hack_attempt(); error("Unauthorized Access from $ENV{'REMOTE_ADDR'}!! Get out from my system NOW!!"); }
		}
	}
	if ($input{'settings7'} eq "Administrator") { if ($username ne "admin") { hack_attempt(); error("You are not Authorized for this action");} }
	if ($input{'username'} ne $username) { check_user_permission(); }
	if ($input{'memberpicpersonalcheck'} && ( $input{'memberpicpersonal'} =~ m/\.gif\Z/i || $input{'memberpicpersonal'} =~ m/\.jpg\Z/i || $input{'memberpicpersonal'} =~ m/\.jpeg\Z/i || $input{'memberpicpersonal'} =~ m/\.png\Z/i ) ) {
		$input{'memberpic'} = $input{'memberpicpersonal'};
	}
	if ($input{'memberpic'} !~ m^\A[0-9a-zA-Z_\.\#\%\-\:\+\?\$\&\~\.\,\@/]+\Z^) { error("$err{'006'}"); }

	open(FILE, "$memberdir/$input{'username'}.dat") || error("$err{'010'}");
	chomp(@memsettings = <FILE>);
	close(FILE);

	if ($username eq "admin") {
		if ($input{'passwrd1'} eq $memsettings[0]) { $passwrd = $input{'passwrd1'}; }
		else { $passwrd = crypt($input{'passwrd1'}, substr($input{'username'}, 0, 2)); }
	}
	else {$passwrd = $memsettings[0];}

	if ($input{'moda'} eq "$btn{'006'}") {
		open(FILE, ">$memberdir/$input{'username'}.dat") || error("$err{'016'} $input{'username'}.dat in sub editprofile2");
		lock(FILE);
		print FILE "$passwrd\n";
		print FILE "$input{'name'}\n";
		print FILE "$input{'email'}\n";
		print FILE "$input{'websitetitle'}\n";
		print FILE "$input{'websiteurl'}\n";
		if ($input{'signature'} eq "") { $input{'signature'} = "$msg{'026'}"; }
		$input{'signature'} =~ s/\n/\&\&/g;
		$input{'signature'} =~ s/\r//g;
		print FILE "$input{'signature'}\n";
		print FILE "$input{'settings6'}\n";
		print FILE "$input{'settings7'}\n";
		print FILE "$input{'icq'}\n";
		print FILE "$input{'memberpic'}\n";
		print FILE "$input{'settings10'}\n";
		print FILE "$input{'settings11'}\n";
		print FILE "$input{'settings12'}\n";
		print FILE "$input{'theme'}\n";
		print FILE "$input{'settings14'}\n";
		unlock(FILE);
		close(FILE);

		open(FILE, "$memberdir/$input{'username'}.dat");
		@settings = <FILE>;
		close(FILE);

		for( $i = 0; $i < @settings; $i++ ) {
			$settings[$i] =~ s~[\n\r]~~g;
		}
		$username = $input{'username'};
		$password = $settings[0];
		$usertheme = $settings[13];

		if ($input{'username'} eq $username) {
			$password = $passwrd;
			print qq~Set-Cookie: $cookieusername=$username; path=/; expires=$cookie_expdate;\n~;
			print qq~Set-Cookie: $cookiepassword=$password; path=/; expires=$cookie_expdate;\n~;
			print qq~Set-Cookie: $cookieusertheme=$usertheme; path=/; expires=$cookie_expdate;\n~;
			print qq~Set-Cookie: $cookieuserclang=$userclang; path=/; expires=$cookie_expdate;\n~;
		}

		loaduser();
		logvisitors();
		writelog("Change Profile");
		welcome($username);
	} 
	else {
		unlink("$memberdir/$input{'username'}.dat");
		unlink("$memberdir/$input{'username'}.msg");
		unlink("$memberdir/$input{'username'}.log");

		open(FILE, "$memberdir/memberlist.dat");
		chomp(@members = <FILE>);
		close(FILE);

		open(FILE, ">$memberdir/memberlist.dat");
		lock(FILE);
		foreach $curmem (@members) {
			if ($curmem ne $input{'username'}) { print FILE "$curmem\n"; }
		}
		unlock(FILE);
		close(FILE);

        	open(LOG, "$datadir/log.dat");
        	@entries = <LOG>;
        	close(LOG);

        	open(LOG, ">$datadir/log.dat");
        	lock(LOG);
 		$field="$username";
        	foreach $curentry (@entries) {
                	$curentry =~ s/\n//g;
       			($name, $value, $userlanguage) = split(/\|/, $curentry);
                	if($name ne "$field") {
                        	print LOG "$curentry\n";
                	}
        	}
        	unlock(LOG);
        	close(LOG);

		if ($input{'username'} eq $username) { 
			print qq~Set-Cookie: $cookieusername=; path=/; expires=Tue, 01-Jan-1980 00:00:00 GMT;\n~;
			print qq~Set-Cookie: $cookiepassword=; path=/; expires=Tue, 01-Jan-1980 00:00:00 GMT;\n~;
			print qq~Set-Cookie: $cookieusertheme=; path=/; expires=Tue, 01-Jan-1980 00:00:00 GMT;\n~;
			print qq~Set-Cookie: $cookieuserclang=; path=/; expires=Tue, 01-Jan-1980 00:00:00 GMT;\n~;

			$username = $anonuser;
			$password = "";
			$usertheme = "standard";
			@settings = ();
			$realname = "";
			$realemail = "";
			$ENV{'HTTP_COOKIE'} = "";

			logvisitors();
			byebye(); 
		}
		else { 
			print "Location: $pageurl/$cgi\?action=memberlist\n\n";
		}
	}
	exit;
}

##################
sub viewprofile {
##################
	if ($info{'username'} =~ /\//) { error("$err{'004'}"); }
	if ($username eq $anonuser) { error("$err{'011'}"); }

	open(FILE, "$memberdir/$info{'username'}.dat") || error("$err{'010'}");
	chomp(@memsettings = <FILE>);
	close(FILE);

	if ($memsettings[9] eq "") { $memsettings[9] = "_nopic.gif"; }
	if ($memsettings[9] =~ /^\http:\/\// ) {
		if ($memberpic_width ne 0) { $tmp_width = qq~width="$memberpic_width"~; } 
		else { $tmp_width = ""; }
		if ($memberpic_height ne 0) { $tmp_height = qq~height="$memberpic_height"~; } 
		else { $tmp_height = ""; }
		$memberpic = qq~<img src="$memsettings[9]" $tmp_width $tmp_height border="0" alt=""></a>~;
	}
	else {
		$memberpic = qq~<img src="$imagesurl/avatars/$memsettings[9]" border="0" alt=""></a>~;
	}

	opendir(DIRMPIC, "$imagesdir/memberpics");
	@contentsmpic = readdir(DIRMPIC);
	closedir(DIRMPIC);

	foreach $linempic (sort @contentsmpic) {
		($namempic, $extensionmpic) = split (/\./, $linempic);
		if ($namempic eq $username) {
			$memberpic = qq~<img src="$imagesurl/memberpics/$linempic" border="0" alt=""></a>~;
		}
		else {}
	}

	open(FILE, "$memberdir/membergroups.dat");
	@membergroups = <FILE>;
	close(FILE);
	$memberinfo = $memberranks[0];

	$ranking = $memsettings[6]+$memsettings[11]+$memsettings[12];
	if ($ranking > 25) { $memberinfo = $memberranks[1]; }
	if ($ranking > 50) { $memberinfo = $memberranks[2]; }
	if ($ranking > 75) { $memberinfo = $memberranks[3]; }
	if ($ranking > 100) { $memberinfo = $memberranks[4]; }
	if ($ranking > 250) { $memberinfo = $memberranks[5]; }
	if ($ranking > 500) { $memberinfo = $memberranks[6]; }
	if ($memsettings[7] ne "") { $memberinfo = $memsettings[7]; }
	if ($memsettings[7] eq $root) { $memberinfo = $levelusers[0]; }

	$navbar = "$admin{'btn2'} $nav{'017'}";
	print_top();
	print qq~<table border="0" width="100%" cellspacing="1">
<tr>
<td><b>$info{'username'}</b> 
~;
	if (($info{'username'} eq $username) || ($settings[7] eq "$root")) { print qq~[<a href="$pageurl/$cgi?action=editprofile&amp;username=$info{'username'}">$nav{'016'}</a>] [<a href=\"$pageurl/$cgi\?action=uploadavatar\&username=$username\">Upload Avatar</a>]~; }
	if ($info{'username'} ne $username) { print qq~ [<a href="$pageurl/$cgi?action=imsend&amp;to=$info{'username'}">$nav{'018'}</a>]~; }

	print qq~</td>
</tr>
<tr>
<td>
<table border="0">
<tr>
<td><b>$msg{'013'}</b></td>
<td>$memsettings[1]</td>
</tr>
<tr>
<td><b>$msg{'007'}</b></td>
<td><a href="mailto:$memsettings[2]">$memsettings[2]</a></td>
</tr>
<tr>
<td><b>$msg{'014'}</b></td>
<td><a href="$memsettings[4]" target="_blank">$memsettings[3]</a></td>
</tr>
<tr>
<td><b>$msg{'016'}</b></td>
<td>$memsettings[8]</td>
</tr>
<tr>
<td><b>$msg{'021'}</b></td>
<td>$memsettings[6]</td>
</tr>
<tr>
<td><b>$msg{'022'}</b></td>
<td>$memsettings[11]</td>
</tr>
<tr>
<td><b>$msg{'023'}</b></td>
<td>$memsettings[12]</td>
</tr>
<tr>
<td><b>$msg{'024'}</b></td>
<td>$memberinfo</td>
</tr>
<tr>
<td><b>$msg{'027'}</b></td>
<td>$memsettings[10]</td>
</tr>
<tr>
<td valign="top"><b>$msg{'018'}</b></td>
<td>$memberpic</td>
</tr>
</table>
</td>
</tr>
</table>
~;
	print_bottom();
	exit;
}

###################
sub uploadavatar {
###################

$uploadstatus = "$info{'uploadstatus'}<br>"; 

opendir(DIRMPIC, "$imagesdir/memberpics");
@contentsmpic = readdir(DIRMPIC);
closedir(DIRMPIC);

chomp(@contentsmpic);

foreach $linempic (sort @contentsmpic) {
	($namempic, $extensionmpic) = split (/\./, $linempic);
	if ($namempic eq $username) {
		$avatarpic = "$linempic - <a href=\"$pageurl/$cgi\?action=uploadavatar\&command=delete\&username=$username\">Delete</a><br>";
	}
	else { $avatarpic = "Not uploaded (empty)<br>"; }
}

if ($info{'command'} eq "delete") {
	unlink ("$imagesdir/memberpics/$info{'username'}.gif");
	$uploadstatus = "Your uploaded avatar pic has been delete!<br>";
}	

$navbar = "$admin{'btn2'} Upload Avatar";

print_top();
print qq~
<u>Terms of Uploaded Avatar Pic</u><p>
<ul><li> Must use .gif as file extension.
<li> Keep the file under 20Kb in size.
</ul><p>
Your avatar pic file status :<br>
$uploadstatus
$avatarpic
<form method=\"POST\" action=\"$pageurl/admin/avatar/index.cgi\" ENCTYPE=\"multipart/form-data\">
Avatar File: 
<input type=\"hidden\" name=\"username\" value=\"$username\">
<input type=\"file\" name=\"ufile\" size='30'>
<br>
<input type=\"submit\" value=\"Upload!\">
</form>~;
print_bottom();

writelog ("Upload Avatar");
}

1; # return true
