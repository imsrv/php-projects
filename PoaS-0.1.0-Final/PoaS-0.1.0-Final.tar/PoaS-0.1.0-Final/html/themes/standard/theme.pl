###############################################################################
###############################################################################
# header.pl - prints the top of each page                                     #
#                                                                             #
# Copyright (C) 2002 by Luck (perl_oas@yahoo.com)                              #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: header.pl, Last modified: 17:23 04/16/2002			      # ###############################################################################
###############################################################################


#############
sub getvars {
#############
	$titlebg = "#000000";
	$titletext = "#000000";
	$windowbg = "#eeeef8";
	$windowbg2 = "#ffffff";
	$windowbg3 = "#eeeeee";
}

##############
sub menuitem {
##############
	my ($url, $title) = @_;
	print qq~<img src="$themesurl/standard/images/dot.gif">&nbsp;<a href="$pageurl/$cgi\?action=$url" class="menu">$title</a><br>
~;

}

##############
sub menuitem1 {
##############
	my ($url1, $title1) = @_;
	print qq~<img src="$themesurl/standard/images/dot.gif">&nbsp;<a href="$url1" class="menu">$title1</a>
~;

}

###############
sub boxheader {
###############
        my ($width, $title, $titlecolor, $bgcolor) = @_;
	print qq~<table width="149" border="1" cellspacing="2" cellpadding="3" bordercolor="#57A6CC" class=menu_left align="right"><br>
              <tr> 
                <td bgcolor="#C6E7F7"> 
                  <div align="center"><b>$title</b></div>
                </td>
              </tr>
              <tr> 
                <td> 
~;
}

###############
sub boxfooter {
###############
	print qq~</td>
              </tr>
            </table>
~;
}

1; # return true
