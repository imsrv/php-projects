#!/usr/bin/perl

############################################
##                                        ##
##        Account Manager User Signup     ##
##          by CGI Script Center          ##
##  (http://support.cgiscriptcenter.com)  ##
##                                        ##
##              version:  1.030           ##
##         last modified:  08/23/2000     ##
##         copyright (c) 1998 - 2000      ##
##                                        ##
##    latest version is available from    ##
##     http://www.cgiscriptcenter.com     ##
##                                        ##
############################################
#
##############################################################
# EDIT THE VARIABLES BELOW ###################################
##############################################################

require "c:/full/directory/path/to/config.pl";

##############################################################
##############################################################
# COPYRIGHT NOTICE:
#
# Copyright 1998 Diran Alemshah.  All Rights Reserved.
#
# LICENSOR'S PROGRAM IS COPYRIGHTED AND LICENSED (NOT SOLE).
# LICENSOR DOES NOT SELL OR TRANSFER TITLE TO THE LICENSED
# PROGRAM TO YOU. YOUR LICENSE OF THE LICENSED PROGRAM WILL
# NOT COMMENCE UNTIL YOU HAVE EXECUTED THIS AGREEMENT AND AN
# AUTHORIZED REPRESENTATIVE OF LICENSOR HAS RECEIVED, APPROVED,
# AND EXECUTED A COPY OF IT AS EXECUTED BY YOU.
# 1. License Grant.</B> Licensor hereby grants to you, and you
# accept, a nonexclusive license to use the downloaded computer
# programs, object code form only (collectively referred to as
# the &quot;Software&quot;), and any accompanying User Documentation,
# only as authorized in this License Agreement. The Software may be
# used on any website owned by Licensee, or if Licensee is a company
# or corporation, any website owned by Licensee company or corporation.
# You agree that you will not assign, sublicense, transfer, pledge,
# lease, rent, or share your rights under this License Agreement.
# You agree that you may not reverse assemble, reverse compile, or
# otherwise translate the Software<BR> <BR> Upon loading the Software
# into your computer, you may make a copy of the Software for
# backup purposes. You may make one copy of any User's Manual
# provided for backup purposes. Any such copies of the Software
# or the User's Manual shall include Licensor's copyright and other
# proprietary notices. Except as authorized under this paragraph,
# no copies of the Program or any portions thereof may be made by
# you or any person under your authority or control.
# 2. License Fees.  The license fees paid by you are paid
# in consideration of the licenses granted under this License
# Agreement. You are solely responsible for payment of any taxes
# (including sales or use taxes, intangible taxes, and property taxes)
# resulting from your acceptance of this license and your possession
# and use of the Licensed Program, exclusive of taxes based on
# Licensor's income. Licensor reserves the right to have you
# pay any such taxes as they fall due to Licensor for remittance to
# the appropriate authority. You agree to hold harmless Licensor
# from all claims and liability arising from your failure to report
# or pay such taxes.
# 3. This License Agreement is effective upon your submission of this form.
# 4. Limited Warranty. Licensor warrants, for your benefit alone,
# that the Licensed Program conforms in all material respects to
# the specifications for the current version of the Licensed Program.
# This warranty is expressly conditioned on your observance of the
# operating, security, and data-control procedures set forth in the
# User's Manual included with the Licensed Program.
# 
# EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, LICENSOR
# DISCLAIMS ANY AND ALL PROMISES, REPRESENTATIONS, AND WARRANTIES
# WITH RESPECT TO THE LICENSED PROGRAM, INCLUDING ITS CONDITION,
# ITS CONFORMITY TO ANY REPRESENTATION OR DESCRIPTION, THE EXISTENCE
# OF ANY LATENT OR PATENT DEFECTS, ANY NEGLIGENCE, AND ITS
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
# 5. Limitation of Liability.</B> Licensor's cumulative liability
# to you or any other party for any loss or damages resulting
# from any claims, demands, or actions arising out of or relating
# to this Agreement shall not exceed the license fee paid to Licensor
# for the use of the Program. In no event shall Licensor be liable
# for any indirect, incidental, consequential, special, or exemplary
# damages or lost profits, even if Licensor has been advised of the
# possibility of such damages.
# 6. Proprietary Protection. Licensor shall have sole and exclusive
# ownership of all right, title, and interest in and to the Licensed
# Program and all modifications and enhancements thereof (including
# ownership of all trade secrets and copyrights pertaining thereto),
# subject only to the rights and privileges expressly granted to you
# herein by Licensor. This Agreement does not provide you with title
# or ownership of the Licensed Program, but only a right of limited
# use. You must keep the Licensed Program free and clear of all claims,
# liens, and encumbrances.
# 7. Restrictions. You may not use, copy, modify, or distribute the
# Licensed Program (electronically or otherwise), or any copy,
# adaptation, transcription, or merged portion thereof, except as
# expressly authorized by Licensor. You may not reverse assemble,
# reverse compile, or otherwise translate the Licensed Program.
# Your rights may not be transferred, leased, assigned, or sublicensed
# except for a transfer of the Licensed Program in its entirety to
# (1) a successor in interest of your entire business who assumes
# the obligations of this Agreement or (2) any other party who is
# reasonably acceptable to Licensor, enters into a substitute
# version of this Agreement, and pays an administrative fee intended
# to cover attendant costs. No service bureau work, multiple-user
# license, or time-sharing arrangement is permitted, except as
# expressly authorized by Licensor. If you use, copy, or modify
# the Licensed Program or if you transfer possession of any copy,
# adaptation, transcription, or merged portion of the Licensed
# Program to any other party in any way not expressly authorized
# by Licensor, your license is automatically terminated.
# 8. Licensor's Right Of Entry.</B> You hereby authorize Licensor
# to enter your premises in order to inspect the Licensed Program
# in any reasonable manner during regular business hours to verify
# your compliance with the terms hereof.
# 9. Injunctive Relief.</B> You acknowledge that, in the event
# of your breach of any of the foregoing provisions, Licensor
# will not have an adequate remedy in money or damages. Licensor
# shall therefore be entitled to obtain an injunction against such
# breach from any court of competent jurisdiction immediately upon
# request. Licensor's right to obtain injunctive relief shall not
# limit its right to seek further remedies.
# 10. Trademark. COMMISSION CART(TM), ACCOUNT MANAGER(TM), PICLINK
# ADVERTISER(TM), BANDWIDTH PROTECTOR(TM), PC CONFIGURATOR(TM)
# are all trademarks of Licensor. No right, license, or interest
# to such trademark is granted hereunder, and you agree that no
# such right, license, or interest shall be asserted by you with
# respect to such trademark.
# 11. Governing Law.  This License Agreement shall be construed
# and governed in accordance with the laws of the State of California,
# USA.
# 12. Costs of Litigation. If any action is brought by either party
# to this License Agreement against the other party regarding the
# subject matter hereof, the prevailing party shall be entitled
# to recover, in addition to any other relief granted, reasonable
# attorney fees and expenses of litigation.
# 13. Severability. Should any term of this License Agreement be
# declared void or unenforceable by any court of competent
# jurisdiction, such declaration shall have no effect on the
# remaining terms hereof.
# 14. No Waiver. The failure of either party to enforce any
# rights granted hereunder or to take action against the other
# party in the event of any breach hereunder shall not be deemed
# a waiver by that party as to subsequent enforcement of rights
# or subsequent actions in the event of future breaches.
# 15. Integration.  THIS AGREEMENT IS THE COMPLETE AND EXCLUSIVE
# STATEMENT OF LICENSOR'S OBLIGATIONS AND RESPONSIBILITIES TO YOU
# AND SUPERSEDES ANY OTHER PROPOSAL, REPRESENTATION, OR OTHER
# COMMUNICATION BY OR ON BEHALF OF LICENSOR RELATING TO THE
# SUBJECT MATTER HEREOF
#
##############################################################
# DO NOT EDIT BELOW THIS LINE
##############################################################

read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
@pairs = split(/&/, $buffer);
foreach $pair (@pairs) {
	($name, $value) = split(/=/, $pair);
	$value =~ tr/+/ /;
	$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	if ($INPUT{$name}) { $INPUT{$name} = $INPUT{$name}.",".$value; }
	else { $INPUT{$name} = $value; }
      $value =~ s/<!--(.|\n)*-->//g;
}

$version = "1.030";

$cgiurl = $ENV{'SCRIPT_NAME'};

if ($INPUT{'find'}) { &find; } ######### Will search for member info.
if ($INPUT{'process'}) { &sorder; } 
#elsif ($INPUT{'order'}) { &order; }
#elsif ($INPUT{'sorder'}) {&sorder; } 
else {&sorder;}############# IF no button was pressed, run just as 
exit;





sub sorder {


if (($INPUT{'x_response_code'} eq '2') || ($INPUT{'x_avs_code'} eq 'R')) {

unless ($decline_redirect) { 
        
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;

    <CENTER><BR>
    <TABLE BORDER="0" WIDTH="400">
      <TBODY>
      <TR>
        <TD>
        
        <P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT COLOR="#FF0000">Account
          Manager</FONT> Status: Unable To Process</FONT></B></P>
        
        <P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">We
          were unable to receive an authorization from your credit card bank for
          this transaction. You may want to try another credit card or contact
          your bank for details regarding this problem.</FONT></P>
        
        <P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please
          contact <A HREF="mailto:$orgmail">$orgname Support</A> if you need
          any further assistance.</FONT></P>
        <HR SIZE="1">
        <CENTER><FONT SIZE="-2" FACE="verdana,arial,helvetica"> $orgname is maintained
        with <A HREF="http://cgi.elitehost.com"><B>Account Manager
          $version</B></A></FONT> </CENTER> </TD>
      </TR></TBODY>
    </TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

print "Location: $decline_redirect\n\n";
exit;


}


if ($INPUT{'x_response_code'} eq '3') {
print "Content-type: text/html\n\n";
print "$INPUT{'x_response_reason_text'}<BR>";
exit;
}

if ($INPUT{'x_cust_id'}) {
&finish;
} else {
print "Content-type: text/html\n\n";
print<<EOF;
Your account information was not properly processed.<BR><BR>
If you feel you've received this response in error, please contact
our administration at:  $orgmail.
EOF
exit;
}

}

# &add;

sub close {

open (FILE,"$memberinfo/email.txt"); #### Full path name from root.
@closing  = <FILE>;
close(FILE);

$body = "";
 
#    $body .= "To: $INPUT{'x_email'}\n";
#    $body .= "From: $orgmail ($orgname)\n";
#    $body .= "Subject: $sign_up_response\n";
    $body .= "-" x 75 . "\n\n";
    
                            
    foreach $line(@closing) {
    $line =~ s/<FIRST_NAME>/$INPUT{'x_first_name'}/g;
    $line =~s/<LAST_NAME>/$INPUT{'x_last_name'}/g;
    $line =~ s/<USERNAME>/$INPUT{'USER8'}/g;
    $line =~s/<PASSWORD>/$INPUT{'USER9'}/g;
    $line =~s/<ORGNAME>/$orgname/g;
    $line =~s/<ORGMAIL>/$orgmail/g;
    }
                        
    foreach $line(@closing) {
    $body .= "$line";
    }

    $body .="\n\n";

&sendmail("$INPUT{'x_email'}","$orgname","$sign_up_response","$body");
      
 
               

#################################################################
## MAIL BACK TO ADMIN ###########################################
#################################################################

$body = "";
 
#    $body .= "To: $orgmail\n";
#    $body .= "From: $INPUT{'x_email'} ($INPUT{'x_first_name'} $INPUT{'x_last_name'})\n";
#    $body .= "Subject: Account Manager Form Response\n";
    $body .= "-" x 75 . "\n\n";
    
    $body .= "Customer Information\n";
    $body .= "-" x 75 . "\n\n";
    $body .= "Name: $INPUT{'x_first_name'} $INPUT{'x_last_name'}\n";
    $body .= "Address: $INPUT{'x_address'}\n";
    $body .= "Address2: $INPUT{'USER2'}\n";
    $body .= "City: $INPUT{'x_city'}\n";
    $body .= "State: $INPUT{'x_state'}\n";
    $body .= "Zip: $INPUT{'x_zip'}\n";
    $body .= "Country: $INPUT{'x_country'}\n";
    $body .= "Phone: $INPUT{'x_phone'}\n";
    $body .= "Email: $INPUT{'x_email'}\n\n";
    

if ($INPUT{'payment'} eq "cc") {
$INPUT{'payment'} = "Credit Card";
}


    $body .= "Payment Information\n";
    $body .= "-" x 75 . "\n\n";
    $body .= "Form of Payment: $INPUT{'USER6'}\n";

if ($INPUT{'creditcards'}) {
    $body .= "Credit Card: $INPUT{'creditcards'}\n";
}

if ($INPUT{'nameoncard'}) {
    $body .= "Name on Card: $INPUT{'nameoncard'}\n";
}

if ($INPUT{'cardnumber'}) {
    $body .= "Card Number: $INPUT{'cardnumber'}\n";
}

if ($INPUT{'EXPDATE'}) {
    $body .= "Expiration: $INPUT{'EXPDATE'}\n";
}

if ($INPUT{'billingaddress'}) {
    $body .= "Billing Address: $INPUT{'billingaddress'}\n";
}

if ($INPUT{'billingaddress2'}) {
    $body .= "Billing Address2: $INPUT{'billingaddress2'}\n";
}

if ($INPUT{'city'}) {
    $body .= "City: $INPUT{'ccity'}\n";
}

if ($INPUT{'state'}) {
    $body .= "State: $INPUT{'cstate'}\n";
}

if ($INPUT{'zip'}) {
    $body .= "Zip: $INPUT{'czip'}\n\n";
}



    $body .= "Purchase Information\n";
    $body .= "Account: $account_name\n";
    $body .= "Account Setup: \$$setup\n";
    $body .= "Account Monthly: \$$monthly\n";
    if ($INPUT{'acctlength'}) {
    $body .= "Account Length: $INPUT{'acctlength'} days\n";
    }



&sendmail("$orgmail","$INPUT{'x_email'}","$sign_up_response","$body");



      
 
unless ($redirect) { 
        
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
    <TABLE BORDER="0" WIDTH="400">
      <TBODY>
      <TR>
        <TD>
        
        <P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT COLOR="#FF0000">Account
          Manager</FONT> Status: Success!</FONT></B></P>
        
        <P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Your
          account has been created!<BR>
          <BR>
          Please use the following link to gain direct access to our <B><A HREF="$redirect2">Members
            Area</A></B></FONT></P>
        
        <P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please
          contact <A HREF="mailto:$orgmail">$orgname Support</A> if you need
          any further assistance.</FONT></P>
        <HR SIZE="1">
        <CENTER><FONT SIZE='\"-2\"' FACE='\"verdana,'> $orgname is maintained
        with <A HREF='\"http://cgi.elitehost.com\"'><B>Account Manager
          $version</B></A></FONT> </CENTER> </TD>
      </TR></TBODY>
    </TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

print "Location: $redirect\n\n";
exit;


}

#}




# &dupeaddress;
# &dupeaddress2;
# &usertemp;
# &dupepwd;
# &verify;
# exit;

&temp;
exit;
#}





######################################
# Create temp files for Admin approval
######################################

sub temp {

unless ($INPUT{'x_cust_id'}) {
print "Content-type: text/html\n\n";
print<<EOF;
Your account information was not properly processed.<BR><BR>
If you feel you've received this response in error, please contact
our administration at:  $orgmail.
EOF
exit;
}



# First, seed the random number generator
	srand;

	# Then get a random # for which a file name can be created
	$randNum = int(rand(999999));

      

&accounttypes;




#$setup = $one_setup + $two_setup;
#$monthly = $one_monthly + $two_monthly;

$INPUT{'USER8'} =~ s/\W.*//;


$INPUT{'x_first_name'} =~ s/\s+$//;
$INPUT{'x_last_name'} =~ s/\s+$//;



$newline2 = join
("\:",$INPUT{'USER8'},$INPUT{'USER9'},$INPUT{'x_email'},$INPUT{'x_first_name'},$INPUT{'x_last_name'},$setup,$monthly,$INPUT{'USER6'},$INPUT{'x_method'},$INPUT{'nameoncard'},$INPUT{'x_card_num'},$INPUT{'x_exp_date'},$INPUT{'billingaddress'},$INPUT{'billingaddress2'},$INPUT{'x_city'},$INPUT{'x_state'},$INPUT{'x_zip'},$INPUT{'lbill'},$INPUT{'papplied'},$INPUT{'aapplied'},$INPUT{'tbalance'},$INPUT{'tnew'},$INPUT{'tcharges'},$INPUT{'nnew'},$INPUT{'linvoice'},$INPUT{'taxes'},$INPUT{'ccity'},$INPUT{'cstate'},$INPUT{'czip'},$length,$INPUT{'x_address'},$INPUT{'USER2'},$INPUT{'x_phone'},$INPUT{'x_country'},$INPUT{'ibillpincode'},$INPUT{'ibilltransnumber'},$INPUT{'ibillrebill'},0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,$INPUT{'x_response_code'},$INPUT{'x_auth_code'},$INPUT{'x_response_reason_text'},$INPUT{'x_avs_code'},$INPUT{'x_trans_id'},$INPUT{'x_invoice_num'},$INPUT{'x_description'},$INPUT{'x_cust_id'},$INPUT{'x_type'},$INPUT{'USER3'},$INPUT{'USER4'},$INPUT{'USER5'},$INPUT{'USER7'},$INPUT{'USER8'},$INPUT{'USER9'},$INPUT{'USER10'},0);
$newline2 .= "\n";



open(TEMP2, ">$memberinfo/$INPUT{'USER8'}.infotmp") or print "unable to create user info temp file.  Check your directory permission settings";
if ($LOCK_EX){ 
      flock(TEMP2, $LOCK_EX); #Locks the file
	}
print TEMP2 $newline2;
close (TEMP2);

       if ($instantaccess == 1) {

open (FILE, "<$memberinfo/$INPUT{'USER8'}.infotmp");
if ($LOCK_EX){ 
      flock(FILE, $LOCK_EX); #Locks the file
	}
      @approved = <FILE>;
      close (FILE);
      foreach $item(@approved) {
             
         open(DATABASE, ">>$memberinfo/amdata.db") or print"unable to create access temp file";
         if ($LOCK_EX){ 
      flock(DATABASE, $LOCK_EX); #Locks the file
	}
         chomp($item);
         print DATABASE "$item\n";

           if ($htaccess == "1") {
           open (DAT2, "<$memberinfo/$INPUT{'USER8'}.infotmp");
if ($LOCK_EX){ 
      flock(DAT2, $LOCK_EX); #Locks the file
	} 
           @second = <DAT2>;
           close (DAT2);
                foreach $item(@second) {
                @edit_second = split(/\:/,$item);
                chop ($edit_second[1]) if ($edit_second[1] =~ /\n$/);

                if ($crypt) {
		    $newpassword = crypt($edit_second[1], aa);
                } else {
		    $newpassword = $edit_second[1];
                }
                open(PASSWD, ">>$memaccess") or print"unable to create access temp file";
                print PASSWD "$edit_second[0]:$newpassword\n";
   }

close (PASSWD);


 }
close (DATABASE);
}

open (FILE, "<$memberinfo/$INPUT{'USER8'}.infotmp");
if ($LOCK_EX){ 
      flock(FILE, $LOCK_EX); #Locks the file
	}
       @approved = <FILE>;
       close (FILE);
       foreach $item(@approved) {

             @edit_approved = split(/\:/,$item);      


## Create Customer Billing Statement

if ($payment == 1) {
open (STATEMENT, ">$memberinfo/$edit_approved[0]statement.txt");
if ($LOCK_EX){ 
      flock(STATEMENT, $LOCK_EX); #Locks the file
	}
print STATEMENT "Customer Billing Statement - Created: $date2\n";
print STATEMENT "For $edit_approved[3] $edit_approved[4]\n";
print STATEMENT "=" x 75 . "\n\n";
print STATEMENT "$date2\n";
print STATEMENT "USER ID:              $edit_approved[0]\n";
  if ($edit_approved[7] eq "cc") {
print STATEMENT "Billing Address:      $edit_approved[12]\n";
              if ($edit_approved[8]) {
print STATEMENT "Billing Address2:     $edit_approved[13]\n";
}
}
print STATEMENT "Setup Charge:         $edit_approved[5]\n";
print STATEMENT "Monthly Charge:       $edit_approved[6]\n\n";
print STATEMENT "=" x 75 . "\n\n";
}
       
close (STATEMENT);

      $tempfile = "$tempdir/$edit_approved[2]";      
      
      open (FILE,"$memberinfo/approved.txt"); #### Full path name from root.
if ($LOCK_EX){ 
      flock(FILE, $LOCK_EX); #Locks the file
	}
 @approved_email_file  = <FILE>;
 close(FILE);

# Output a temporary file

$body = "";
    
    $body .= "To: $edit_approved[2]\n";
    $body .= "From: $orgmail\n";
    $body .= "Subject: $approved_email_subject\n\n";
    #Date
    $body .= "$date\n";
    
    # Check for Message Subject

    $body .= "-" x 75 . "\n\n";

    foreach $line(@approved_email_file) {
    $line =~ s/<FIRST_NAME>/$INPUT{'x_first_name'}/g;
    $line =~s/<LAST_NAME>/$INPUT{'x_last_name'}/g;
    $line =~ s/<USERNAME>/$INPUT{'USER8'}/g;
    $line =~s/<PASSWORD>/$INPUT{'USER9'}/g;
    $line =~s/<ORGNAME>/$orgname/g;
    $line =~s/<ORGMAIL>/$orgmail/g;
    $body .= "$line";
    }
                        
    foreach $line2(@closing) {
    $body .= "$line2";
    }

    $body .="\n\n";

&sendmail("$edit_approved[2]","$orgmail","$approved_email_subject","$body");
 
        
        unlink ("$memberinfo/$lines");
        }
unlink ("$memberinfo/$INPUT{'USER8'}.infotmp");


}

if ($INPUT{$lines}) {
unlink ("$memberinfo/$lines");

}

#}

#}
&close;

exit;

}








sub parseusername {
$desiredname = $INPUT{'USER8'};
$lines =~ tr/A-Z/a-z/;
$desiredname =~ tr/A-Z/a-z/;
}

sub parseusername2 {
$desiredname = $INPUT{'USER8'};
$edit_array[0] =~ tr/A-Z/a-z/;
$desiredname =~ tr/A-Z/a-z/;
}




sub accounttypes {

if (($INPUT{'USER7'} !=~ /choose one/i) && ($INPUT{'USER7'} eq one)) {


# print "Content-type: text/html\n\n";
# print "Accounts = $INPUT{'accounts'}<BR>";
# exit;

$account_name = $account_one; 
$setup = $setup_one;
$monthly = $monthly_one;
$length = $lengthone;
}

if (($INPUT{'USER7'} !=~ /choose one/i) && ($INPUT{'USER7'} eq two)) {


$account_name = $account_two; 
$setup = $setup_two;
$monthly = $monthly_two;
$length = $lengthtwo;
}

if (($INPUT{'USER7'} !=~ /choose one/i) && ($INPUT{'USER7'} eq three)) {


$account_name = $account_three; 
$setup = $setup_three;
$monthly = $monthly_three;
$length = $lengththree;
}

$finaltotal = $setup + $monthly;

}



sub finish {

if ($INPUT{'x_cust_id'}) {
$new_id = $INPUT{'x_cust_id'};
#&newid;
&temp;
} else {
print "Content-type: text/html\n\n";
print<<EOF;
Your account information was not properly processed.<BR><BR>
If you feel you've received this response in error, please contact
our administration at:  $orgmail.
EOF
exit;
}
exit;
}





sub parseemail {
$email = $INPUT{'x_email'};
$edit_array[2] =~ tr/A-Z/a-z/;
$email =~ tr/A-Z/a-z/;
}


sub header {
open (FILE,"<$header/header.txt"); #### Full path name from root. 
 @headerfile = <FILE>;
 close(FILE);
print "<HTML><HEAD><TITLE></TITLE></HEAD><BODY $bodyspec>\n";
foreach $line(@headerfile) {
print "$line";
  }
}


sub footer {
open (FILE,"<$footer/footer.txt"); #### Full path name from root. 
 @footerfile = <FILE>;
 close(FILE);
foreach $line(@footerfile) {
print "$line";
}
print "</BODY></HTML>";
}

sub secureheader {
open (SHFILE,"<$secureheader/header.txt"); #### Full path name from root. 
 @shheaderfile = <SHFILE>;
 close(SHFILE);
print "<HTML><HEAD><TITLE></TITLE></HEAD><BODY $bodyspec>\n";
foreach $line(@shheaderfile) {
print "$line";
  }
}

sub securefooter {
open (SFFILE,"<$securefooter/footer.txt"); #### Full path name from root.
if ($LOCK_EX){ 
      flock(SFFILE, $LOCK_EX); #Locks the file
} 
 @sfooterfile = <SFFILE>;
 close(SFFILE);
foreach $sfline(@sfooterfile) {
print "$sfline";

}
print<<EOF;
</BODY></HTML>
EOF
}


sub sendmail {


	my($to, $from, $subject, $body, $tempfile) = @_;

	if (lc $mailusing eq 'sendmail')   
		{
		open (MAIL, "|$mailprog -t -oi") || print ("Can't open $mailprog!\n");
                if ($usehtml eq 'on') {
                print MAIL "Content-type: text/html\n";
                }

		$body .= "To: $to\n";
		$body .= "From: $from\r\n";
		$body .= "Subject: $subject\r\n";
		$body .= "$body\r\n";
            print MAIL "\r\n\r\n";
		close MAIL;
		}
	else
		{
		if (lc $mailusing eq 'blat') 
			{
#                if ($usehtml eq 'on') {
#                print MAIL "Content-type: text/html\n";
#                }
$tempfile = "$memberinfo/$to";
 
        open(MAIL,">$tempfile") || die("Cannot open $tempfile -- Check Directory Permissions : $!"); 
                


		print MAIL "$body\r\n";

            close MAIL;

        #'use' the process module.
        use Win32::Process;
       
        #theWin32:: module. Includes the Win32 error checking etc.
        # see Win32:: section for included functions.
        use Win32;
        
        #Create the process object.
        Win32::Process::Create($ProcessObj, $mailprog, "Blat $tempfile -t \"$to\" -i \"$from\" -s \"$subject\" -f \"$from\" ", 0, DETACHED_PROCESS, ".")|| die ; 

        #Wait for the process to end. NO timeout 
        $ProcessObj->Wait(INFINITE);
        unlink($tempfile);

			}
		else
			{
			$err = &sockets_mail($to, $from, $subject, $body); 
			if ($err < 1)
				{print "<br>\nSendmail error # $err<br>\n";}			
			}
		}	
}


sub sockets_mail {

    my ($to, $from, $subject, $message) = @_;

    my ($replyaddr) = $from;
   
    if (!$to) { return -8; }

    my ($proto, $port, $smptaddr);

    my ($AF_INET)     =  2;
    my ($SOCK_STREAM) =  1;

    $proto = (getprotobyname('tcp'))[2];
    $port  = 25;

    $smtpaddr = ($smtp_addr =~ /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/)
                    ? pack('C4',$1,$2,$3,$4)
                    : (gethostbyname($smtp_addr))[4];

    if (!defined($smtpaddr)) { return -1; }

    if (!socket(S, $AF_INET, $SOCK_STREAM, $proto))             { return -2; }
    if (!connect(S, pack('Sna4x8', $AF_INET, $port, $smtpaddr))) { return -3; }

    # my($oldfh) = select(S); $| = 1; select($oldfh);

    select(S);
    $| = 1;
    select(STDOUT);

    $_ = <S>; if (/^[45]/) { close S; return -4; }

    print S "helo localhost\r\n";
    $_ = <S>; if (/^[45]/) { close S; return -5; }

    print S "mail from: $from\r\n";
    $_ = <S>; if (/^[45]/) { close S; return -5; }
   
    print S "rcpt to: $to\r\n";
    $_ = <S>; if (/^[45]/) { close S; return -6; }
    

    print S "data\r\n";
    $_ = <S>; if (/^[45]/) { close S; return -5; }


    if ($usehtml eq 'on') {
    print S "Content-type: text/html\n";
    } else {
    print S "Content-Type: text/plain; charset=us-ascii\r\n";
    }
    print S "To: $to\r\n";
    print S "From: $from\r\n";
    print S "Reply-to: $replyaddr\r\n" if $replyaddr;
    print S "Subject: $subject\r\n\r\n";
    print S "$message";
    print S "\r\n.\r\n";

    $_ = <S>; if (/^[45]/) { close S; return -7; }

    print S "quit\r\n";
    $_ = <S>;

    close S;
    return 1;
}