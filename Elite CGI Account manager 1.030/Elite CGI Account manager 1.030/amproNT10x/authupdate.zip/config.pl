#!/usr/bin/perl

# You will find a complete HTML tutorial/manual in our
# Registered Users Area of our website:
# http://www.cgiscriptcenter.com

# Version 1.030
##############################################################
# EDIT USER CONFIGURATIONS BELOW
##############################################################

# Add your BODY tag information, like background graphic, color, etc.
$bodyspec = "background=\"\" bgcolor=\"#FFFFFF\" link=\"#0000FF\" vlink=\"#0000FF\"";

# Add your own graphics, text, links, etc., to the top of your pages.
# Give the full directory path to your header.txt file.  DO NOT include
# the header.txt file in the path here, just the directories.
# $header = "/full/path/to/directory";
$header = "";

# Add your own graphics, text, links, etc., to the bottom of your pages.
# Give the full directory path to your footer.txt file.  DO NOT include
# the footer.txt file in the path here, just the directories.
# $footer = "/full/path/to/directory";
$footer = "";

$secureheader = "";
$securefooter = "";

# Edit the font colors of the text on the help and error screens that
# users will see.  This is helpful if you add a background color or
# graphic.
$fontcolor = "#000000";

# Type the name of your organization, group, or company
$orgname = "Your Company";

# Type an email address that customer/user can respond to
$orgmail = "you\@yourserver.com";

# if do not have Sendmail, you can also opt to use
# 'sockets' mail.  This requires either an IP address of your
# SMTP mail server, or the Domain address of the SMTP mail server.
# Three options are:  'sendmail','sockets'.

$mailusing = 'sockets';


# You only need to set this variable if you have set 'sockets' above.
# This should be either the IP address or the Domain address to your
# SMTP mail server.

$smtp_addr = 'mail.yourserver.com';

# Type the full path to your Mail program.  Only necessary when
# using UNIX and Sendmail.
$mailprog = "";




# Here you can create the text message that the potential
# new members/user will receive in the email once they fill
# in your web form.
# Place the information in a text file
# and save the file as: email.txt
# Place the full path to the email.txt file (if any) here.
# DO NOT place the name of the file (email.txt) here, just
# the directory path where the file is kept.
$closing = "";


# If you use IBiLL or choose to allow Instant Approval/Access
# to your members area, enter the number 1 between the quotes
# for $instantaccess, like so:  $instantaccess = "1";
# This will automatically add the new user to your private
# area and update your members database.

$instantaccess = "1";


# This is the Suject of the email that is sent to anyone that
# signs up.
$sign_up_response = "Thank you for your submission!";


# This would be the suject of the Aproval email the user will
# receive if you have Instant Access on.
$approved_email_subject = "You've Been Approved!";


# If you would like to customize the e-mail messages that your
# customers/users receive when they complete and submit any of
# your website forms, create the following text files and upload
# them all to your $memberinfo directory:
#
# email.txt - In this file, include information someone would
# receive when they submit an account request to you, prior to
# approval or denial of account.
#
# approved.txt - In this file, include the information that you
# would like your customer/user to receive once you have approved
# his/her account.
#
# denied.txt - In this file, include the information that you would
# like your customer/user to receive if their account has been denied.
#
# Once completed, upload these three text files to your $memberinfo
# directory.

# If you are run the script and receive File Locking (flock)
# errors, remove the number 2 from between the quotes.
# Then it would appear: $LOCK_EX = "";
$LOCK_EX = "2";

# If you choose to offer limited time accounts, make sure to place
# a "1" between the quotes below.
# Example: $acctlength = "1";
# Otherwise, do not place anything between the quotation marks.

$acctlength = "1";


# If you are offering accounts for purchase, place the account
# Information here.  We have included some examples below
# Note, do not place dollar signs ($).  The program will do that
# for you.

# If you do not need an expiration of the account, simply leave
# the $length(one-two-three) = ""; empty.  Like so.
# You can set the $lengthone, $lengthtwo, and $lengthtree variables
# to any number of days that you want each account to expire in.
# If your accounts do not expire, and do not need to renewal,
# simply leave those variables blank, and make sure that your
# $acctlength above also has nothing between the quotes.


$account_one = "Basic Plan";
$setup_one = "25";
$monthly_one = "24.99";
$lengthone = "30";

$account_two = "Deluxe Plan";
$setup_two = "45";
$monthly_two = "44.99";
$lengthtwo = "60";

$account_three = "Gold Plan";
$setup_three = "";
$monthly_three = "";
$lengththree = "90";


# If you choose to offer limited time accounts (above), choose the
# number of days before expiration that you would like your customer
# notified of his/her account expiring.
# Example: $renewal = "7"; 
# This will send your customer a reminder 7 days before his/her account
# expiring, to contact you to renew his/her account.

$renewal = "7";

# Place the full directory path here to the backup directory, where you
# want your nightly backups of your membership database and the
# htpasswd files.

$backup = "/full/directory/path/to/backup";

# Enter your website URL here

$website = "http://www.yourserver.com";


# Give the full directory path where you would like your password.txt
# file to be saved.  DO NOT include the name password.txt in the path
# here, just the directories.  $passfile = "/full/path/to/directory";
# Permissions settings should be between 755 - 777.  Permission
# settings vary between servers.
$passfile = "c:/inetpub/wwwroot/stuff/acctmansock/pass";



# Type the subject that will appear in the email customer/user
# receives
$subject = "ABC Member Info";


# If you use .htaccess or .nsconfig, use a "1", otherwise leave blank
# or set to "0".  This is if you use a secure users area.

$htaccess = "1";


# Encryption
# If you are using Apache for Windows, you will want to leave this
# to the default setting of $crypt = "";
# If you are using a crypt-capable web server, place a 1 between the
# quotes, to encrypt your passwords.  

$crypt = "";


# If you entered "1" above, enter the full path to your
# htpasswd or .nsconfig file.
# Like this: $memaccess = "/full/path/to/htpasswd";
# This is the file that houses the usernames and encrypted passwords
# but is only needed if you use .htaccess or .nsconfig
# Permissions settings should be between 755 - 777.  Permission
# settings vary between servers.
# The program will create the file called "htpasswd" for you.
# We placed the actual path name here in case you already have
# a password file that you want to replace it with.
$memaccess = "c:/inetpub/wwwroot/stuff/acctmansock/info/.htpasswd";

# Type the full path to the database file that contains all the info
# Permissions settings should be between 755 - 777.  Permission
# settings vary between servers.
$memberinfo = "c:/inetpub/wwwroot/stuff/acctmansock/info";


# Subject of email that is automatically sent to users that you
# chose not to accept in your Account Manager.
$denied_email_subject = "Application Denied";

# Subject for email that is automatically sent to users that you
# chose to accept in your Account Manager.
$approved_email_subject ="Application Approved";

# If accepting/charging for a membership account, enter a "1"
# between the quotations, other wise leave it empty "";
$payment = "1";

## The information below will appear on Emailed billing
# statements.  If you are not billing your customers,
# you will not need to edit the information below.

# Name of your billing supervisor who's name will appear on
# emailed billing statments.
$billing = "Billing Supervisor";

# Make Checks out to:
$billingaddress1 = "Elite Web Design and Marketing";

# Address
$billingaddress2 = "10680 Los Alamitos Blvd.";

# City, State, Zip
$billingaddress3 = "Los Alamitos, CA  90720";

# Billing Inquiries, email at yourname\@yourdomain.com
# or call (enter phone number).
$billinginquiries = "Billing Inquires at (phone) or E-mail at accounts\@elitehost.com";


# Enter the maximum IP addresses that you would like any one account
# to have access from in any single 24 hour period.  Keep in mind that
# most ISP's will issue a user a new IP address each time they log off
# and back on the Internet.

$userips = "10";

#################### IBILL USERS ONLY ############################
##################################################################

# If you are using IBILL's pincoding, enter the number "1" between
# the quotations below.  Otherwise, leave it empty.
# Example:  $IBILL = "1"; for IBILL pincoding turned on
# Exmaple:  $IBILL = "";  for IBILL pincoding turned off

$IBILL = "";

# If you wish to redirect those that are denied an account due to
# a non matching Pincode, place the full url of where you would
# like this person directed.
# Example:  $Idenyurl = "http://www.yourserver.com/deniedaccess.htm";

$Idenyurl = "";

# Enter the full directory path to the pincode file provided you by
# IBILL here.  Be sure to include the name of the file itself.
#
# Account Manager is presently designed to offer up to three account
# types.  Using IBILL, each account will have its own set of
# authorization pincodes. Enter the path for up to 3 separate pin
# code text files here.  Make sure to place these pin codes in a
# directory that is not accessible by the web, if possible. Most
# ISP's will offer their customers at least one directory for this.
# Make sure to set permissions on the files for read and write.
# 744-766.  Some servers will require as high as 777. Contact your
# server administration for specific settings on your server.
# Example:  /home/httd/yourserver/directory/1pincode.txt";


$act1pincodes = "/full/directory/path/to/your/account1pincodes.txt";
$act2pincodes = "/full/directory/path/to/your/account2pincodes.txt";
$act3pincodes = "/full/directory/path/to/your/account3pincodes.txt";

#################################################################
################## Authorize.net Users Only #####################
#################################################################

# If you will be using the real-time credit card processing system
# built into Commission Cart, through Authorize.net
# (Details found at: http://www.authorizenet.com)
# You will want to place a "1" between the quotes below to turn
# on the Instant Approval.  You will also need to set up your
# configurations through Authorize.net using your Authorize.net
# control panel.  Contact Authorize.net for details.
$authorizenet = "1";

# If using ECX QuickCommerce, place a "1" between the quotes.
# Example:  $ecx = "1";
$ecx = "";

## Place the URL to your main Members Area page here:
## Example:  $redirect2 = "http://www.yourserver.com/members/index.html";
## This will be the directory you have .htaccess protected.
$redirect2 = "http://www.yourserver.com/privatedirectory";

# If you would like to redirect  your customers who's credit
# cards are denied to a page you have created, place the full
# URL path below.
# Example:  $decline_redirect = "http://www.yourserver.com/declined.htm";
# Otherwise, the program will let the customer know that the system
# was unable to process their credit card.

$decline_redirect = "";

# If you would like to "Test" your Authorizenet 3.0 system, without
# actually running a real transaction through, set the $test_request
# value to TRUE.
# Example: $test_request = "TRUE";
# When you are through testing and wish to start charging, remove the "TRUE" like so:
# Example $test_request = "";

$test_request = "TRUE";

# This is a very important field.  This field *must* have the full
# URL path to your authorizenet.pl (or .cgi) file.  Authorizenet
# will receive the data sent by Commission Cart, then send the
# majority of that data back to Commission Cart, by posting that
# data to the authorizenet.pl (or .cgi) file.
# Example:
# $auth_redirect = "http://www.yourserver.com/cgi-bin/ampro/authorizenet.pl";

$auth_redirect = "http://www.yourserver.com/cgi-bin/acctman/authorizenet.pl";


## IMPORTANT ##
# IF YOU JUST SET $authorizenet = "1";
# Make sure you have $instantapprove = "1"; above, also.

# If you DO NOT wish your customers to see anything displayed from
# the Authorize.net site, and strictly sending the information
# through Authorize.net for approval only, place a "1" between
# the quotes below.  If you did not choose a "1" for the variable
# above ($authorizenet = ""), it really won't matter if you place
# a "1" here or not.
$seamless = "1";


# If you are using Authorize.net, you'll receive a "login" from
# Authorize.net.  Place that "login" name in the quotes below.
# Example:  $login = "abccompany";
$login = "";


# The $transtype variable simply that you are doing a "Normal
# Approval".  See your Authorize.net documentation for more information
# about transaction types.  By default, leave the variable below
# set to "NA".

$transtype = "NA";

##################################################################
##################################################################
