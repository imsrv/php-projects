#!/usr/bin/perl

############################################
##                                        ##
##        Account Manager User Signup     ##
##        FOR AUTHORIZENET USERS ONLY     ##
##          by CGI Script Center          ##
##     (e-mail cgi@cgiscriptcenter.com)   ##
##                                        ##
##              version:  1.030           ##
##        last modified:  08/23/2000      ##
##        copyright (c) 1998 - 2000       ##
##                                        ##
##    latest version is available from    ##
##     http://www.cgiscriptcenter.com     ##
##                                        ##
############################################
#
##############################################################
# EDIT THE VARIABLES BELOW ###################################
##############################################################

require "/full/directory/path/to/config.pl";

##############################################################
##############################################################
# COPYRIGHT NOTICE:
#
# Copyright 1998 Diran Alemshah.  All Rights Reserved.
#
# LICENSOR'S PROGRAM IS COPYRIGHTED AND LICENSED (NOT SOLE).
# LICENSOR DOES NOT SELL OR TRANSFER TITLE TO THE LICENSED
# PROGRAM TO YOU. YOUR LICENSE OF THE LICENSED PROGRAM WILL
# NOT COMMENCE UNTIL YOU HAVE EXECUTED THIS AGREEMENT AND AN
# AUTHORIZED REPRESENTATIVE OF LICENSOR HAS RECEIVED, APPROVED,
# AND EXECUTED A COPY OF IT AS EXECUTED BY YOU.
# 1. License Grant.</B> Licensor hereby grants to you, and you
# accept, a nonexclusive license to use the downloaded computer
# programs, object code form only (collectively referred to as
# the &quot;Software&quot;), and any accompanying User Documentation,
# only as authorized in this License Agreement. The Software may be
# used on any website owned by Licensee, or if Licensee is a company
# or corporation, any website owned by Licensee company or corporation.
# You agree that you will not assign, sublicense, transfer, pledge,
# lease, rent, or share your rights under this License Agreement.
# You agree that you may not reverse assemble, reverse compile, or
# otherwise translate the Software<BR> <BR> Upon loading the Software
# into your computer, you may make a copy of the Software for
# backup purposes. You may make one copy of any User's Manual
# provided for backup purposes. Any such copies of the Software
# or the User's Manual shall include Licensor's copyright and other
# proprietary notices. Except as authorized under this paragraph,
# no copies of the Program or any portions thereof may be made by
# you or any person under your authority or control.
# 2. License Fees.  The license fees paid by you are paid
# in consideration of the licenses granted under this License
# Agreement. You are solely responsible for payment of any taxes
# (including sales or use taxes, intangible taxes, and property taxes)
# resulting from your acceptance of this license and your possession
# and use of the Licensed Program, exclusive of taxes based on
# Licensor's income. Licensor reserves the right to have you
# pay any such taxes as they fall due to Licensor for remittance to
# the appropriate authority. You agree to hold harmless Licensor
# from all claims and liability arising from your failure to report
# or pay such taxes.
# 3. This License Agreement is effective upon your submission of this form.
# 4. Limited Warranty. Licensor warrants, for your benefit alone,
# that the Licensed Program conforms in all material respects to
# the specifications for the current version of the Licensed Program.
# This warranty is expressly conditioned on your observance of the
# operating, security, and data-control procedures set forth in the
# User's Manual included with the Licensed Program.
# 
# EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, LICENSOR
# DISCLAIMS ANY AND ALL PROMISES, REPRESENTATIONS, AND WARRANTIES
# WITH RESPECT TO THE LICENSED PROGRAM, INCLUDING ITS CONDITION,
# ITS CONFORMITY TO ANY REPRESENTATION OR DESCRIPTION, THE EXISTENCE
# OF ANY LATENT OR PATENT DEFECTS, ANY NEGLIGENCE, AND ITS
# MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.
# 5. Limitation of Liability.</B> Licensor's cumulative liability
# to you or any other party for any loss or damages resulting
# from any claims, demands, or actions arising out of or relating
# to this Agreement shall not exceed the license fee paid to Licensor
# for the use of the Program. In no event shall Licensor be liable
# for any indirect, incidental, consequential, special, or exemplary
# damages or lost profits, even if Licensor has been advised of the
# possibility of such damages.
# 6. Proprietary Protection. Licensor shall have sole and exclusive
# ownership of all right, title, and interest in and to the Licensed
# Program and all modifications and enhancements thereof (including
# ownership of all trade secrets and copyrights pertaining thereto),
# subject only to the rights and privileges expressly granted to you
# herein by Licensor. This Agreement does not provide you with title
# or ownership of the Licensed Program, but only a right of limited
# use. You must keep the Licensed Program free and clear of all claims,
# liens, and encumbrances.
# 7. Restrictions. You may not use, copy, modify, or distribute the
# Licensed Program (electronically or otherwise), or any copy,
# adaptation, transcription, or merged portion thereof, except as
# expressly authorized by Licensor. You may not reverse assemble,
# reverse compile, or otherwise translate the Licensed Program.
# Your rights may not be transferred, leased, assigned, or sublicensed
# except for a transfer of the Licensed Program in its entirety to
# (1) a successor in interest of your entire business who assumes
# the obligations of this Agreement or (2) any other party who is
# reasonably acceptable to Licensor, enters into a substitute
# version of this Agreement, and pays an administrative fee intended
# to cover attendant costs. No service bureau work, multiple-user
# license, or time-sharing arrangement is permitted, except as
# expressly authorized by Licensor. If you use, copy, or modify
# the Licensed Program or if you transfer possession of any copy,
# adaptation, transcription, or merged portion of the Licensed
# Program to any other party in any way not expressly authorized
# by Licensor, your license is automatically terminated.
# 8. Licensor's Right Of Entry.</B> You hereby authorize Licensor
# to enter your premises in order to inspect the Licensed Program
# in any reasonable manner during regular business hours to verify
# your compliance with the terms hereof.
# 9. Injunctive Relief.</B> You acknowledge that, in the event
# of your breach of any of the foregoing provisions, Licensor
# will not have an adequate remedy in money or damages. Licensor
# shall therefore be entitled to obtain an injunction against such
# breach from any court of competent jurisdiction immediately upon
# request. Licensor's right to obtain injunctive relief shall not
# limit its right to seek further remedies.
# 10. Trademark. COMMISSION CART(TM), ACCOUNT MANAGER(TM), PICLINK
# ADVERTISER(TM), BANDWIDTH PROTECTOR(TM), PC CONFIGURATOR(TM)
# are all trademarks of Licensor. No right, license, or interest
# to such trademark is granted hereunder, and you agree that no
# such right, license, or interest shall be asserted by you with
# respect to such trademark.
# 11. Governing Law.  This License Agreement shall be construed
# and governed in accordance with the laws of the State of California,
# USA.
# 12. Costs of Litigation. If any action is brought by either party
# to this License Agreement against the other party regarding the
# subject matter hereof, the prevailing party shall be entitled
# to recover, in addition to any other relief granted, reasonable
# attorney fees and expenses of litigation.
# 13. Severability. Should any term of this License Agreement be
# declared void or unenforceable by any court of competent
# jurisdiction, such declaration shall have no effect on the
# remaining terms hereof.
# 14. No Waiver. The failure of either party to enforce any
# rights granted hereunder or to take action against the other
# party in the event of any breach hereunder shall not be deemed
# a waiver by that party as to subsequent enforcement of rights
# or subsequent actions in the event of future breaches.
# 15. Integration.  THIS AGREEMENT IS THE COMPLETE AND EXCLUSIVE
# STATEMENT OF LICENSOR'S OBLIGATIONS AND RESPONSIBILITIES TO YOU
# AND SUPERSEDES ANY OTHER PROPOSAL, REPRESENTATION, OR OTHER
# COMMUNICATION BY OR ON BEHALF OF LICENSOR RELATING TO THE
# SUBJECT MATTER HEREOF
#
##############################################################
# DO NOT EDIT BELOW THIS LINE
##############################################################

read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
@pairs = split(/&/, $buffer);
foreach $pair (@pairs) {
	($name, $value) = split(/=/, $pair);
	$value =~ tr/+/ /;
	$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	if ($INPUT{$name}) { $INPUT{$name} = $INPUT{$name}.",".$value; }
	else { $INPUT{$name} = $value; }
      $value =~ s/<!--(.|\n)*-->//g;
}

$version = "1.030";

$cgiurl = $ENV{'SCRIPT_NAME'};

if ($INPUT{'find'}) { &find; } ######### Will search for member info.
if ($INPUT{'process'}) { &sorder; } 
#elsif ($INPUT{'order'}) { &order; }
#elsif ($INPUT{'sorder'}) {&sorder; } 
else {&sorder;}############# IF no button was pressed, run just as 
exit;


sub sorder {

unless ($INPUT{'agree'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>You Must Agree.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">In order for us to process your request, you must check the box marked <B>"I agree to the above"</B> on our order form.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}


unless ($INPUT{'fname'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your First Name.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your first name</B> in our service request form.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

unless ($INPUT{'lname'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your Last Name.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your last name</B> in our service request form.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

unless ($INPUT{'address'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your Address.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your address</B> in our service request form.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

unless ($INPUT{'city'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your City.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your city</B> in our service request form.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

unless ($INPUT{'state'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your State.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your state</B> in our service request form.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}


unless ($INPUT{'zip'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your Zip Code.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your ZIP or Postal Code</B> in our service request form.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

unless ($INPUT{'country'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your Country.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your Country</B> in our service request form.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}




unless ($INPUT{'phone'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your Phone Number.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your phone number</B> in our service request form.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

$INPUT{'email'} =~ s/\s//g;

unless ($INPUT{'email'} =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|(,)/
	  || $INPUT{'email'} !~
	  /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/)
	  {
         $legalemail = 1;
        } else {
         $legalemail = 0;
        }


if ($legalemail !~ 1) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your E-Mail Address.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your E-mail address</B> in our service request form.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}


unless ($INPUT{'payment'}) {
    print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your Form of Payement.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your form of payment</B> in our service request form.  Check the circle for Credit Card or Check purchase.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

if (($INPUT{'acctlength'}) && ($INPUT{'acctlength'} =~ /choose one/i)) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your Choice of Account Length.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to choose the <B>length of your account</B> in our service request form.  Select from our drop down box which account length you would like.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}


if ($INPUT{'payment'} eq "cc") {
   if ($INPUT{'creditcards'} =~ /Choose One/) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your Credit Card Choice.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your credit card choice</B> in our service request form.  Select from our drop down box which credit card you would like to use.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

unless ($INPUT{'nameoncard'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Name on Card.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>the name on your credit card</B> in our service request form.  Please enter the full name that appears on your cedit card.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

###### CC verifier 2 modified start

if($INPUT{'cardnumber'}) {

    &CC_Verify;

} else {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter the Card Number.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>the number on your credit card</B> in our service request form.  It is not necessary to enter spaces between any numbers.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

####### CC verifier 2 modified end

unless ($INPUT{'exp'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter the Expiration Date.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>the expiration date on your credit card</B> in our service request form.  This should appear as MONTH/YEAR.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

unless ($INPUT{'billingaddress'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter the Billing Address.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>the billing address of your credit card</B> in our service request form.  This informatin is required by most credit card companies for online purchases.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

unless ($INPUT{'ccity'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your City.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your city</B> in our service request form.  This is required for most online credit card purchases.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

unless ($INPUT{'cstate'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your State.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your state</B> in our service request form.  This is required for most online credit card purchases.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}


unless ($INPUT{'czip'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your Zip Code.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your ZIP or Postal Code</B> in our service request form. This is required for most online credit card purchases.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}




}

&add;

sub close {

open (FILE,"$memberinfo/email.txt"); #### Full path name from root.
@closing  = <FILE>;
close(FILE);

 open (MAIL, "|$mailprog -t")
	            || print "Can't start mail program"; 
 
    print MAIL "To: $INPUT{'email'}\n";
    print MAIL "From: $orgmail($orgname)\n";
    print MAIL "Subject: $sign_up_response\n";
    print MAIL "-" x 75 . "\n\n";
    
                            
    foreach $line(@closing) {
    $line =~ s/<FIRST_NAME>/$INPUT{'fname'}/g;
    $line =~s/<LAST_NAME>/$INPUT{'lname'}/g;
    $line =~ s/<USERNAME>/$INPUT{'username'}/g;
    $line =~s/<PASSWORD>/$INPUT{'pwd'}/g;
    $line =~s/<ORGNAME>/$orgname/g;
    $line =~s/<ORGMAIL>/$orgmail/g;
    }
                        
    foreach $line(@closing) {
    print MAIL "$line";
    }

    print MAIL"\n\n";
    close (MAIL);

      
 
#################################################################
## MAIL BACK TO ADMIN ###########################################
#################################################################

open (MAIL, "|$mailprog -t")
	            || print "Can't start mail program"; 
 
    print MAIL "To: $orgmail\n";
    print MAIL "From: $INPUT{'email'} ($INPUT{'fname'} $INPUT{'lname'})\n";
    print MAIL "Subject: Account Manager Form Response\n";
    print MAIL "-" x 75 . "\n\n";
    
    print MAIL "Customer Information\n";
    print MAIL "-" x 75 . "\n\n";
    print MAIL "Name: $INPUT{'fname'} $INPUT{'lname'}\n";
    print MAIL "Address: $INPUT{'address'}\n";
    print MAIL "Address2: $INPUT{'address2'}\n";
    print MAIL "City: $INPUT{'city'}\n";
    print MAIL "State: $INPUT{'state'}\n";
    print MAIL "Zip: $INPUT{'zip'}\n";
    print MAIL "Phone: $INPUT{'phone'}\n";
    print MAIL "Email: $INPUT{'email'}\n\n";
    

if ($INPUT{'payment'} eq "cc") {
$INPUT{'payment'} = "Credit Card";
}


    print MAIL "Payment Information\n";
    print MAIL "-" x 75 . "\n\n";
    print MAIL "Form of Payment: $INPUT{'payment'}\n";

if ($INPUT{'creditcards'}) {
    print MAIL "Credit Card: $INPUT{'creditcards'}\n";
}

if ($INPUT{'nameoncard'}) {
    print MAIL "Name on Card: $INPUT{'nameoncard'}\n";
}

if ($INPUT{'cardnumber'}) {
    print MAIL "Card Number: $INPUT{'cardnumber'}\n";
}

if ($INPUT{'exp'}) {
    print MAIL "Expiration: $INPUT{'exp'}\n";
}

if ($INPUT{'billingaddress'}) {
    print MAIL "Billing Address: $INPUT{'billingaddress'}\n";
}

if ($INPUT{'billingaddress2'}) {
    print MAIL "Billing Address2: $INPUT{'billingaddress2'}\n";
}

if ($INPUT{'city'}) {
    print MAIL "City: $INPUT{'ccity'}\n";
}

if ($INPUT{'state'}) {
    print MAIL "State: $INPUT{'cstate'}\n";
}

if ($INPUT{'zip'}) {
    print MAIL "Zip: $INPUT{'czip'}\n\n";
}



    print MAIL "Purchase Information\n";
    print MAIL "Account: $account_name\n";
    print MAIL "Account Setup: \$$setup\n";
    print MAIL "Account Monthly: \$$monthly\n";
    if ($INPUT{'acctlength'}) {
    print MAIL "Account Length: $INPUT{'acctlength'} days\n";
    }





    close (MAIL);

      
 
        
unless ($redirect) { 
        
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account
Manager</FONT> Status:  Success!</FONT></B></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Your $orgname account information has been sent to the site administrators.  You should receive a response shortly.  Thank you for your interest.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please contact
<A HREF="mailto:$orgmail">$orgname Support</A> if you
need any further assistance.</FONT></P>
<HR SIZE="1">
<CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\"><B>Account Manager $version</B></A></FONT>
</CENTER> 
</TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

print "Location: $redirect\n\n";
exit;


}

}

sub checkaddress {

$INPUT{'email'} =~ s/\s//g;

unless ($INPUT{'email'} =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|(,)/
	  || $INPUT{'email'} !~
	  /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/)
	  {
         $legalemail = 1;
        } else {
         $legalemail = 0;
        }


if ($legalemail !~ 1) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account Manager</FONT> Status:<BR>Please Enter Your E-Mail Address.</FONT></B></P></CENTER>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please don't forget to enter <B>your E-mail address</B> in our service request form.</FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further
assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P>
<CENTER><TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD COLSTART="1"><HR SIZE="1">
<CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname
maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}
}

sub find {

&checkaddress;

# Open member database, read info
open (DAT,"<$memberinfo/amdata.db");
if ($LOCK_EX){ 
      flock(DAT, $LOCK_EX); #Locks the file
	}
 @database_array = <DAT>;
 close (DAT);

foreach $lines(@database_array) {
          @edit_array = split(/\:/,$lines);
          
&parseemail;
# if ($edit_array[2] =~ /$INPUT{'email'}/i) {last; }

if ($edit_array[2] eq $email) {last; }

}

# unless ($edit_array[2] =~ /$INPUT{'email'}/i) {

unless ($edit_array[2] eq $email) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print "<CENTER><BR><TABLE
BORDER=\"0\" WIDTH=\"450\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART=\"1\"><P><B><FONT FACE=\"verdana, arial, helvetica\"><FONT
COLOR=\"#FF0000\">Account Manager</FONT> Status:  Not Found!</FONT></B></P><P><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">Your $orgname account information was not found in our database.  Please make sure that you used the same email address that you created your account with.</FONT></P><P><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">Please contact <A
HREF=\"mailto:$orgmail\">$orgname Support</A> for your account information.</FONT></P><HR
SIZE=\"1\"><CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\"><B>Account Manager $version</B></A></FONT>
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>";
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
} 

print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print "<CENTER><BR><TABLE
BORDER=\"0\" WIDTH=\"450\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART=\"1\"><P><B><FONT FACE=\"verdana, arial, helvetica\"><FONT
COLOR=\"#FF0000\">Account Manager</FONT> Status:  Success!</FONT></B></P><P><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">Your $orgname account information has been emailed to you at: $INPUT{'email'}.</FONT></P><P><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">Please contact <A
HREF=\"mailto:$orgmail\">$orgname Support</A> if you need any further assistance.</FONT></P><HR
SIZE=\"1\"><CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\"><B>Account Manager $version</B></A></FONT>
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>";
if ($securefooter) {
&securefooter;
} else {
&footer;
}

open (MAIL, "|$mailprog -t")
	            || print "Can't start mail program"; 
    
    print MAIL "To: $edit_array[2]\n";
    print MAIL "From: $orgmail ($orgname Support)\n";
    # Check for Message Subject
    print MAIL "Subject: $orgname Account Information\n";
    #Date
    print MAIL "$date\n";
    

    print MAIL "-" x 75 . "\n\n";

    print MAIL "You requested your $orgname account information:\n\n";

    print MAIL "Your $orgname User ID is: $edit_array[0]\n";
    print MAIL "Your $orgname password is: $edit_array[1]\n\n";

    print MAIL "please contact $orgname support at: $orgmail\n";
    print MAIL "if you have any questions.\n\n";

    print MAIL "$orgname Support Team\n";    

    close (MAIL);
 
                
exit;

}

sub add {

unless ($INPUT{'username'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print "<CENTER><TABLE BORDER=\"0\" WIDTH=\"450\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD ALIGN=\"CENTER\" COLSTART=\"1\">     
<FONT SIZE=\"+1\" COLOR=\"$fontcolor\" FACE=\"verdana, arial, helvetica\"><FONT COLOR=\"#FF0000\">Account
Manager:</FONT><BR>Account Information Input Form</FONT><BR><BR>
<TABLE BORDER=\"0\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
ALIGN=\"LEFT\" COLSTART=\"1\"><FONT COLOR=\"$fontcolor\" SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><B>Username
Error!  No Username</B></FONT><BR><BR><FONT
COLOR=\"$fontcolor\" SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">Please go back and a Username.</FONT></TD></TR><TR><TD COLSTART=\"1\"><HR SIZE=\"1\">
<CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\"><B>Account Manager $version</B></A></FONT>
</CENTER> </TD></TR></ROWS></TBODY></TABLE></TD></TR></ROWS></TBODY></TABLE></CENTER>";
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
    }

if ($INPUT{'username'} =~ /\s/) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print "<CENTER><TABLE BORDER=\"0\" WIDTH=\"450\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD ALIGN=\"CENTER\" COLSTART=\"1\">     
<FONT SIZE=\"+1\" COLOR=\"$fontcolor\" FACE=\"verdana, arial, helvetica\"><FONT COLOR=\"#FF0000\">Account
Manager:</FONT><BR>Account Information Input Form</FONT><BR><BR>
<TABLE BORDER=\"0\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
ALIGN=\"LEFT\" COLSTART=\"1\"><FONT SIZE=\"+1\" COLOR=\"$fontcolor\" FACE=\"verdana, arial, helvetica\"><B>Username
Error!  Username Contains a Space</B></FONT><BR><BR><FONT
SIZE=\"-1\" COLOR=\"$fontcolor\" FACE=\"verdana, arial, helvetica\">Please go back and enter a Username without spaces.  If you would like to use a multi-word Username, be sure to use an underscore ( _ ).</FONT></TD></TR><TR><TD COLSTART=\"1\"><HR SIZE=\"1\">
<CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\"><B>Account Manager $version</B></A></FONT>
</CENTER> </TD></TR></ROWS></TBODY></TABLE></TD></TR></ROWS></TBODY></TABLE></CENTER>";
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
    }

if ($INPUT{'username'} eq $INPUT{'pwd'}) {

print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print "<CENTER><TABLE BORDER=\"0\" WIDTH=\"450\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD ALIGN=\"CENTER\" COLSTART=\"1\">     
<FONT SIZE=\"+1\" COLOR=\"$fontcolor\" FACE=\"verdana, arial, helvetica\"><FONT COLOR=\"#FF0000\">Account Manager:</FONT><BR>  Account Information Input Form</FONT><BR><BR>
<TABLE BORDER=\"0\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
ALIGN=\"LEFT\" COLSTART=\"1\"><FONT SIZE=\"+1\" COLOR=\"$fontcolor\" FACE=\"verdana, arial, helvetica\"><B>Password Error!  Same as Username</B></FONT><BR><BR><FONT
SIZE=\"-1\" COLOR=\"$fontcolor\" FACE=\"verdana, arial, helvetica\">You must chose a Password other than your Username, for security considerations.  Please return and enter another password.</FONT></TD></TR>

</ROWS></TBODY></TABLE></TD></TR></ROWS></TBODY></TABLE></CENTER>";
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}

unless ($INPUT{'pwd'} eq $INPUT{'pwd2'} && $INPUT{'pwd'} && $INPUT{'pwd2'} ){

print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print "<CENTER><TABLE BORDER=\"0\" WIDTH=\"450\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD ALIGN=\"CENTER\" COLSTART=\"1\">     
<FONT SIZE=\"+1\" COLOR=\"$fontcolor\" FACE=\"verdana, arial, helvetica\"><FONT COLOR=\"#FF0000\">Account
Manager:</FONT><BR>Account Information Input Form</FONT><BR><BR>
<TABLE BORDER=\"0\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
ALIGN=\"LEFT\" COLSTART=\"1\"><FONT COLOR=\"$fontcolor\" SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><B>Password
Error!  Password Mismatch</B></FONT><BR><BR><FONT
COLOR=\"$fontcolor\" SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">Please go back and re-enter your
password choice.</FONT></TD></TR><TR><TD COLSTART=\"1\"><HR SIZE=\"1\">
<CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\"><B>Account Manager $version</B></A></FONT>
</CENTER> </TD></TR></ROWS></TBODY></TABLE></TD></TR></ROWS></TBODY></TABLE></CENTER>";
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
    } 


if (-e "$memberinfo/amdata.db") {

open (MEMBER, "<$memberinfo/amdata.db");
if ($LOCK_EX){ 
      flock(MEMBER, $LOCK_EX); #Locks the file
	}
@database_array = <MEMBER>;
 close (MEMBER);

foreach $lines(@database_array) {
          @edit_array = split(/\:/,$lines);
    
&parseusername2;

#    if ($edit_array[0] eq $INPUT{'username'}) {last; }

if (($edit_array[0]) && ($edit_array[0] eq $desiredname)) {last; }
    
}

$INPUT{'username'} =~ s/\W.*//;
# if ($edit_array[0] eq $INPUT{'username'}) {

if (($edit_array[0]) && ($edit_array[0] eq $desiredname)) {

print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print "<CENTER><TABLE BORDER=\"0\" WIDTH=\"450\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD ALIGN=\"CENTER\" COLSTART=\"1\">     
<FONT COLOR=\"$fontcolor\" SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><FONT COLOR=\"#FF0000\">Account Manager:</FONT><BR>User Name Taken</FONT><BR><BR>
<TABLE BORDER=\"0\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
ALIGN=\"LEFT\" COLSTART=\"1\"><FONT COLOR=\"$fontcolor\" SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><B>User Name Error!  User Name Taken</B></FONT><BR><BR><FONT
COLOR=\"$fontcolor\" SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">The User Name you have selected is already in use by another user.  Please return and enter another user name.</FONT></TD></TR>
<TR><TD COLSTART=\"1\"><HR SIZE=\"1\">
<CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\"><B>Account Manager $version</B></A></FONT>
</CENTER></TD></TR></ROWS></TBODY></TABLE></TD></TR></ROWS></TBODY></TABLE></CENTER>";
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}


# open (MEMBER, "<$memberinfo/amdata.db");
# if ($LOCK_EX){ 
#      flock(MEMBER, $LOCK_EX); #Locks the file
#	}
# @database_array = <MEMBER>;
# close (MEMBER);

# foreach $lines(@database_array) {
#           @edit_array = split(/\:/,$lines);
#    if ($edit_array[1] eq $INPUT{'pwd'}) {last; }
    
# }

# if ($edit_array[1] eq $INPUT{'pwd'}) {

# print "Content-type: text/html\n\n";
# &header;
# print "<CENTER><TABLE BORDER=\"0\" WIDTH=\"450\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
# ><TD ALIGN=\"CENTER\" COLSTART=\"1\">     
# <FONT SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><FONT COLOR=\"#FF0000\">Account
# Manager:</FONT>  Account Information Input Form</FONT><BR><BR>
# <TABLE BORDER=\"0\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
# ALIGN=\"LEFT\" COLSTART=\"1\"><FONT SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><B>Password Error!  Password Taken</B></FONT><BR><BR><FONT
# SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">The password you have selected is already in use by another user.  Please return and enter another password.</FONT></TD></TR>
# <TR><TD COLSTART=\"1\"><HR SIZE=\"1\">
# <CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
# HREF=\"http://cgi.elitehost.com\"><B>Account Manager $version</B></A></FONT>
# </CENTER></TD></TR></ROWS></TBODY></TABLE></TD></TR></ROWS></TBODY></TABLE></CENTER>";
# &footer;
# exit;
# }

}
&dupeaddress;
&dupeaddress2;
&usertemp;
# &dupepwd;
&verify;
exit;

&temp;
exit;
}





sub usertemp {


opendir (DIR, "$memberinfo"); 
@file = grep { /.infotmp/} readdir(DIR);
foreach $lines(@file) {
 $lines =~ s/\W.*//;

&parseusername;

if ($lines eq $desiredname) {

# if ($lines =~ /$INPUT{'username'}\b/i) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="450"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account
Manager</FONT> Status:  Username Taken!</FONT></B></P>
<P><FONT COLOR="$fontcolor" SIZE="-1" FACE="verdana, arial, helvetica">The Username: $INPUT{'username'} has already been reserved by someone awaiting membership</FONT></P>
<P><FONT COLOR="$fontcolor" SIZE="-1" FACE="verdana, arial, helvetica">Please choose another Username.</FONT></P>
<HR SIZE="1">
<CENTER><FONT SIZE="-2" FACE="verdana, arial, helvetica"><B>$orgname maintained with
<A HREF="http://cgi.elitehost.com/"><B>Account Manager $version</B></A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
  exit;   
    
}
}
}

sub dupeaddress {
#print "Content-type: text/html\n\n";
open (EMAIL, "<$memberinfo/amdata.db");
if ($LOCK_EX){ 
      flock(EMAIL, $LOCK_EX); #Locks the file
	}
@database_array = <EMAIL>;
 close (EMAIL);

foreach $lines(@database_array) {
          @edit_array = split(/\:/,$lines);
&parseemail;

if ($edit_array[2] eq $email) {

# if ($edit_array[2] =~ /$INPUT{'email'}/i) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="450"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account
Manager</FONT> Status:  Address Taken!</FONT></B></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">The E-mail address: $INPUT{'email'} is already in our database. </FONT></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please contact
<A HREF="mailto:$orgmail"><B>$orgname Support</B></A> if you
need any further assistance.</FONT></P>
<HR SIZE="1">
<CENTER><FONT SIZE="-2" FACE="verdana, arial, helvetica"><B>$orgname maintained with
<A HREF="http://cgi.elitehost.com/"><B>Account Manager $version</B></A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}
}
}

sub dupeaddress2 {


opendir (DIR, "$memberinfo");
close (DIR); 
@file = grep { /.infotmp/} readdir(DIR);
 foreach $lines(@file) {

       open (DAT, "<$memberinfo/$lines");
if ($LOCK_EX){ 
      flock(DAT, $LOCK_EX); #Locks the file
	} 
             @approval = <DAT>;
                foreach $item(@approval) {
                    @edit_approval = split(/\:/,$item);
                  
&parseemail;                 

if ($edit_approval[2] eq $email) {last; }

# if ($edit_approval[2] =~ /$INPUT{'email'}/i) {last; }
}

if ($edit_approval[2] eq $email) {

# if ($edit_approval[2] =~ /$INPUT{'email'}/i) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="450"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account
Manager</FONT> Status:  Address Taken!</FONT></B></P>
<P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">The E-mail address:
$INPUT{'email'} was found in use by someone awaiting membership.</FONT></P>
<P><FONT COLOR="$fontcolor" SIZE="-1" FACE="verdana, arial, helvetica">Please contact
<A HREF="mailto:$orgmail"><B>$orgname Support</B></A> if you need any further
assistance.</FONT></P>
<HR SIZE="1">
<CENTER><FONT SIZE="-2" FACE="verdana, arial, helvetica"><B>$orgname
maintained with
<A HREF="http://cgi.elitehost.com/"><B>Account Manager $version</B></A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
#close (DIR);
exit;

}
}
}

sub dupepwd {


opendir (DIR, "$memberinfo");
close (DIR); 
@file = grep { /.infotmp/} readdir(DIR);
 foreach $lines(@file) {

       open (DAT, "<$memberinfo/$lines");
if ($LOCK_EX){ 
      flock(DAT, $LOCK_EX); #Locks the file
	} 
             @approval = <DAT>;
                foreach $item(@approval) {
                    @edit_approval = split(/\:/,$item);
                  
 if ($edit_approval[1] eq $INPUT{'pwd'}) {last; }
}

if ($edit_approval[1] eq $INPUT{'pwd'}) {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR>
<TABLE BORDER="0" WIDTH="450"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART="1"><P><B><FONT FACE="verdana, arial, helvetica"><FONT
COLOR="#FF0000">Account
Manager</FONT> Status:  Address Taken!</FONT></B></P>
<P><FONT SIZE="-1" FACE="verdana, arial, helvetica">The Password you chose has already been requested by a new prospective user.  Please choose another.</FONT></P>
<P><FONT SIZE="-1" FACE="verdana, arial, helvetica">Please contact
<A HREF="mailto:$orgmail"><B>$orgname Support</B></A> if you need any further
assistance.</FONT></P>
<HR SIZE="1">
<CENTER><FONT SIZE="-2" FACE="verdana, arial, helvetica"><B>$orgname
maintained with
<A HREF="http://cgi.elitehost.com/"><B>Account Manager $version</B></A></B></FONT> 
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
#close (DIR);
exit;

}
}
}


######################################
# Create temp files for Admin approval
######################################

sub temp {

# First, seed the random number generator
	srand;

	# Then get a random # for which a file name can be created
	$randNum = int(rand(999999));

      

&accounttypes;




#$setup = $one_setup + $two_setup;
#$monthly = $one_monthly + $two_monthly;

$INPUT{'username'} =~ s/\W.*//;


$INPUT{'fname'} =~ s/\s+$//;
$INPUT{'lname'} =~ s/\s+$//;


$newline2 = join
("\:",$INPUT{'username'},$INPUT{'pwd'},$INPUT{'email'},$INPUT{'fname'},$INPUT{'lname'},$setup,$monthly,$INPUT{'payment'},$INPUT{'creditcards'},$INPUT{'nameoncard'},$INPUT{'cardnumber'},$INPUT{'exp'},$INPUT{'billingaddress'},$INPUT{'billingaddress2'},$INPUT{'city'},$INPUT{'state'},$INPUT{'zip'},$INPUT{'lbill'},$INPUT{'papplied'},$INPUT{'aapplied'},$INPUT{'tbalance'},$INPUT{'tnew'},$INPUT{'tcharges'},$INPUT{'nnew'},$INPUT{'linvoice'},$INPUT{'taxes'},$INPUT{'ccity'},$INPUT{'cstate'},$INPUT{'czip'},$length,$INPUT{'address'},$INPUT{'address2'},$INPUT{'phone'},$INPUT{'country'},$INPUT{'ibillpincode'},$INPUT{'ibilltransnumber'},$INPUT{'ibillrebill'},0);
$newline2 .= "\n";



open(TEMP2, ">$memberinfo/$INPUT{'username'}.infotmp") or print "unable to create user info temp file.  Check your directory permission settings";
if ($LOCK_EX){ 
      flock(TEMP2, $LOCK_EX); #Locks the file
	}
print TEMP2 $newline2;
close (TEMP2);

       if ($instantaccess == 1) {

open (FILE, "<$memberinfo/$INPUT{'username'}.infotmp");
if ($LOCK_EX){ 
      flock(FILE, $LOCK_EX); #Locks the file
	}
      @approved = <FILE>;
      close (FILE);
      foreach $item(@approved) {
             
         open(DATABASE, ">>$memberinfo/amdata.db") or print"unable to create access temp file";
         if ($LOCK_EX){ 
      flock(DATABASE, $LOCK_EX); #Locks the file
	}
         chomp($item);
         print DATABASE "$item\n";

           if ($htaccess == "1") {
           open (DAT2, "<$memberinfo/$INPUT{'username'}.infotmp");
if ($LOCK_EX){ 
      flock(DAT2, $LOCK_EX); #Locks the file
	} 
           @second = <DAT2>;
           close (DAT2);
                foreach $item(@second) {
                @edit_second = split(/\:/,$item);
                chop ($edit_second[1]) if ($edit_second[1] =~ /\n$/);
		    $newpassword = crypt($edit_second[1], aa); 
                open(PASSWD, ">>$memaccess") or print"unable to create access temp file";
                print PASSWD "$edit_second[0]:$newpassword\n";
   }

close (PASSWD);


 }
close (DATABASE);
}

open (FILE, "<$memberinfo/$INPUT{'username'}.infotmp");
if ($LOCK_EX){ 
      flock(FILE, $LOCK_EX); #Locks the file
	}
       @approved = <FILE>;
       close (FILE);
       foreach $item(@approved) {

             @edit_approved = split(/\:/,$item);      


## Create Customer Billing Statement

if ($payment == 1) {
open (STATEMENT, ">$memberinfo/$edit_approved[0]statement.txt");
if ($LOCK_EX){ 
      flock(STATEMENT, $LOCK_EX); #Locks the file
	}
print STATEMENT "Customer Billing Statement - Created: $date2\n";
print STATEMENT "For $edit_approved[3] $edit_approved[4]\n";
print STATEMENT "=" x 75 . "\n\n";
print STATEMENT "$date2\n";
print STATEMENT "USER ID:              $edit_approved[0]\n";
  if ($edit_approved[7] eq "cc") {
print STATEMENT "Billing Address:      $edit_approved[12]\n";
              if ($edit_approved[8]) {
print STATEMENT "Billing Address2:     $edit_approved[13]\n";
}
}
print STATEMENT "Setup Charge:         $edit_approved[5]\n";
print STATEMENT "Monthly Charge:       $edit_approved[6]\n\n";
print STATEMENT "=" x 75 . "\n\n";
}
       
close (STATEMENT);

      #$tempfile = "$tempdir/$edit_approved[2]";      
      
      open (FILE,"$memberinfo/approved.txt"); #### Full path name from root.
if ($LOCK_EX){ 
      flock(FILE, $LOCK_EX); #Locks the file
	}
 @approved_email_file  = <FILE>;
 close(FILE);

# Output a temporary file

    open (MAIL, "|$mailprog -t")
	            || print "Can't start mail program";  
    
    print MAIL "To: $edit_approved[2]\n";
    print MAIL "From: $orgmail\n";

    #Date
    print MAIL "$date\n";
    
    # Check for Message Subject
    print MAIL "Subject: $approved_email_subject\n\n";
    print MAIL "-" x 75 . "\n\n";

    foreach $line(@closing) {
    $line =~ s/<FIRST_NAME>/$INPUT{'fname'}/g;
    $line =~s/<LAST_NAME>/$INPUT{'lname'}/g;
    $line =~ s/<USERNAME>/$INPUT{'username'}/g;
    $line =~s/<PASSWORD>/$INPUT{'pwd'}/g;
    $line =~s/<ORGNAME>/$orgname/g;
    $line =~s/<ORGMAIL>/$orgmail/g;
    }
                        
    foreach $line(@closing) {
    print MAIL "$line";
    }

    print MAIL"\n\n";
    close (MAIL);

 
        
        unlink ("$memberinfo/$lines");
        }
unlink ("$memberinfo/$INPUT{'username'}.infotmp");


}

if ($INPUT{$lines}) {
unlink ("$memberinfo/$lines");

}

#}

#}
&close;

exit;

}



######### CC verifier 3 Subroutine start
sub CC_Verify {

# print "Content-type: text/html\n\n";
# print "Validation running<BR>";

$cardnumber = $INPUT{'cardnumber'}; 

# print "$cardnumber<BR>";

# Remove any spaces or dashes in card number
$cardnumber =~ s/ //g;
$cardnumber =~ s/-//g;
$length = length($cardnumber);

# Make sure that only numbers exist
if (!($cardnumber =~ /^[0-9]*$/)) {
 &invalid_cc;
 }





# Verify correct length for each card type
if ($INPUT{'creditcards'} eq "visa") { &vlen; }
if ($INPUT{'creditcards'} eq "mastercard") { &mclen; }
if ($INPUT{'creditcards'} eq "amex") { &alen; }
if ($INPUT{'creditcards'} eq "novus") { &nlen; }

sub vlen {
    &invalid_cc unless (($length ==13) || ($length == 16));
}
sub mclen {
    &invalid_cc unless ($length == 16);    
}
sub alen {
    &invalid_cc unless ($length == 15);    
}
sub nlen {
    &invalid_cc unless ($length == 16);    
}

# Now Verify via Mod 10 for each one
if ($INPUT{'creditcards'} eq "visa") { &vver; }
if ($INPUT{'creditcards'} eq "mastercard") { &ver16; }
if ($INPUT{'creditcards'} eq "amex") { &ver15; }
if ($INPUT{'creditcards'} eq "novus") { &ver16; }

# pick one for Visa
sub vver {
	if ($length == 13) { &ver13; }
	if ($length == 16) { &ver16; }
}

# For 13 digit cards
sub ver13 {
        $cc0 = substr($cardnumber,0,1);
        $cc1 = substr($cardnumber,1,1);
        $cc2 = substr($cardnumber,2,1);
        $cc3 = substr($cardnumber,3,1);
        $cc4 = substr($cardnumber,4,1);
        $cc5 = substr($cardnumber,5,1);
        $cc6 = substr($cardnumber,6,1);
        $cc7 = substr($cardnumber,7,1);
        $cc8 = substr($cardnumber,8,1);
        $cc9 = substr($cardnumber,9,1);
        $cc10 = substr($cardnumber,10,1);
        $cc11 = substr($cardnumber,11,1);
        $cc12 = substr($cardnumber,12,1);

        $cc1a = $cc1 * 2;
        $cc3a = $cc3 * 2;
        $cc5a = $cc5 * 2;
        $cc7a = $cc7 * 2;
        $cc9a = $cc9 * 2;
        $cc11a = $cc11 * 2;

        if ($cc1a >= 10) {
            $cc1b = substr($cc1a,0,1);
            $cc1c = substr($cc1a,1,1);
            $cc1 = $cc1b+$cc1c;
        } else {
            $cc1 = $cc1a;
        }
        if ($cc3a >= 10) {
            $cc3b = substr($cc3a,0,1);
            $cc3c = substr($cc3a,1,1);
            $cc3 = $cc3b+$cc3c;
        } else {
            $cc3 = $cc3a;
        }
        if ($cc5a >= 10) {
            $cc5b = substr($cc5a,0,1);
            $cc5c = substr($cc5a,1,1);
            $cc5 = $cc5b+$cc5c;
        } else {
            $cc5 = $cc5a;
        }
        if ($cc7a >= 10) {
            $cc7b = substr($cc7a,0,1);
            $cc7c = substr($cc7a,1,1);
            $cc7 = $cc7b+$cc7c;
        } else {
            $cc7 = $cc7a;
        }
        if ($cc9a >= 10) {
            $cc9b = substr($cc9a,0,1);
            $cc9c = substr($cc9a,1,1);
            $cc9 = $cc9b+$cc9c;
        } else {
            $cc9 = $cc9a;
        }
        if ($cc11a >= 10) {
            $cc11b = substr($cc11a,0,1);
            $cc11c = substr($cc11a,1,1);
            $cc11 = $cc11b+$cc11c;
        } else {
            $cc11 = $cc11a;
        }

        $val = $cc0+$cc1+$cc2+$cc3+$cc4+$cc5+$cc6+$cc7+$cc8+$cc9+$cc10+$cc11+$cc12;
        if (substr($val,1,1) !=0 ) {
            &invalid_cc;
        }
	}

# For 16 digit cards
sub ver16 {
        $cc0 = substr($cardnumber,0,1);
        $cc1 = substr($cardnumber,1,1);
        $cc2 = substr($cardnumber,2,1);
        $cc3 = substr($cardnumber,3,1);
        $cc4 = substr($cardnumber,4,1);
        $cc5 = substr($cardnumber,5,1);
        $cc6 = substr($cardnumber,6,1);
        $cc7 = substr($cardnumber,7,1);
        $cc8 = substr($cardnumber,8,1);
        $cc9 = substr($cardnumber,9,1);
        $cc10 = substr($cardnumber,10,1);
        $cc11 = substr($cardnumber,11,1);
        $cc12 = substr($cardnumber,12,1);
        $cc13 = substr($cardnumber,13,1);
        $cc14 = substr($cardnumber,14,1);
        $cc15 = substr($cardnumber,15,1);

        $cc0a = $cc0 * 2;
        $cc2a = $cc2 * 2;
        $cc4a = $cc4 * 2;
        $cc6a = $cc6 * 2;
        $cc8a = $cc8 * 2;
        $cc10a = $cc10 * 2;
        $cc12a = $cc12 * 2;
        $cc14a = $cc14 * 2;

        if ($cc0a >= 10) {
            $cc0b = substr($cc0a,0,1);
            $cc0c = substr($cc0a,1,1);
            $cc0 = $cc0b+$cc0c;
        } else {
            $cc0 = $cc0a;
        }
        if ($cc2a >= 10) {
            $cc2b = substr($cc2a,0,1);
            $cc2c = substr($cc2a,1,1);
            $cc2 = $cc2b+$cc2c;
        } else {
            $cc2 = $cc2a;
        }
        if ($cc4a >= 10) {
            $cc4b = substr($cc4a,0,1);
            $cc4c = substr($cc4a,1,1);
            $cc4 = $cc4b+$cc4c;
        } else {
            $cc4 = $cc4a;
        }
        if ($cc6a >= 10) {
            $cc6b = substr($cc6a,0,1);
            $cc6c = substr($cc6a,1,1);
            $cc6 = $cc6b+$cc6c;
        } else {
            $cc6 = $cc6a;
        }
        if ($cc8a >= 10) {
            $cc8b = substr($cc8a,0,1);
            $cc8c = substr($cc8a,1,1);
            $cc8 = $cc8b+$cc8c;
        } else {
            $cc8 = $cc8a;
        }
        if ($cc10a >= 10) {
            $cc10b = substr($cc10a,0,1);
            $cc10c = substr($cc10a,1,1);
            $cc10 = $cc10b+$cc10c;
        } else {
            $cc10 = $cc10a;
        }
        if ($cc12a >= 10) {
            $cc12b = substr($cc12a,0,1);
            $cc12c = substr($cc12a,1,1);
            $cc12 = $cc12b+$cc12c;
        } else {
            $cc12 = $cc12a;
        }
        if ($cc14a >= 10) {
            $cc14b = substr($cc14a,0,1);
            $cc14c = substr($cc14a,1,1);
            $cc14 = $cc14b+$cc14c;
        } else {
            $cc14 = $cc14a;
        }

        $val = $cc0+$cc1+$cc2+$cc3+$cc4+$cc5+$cc6+$cc7+$cc8+$cc9+$cc10+$cc11+$cc12+$cc13+$cc14+$cc15;
        if (substr($val,1,1) !=0 ) {
            &invalid_cc;
        }
    }


# For 15 digit (Amex) cards
sub ver15 {
        $cc0 = substr($cardnumber,0,1);
        $cc1 = substr($cardnumber,1,1);
        $cc2 = substr($cardnumber,2,1);
        $cc3 = substr($cardnumber,3,1);
        $cc4 = substr($cardnumber,4,1);
        $cc5 = substr($cardnumber,5,1);
        $cc6 = substr($cardnumber,6,1);
        $cc7 = substr($cardnumber,7,1);
        $cc8 = substr($cardnumber,8,1);
        $cc9 = substr($cardnumber,9,1);
        $cc10 = substr($cardnumber,10,1);
        $cc11 = substr($cardnumber,11,1);
        $cc12 = substr($cardnumber,12,1);
        $cc13 = substr($cardnumber,13,1);
        $cc14 = substr($cardnumber,14,1);

        $cc1a = $cc1 * 2;
        $cc3a = $cc3 * 2;
        $cc5a = $cc5 * 2;
        $cc7a = $cc7 * 2;
        $cc9a = $cc9 * 2;
        $cc11a = $cc11 * 2;
        $cc13a = $cc13 * 2;

        if ($cc1a >= 10) {
            $cc1b = substr($cc1a,0,1);
            $cc1c = substr($cc1a,1,1);
            $cc1 = $cc1b+$cc1c;
        } else {
            $cc1 = $cc1a;
        }
        if ($cc3a >= 10) {
            $cc3b = substr($cc3a,0,1);
            $cc3c = substr($cc3a,1,1);
            $cc3 = $cc3b+$cc3c;
        } else {
            $cc3 = $cc3a;
        }
        if ($cc5a >= 10) {
            $cc5b = substr($cc5a,0,1);
            $cc5c = substr($cc5a,1,1);
            $cc5 = $cc5b+$cc5c;
        } else {
            $cc5 = $cc5a;
        }
        if ($cc7a >= 10) {
            $cc7b = substr($cc7a,0,1);
            $cc7c = substr($cc7a,1,1);
            $cc7 = $cc7b+$cc7c;
        } else {
            $cc7 = $cc7a;
        }
        if ($cc9a >= 10) {
            $cc9b = substr($cc9a,0,1);
            $cc9c = substr($cc9a,1,1);
            $cc9 = $cc9b+$cc9c;
        } else {
            $cc9 = $cc9a;
        }
        if ($cc11a >= 10) {
            $cc11b = substr($cc11a,0,1);
            $cc11c = substr($cc11a,1,1);
            $cc11 = $cc11b+$cc11c;
        } else {
            $cc11 = $cc11a;
        }
        if ($cc13a >= 10) {
            $cc13b = substr($cc13a,0,1);
            $cc13c = substr($cc13a,1,1);
            $cc13 = $cc13b+$cc13c;
        } else {
            $cc13 = $cc13a;
        }

        $val = $cc0+$cc1+$cc2+$cc3+$cc4+$cc5+$cc6+$cc7+$cc8+$cc9+$cc10+$cc11+$cc12+$cc13+$cc14;
        if (substr($val,1,1) !=0 ) {
            &invalid_cc;
        }
    }


}


#####
# This Section For Anything Past CC Validation
#####


sub invalid_cc {
print "Content-type: text/html\n\n";
if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><BR> <TABLE BORDER="0" WIDTH="400"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD COLSTART="1"><CENTER><P><B><FONT COLOR="$fontcolor" FACE="verdana, arial, helvetica"><FONT COLOR="#FF0000">Account Manager</FONT> Status:<BR>Card Number Does Not Pass Validaion.</FONT></B></P></CENTER> <P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">Please use your <B>Back</B> button and verify that the number you've entered is correct and contains no additional characters other than spaces or hyphens.</FONT></P> <P><FONT SIZE="-1" COLOR="$fontcolor" FACE="verdana, arial, helvetica">If you need further assistance, please contact <A HREF="mailto:$orgmail">$orgname Support</A>.</FONT></P> <CENTER><TABLE BORDER="0" WIDTH="400">
<TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD COLSTART="1"><HR SIZE="1"> <CENTER><FONT SIZE="-2" COLOR="$fontcolor" FACE="verdana, arial, helvetica">$orgname maintained with <B><A HREF="http://cgi.elitehost.com/">Account Manager $version</A></B></FONT> </CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER>
EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;

}




#####

######### CC verifier 3 Subroutine end 


sub verify {
&newid;

print "Content-type: text/html\n\n";

if ($secureheader) {
&secureheader;
} else {
&header;
}
print<<EOF;
<CENTER><TABLE BORDER="0" WIDTH="400"><SQTBODY><COLDEFS><COLDEF></COLDEFS><ROWS>
<TR><TD COLSTART="1"><FONT FACE="verdana, arial, helvetica" COLOR="#FF0000"><B>Step 2:</B> </FONT><FONT SIZE="-1" FACE="verdana, arial, helvetica">Please verify the information below.<BR></FONT></TD></TR></ROWS></SQTBODY></TABLE></CENTER>


<CENTER><TABLE BORDER="0" WIDTH="400"><SQTBODY><COLDEFS><COLDEF><COLDEF></COLDEFS>
<ROWS>

EOF




&accounttypes;

$total  = sprintf("%1.2f",$finaltotal);



print<<EOF;
<TR><TD COLSTART="1"><BR><FONT FACE="arial, helvetica" COLOR="#FF0000">Total:</FONT></TD><TD COLSTART="2" WIDTH="100" NOWRAP="NOWRAP" ALIGN="RIGHT"><FONT FACE="arial, helvetica" COLOR="#FF0000">
EOF
printf("\$%.2f",$finaltotal);

$total  = sprintf("%1.2f",$finaltotal);
# $total = int (( $finaltotal * 100 ) + .5 ) / 100;




print"</FONT></TD></TR>
</ROWS></SQTBODY></TABLE><BR></CENTER>
<CENTER><FORM ACTION=\"";


#if (!($authorizenet)) {
#print "$purchaseurl";
#} else {
#print "https://www.authorize.net/scripts/authnet25/AuthPost2.asp";
#}

if ($authorizenet) {
print "https://secure.authorize.net/gateway/transact.dll";
} elsif ($ecx) {
print "https://secure.quickcommerce.net/gateway/transact.dll";
} else {
print "$cgiurl";
}


print<<EOF;
" METHOD="POST">
<INPUT TYPE="HIDDEN" NAME="x_ADC_Relay_Response" VALUE="TRUE">
<INPUT TYPE="HIDDEN" NAME="x_Version" VALUE="3.0">
<INPUT TYPE="HIDDEN" NAME="x_Email_Customer" VALUE="FALSE">
<INPUT TYPE="HIDDEN" NAME="username" VALUE="$INPUT{'username'}">
<INPUT TYPE="HIDDEN" NAME="pwd" VALUE="$INPUT{'pwd'}">
<INPUT TYPE="HIDDEN" NAME="x_Cust_ID" VALUE="$new_id">
EOF

if ($authorizenet || $ecx) {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="x_Login" VALUE="$login">
<INPUT TYPE="HIDDEN" NAME="x_Test_Request" VALUE="$test_request">
<INPUT TYPE="HIDDEN" NAME="x_ADC_URL" VALUE="$auth_redirect">
<INPUT TYPE="HIDDEN" NAME="x_Email_Customer" VALUE="FALSE">
<INPUT TYPE="HIDDEN" NAME="x_Email_Merchant" VALUE="FALSE">
<INPUT TYPE="HIDDEN" NAME="x_Amount" VALUE="$total">
<INPUT TYPE="HIDDEN" NAME="x_Type" VALUE="$transtype">
<INPUT TYPE="HIDDEN" NAME="USER3" VALUE="$orgmail">
<INPUT TYPE="HIDDEN" NAME="USER4" VALUE="$orgname">
<INPUT TYPE="HIDDEN" NAME="USER5" VALUE="$approved_email_subject">
<INPUT TYPE="HIDDEN" NAME="USER6" VALUE="cc">
<INPUT TYPE="HIDDEN" NAME="USER7" VALUE="$INPUT{'accounts'}">
<INPUT TYPE="HIDDEN" NAME="USER8" VALUE="$INPUT{'username'}">
<INPUT TYPE="HIDDEN" NAME="USER9" VALUE="$INPUT{'pwd'}">
<INPUT TYPE="HIDDEN" NAME="x_Email" VALUE="$INPUT{'email'}">
EOF
}

if ($seamless) {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="DISABLERECEIPT" VALUE="TRUE">
EOF
}



print<<EOF;
<CENTER><TABLE BORDER="0" WIDTH="400"><SQTBODY
><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD COLSTART="1"><HR SIZE="2" NOSHADE="NOSHADE"></TD></TR>
<TR><TD ALIGN="CENTER" COLSTART="1"><TABLE BORDER="0" WIDTH="350" NOWRAP="NOWRAP">
<SQTBODY><COLDEFS><COLDEF><COLDEF></COLDEFS><ROWS><TR><TD COLSPAN="2" COLSTART="1"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>Customer Information</B></FONT><BR> <FONT SIZE="-2" FACE="verdana, arial, helvetica" COLOR="#FF0000"><B>Fields marked with an astriks<BR> are required input fields.</B></FONT><BR> <BR> </TD></TR><TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="verdana, arial, helvetica">First Name:</FONT> </TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'fname'}</B></FONT> <INPUT TYPE="HIDDEN" NAME="fname" VALUE="$INPUT{'fname'}">
<INPUT TYPE="HIDDEN" NAME="x_First_Name" VALUE="$INPUT{'fname'}">
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="verdana, arial, helvetica">Last Name:</FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'lname'}</B></FONT>
<INPUT TYPE="HIDDEN" NAME="lname" VALUE="$INPUT{'lname'}">
<INPUT TYPE="HIDDEN" NAME="x_Last_Name" VALUE="$INPUT{'lname'}">
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="verdana, arial, helvetica">Address:</FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'address'}</B></FONT>
EOF

if ($authorizenet || $ecx) {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="x_Address" VALUE="$INPUT{'address'}">
EOF
} else {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="address" VALUE="$INPUT{'address'}">
EOF
}


print<<EOF;
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="verdana, arial, helvetica">Address 2: </FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'address2'}</B></FONT>
<INPUT TYPE="HIDDEN" NAME="address2" VALUE="$INPUT{'address2'}">
<INPUT TYPE="HIDDEN" NAME="USER2" VALUE="$INPUT{'address2'}">
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="verdana, arial, helvetica">City: </FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'city'}</B></FONT>
EOF

if ($authorizenet || $ecx) {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="x_City" VALUE="$INPUT{'city'}">
EOF
} else {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="city" VALUE="$INPUT{'city'}">
EOF
}


print<<EOF;
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="verdana, arial, helvetica">State or Province: </FONT></TD><TD COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>
EOF

if ($INPUT{'state2'}) {
print<<EOF;
$INPUT{'state2'}
EOF
} else {
print<<EOF;
$INPUT{'state'}
EOF
}

print<<EOF;
</B></FONT>
EOF

if ($INPUT{'state2'}) {

print<<EOF;
<INPUT TYPE="HIDDEN" NAME="state2" VALUE="$INPUT{'state2'}">
<INPUT TYPE="HIDDEN" NAME="USER7" VALUE="$INPUT{'state2'}">
EOF
} else {

if ($authorizenet || $ecx) {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="x_State" VALUE="$INPUT{'state'}">
EOF
} else {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="state" VALUE="$INPUT{'state'}">
EOF
}
}


print<<EOF;
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="verdana, arial, helvetica">Postal Code (ZIP): </FONT></TD><TD COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'zip'}</B></FONT>
EOF

if ($authorizenet || $ecx) {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="x_Zip" VALUE="$INPUT{'zip'}">
EOF
} else {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="zip" VALUE="$INPUT{'zip'}">
EOF
}


print<<EOF;
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="verdana, arial, helvetica">Country: </FONT></TD><TD COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'country'}</B></FONT>
EOF

if ($authorizenet || $ecx) {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="x_Country" VALUE="$INPUT{'country'}">
EOF
} else {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="country" VALUE="$INPUT{'country'}">
EOF
}

print<<EOF;
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="verdana, arial, helvetica">Telephone Number: </FONT></TD><TD COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'phone'}</B></FONT>
EOF

if ($authorizenet || $ecx) {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="x_Phone" VALUE="$INPUT{'phone'}">
EOF
} else {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="phone" VALUE="$INPUT{'phone'}">
EOF
}

print<<EOF;
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="verdana, arial, helvetica">E-Mail Address: </FONT></TD><TD COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'email'}</B></FONT>
EOF

if ($authorizenet || $ecx) {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="x_Email" VALUE="$INPUT{'email'}">
EOF
} else {
print<<EOF;
<INPUT TYPE="HIDDEN" NAME="email" VALUE="$INPUT{'email'}">
EOF
}

print<<EOF;
</TD></TR></ROWS></SQTBODY></TABLE> <TABLE BORDER="0" WIDTH="350" NOWRAP="NOWRAP">
<SQTBODY><COLDEFS><COLDEF><COLDEF></COLDEFS><ROWS><TR><TD COLSPAN="2" COLSTART="1"><BR> <BR> <FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>Method of Payment</B><BR> </FONT><FONT SIZE="-2" FACE="verdana, arial, helvetica"><B><FONT COLOR="#FF0000">Please be sure to select your payment method</FONT></B></FONT><BR> <BR> </TD></TR><TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="verdana, arial, helvetica">Paid by:</FONT></TD>
EOF

if ($INPUT{'payment'} eq check) {
print<<EOF;
<TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>Check</B></FONT><INPUT TYPE="HIDDEN" NAME="payment" VALUE="$INPUT{'payment'}"></TD></TR>
EOF
} else {
print<<EOF;
<TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>Credit Card</B></FONT><INPUT TYPE="HIDDEN" NAME="payment" VALUE="$INPUT{'payment'}"></TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="arial, helvetica">Credit Card:</FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'creditcards'}</B></FONT>
<INPUT TYPE="HIDDEN" NAME="creditcards" VALUE="$INPUT{'creditcards'}">
<INPUT TYPE="HIDDEN" NAME="x_Method" VALUE="$INPUT{'creditcards'}">
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="arial, helvetica">Name On Card:</FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'nameoncard'}</B></FONT>
<INPUT TYPE="HIDDEN" NAME="nameoncard" VALUE="$INPUT{'nameoncard'}">
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="arial, helvetica"> Card Number:</FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'cardnumber'}</B></FONT>
<INPUT TYPE="HIDDEN" NAME="cardnumber" VALUE="$INPUT{'cardnumber'}">
<INPUT TYPE="HIDDEN" NAME="x_Card_Num" VALUE="$INPUT{'cardnumber'}">
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="arial, helvetica">Expiration Date:</FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'exp'}</B></FONT>
<INPUT TYPE="HIDDEN" NAME="exp" VALUE="$INPUT{'exp'}">
<INPUT TYPE="HIDDEN" NAME="x_Exp_Date" VALUE="$INPUT{'exp'}">
</TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="arial, helvetica">Billing Address:</FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'billingaddress'}</B></FONT> <INPUT TYPE="HIDDEN" NAME="billingaddress" VALUE="$INPUT{'billingaddress'}"></TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="arial, helvetica">Billing Address 2:</FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'billingaddress2'}</B></FONT><INPUT TYPE="HIDDEN" NAME="billingaddress2" VALUE="$INPUT{'billingaddress2'}"></TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="arial, helvetica">Billing City:</FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'ccity'}</B></FONT><INPUT TYPE="HIDDEN" NAME="ccity" VALUE="$INPUT{'ccity'}"></TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="arial, helvetica">Billing State:</FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'cstate'}</B></FONT><INPUT TYPE="HIDDEN" NAME="cstate" VALUE="$INPUT{'cstate'}"></TD></TR>
<TR><TD VALIGN="TOP" COLSTART="1"><FONT SIZE="-1" FACE="arial, helvetica">Billing Zip:</FONT></TD><TD VALIGN="TOP" COLSTART="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><B>$INPUT{'czip'}</B></FONT><INPUT TYPE="HIDDEN" NAME="czip" VALUE="$INPUT{'czip'}"></TD></TR>
EOF
}
print<<EOF;
<TR><TD VALIGN="TOP" COLSTART="1" COLSPAN="2"><FONT SIZE="-1" FACE="verdana, arial, helvetica"><BR><BR><B>If all of the above is correct</B>, please press <B><FONT COLOR="#FF0000"> SUBMIT</FONT></B> below, otherwise press your browser's BACK button or if your browser supports Javascript press the <B><FONT COLOR="#FF0000"> BACK TO INFORMTION FORM</FONT></B> button below.<BR> <COLSTART="1"><BR>
<BR><CENTER><INPUT TYPE="SUBMIT" NAME="finish" VALUE="Submit My Order"><INPUT TYPE="RESET" NAME=""></CENTER></TD></TR></ROWS></SQTBODY></TABLE></TD></TR>

</TABLE></CENTER></FORM>

<FORM><INPUT TYPE="BUTTON" VALUE="BACK TO INFORMATION FORM" ONCLICK="history.go(-1)"></FORM>



EOF
if ($securefooter) {
&securefooter;
} else {
&footer;
}
exit;
}



sub parseusername {
$desiredname = $INPUT{'username'};
$lines =~ tr/A-Z/a-z/;
$desiredname =~ tr/A-Z/a-z/;
}

sub parseusername2 {
$desiredname = $INPUT{'username'};
$edit_array[0] =~ tr/A-Z/a-z/;
$desiredname =~ tr/A-Z/a-z/;
}




sub accounttypes {

if (($INPUT{'accounts'} !=~ /choose one/i) && ($INPUT{'accounts'} eq one)) {

if ($IBILL) {
$webfile = $act1pincodes;
&ibill;
}

# print "Content-type: text/html\n\n";
# print "Accounts = $INPUT{'accounts'}<BR>";
# exit;

$account_name = $account_one; 
$setup = $setup_one;
$monthly = $monthly_one;
$length = $lengthone;
}

if (($INPUT{'accounts'} !=~ /choose one/i) && ($INPUT{'accounts'} eq two)) {

if ($IBILL) {
$webfile = $act2pincodes;
&ibill;
}
$account_name = $account_two; 
$setup = $setup_two;
$monthly = $monthly_two;
$length = $lengthtwo;
}

if (($INPUT{'accounts'} !=~ /choose one/i) && ($INPUT{'accounts'} eq three)) {

if ($IBILL) {
$webfile = $act3pincodes;
&ibill;
}
$account_name = $account_three; 
$setup = $setup_three;
$monthly = $monthly_three;
$length = $lengththree;
}

$finaltotal = $setup + $monthly;

}


sub newid {

open (ID,"$memberinfo/ordernumber.txt"); ## Creating an invoice number.
if ($LOCK_EX){ 
      flock(ID, $LOCK_EX); #Locks the file
	}
$new_id = <ID> ;
if (!$new_id) {
$new_id = "AM100";
} 

close (ID);
$new_id++;
open (NEWID,">$memberinfo/ordernumber.txt");
if ($LOCK_EX){ 
      flock(NEWID, $LOCK_EX); #Locks the file
	}
print NEWID "$new_id";
close (NEWID);
}


sub parseemail {
$email = $INPUT{'email'};
$edit_array[2] =~ tr/A-Z/a-z/;
$email =~ tr/A-Z/a-z/;
}


sub header {
open (FILE,"<$header/header.txt"); #### Full path name from root. 
 @headerfile = <FILE>;
 close(FILE);
print "<HTML><HEAD><TITLE></TITLE></HEAD><BODY $bodyspec>\n";
foreach $line(@headerfile) {
print "$line";
  }
}


sub footer {
open (FILE,"<$footer/footer.txt"); #### Full path name from root. 
 @footerfile = <FILE>;
 close(FILE);
foreach $line(@footerfile) {
print "$line";
}
print "</BODY></HTML>";
}

sub secureheader {
open (SHFILE,"<$secureheader/header.txt"); #### Full path name from root. 
 @shheaderfile = <SHFILE>;
 close(SHFILE);
print "<HTML><HEAD><TITLE></TITLE></HEAD><BODY $bodyspec>\n";
foreach $line(@shheaderfile) {
print "$line";
  }
}

sub securefooter {
open (SFFILE,"<$securefooter/footer.txt"); #### Full path name from root.
if ($LOCK_EX){ 
      flock(SFFILE, $LOCK_EX); #Locks the file
} 
 @sfooterfile = <SFFILE>;
 close(SFFILE);
foreach $sfline(@sfooterfile) {
print "$sfline";

}
print<<EOF;
</BODY></HTML>
EOF
}

