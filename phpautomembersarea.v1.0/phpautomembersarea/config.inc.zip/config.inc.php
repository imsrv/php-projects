<?
//  phpAutoMembersArea config file

$phpAutoMembersArea_version = "1.0";


  define('DBHOST', 'localhost');
  define('DBUSER', 'test');
  define('DBPASS', 'test');
  define('DBNAME', 'test');

  define('CO_NAME', 'Name');
  define('ADMIN_FOLDER', 'admin');
?>