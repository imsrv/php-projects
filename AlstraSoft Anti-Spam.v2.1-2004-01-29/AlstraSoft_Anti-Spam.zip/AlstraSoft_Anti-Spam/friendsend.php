<?php
	include("./vars.inc");
	include("./template.inc");
	$q = new CDbSpam;
	$t = new Template($rootpath);
	$t->set_file("doctemplate","phptemplate.htm");
	$query='select friendmessage from admin where id=1';
	$q->query($query);
	$q->next_record();
	$message=$q->f("friendmessage");
	if ($textfield6=='') $textfield6='Anonymous';
	if ($textfield1!='') @mail($textfield1,$textfield6.' wants you to visit alstrasoft.com',$message."\n".$textfield6,"From: AlstraSoft Anti-Spam <noreply@alstrasoft.com> \r\n");
	if ($textfield2!='') @mail($textfield2,$textfield6.' wants you to visit alstrasoft.com',$message."\n".$textfield6,"From: AlstraSoft Anti-Spam <noreply@alstrasoft.com> \r\n");
	if ($textfield3!='') @mail($textfield3,$textfield6.' wants you to visit alstrasoft.com',$message."\n".$textfield6,"From: AlstraSoft Anti-Spam <noreply@alstrasoft.com> \r\n");
	if ($textfield4!='') @mail($textfield4,$textfield6.' wants you to visit alstrasoft.com',$message."\n".$textfield6,"From: AlstraSoft Anti-Spam <noreply@alstrasoft.com> \r\n");
	if ($textfield5!='') @mail($textfield5,$textfield6.' wants you to visit alstrasoft.com',$message."\n".$textfield6,"From: AlstraSoft Anti-Spam <noreply@alstrasoft.com> \r\n");
	$t->set_var("title","Tell a Friend");
	$t->set_var("content","<br><div align=\"center\">Your e-mail has been sent. </div><br><br><br><br>" );
	$t->parse("out","doctemplate");
	$t->p("out");

?>