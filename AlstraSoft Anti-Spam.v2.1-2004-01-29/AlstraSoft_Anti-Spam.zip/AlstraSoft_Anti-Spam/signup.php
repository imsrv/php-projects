<?php
	
	include("./vars.inc");
//	include("./template.inc");
	
//	$t = new Template($rootpath);
	
//	$t->set_file("doctemplate","phptemplate.htm");	
	session_start();
	$q = new CDbPharma;
	$q->query('select count(*) as numar from users  where username="'.$username.'"');
	$q->next_record();
	$n=$q->f("numar");
	if ($username=='')
	{
		echo('<script language="JavaScript"> function go() { window.location.href="signupform.php?error='.htmlentities(urlencode(' ERROR: You must enter an username.')).'&fullname='.htmlentities(urlencode($fullname)).'&phone='.htmlentities(urlencode($phone)).'&email='.htmlentities(urlencode($email)).'&shippingaddress='.htmlentities(urlencode($shippingaddress)).'&shippingcity='.htmlentities(urlencode($shippingcity)).'&shippingstate='.htmlentities(urlencode($shippingstate)).'&shippingpostalcode='.htmlentities(urlencode($shippingpostalcode)).'&shippingcountry='.htmlentities(urlencode($shippingcountry)).'&billingaddress='.htmlentities(urlencode($billingaddress)).'&billingcity='.htmlentities(urlencode($billingcity)).'&billingstate='.htmlentities(urlencode($billingstate)).'&billingpostalcode='.htmlentities(urlencode($billingpostalcode)).'&billingcountry='.htmlentities(urlencode($billingcountry)).'&edit='.$edit.' "} </script> <body onLoad=go(); > </body>');
	}
	else
	if (($n!=0)&&($edit!=1)) 
	{
		echo('<script language="JavaScript"> function go() { window.location.href="signupform.php?error='.htmlentities(urlencode(' ERROR: Username already exists. Please enter another.')).'&fullname='.htmlentities(urlencode($fullname)).'&phone='.htmlentities(urlencode($phone)).'&email='.htmlentities(urlencode($email)).'&shippingaddress='.htmlentities(urlencode($shippingaddress)).'&shippingcity='.htmlentities(urlencode($shippingcity)).'&shippingstate='.htmlentities(urlencode($shippingstate)).'&shippingpostalcode='.htmlentities(urlencode($shippingpostalcode)).'&shippingcountry='.htmlentities(urlencode($shippingcountry)).'&billingaddress='.htmlentities(urlencode($billingaddress)).'&billingcity='.htmlentities(urlencode($billingcity)).'&billingstate='.htmlentities(urlencode($billingstate)).'&billingpostalcode='.htmlentities(urlencode($billingpostalcode)).'&billingcountry='.htmlentities(urlencode($billingcountry)).'&edit='.$edit.' "} </script> <body onLoad=go(); > </body>');
	}
	else
	if ($password!=$rpassword)
	{
		echo('<script language="JavaScript"> function go() { window.location.href="signupform.php?error='.htmlentities(urlencode('ERROR: Passwords do not match')).'&username='.htmlentities(urlencode($username)).'&fullname='.htmlentities(urlencode($fullname)).'&phone='.htmlentities(urlencode($phone)).'&email='.htmlentities(urlencode($email)).'&shippingaddress='.htmlentities(urlencode($shippingaddress)).'&shippingcity='.htmlentities(urlencode($shippingcity)).'&shippingstate='.htmlentities(urlencode($shippingstate)).'&shippingpostalcode='.htmlentities(urlencode($shippingpostalcode)).'&shippingcountry='.htmlentities(urlencode($shippingcountry)).'&billingaddress='.htmlentities(urlencode($billingaddress)).'&billingcity='.htmlentities(urlencode($billingcity)).'&billingstate='.htmlentities(urlencode($billingstate)).'&billingpostalcode='.htmlentities(urlencode($billingpostalcode)).'&billingcountry='.htmlentities(urlencode($billingcountry)).'&edit='.$edit.' "} </script> <body onLoad=go(); > </body>');
	}
	else 
	{
		if ($edit==1)
		{
			$query='UPDATE users SET username= \''.$username.'\', password= \''.$password.'\' , fullname= \''.$fullname.'\', phone= \''.$phone.'\', email= \''.$email.'\' , shippingaddress= \''.$shippingaddress.'\', shippingcity= \''.$shippingcity.'\', shippingstate= \''.$shippingstate.'\', shippingpostalcode= \''.$shippingpostalcode.'\', shippingcountry= \''.$shippingcountry.'\', billingaddress= \''.$billingaddress.'\' , billingcity= \''.$billingcity.'\', billingstate= \''.$billingstate.'\', billingpostalcode= \''.$billingpostalcode.'\', billingcountry= \''.$billingcountry.'\' WHERE username=\''.$username.'\'';
			$q->query($query);
			$message="You have changed your account information on PharmaOnNet Store\nAccount information:\nUsername: $username\nPassword: $password\n\nWith respect, \nPharmaOnNet.";
			@mail($email,"Account updated",$message,"From:support@pharmaoonet.com");
		}
		else
		{
			$query=sprintf("INSERT INTO users (username, password, fullname, phone, email, shippingaddress, shippingcity, shippingstate, shippingpostalcode, shippingcountry, billingaddress, billingcity, billingstate, billingpostalcode, billingcountry) VALUES (\"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\")", $username, $password, $fullname, $phone, $email, $shippingaddress, $shippingcity, $shippingstate, $shippingpostalcode, $shippingcountry, $billingaddress, $billingcity, $billingstate, $billingpostalcode, $billingcountry);
			$q->query($query);
			$message="You have created a new account on PharmaOnNet Store\nAccount information:\nUsername: $username\nPassword: $password\n\nWith respect, \nPharmaOnNet.";
			@mail($email,"Congratulations",$message,"From:support@pharmaoonet.com");
			session_unregister("sessuser");
		}
		echo('<script language="JavaScript"> function go() { window.location.href="shop.php"} </script> <body onLoad=go(); > </body>');
	}

//	$t->set_var("CONTENT","");
//	$t->parse("out","doctemplate");
//	$t->p("out");
?>