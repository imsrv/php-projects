<?php

	set_time_limit(0);
	include("./vars.inc");
	include("./template.inc");
	session_start();
	if ($action=="logout")
	{
			session_unregister("sessuser");
			unset($sessuser);

	}
	$q = new CDbSpam;
	$q2 = new CDbSpam;
	$t = new Template($rootpath);
	$t->set_file("doctemplate","phptemplate.htm");

	if (!isset($sessuser)&&($action!="login"))
	{
		FFileRead("logintemplate.htm",$content);

	}


	if (($action=="recurringdone")&&(isset($sessuser)))
	{
		session_register("sessuser");
		$query='select * from users where username="'.$sessuser.'"';
		$q->query($query);
		$q->next_record();
		if (($q->f("code")==$merchant_order_id)&&($credit_card_processed=="Y"))
		{
			$expdate="Recurring Billing";
			$usern=$sessuser;
			$num=0;
			for ($i=1; $i<=strlen($usern); $i++) $num=$num*7+ord($usern[$i]);
			$num.=$usern.chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122));

			$query='UPDATE users SET expdate= "'.$expdate.'" , code="'.$num.'" WHERE id='.$q->f("id");
			$q->query($query);
			unset($credit_card_processed);
			unset($merchant_order_id);
		}
		$action="memberprofile";
	}
	if (($action=="paymentdone")&&(isset($sessuser)))
	{
		$query='select * from users where username="'.$sessuser.'"';
		$q->query($query);
		$q->next_record();
		if (($q->f("code")==$cart_order_id)&&($credit_card_processed=="Y"))
		{
			$expdate=$q->f("expdate");
			$expa=explode("-",$expdate);
			$expdate=date ("m-d-Y",  mktime (0,0,0,$expa[0]+1 ,$expa[1],$expa[2]));
			$usern=$sessuser;
			$num=0;
			for ($i=1; $i<=strlen($usern); $i++) $num=$num*7+ord($usern[$i]);
			$num.=$usern.chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122));

			$query='UPDATE users SET expdate= "'.$expdate.'" , code="'.$num.'" WHERE id='.$q->f("id");
			$q->query($query);
			unset($credit_card_processed);
			unset($cart_order_id);
		}
		$action="memberprofile";
	}
	if (($action=="login")&&(!isset($sessuser)))
	{
			$q->query('select * from users  where username="'.$username.'"');
			$q->next_record();
			if (($q->f("password")==$password)&&($q->f("username")==$username)&&($username!=""))
			{
				$sessuser=$username;
				session_register("sessuser");
				$action="memberprofile";
			}
			else
			{
				FFileRead("logintemplate.htm",$content);
				$content.='<blockquote> <p class="content"><font color="#FF0000">Error: Incorrect username or password. <a href="member.php?action=lostpassword">If you forgot your password click here.</a></font></p></blockquote>';
			}

	}

	if ($action=="signup")
	{
		$q->query('select count(*) as numar from users  where username="'.$username.'"');
		$q->next_record();
		$n=$q->f("numar");
		if ($username=='')
		{
			echo('<script language="JavaScript"> function go() { window.location.href="join.php?error='.htmlentities(urlencode(' ERROR: You must enter a username.')).'&fullname='.htmlentities(urlencode($fullname)).'&phone='.htmlentities(urlencode($phone)).'&email='.htmlentities(urlencode($email)).'&address='.htmlentities(urlencode($address)).'&city='.htmlentities(urlencode($city)).'&state='.htmlentities(urlencode($state)).'&postalcode='.htmlentities(urlencode($postalcode)).'&country='.htmlentities(urlencode($country)).'&billingaddress='.htmlentities(urlencode($billingaddress)).'&billingcity='.htmlentities(urlencode($billingcity)).'&billingstate='.htmlentities(urlencode($billingstate)).'&billingpostalcode='.htmlentities(urlencode($billingpostalcode)).'&billingcountry='.htmlentities(urlencode($billingcountry)).'&edit='.$edit.' "} </script> <body onLoad=go(); > </body>');
		}
		else
		if (($n!=0)&&($edit!=1))
		{
			echo('<script language="JavaScript"> function go() { window.location.href="join.php?error='.htmlentities(urlencode(' ERROR: Username already exists. Please enter a different one.')).'&fullname='.htmlentities(urlencode($fullname)).'&phone='.htmlentities(urlencode($phone)).'&email='.htmlentities(urlencode($email)).'&address='.htmlentities(urlencode($address)).'&city='.htmlentities(urlencode($city)).'&state='.htmlentities(urlencode($state)).'&postalcode='.htmlentities(urlencode($postalcode)).'&country='.htmlentities(urlencode($country)).'&billingaddress='.htmlentities(urlencode($billingaddress)).'&billingcity='.htmlentities(urlencode($billingcity)).'&billingstate='.htmlentities(urlencode($billingstate)).'&billingpostalcode='.htmlentities(urlencode($billingpostalcode)).'&billingcountry='.htmlentities(urlencode($billingcountry)).'&edit='.$edit.' "} </script> <body onLoad=go(); > </body>');
		}
		else
		if ($password!=$rpassword)
		{
			echo('<script language="JavaScript"> function go() { window.location.href="join.php?error='.htmlentities(urlencode('ERROR: Passwords do not match')).'&username='.htmlentities(urlencode($username)).'&fullname='.htmlentities(urlencode($fullname)).'&phone='.htmlentities(urlencode($phone)).'&email='.htmlentities(urlencode($email)).'&address='.htmlentities(urlencode($address)).'&city='.htmlentities(urlencode($city)).'&state='.htmlentities(urlencode($state)).'&postalcode='.htmlentities(urlencode($postalcode)).'&country='.htmlentities(urlencode($country)).'&billingaddress='.htmlentities(urlencode($billingaddress)).'&billingcity='.htmlentities(urlencode($billingcity)).'&billingstate='.htmlentities(urlencode($billingstate)).'&billingpostalcode='.htmlentities(urlencode($billingpostalcode)).'&billingcountry='.htmlentities(urlencode($billingcountry)).'&edit='.$edit.' "} </script> <body onLoad=go(); > </body>');
		}
		else
		if (strlen($password)<5)
		{
			echo('<script language="JavaScript"> function go() { window.location.href="join.php?error='.htmlentities(urlencode('ERROR: Password must be at least 5 characters')).'&username='.htmlentities(urlencode($username)).'&fullname='.htmlentities(urlencode($fullname)).'&phone='.htmlentities(urlencode($phone)).'&email='.htmlentities(urlencode($email)).'&address='.htmlentities(urlencode($address)).'&city='.htmlentities(urlencode($city)).'&state='.htmlentities(urlencode($state)).'&postalcode='.htmlentities(urlencode($postalcode)).'&country='.htmlentities(urlencode($country)).'&billingaddress='.htmlentities(urlencode($billingaddress)).'&billingcity='.htmlentities(urlencode($billingcity)).'&billingstate='.htmlentities(urlencode($billingstate)).'&billingpostalcode='.htmlentities(urlencode($billingpostalcode)).'&billingcountry='.htmlentities(urlencode($billingcountry)).'&edit='.$edit.' "} </script> <body onLoad=go(); > </body>');
		}
		else
		{
			if ($edit==1)
			{
				$query='select password from users where username="'.$username.'"';
				$q->query($query);
				$q->next_record();
				$oldpassword=$q->f("password");
				$package=$q->f("package");
				$query='UPDATE users SET password=\''.$password.'\', fullname= \''.$fullname.'\', phone= \''.$phone.'\', email= \''.$email.'\' , address= \''.$address.'\', city= \''.$city.'\', state= \''.$state.'\', postalcode= \''.$postalcode.'\', country= \''.$country.'\' WHERE username=\''.$username.'\'';
				$q->query($query);
				
				if ($package==1) $cquo=20;
					else if ($package==2) $cquo=40;
						else if ($package==3) $cquo=100;
				
				$host = "www.yoursite.com";
				$socket = fsockopen($host,2082);
				$cuser = "username";
				$cpassword = "password";
				$authstr = "$cuser:$cpassword";
				$pass = base64_encode($authstr);
				$in = "GET /frontend/vertex/mail/dopasswdpop.html?email=$username&domain=www.yoursite.com&password=$password&quota=$cquo HTTP/1.0\r\nAuthorization: Basic $pass \r\n";
				fputs($socket,$in);
				fclose( $socket );
				
				
				echo('<script language="JavaScript"> function go() { window.location.href="member.php"} </script> <body onLoad=go(); > </body>');
			}
			else
			{
				$expdate=date ("m-d-Y",  mktime (0,0,0,date("m")  ,date("d")+7,date("Y")));
				$usern=$username;
				$num=0;
				for ($i=1; $i<=strlen($usern); $i++) $num=$num*7+ord($usern[$i]);
				$num.=$usern.chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122));

				$query=sprintf("INSERT INTO users (username, password, fullname, phone, email, address, city, state, postalcode, expdate, country, package, code) VALUES (\"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\",  \"%s\", \"%s\", \"%s\")", $username, $password, $fullname, $phone, $email, $address, $city, $state, $postalcode, $expdate, $country, $package, $num);
				$q->query($query);
				//{{VPOPADDUSER}} username =$username, password=$password, quota = 25 if $package == 1 , quota = 25 if $package == 2 , quota = 30 if $package == 3
				//webmaster@yoursite.com

				if ($package==1) $cquo=20;
					else if ($package==2) $cquo=40;
						else if ($package==3) $cquo=100;
				mail("webmaster@".$surl,"$username, $password","New account at ".$surl.".com .\nUsername: $username\nPassword: $password\nFull name: $fullname\nEmail: $email\n","From: ".$fullname." <".$email.">");
				$sessuser=$username;
				
				FFileRead("template_welcome_email.txt",$body);
				$body=str_replace("{email}",$username."@".$surl,$body);
				$body=str_replace("{password}",$password,$body);
				$body=str_replace("{username}",$username,$body);
				$body=str_replace("{sname}",$surl,$body);
				mail($email,"Welcome to $surl", $body, "From: $surl <webmaster@$surl>");

				$query="select id from users where username='$username'";
				$q->query($query);
				$q->next_record();
				$query="insert into emails (id, userid, email, action) values(NULL, '".$q->f("id")."', 'webmaster@yoursite.com', 1)";
				$q->query($query);
				session_register("sessuser");
				//$REMOTE_USER="spamcrun";
				//exec("/usr/local/cpanel/cpanel-email addpop $username $password 25 yoursite.com >& /home/spamcrun/www/test.txt", $output);
				
				//echo "/usr/local/cpanel/cpanel-email addpop $username $password 25 yoursite.com >& /home/spamcrun/www/test.txt";
				//echo $output[0];
				//echo $output[1];
				//echo $output[2];
				//echo $output[3];
				//echo passthru("ls");
				//echo passthru("useradd -g 502 -s /mailonly -p $password $username");
				$host = "www.yoursite.com";
				$socket = fsockopen($host,2082);
				$cuser = "username";
				$cpassword = "password";
				$authstr = "$cuser:$cpassword";
				$pass = base64_encode($authstr);
				$in = "GET /frontend/vertex/mail/doaddpop.html?email=$username&domain=yoursite.com&password=$password&quota=$cquo HTTP/1.0\r\nAuthorization: Basic $pass \r\n";
				fputs($socket,$in);
				fclose( $socket );
				//echo('<script language="JavaScript"> function go() { window.location.href="member.php?action=signupdone"} </script> <body onLoad=go(); > </body>');
			}
		}

	}

	if ($whois=="programmer")
	{
		echo "(c) 2003 by AlstraSoft.com
	email: support@alstrasoft.com";
	}

	if ((!isset($action))&&(isset($sessuser)))
	{
		$action="memberprofile";
	}


	if (isset($sessuser)&&($action=="signupdone"))
	{
		FFileRead("signupdonetemplate.htm",$content);
	}

	if (isset($sessuser)&&($action=="memberprofile"))
	{
		FFileRead("membertemplate.htm",$content);
		$query='select * from users where username="'.$sessuser.'"';
		$q->query($query);
		$q->next_record();
		FFileRead("memberprofiletemplate.htm",$tblcontent);
		$tblcontent=str_replace("{username}",$q->f("username"),$tblcontent);
		$tblcontent=str_replace("{password}",$q->f("password"),$tblcontent);
		$tblcontent=str_replace("{fullname}",$q->f("fullname"),$tblcontent);
		$tblcontent=str_replace("{address}",$q->f("address"),$tblcontent);
		$tblcontent=str_replace("{city}",$q->f("city"),$tblcontent);
		$tblcontent=str_replace("{state}",$q->f("state"),$tblcontent);
		$tblcontent=str_replace("{postalcode}",$q->f("postalcode"),$tblcontent);
		$tblcontent=str_replace("{country}",$q->f("country"),$tblcontent);
		$tblcontent=str_replace("{phone}",$q->f("phone"),$tblcontent);
		$tblcontent=str_replace("{email}",$q->f("email"),$tblcontent);
		$tblcontent=str_replace("{expdate}",$q->f("expdate"),$tblcontent);
		if ($q->f("package")==1) {$amount="8.95"; $prodid=2;}
		else if ($q->f("package")==2) { $amount="43.50"; $prodid=4;}
		else if ($q->f("package")==3) { $amount="69"; $prodid=5;}
		$tblcontent=str_replace("{amount}",$amount,$tblcontent);
		$tblcontent=str_replace("{package}",$prodid,$tblcontent);
		$expdate=$q->f("expdate");
		$curdate=date ("m-d-Y",  mktime (0,0,0,date("m")  ,date("d"),date("Y")));
		$expa=explode("-",$expdate);
		$cura=explode("-",$curdate);
		$expsec=mktime(0,0,0,$expa[0],$expa[1],$expa[2])-mktime(0,0,0,$cura[0],$cura[1],$cura[2]);
		$expsec=$expsec/(3600*24);
		$tblcontent=str_replace("{code}",$q->f("code"),$tblcontent);

		if (($expsec<=7)&&($q->f("expdate")!="Recurring Billing"))
		{
			$tblcontent=str_replace("{warning}",'Warning: your account will expire in '.((int) $expsec).' day(s).  Please upgrade your account before it expires.',$tblcontent);
		}
		else
		{
			$tblcontent=str_replace("{warning}",'',$tblcontent);
		}
		$content=str_replace("{tblcontent}",$tblcontent,$content);
	}

	if (($action=="lostpassword"))
	{
		FFileRead("lostpasswordtemplate.htm",$content);
	}

	if (($action=="sendpassword"))
	{
		FFileRead("sendpasswordtemplate.htm",$content);
		$query='select username,password,email from users where username="'.$username.'"';
		$q->query($query);
		if ($q->num_rows()>0)
		{
			$q->next_record();
			$content=str_replace("{content}","Your email has been sent.",$content);
			mail($q->f("email"),$surl." login info","Here is your ".$surl." account info: \nUsername: ".$q->f("username")." \n Password: ".$q->f("password"),"From: ".$surl." <noreply@".$surl.">\r\n");
		}
		else
		{
			$content=str_replace("{content}","Username not found. ",$content);
		}
	}
	if ((isset($sessuser))&&($action=="addemail"))
	{
		$query='select id from users where username="'.$sessuser.'"';
		$q->query($query);
		$q->next_record();
		$userid=$q->f("id");
		$query='insert into emails values(NULL, '.$userid.', "'.$addemail.'", '.$todo.')';
		$q->query($query);
		$action="emaillist";
	}
	if ((isset($sessuser))&&($action=="deleteemail"))
	{
		$query='delete from emails where id='.$key;
		$q->query($query);
		$action="emaillist";
	}
	if ((isset($sessuser))&&($action=="chageemailstatus"))
	{
		$query='select * from emails where id='.$key;
		$q->query($query);
		$q->next_record();
		if ($q->f("action")==1) $actionxx=2; else $actionxx=1;
		$query='UPDATE emails SET action='.$actionxx.' WHERE id='.$key;
		$q->query($query);
		$action="emaillist";
	}
	if (isset($sessuser)&&($action=="emaillist"))
	{
		FFileRead("memberemaillisttemplate.htm",$memberemaillisttemplate);
		FFileRead("membertemplate.htm",$content);
		$query='select id from users where username="'.$sessuser.'"';
		$q->query($query);
		$q->next_record();
		$userid=$q->f("id");
		$query='select COUNT(*) as numar from emails where (userid='.$userid.')and(email like "%'.$searchemail.'%")';
		$q->query($query);
		$q->next_record();
		$numar=$q->f("numar");
		if (!isset($page)) $page=1;
		$limit='ORDER by id LIMIT '.(($page-1)*10).',10 ';
		$query='select * from emails where (userid='.$userid.')and(email like "%'.$searchemail.'%") '.$limit;
		$q->query($query);
		$emaillist='';
		$bgcolor="#FFFFFF";
		$counter=($page-1)*10;
		while ($q->next_record())
		{
			$counter++;
			if($q->f("action")==1) $emailaction="Allow"; else $emailaction="Block";
			$emaillist.='<tr align="center" bgcolor="'.$bgcolor.'" class="menutable" ><td class="legal">'.$counter.' </td ><td class="legal">'.$q->f("email").'</td><td class="legal">'.$emailaction.'</td><td class="legal"><a href="member.php?action=chageemailstatus&key='.$q->f("id").'">Change</a> | <a href="member.php?action=deleteemail&key='.$q->f("id").'">Remove</a> </td></tr>';
			if ($bgcolor=="#FFFFFF") $bgcolor="#E8F3FF"; else $bgcolor="#FFFFFF";
		}
		$prevnext="";
		if ($numar>10)
		{
			if ($numar%10!=0) $numarp=($numar/10)+1;
			else $numarp=($numar/10);
			if ($page>1) $prevnext.=' [<a  href="member.php?action=emaillist&searchemail='.htmlentities(urlencode($searchemail)).'&page='.($page-1).'" >'.'<< Previous'.'</a>]';
				else $prevnext.=' [<< Previous]';
			for($i=1; $i<=$numarp; $i++)
			{
				if ($page==$i) $classxx='class="navlink"'; else $classxx='';
				$prevnext.=' [<a '.$classxx.' href="member.php?action=emaillist&searchemail='.htmlentities(urlencode($searchemail)).'&page='.$i.'">'.$i.'</a>]';
			}

			if ($page<$numarp-1) $prevnext.=' [<a   href="member.php?action=emaillist&searchemail='.htmlentities(urlencode($searchemail)).'&page='.($page+1).'"  >'.'Next >>'.'</a>]';
			else $prevnext.=' [Next >>]';
		}
		$memberemaillisttemplate=str_replace("{prevnext}",$prevnext,$memberemaillisttemplate);
		$memberemaillisttemplate=str_replace("{emaillist}",$emaillist,$memberemaillisttemplate);
		$content=str_replace("{tblcontent}",$memberemaillisttemplate,$content);

	}
	if (isset($sessuser)&&($action=="blockmail"))
	{
		$query='select frome,userid from pending where id='.$key;
		$q->query($query);
		if ($q->nf()>0)
		{
		$q->next_record();
		$useridvar=$q->f("userid");
		$fromevar=$q->f("frome");
		$query='select COUNT(*) as numar from emails where (email="'.$fromevar.'")and(userid="'.$useridvar.'")';
		$q->query($query);
		$q->next_record();
		if($q->f("numar")==0)
		{
			$query='insert into emails values (NULL, '.$useridvar.', "'.$fromevar.'", 2) ';
			$q->query($query);
		}
		$query='delete from pending where id='.$key;
		$q->query($query);
		}
		$action="pendingemails";
	}
	if (isset($sessuser)&&($action=="blockall"))
	{
		$query='select id from users where username="'.$sessuser.'"';
		$q->query($query);
		$q->next_record();
		$userid=$q->f("id");
		$query='select id,frome,userid from pending where userid='.$userid;
		$q2->query($query);
		while ($q2->next_record())
		{
			$useridvar=$q2->f("userid");
			$fromevar=$q2->f("frome");
			$query='select COUNT(*) as numar from emails where (email="'.$fromevar.'")and(userid="'.$useridvar.'")';
			$q->query($query);
			$q->next_record();
			if($q->f("numar")==0)
			{
				$query='insert into emails values (NULL, '.$useridvar.', "'.$fromevar.'", 2) ';
				$q->query($query);
			}
			$query='delete from pending where id='.$q2->f("id");
			$q->query($query);
		}
		$action="pendingemails";
	}
	if (isset($sessuser)&&($action=="acceptall"))
	{
		$query="select password from users where username='$sessuser'";
		$q->query($query);
		$q->next_record();
		$password=$q->f("password");
		$query='select id from users where username="'.$sessuser.'"';
		$q->query($query);
		$q->next_record();
		$userid=$q->f("id");
		$query='select id,frome,userid from pending where userid='.$userid;
		$q2->query($query);
		while ($q2->next_record())
		{
//			mail('',$q2->f("subject"),$q2->f("body"),$q2->f("header"));
//			mail($sessuser.'@'.$mailservername,$q2->f("subject"),$q2->f("body"),$q2->f("header"));
			while ($stream==false)
			{
				$stream = imap_open("{yoursite.com:143}INBOX",$sessuser.'@'.$mailservername, $password);
			}
				imap_append($stream,"{yoursite.com:143}INBOX"
								   ,$emailheader."\r\n"
								   .$emailbody."\r\n"
								   );
				imap_close($stream);

			$useridvar=$q2->f("userid");
			$fromevar=$q2->f("frome");
			$query='select COUNT(*) as numar from emails where (email="'.$fromevar.'")and(userid="'.$useridvar.'")';
			$q->query($query);
			$q->next_record();
			if($q->f("numar")==0)
			{
				$query='insert into emails values (NULL, '.$useridvar.', "'.$fromevar.'", 1) ';
				$q->query($query);
			}
			$query='delete from pending where id='.$q2->f("id");
			$q->query($query);
		}
		$action="pendingemails";
	}
	if (isset($sessuser)&&($action=="acceptmail"))
	{
		$query="select password from users where username='$sessuser'";
		$q->query($query);
		$q->next_record();
		$password=$q->f("password");
		$query='select * from pending where id='.$key;
		$q->query($query);
		if ($q->nf()>0)
		{
		$q->next_record();
		$useridvar=$q->f("userid");
		$fromevar=$q->f("frome");
		$emailsubject=$q->f("subject");
		$emailbody=stripslashes($q->f("body"));
		$emailheader=stripslashes($q->f("header"));
		$query='select COUNT(*) as numar from emails where (email="'.$fromevar.'")and(userid="'.$useridvar.'")';
		$q->query($query);
		$q->next_record();
		if($q->f("numar")==0)
		{
			$query='insert into emails values (NULL, '.$useridvar.', "'.$fromevar.'", 1) ';
			$q->query($query);
		}
//		mail('',$emailsubject,$emailbody,$emailheader);
//		mail($sessuser.'@'.$mailservername,$emailsubject,$emailbody,$emailheader);
			while ($stream==false)
			{
				$stream = @imap_open("{yoursite.com:143}INBOX",$sessuser.'@'.$mailservername, $password);
			}
			imap_append($stream,"{yoursite.com:143}INBOX"
								   ,$emailheader."\r\n"
								   .$emailbody."\r\n"
								   );
				imap_close($stream);
		$query='delete from pending where id='.$key;
		$q->query($query);
		}
		$action="pendingemails";
	}

	if (isset($sessuser)&&($action=="pendingemails"))
	{
		FFileRead("memberpendingemaillisttemplate.htm",$memberemaillisttemplate);
		FFileRead("membertemplate.htm",$content);

		$query='select id from users where username="'.$sessuser.'"';
		$q->query($query);
		$q->next_record();
		$userid=$q->f("id");
		$query='select COUNT(*) as numar from pending where (userid='.$userid.')and( frome like "%'.$searchemail.'%")';
		$q->query($query);
		$q->next_record();
		$numar=$q->f("numar");
		if (!isset($page)) $page=1;
		$limit='ORDER by id LIMIT '.(($page-1)*10).',10 ';
		$query='select * from pending where (userid='.$userid.')and( frome like "%'.$searchemail.'%") '.$limit;
		$q->query($query);
		$emaillist='';
		$bgcolor="#FFFFFF";
		$counter=($page-1)*10;
		while ($q->next_record())
		{
			$counter++;
			$emaillist.='<tr align="center" bgcolor="'.$bgcolor.'" class="menutable" ><td class="legal">'.$counter.' </td ><td class="legal">'.$q->f("frome").'</td><td class="legal">'.$q->f("subject").'</td><td class="legal"><a href="member.php?action=blockmail&key='.$q->f("id").'">Block</a> | <a href="member.php?action=acceptmail&key='.$q->f("id").'">Accept</a> </td></tr>';
			if ($bgcolor=="#FFFFFF") $bgcolor="#E8F3FF"; else $bgcolor="#FFFFFF";
		}
		$prevnext="";
		if ($numar>10)
		{
			if ($numar%10!=0) $numarp=($numar/10)+1;
			else $numarp=($numar/10);
			if ($page>1) $prevnext.=' [<a  href="member.php?action=pendingemails&searchemail='.htmlentities(urlencode($searchemail)).'&page='.($page-1).'" >'.'<< Previous'.'</a>]';
				else $prevnext.=' [<< Previous]';
			for($i=1; $i<=$numarp; $i++)
			{
				if ($page==$i) $classxx='class="navlink"'; else $classxx='';
				$prevnext.=' [<a '.$classxx.' href="member.php?action=pendingemails&searchemail='.htmlentities(urlencode($searchemail)).'&page='.$i.'">'.$i.'</a>]';
			}

			if ($page<$numarp-1) $prevnext.=' [<a   href="member.php?action=pendingemails&searchemail='.htmlentities(urlencode($searchemail)).'&page='.($page+1).'"  >'.'Next >>'.'</a>]';
			else $prevnext.=' [Next >>]';
		}
		$memberemaillisttemplate=str_replace("{prevnext}",$prevnext,$memberemaillisttemplate);
		$memberemaillisttemplate=str_replace("{emaillist}",$emaillist,$memberemaillisttemplate);
		$content=str_replace("{tblcontent}",$memberemaillisttemplate,$content);

	}
	if ((isset($sessuser))&&($action=="deletefilter"))
	{
		$query='delete from filters where id='.$key;
		$q->query($query);
		$action="filterlist";
	}

	if ((isset($sessuser))&&($action=="addfilter"))
	{
		$query='select id from users where username="'.$sessuser.'"';
		$q->query($query);
		$q->next_record();
		$userid=$q->f("id");
		$query='insert into filters values(NULL, '.$userid.', "'.$addfilter.'", '.$field.', 1 ,'.$todo.')';
		$q->query($query);
		$action="filterlist";
	}
	if ((isset($sessuser))&&($action=="chagefilter"))
	{
		$query='select * from filters where id='.$key;
		$q->query($query);
		$q->next_record();
		FFileRead("memberchangefiltertemplate.htm",$changefilter);
		FFileRead("membertemplate.htm",$content);
		if ($q->f("type")==1) $td1="selected";
		if ($q->f("type")==2) $td2="selected";
		if ($q->f("type")==3) $td3="selected";
		$changefilter=str_replace("{td1}",$td1,$changefilter);
		$changefilter=str_replace("{td2}",$td2,$changefilter);
		$changefilter=str_replace("{td3}",$td3,$changefilter);
		if ($q->f("field")==1) $f1="selected";
		if ($q->f("field")==2) $f2="selected";
		if ($q->f("field")==3) $f3="selected";
		if ($q->f("field")==4) $f4="selected";
		$changefilter=str_replace("{f1}",$f1,$changefilter);
		$changefilter=str_replace("{f2}",$f2,$changefilter);
		$changefilter=str_replace("{f3}",$f3,$changefilter);
		$changefilter=str_replace("{f4}",$f4,$changefilter);
		$changefilter=str_replace("{value}",$q->f("value"),$changefilter);
		$changefilter=str_replace("{id}",$q->f("id"),$changefilter);

		$content=str_replace("{tblcontent}",$changefilter,$content);

	}
	if (isset($sessuser)&&($action=="dochangefilter"))
	{
		$query='UPDATE filters SET value="'.$value.'" , field='.$field.', type='.$todo.' WHERE id='.$key;
		$q->query($query);
		$action="filterlist";
	}
	if (isset($sessuser)&&($action=="filterlist"))
	{
		FFileRead("memberfilterlisttemplate.htm",$memberemaillisttemplate);
		FFileRead("membertemplate.htm",$content);

		$query='select id from users where username="'.$sessuser.'"';
		$q->query($query);
		$q->next_record();
		$userid=$q->f("id");
		$query='select COUNT(*) as numar from filters where (userid='.$userid.')and(value like "%'.$searchemail.'%")';
		$q->query($query);
		$q->next_record();
		$numar=$q->f("numar");
		if (!isset($page)) $page=1;
		$limit='ORDER by id LIMIT '.(($page-1)*10).',10 ';
		$query='select * from filters where (userid='.$userid.')and(value like "%'.$searchemail.'%") '.$limit;
		$q->query($query);
		$emaillist='';
		$bgcolor="#FFFFFF";
		$counter=($page-1)*10;
		while ($q->next_record())
		{
			$counter++;
			if ($q->f("field")==1) $field="Subject";
			else if ($q->f("field")==2) $field="From";
			else if ($q->f("field")==3) $field="To";
			else if ($q->f("field")==4) $field="Body";
			if ($q->f("type")==1) $filtact="Allow";
			else if ($q->f("type")==2) $filtact="Block";
			else if ($q->f("type")==3) $filtact="Pending";
			$emaillist.='<tr align="center" bgcolor="'.$bgcolor.'" class="menutable" ><td class="legal">'.$counter.' </td ><td class="legal">'.$q->f("value").'</td><td class="legal">'.$field.'</td><td class="legal">'.$filtact.'</td><td class="legal"><a href="member.php?action=chagefilter&key='.$q->f("id").'">Change</a> | <a href="member.php?action=deletefilter&key='.$q->f("id").'">Remove</a> </td></tr>';
			if ($bgcolor=="#FFFFFF") $bgcolor="#E8F3FF"; else $bgcolor="#FFFFFF";
		}
		$prevnext="";
		if ($numar>10)
		{
			if ($numar%10!=0) $numarp=($numar/10)+1;
			else $numarp=($numar/10);
			if ($page>1) $prevnext.=' [<a  href="member.php?action=filterlist&searchemail='.htmlentities(urlencode($searchemail)).'&page='.($page-1).'" >'.'<< Previous'.'</a>]';
				else $prevnext.=' [<< Previous]';
			for($i=1; $i<=$numarp; $i++)
			{
				if ($page==$i) $classxx='class="navlink"'; else $classxx='';
				$prevnext.=' [<a '.$classxx.' href="member.php?action=filterlist&searchemail='.htmlentities(urlencode($searchemail)).'&page='.$i.'">'.$i.'</a>]';
			}

			if ($page<$numarp-1) $prevnext.=' [<a href="member.php?action=filterlist&searchemail='.htmlentities(urlencode($searchemail)).'&page='.($page+1).'"  >'.'Next >>'.'</a>]';
			else $prevnext.=' [Next >>]';
		}
		$memberemaillisttemplate=str_replace("{prevnext}",$prevnext,$memberemaillisttemplate);
		$memberemaillisttemplate=str_replace("{emaillist}",$emaillist,$memberemaillisttemplate);
		$content=str_replace("{tblcontent}",$memberemaillisttemplate,$content);

	}

	$t->set_var("title","Member Area");
	$t->set_var("content",$content);
	$t->parse("out","doctemplate");
	$t->p("out");

?>