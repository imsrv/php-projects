<?php
set_time_limit(0);
include ('vars.inc');

$server='{yoursite.com:110/pop3}';
function getHeaders($mbox, $min, $max)
{

	$overview = imap_fetch_overview($mbox,"$min:$max",0);

	if(is_array($overview))
	{
	        reset($overview);

	        $count = 1;

	        while( list($key,$val) = each($overview))
	        {
	                /* parse time */

	                $time			=	strtotime ( $val->date );

	        if($TIME_ONLY_OPTION)
			{
				$now  = date($DEFAULT_TIME_FORMAT_SHORT, time() );
				$then = date($DEFAULT_TIME_FORMAT_SHORT, $time );

				if($now == $then)
					$time = date($DEFAULT_TIME_FORMAT_TIMEONLY, $time );
				else
					$time = date($DEFAULT_TIME_FORMAT, $time );
			}
			else
				$time = date($DEFAULT_TIME_FORMAT, $time );

	                $header[$count][0]	=	$time;
	                $header[$count][1]	=	$val->from;
	                $header[$count][2]	=	$val->subject;
	                $header[$count][4]	=	$val->seen;
	                $header[$count][5]	=	$val->size;
	                $header[$count++][6]	=	$val->uid;
	        }
	}
	return $header;
}

echo "Lauching e-mail filer ... Running init\n";
echo "Initialising database ...";
$q = new CDbSpam;
$qall = new CDbSpam;
echo "done.\n";
$od=1;

while (1)
{
$qquery='select id,expdate ,username,password,fullname from users where 1';
$qall->query($qquery);
//echo "Database query: ".$query." ... ";
while ($qall->next_record())
{ //start checking every mailbox

$userid=$qall->f("id");
$user=$qall->f("username");
$password=$qall->f("password");
$fullname=$qall->f("fullname");
$expdate=$qall->f("expdate");
$curdate=date ("m-d-Y",  mktime (0,0,0,date("m")  ,date("d"),date("Y")));
$expa=explode("-",$expdate);
$cura=explode("-",$curdate);
if ($qall->f("expdate")!="Recurring Billing")
if ((mktime(0,0,0,$expa[0],$expa[1],$expa[2])-mktime(0,0,0,$cura[0],$cura[1],$cura[2]))<0)
{
	$query='delete from users where id='.$userid;
	$q->query($query);
	$query='delete from emails where userid='.$userid;
	$q->query($query);
	$query='delete from pending where userid='.$userid;
	$q->query($query);
	$query='delete from filters where userid='.$userid;
	$q->query($query);
}
//echo $qall->f("username").' --> '.$qall->f("password").' --> '.$qall->f("fullname")."\n";
//echo " Ok , found userid = ".$userid." \n";
//echo "Connecting to POP3 server ...";
$mbox = @imap_open($server,$user."@yoursite.com",$password );
if ($mbox!=false)
{//start mbox check
//echo "done.\n";
//echo " Ok , found userid = ".$userid." \n";

//echo "Counting messages ...";
$msgnum=imap_num_msg($mbox);
$header=getHeaders($mbox,1,$msgnum);
//echo "done.\n";

//echo 'MSGNUM : '.$msgnum."\n";
for ($i=1; $i<=$msgnum; $i++)
{
	$subject=$header[$i][2];
	$seen=$header[$i][4];
	$uid=$header[$i][6];
//	echo $seen."\n";
	$head= imap_fetchheader($mbox,$uid , FT_UID);
	$h=imap_headerinfo($mbox,$uid, FT_UID);
	$from=$h->from;
	$to=$h->to;
	foreach ($from as $id => $object)
	{
		 $fromaddress = $object->mailbox . "@" . $object->host;
	}
	foreach ($to as $id => $object)
	{
		 $toaddress = $object->mailbox . "@" . $object->host;
	}

//	echo $uid.' : '.$fromaddress."\n";
//	echo $uid.' : '.$toaddress."\n";
	$body=imap_body($mbox, $uid, FT_INTERNAL);
	$query='select * from emails where ((userid='.$userid.')and(email like "%'.strtolower($fromaddress).'"))';
	$q->query($query); //((strtolower($fromaddress)!=strtolower('MAILER-DAEMON@mail.remarkablehost.com'))
	$ppp=false;
	$pos = strpos(strtolower($fromaddress),strtolower('@mail.remarkablehost.com'));
//	echo "from: ".strtolower($fromaddress)."\n".strtolower($user.'@yoursite.com')."\n".$pos."\n";
	if ($pos === false) $ppp=true;
	if (strtolower($fromaddress)==strtolower($user.'@biletulmeu.ro')) $ppp=true;
//	echo $ppp."\n";
	if (($ppp))
	{
	if ($q->num_rows()>0)
	{
		$q->next_record();
		if ($q->f("action")==2)
		{
			imap_delete ($mbox, $uid, FT_UID);
			imap_expunge($mbox);
			//echo "message $uid deleted [blocked mail address] \n ";
		}
	}
	else
		{
			$query='select * from filters where userid='.$userid;
			$q->query($query);
			$action=3;
			while ($q->next_record())
			{
				if ($q->f("field")==1)
				{
					$pos = strpos(strtolower($subject), strtolower($q->f("value")));
					if (!($pos === false))
					{
						$action=$q->f("type");
						break;
					}
				}
				else if ($q->f("field")==2)
				{
					$pos = strpos(strtolower($fromaddress), strtolower($q->f("value")));
					if (!($pos === false))
					{
						$action=$q->f("type");
						break;
					}
				}
				else if ($q->f("field")==3)
				{
					$pos = strpos(strtolower($toaddress), strtolower($q->f("value")));
					if (!($pos === false))
					{
						$action=$q->f("type");
						break;
					}
				}
				else if ($q->f("field")==4)
				{
					$pos = strpos(strtolower($body), strtolower($q->f("value")));
					if (!($pos === false))
					{
						$action=$q->f("type");
						break;
					}
				}

			}//end while
			if ($action==3)
			{
				//pending message
				$query='select * from admin where id=1';
				$q->query($query);
				$q->next_record();
				$vermessage=$q->f("confmessage");
				$vermessage=str_replace("{email}",$toaddress,$vermessage);
				$vermessage=str_replace("{fullname}",$fullname,$vermessage);
				$vermessage=str_replace("{subject}",$subject,$vermessage);
				$vercode=$fromaddress;
				$vercode .= chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122)).chr(rand(97,122));
				$vercode.=$toaddress;
				$vermessage=str_replace("{code}",'http://www.yoursite.com/verify.php?code='.$vercode,$vermessage);

				mail($fromaddress,'Please confirm your email for '.$toaddress,$vermessage,"From: $fullname <$toaddress>\r\n");
				//echo "Verify message sent\n";
				$query = 'insert into pending VALUES (NULL, '.$userid.', \''.addslashes($subject).'\', \''.addslashes($head).'\', \''.addslashes($body).'\', \''.addslashes($vercode).'\' , \''.$fromaddress.'\')';
				$q->query($query);
				imap_delete ($mbox, $uid, FT_UID);
				imap_expunge($mbox);
				//echo "message $uid deleted [sent to pending emails ] \n ";

			}
			else if ($action==2)
			{
				//cannot send message
				$query='select * from admin where id=1';
				$q->query($query);
				$q->next_record();

				$cantmessage=$q->f("cantmessage");
				$cantfrom=$q->f("cantfrom");
				$cantmessage=str_replace("{toemail}",$toaddress,$cantmessage);
				mail($fromaddress,$q->f("cantsubject"),$cantmessage,"From: $cantfrom\r\n");
				imap_delete ($mbox, $uid, FT_UID);
				imap_expunge($mbox);
				//echo "message $uid deleted [filter detected block phrase]  \n";
				//echo " To : ".$fromaddress."\n";
				//echo " Subject : ".$q->f("cantsubject")."\n";
				//echo " From : ".$q->f("cantfrom")."\n";

			}
			else if($action==1)
			{
			}
		}//endelse
	}
   }//endfor
imap_close($mbox);
}//endif can open mbox
if ($qall->num_rows()!=0) usleep(1000000/$qall->num_rows());
}//endwhile next record

}//endwhile(1)
?>