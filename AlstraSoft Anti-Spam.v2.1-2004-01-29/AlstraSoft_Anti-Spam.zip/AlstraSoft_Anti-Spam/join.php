<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><!-- InstanceBegin template="/Templates/defeatspam.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<!-- InstanceBeginEditable name="doctitle" -->

<title>AlstraSoft Anti-Spam - Join Now</title>



<!-- InstanceEndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- InstanceBeginEditable name="head" -->



<!-- InstanceEndEditable -->
<link href="defeat.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="740" border="0" align="center" cellpadding="0" cellspacing="0" class="tbl">
  <tr> 
    <td width="749"> <div align="center">
      <p><font color="#FFFFFF"><strong><font color="#0033CC" size="6">AlstraSoft Ant-Spam</font></strong><br>
        <br>
        </font></p>
    </div></td>
  </tr>
  <tr> 
    <td class="menutable"><div align="center" class="navLink"><a href="index.htm"><font color="#000099">Home</font></a> 
        <font color="#000099">|</font> <font color="#000099"><a href="howitworks.htm">How 
        It Works</a> |</font> <font color="#000099"><a href="features.htm">Features</a> 
        |<a href="steps.htm"> Steps</a> |</font> <font color="#000099"><a href="join.php">Join 
        Now</a> |</font> <font color="#000099"><a href="faq.htm">FAQ</a> |</font> 
        <font color="#000099"><a href="tos.htm">Terms Of Service</a> |</font> 
        <font color="#000099"><a href="tellafriend.htm">Tell A Friend</a> |</font> 
        <font color="#000099"><a href="member.php">Member Area</a> | <a href="contact.htm">Contact 
        Us</a></font></div></td>
  </tr>
  <tr> 
    <td height="28" align="left" valign="top"><!-- InstanceBeginEditable name="title" -->



      <div align="center" class="subtitle">Sign Up Page<br>



      </div>



        <!-- InstanceEndEditable --></td>
  </tr>
  <tr> 
    <td height="119" align="left" valign="top"><!-- InstanceBeginEditable name="content" -->





<?php if ($edit!=1) echo '

      <table width="675" height="261" border="0" align="center" cellpadding="0" cellspacing="0" class="bordertable">
  <tr bgcolor="#0033CC">
    <td height="16" colspan="2" width="675"><span class="header">&nbsp;Listed below are the
    packages available to you:</span></td>
  </tr>
  <tr class="menutable">
    <td width="195" height="103">
    <p align="center" style="margin-top: 0; margin-bottom: 0"><span class="promo">Lite </span><br>
    7 Day <b>FREE</b> TRIAL <br>
    $ 8.95 per month</p>
    <p align="center" style="margin-top: 0; margin-bottom: 0">&nbsp;
    25 MB of email storage </p>
    </td>
    <td width="480">Our Lite package offers a low monthly payment for 25 MB of email
    storage. This is email that is stored in the \'Pending Email Area\'. Email stored
    in the \'Pending Email Area\' is email that has not been verified by the sender
    and is usually spam. To reduce the amount of storage space that you are currently
    using, simply delete some (or all) of the email stored in the \'Pending Email
    Area\'.</td>
  </tr>
  <tr class="menutable">
    <td height="103" width="195">
    <p align="center" style="margin-top: 0; margin-bottom: 0"><span class="promo">Normal </span><br>
    7 Day <b>FREE</b> TRIAL <br>
    $ 7.25 per month</p>
    <p align="center" style="margin-top: 0; margin-bottom: 0">
    25 MB of email storage</p>
    </td>
    <td width="480">This package comes with 25 MB of email storage just like our Lite package
    but offers better value by prepaying for 6 months of service. </td>
  </tr>
  <tr class="menutable">
    <td height="103" width="195">
    <p align="center" style="margin-top: 0; margin-bottom: 0"><span class="promo">Deluxe</span> <br>
    7 Day <b>FREE</b> TRIAL <br>
    $ 5.75 per month</p>
    <p align="center" style="margin-top: 0; margin-bottom: 0">
    30 MB of email storage <br>
    </p>
    </td>
    <td width="480">Our Deluxe package comes with 30 MB of email storage and offers the very
    BEST value by prepaying for a period of one year. </td>
  </tr>
</table>';?>



      <p>&nbsp;</p>



      <blockquote>



        <p><font color="#FF0000"><a name="error"></a><?php echo $error; ?></font><br>



        </p>



      </blockquote>



      <form name="form1" method="post" action="member.php?action=signup">



        <table class="bordertable" width="360" height="403" border="0" align="center" cellpadding="0" cellspacing="0">

          <tr>



            <td height="15" colspan="2" class="header">&nbsp; Membership form



              :</td>



          </tr>



          <tr>



            <td height="47" colspan="2">



<?php if ($edit!=1) echo '<div align="center" class="promo"><br>



                Sign up for your 7 day FREE Trial.<br>

                 No Credit Card is needed. <br>



                <br>



              </div>'; ?></td>



          </tr>



          <tr>



            <td width="127" height="19"> <div align="right">Username:</div></td>



            <td width="231"><input name="username" <?php if ($edit ==1) echo ' type="hidden" ';else echo " type='text'  "; ?> class="edit" value="<?php echo $username ?>"> <?php if ($edit==1) echo $username; ?></td>



          </tr>



          <tr>



            <td><div align="right">Password:</div></td>



            <td><input name="password"  type="password" class="edit" id="password" value="<?php echo $password ?>"></td>



          </tr>



          <tr>



            <td height="19">

<div align="right">Retype Password:</div></td>



            <td><input name="rpassword" type="password" class="edit" id="rpassword" value="<?php echo $password ?>"></td>



          </tr>



          <tr>



            <td><div align="right">Full Name :</div></td>



            <td><input name="fullname" type="text" class="edit" id="fullname" value="<?php echo $fullname ?>"></td>



          </tr>



          <tr>



            <td><div align="right">Address :</div></td>



            <td><input name="address" type="text" class="edit" id="address" value="<?php echo $address ?>"></td>



          </tr>



          <tr>



            <td><div align="right">City :</div></td>



            <td><input name="city" type="text" class="edit" id="city" value="<?php echo $city ?>"></td>



          </tr>



          <tr>



            <td height="19"> <div align="right">State :</div></td>



            <td><input name="state" type="text" class="edit" id="state" value="<?php echo $state ?>"></td>



          </tr>



          <tr>



            <td height="20"> <div align="right">Zip :</div></td>



            <td><input name="postalcode" type="text" class="edit" id="postalcode" value="<?php echo $postalcode ?>"></td>



          </tr>



          <tr>



            <td height="20"> <div align="right">Country :</div></td>



            <td><input name="country" type="text" class="edit" id="country" value="<?php echo $country ?>"></td>



          </tr>



          <tr>



            <td height="20"> <div align="right">Phone :</div></td>



            <td><input name="phone" type="text" class="edit" id="phone" value="<?php echo $phone ?>"></td>



          </tr>



          <tr>



            <td height="20"> <div align="right">Email :</div></td>



            <td><input name="email" type="text" class="edit" id="email" value="<?php echo $email ?>"></td>



          </tr>



          <tr>



            <?php if ($edit!=1) echo '<td colspan="2"><div align="center" class="promo"><br>



                Choose your package :<br>



                <br>



              </div></td>



          </tr>



          <tr>



            <td><div align="right">Package :</div></td>



            <td><select name="package" class="edit" id="package">



                <option value="1">Lite - $8.95 a month</option>



                <option value="2">Normal - $7.25 a month</option>



                <option value="3" selected>Deluxe - $5.75 a month</option>



              </select></td>'; ?>



          </tr>



          <tr>



            <td colspan="2">&nbsp;<?php if ($edit==1) echo "<input type='hidden' value='1' name='edit'>"; ?></td>



          </tr>



          <tr>



            <td colspan="2"><div align="center">



                <input name="Submit" type="submit" class="edit" value="<?php if ($edit==1) echo 'Modify'; else echo 'Sign up';?>">



              </div></td>



          </tr>



          <tr>



            <td colspan="2">&nbsp;</td>



          </tr>



        </table>



      </form>



      <p>&nbsp;</p>



      <!-- InstanceEndEditable --></td>
  </tr>
  <tr> 
    <td class="menutable"><div align="center" class="navLink"><a href="index.htm"><font color="#000099">Home</font></a> 
        <font color="#000099">|</font> <font color="#000099"><a href="howitworks.htm">How 
        It Works</a> |</font> <font color="#000099"><a href="features.htm">Features</a> 
        | <a href="steps.htm">Steps</a> |</font> <font color="#000099"><a href="join.php">Join 
        Now</a> |</font> <font color="#000099"><a href="faq.htm">FAQ</a> |</font> 
        <font color="#000099"><a href="tos.htm">Terms Of Service</a> |</font> 
        <font color="#000099"><a href="tellafriend.htm">Tell A Friend</a> |</font> 
        <font color="#000099"><a href="member.php">Member Area</a> | <a href="contact.htm">Contact 
        Us</a></font></div></td>
  </tr>
</table>
<div align="center" class="titlebar">
  <strong>Powered by</strong> <a href="http://www.AlstraSoft.com"><strong>AlstraSoft.com</strong></a></div>
</body>
<!-- InstanceEnd --></html>
