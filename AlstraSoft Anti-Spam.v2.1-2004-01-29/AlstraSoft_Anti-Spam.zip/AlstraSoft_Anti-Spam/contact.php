<?php
	include("./vars.inc");
	include("./template.inc");
	$t = new Template($rootpath);
	$t->set_file("doctemplate","phptemplate.htm");
	$content='<div align=center> Your message was sent ! </div>';
	mail("webmaster@alstrasoft.com",$subject,"New contact us message from :  ".$from."\n\n".$message,"From: Contact Us <".$from.">\r\n");
	$t->set_var("title","Contact Us");
	$t->set_var("content",$content);
	$t->parse("out","doctemplate");
	$t->p("out");

?>