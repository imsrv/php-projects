<?php
	set_time_limit(0);

	include ('vars.inc');
	include("./template.inc");

	$q = new CDbSpam;
	$q2 = new CDbSpam;
	$t = new Template($rootpath);
	$t->set_file("doctemplate","phptemplate.htm");

	$query='select * from pending where code="'.$code.'"';
	$q->query($query);
	if ($q->num_rows()>0)
	{
		$q->next_record();
		$query='select username,password from users where id='.$q->f("userid");
		$q2->query($query);
		if ($q2->num_rows()>0)
		{	
			$q2->next_record();
			//mail($q2->f("username").'@'.$surl,$q->f("subject"),$q->f("body"),$q->f("header"));
//			mail($q2->f("username").'@vroosh.com',$q->f("subject"),$q->f("body"),$q->f("header"));
			while ($stream==false)
			{
				$stream = @imap_open("{yoursite.com:143}INBOX",$q2->f("username").'@'.$surl, $q2->f("password"));
			}

				imap_append($stream,"{yoursite.com:143}INBOX"
								   ,$q->f("header")."\r\n"
								   .$q->f("body")."\r\n"
								   );


				imap_close($stream);
			$query='insert into emails values (NULL, '.$q->f("userid").', \''.$q->f("frome").'\',1)';
			$q->query($query);
			$query=' delete from pending where code="'.$code.'"';
			$q->query($query);
			$title="Congratulations !";
			$content='';
			FFileRead("verifyoktemplate.htm",$content);

		}else{
		
			$title="Error !";
			$content='';
    		FFileRead("verifyerrortemplate.htm",$content);

		}

	}else{
		
			$title="Error !";
			$content='';
			FFileRead("verifyerrortemplate.htm",$content);
	}

	$t->set_var("title",$title);
	$t->set_var("content",$content);
	$t->parse("out","doctemplate");
	$t->p("out");

?>