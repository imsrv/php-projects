<?php

$expdate=date ("m-d-Y",  mktime (0,0,0,date("m")  ,date("d"),date("Y")));
$curdate=date ("m-d-Y",  mktime (0,0,0,date("m")  ,date("d"),date("Y")));
$expa=explode("-",$expdate);
$cura=explode("-",$curdate);
echo mktime(0,0,0,$expa[0],$expa[1],$expa[2])-mktime(0,0,0,$cura[0],$cura[1],$cura[2]);
echo system("~vpopmail/bin/vadduser ionut@defeatspam.com trinity");

?>