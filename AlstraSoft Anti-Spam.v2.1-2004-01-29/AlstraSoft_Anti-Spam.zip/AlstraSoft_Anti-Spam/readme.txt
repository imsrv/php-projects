                                           AlstraSoft Anti-Spam v2.1 Documentation

Server requirements for AlstraSoft Anti-Spam
 
1.) POP3 server
2.) MySQL (version 3.23 or higher)
3.) MYSQL database
4.) PHP (version 4.2.3 or higher)
5.) Imap module for PHP
6.) Cpanel web host (optional: for automatic email setup)
7.) Crontab


Installation And Setup Instructions: 

1) Find "AlstraSoft Anti-Spam" and replace it with your site name (i.e. YOURSITE.com ) in HTML files. You may also edit the 
welcome email template(template_welcome_email.txt).

2) Open member.php, filter.php, verify.php, test.php and friendsend.php and replace yoursite.com with your domain name

3) Create a new database and run the spam.sql (If your webhost has PHPMyAdmin, you can run the spam.sql file there)

4) Modify the vars.inc file
$surl: The url where the files are located
$mailservername: Mail server name. It is usually yoursite.com. Contact your host admin if you are unsure
$Database: MYSQL database name
$User: MYSQL username
$Password: MYSQL password

5) Add cron at every minute : php /full-path/filter.php

6) Modify 2checkout/paypal with your 2Checkout ID and paypal email address in memberprofiletemplate.htm.
Also, modify the following paypal variables:
<input type="hidden" name="return" value="http://YOURSITE.com/member.php?action=paymentdone&credit_card_processed=Y&cart_order_id={code}">
<input type="hidden" name="cancel_return" value="http://YOURSITE.com/member.php">

7) Note: Skip this step if your web host does not support CPanel. If your web host does not support CPanel, you will need to 
manually add an email address each time a new member signs up using his username and password

Change the cpanel info in member.php and filter.php
Member.php file:
Line 127-131

$host = "www.yoursite.com";
$cuser = "username";
$cpassword = "password";
$in = "GET /frontend/VERTEX/mail/dopasswdpop.html?email=$username&domain=YOURSITE.COM&password=$password&quota=$cquo HTTP/1.0\r\nAuthorization: Basic $pass \r\n";

The vertex string(refer above) must be replaced with you cpanel skin. This can be different depending on cpanel version
Line 182-188 : the same.
Filter.php
Line 76-84 : the same

8) Create a folder named "spam" in your web server and upload ALL files into that folder


Customer Support

If you need help installing or configuring your script, we offer professional installation for our software for a flat-fee of 
$30. If you require us to help you install our software on your server, feel free to email us at support@alstrasoft.com or 
use our online feedback form to send us an installation request.  


Version History

Version 2.1:



License Agreement and Disclaimer

AlstraSoft Anti-Spam Software 2.1
Contact: sales@alstrasoft.com 

AlstraSoft.com, Copyright ? 2003
All rights reserved. 


THIS IS NOT FREE SOFTWARE !!!!
If you have downloaded this software from a website other than 'www.AlstraSoft.com' or if you have otherwise received this 
software from someone who is not a representative of this organization you are involved in an illegal activity. The copying, 
distribution, installation and usage of this software without our consent is illegal. In order to help us continue the 
development and production of good software, we kindly ask for your collaboration. Please contact us at 
'piracy@alstrasoft.com' and tell us where you got the software from. We will reward you with a free license and original 
software then. 

LICENSE AGREEMENT
Do not run the AlstraSoft software on a site other than which they have been licensed for. Violation of this license 
agreement may void your right to receive support and subject you to legal action. You should carefully read the following 
terms and conditions before using this software. Unless you have a different license agreement signed by AlstraSoft, your 
use of this software indicates your acceptance of this license agreement and disclaimer of warranty. 


As a registered user, you may alter or modify the DomainTrax Pro as far as the HTML output is concerned. Further modification
of the script code requires written permission of the author (Just drop us a short note ). You cannot give anyone else 
permission to modify the AlstraSoft Software. You are strictly prohibited from distributing copies of this software 
without prior permission. You are specifically prohibited from charging, or requesting donations, for any copies, however 
made, and from distributing the software and/or documentation with other products (commercial or otherwise) without prior 
written permission! 

DISCLAIMER OF WARRANTY
This software, the information, code and/or executables as well as the accompanying files provided are provided "as is" 
without warranty of any kind, either expressed or implied, including but not limited to the implied warranties of 
merchantability and fitness for a particular purpose. In no event shall the author or seller be liable for any damages 
whatsoever including direct, indirect, incidental, consequential, loss of data, loss of business profits or special damages, 
even if the author or seller has been advised of the possibility of such damages. Good data processing procedure dictates 
that any program be thoroughly tested with non-critical data before relying on it. The user must assume the entire risk of 
using the program. 
