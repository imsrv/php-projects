# MySQL-Front Dump 2.5
#
# Host: localhost   Database: spam
# --------------------------------------------------------
# Server version 3.23.55-nt


#
# Table structure for table 'admin'
#

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `confmessage` longtext,
  `cantmessage` longtext,
  `cantsubject` varchar(100) default NULL,
  `cantfrom` varchar(100) default NULL,
  `friendmessage` longtext,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) TYPE=MyISAM;



#
# Dumping data for table 'admin'
#

INSERT INTO `admin` (`id`, `confmessage`, `cantmessage`, `cantsubject`, `cantfrom`, `friendmessage`) VALUES("1", "This is a automated message from {email}\r\n\r\nDue to the high rate of spam and virus\'s, we ask that you perform a ONE \r\nTIME ONLY verification of your email address.\r\n\r\nWe have chosen to use DefeatSpam.com as our Anti-Spam E-Mail filter due to \r\nthe security and ease. We suggest you use it also!\r\nhttp://www.DefeatSpam.com\r\n\r\nJust click the link below to deliver the email message you have sent \r\nwith the subject:  {subject}\r\n\r\nIf you do not click the link below, your email will NOT be delivered to \r\n{email}\r\n\r\nThank You,\r\n{fullname}\r\n\r\nThe DefeatSpam.com E-mail Verifier.\r\n\r\n** YOU MUST CLICK THE LINK BELOW **\r\n{code}", "----- The following addresses had permanent fatal errors -----\r\n{toemail} (Reason: 550 5.2.1. {toemail}... Mailbox disabled, not accepting messages)\r\n\r\n\r\n550 5.1.1. {toemail} ... User unknown\r\n", "Returned mail: see transcript for details", "MailerDaemon@DefeatSpam.com", "Hello,\r\n\r\nI have found this really cool site that KILLS SPAM DEAD. \r\nNo more JUNK E-mail! \r\nI have my Inbox back!\r\n\r\nNothing to Download!\r\nNothing to Install!\r\n\r\nSee for youself!\r\n\r\nGo to:\r\n\r\nhttp://www.defeatspam.com\r\n");


#
# Table structure for table 'emails'
#

DROP TABLE IF EXISTS `emails`;
CREATE TABLE `emails` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `userid` bigint(20) unsigned default NULL,
  `email` varchar(250) default NULL,
  `action` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;



#
# Dumping data for table 'emails'
#


#
# Table structure for table 'filters'
#

DROP TABLE IF EXISTS `filters`;
CREATE TABLE `filters` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `userid` bigint(20) unsigned default NULL,
  `value` varchar(150) default NULL,
  `field` tinyint(1) default NULL,
  `case` tinyint(1) default NULL,
  `type` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;



#
# Dumping data for table 'filters'
#



#
# Table structure for table 'pending'
#

DROP TABLE IF EXISTS `pending`;
CREATE TABLE `pending` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `userid` bigint(20) unsigned default NULL,
  `subject` varchar(250) default NULL,
  `header` longtext,
  `body` longtext,
  `code` varchar(100) default NULL,
  `frome` varchar(250) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;



#
# Dumping data for table 'pending'
#



#
# Table structure for table 'users'
#

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `fullname` varchar(200) default NULL,
  `address` varchar(250) default NULL,
  `city` varchar(100) default NULL,
  `state` varchar(100) default NULL,
  `postalcode` varchar(20) default NULL,
  `email` varchar(100) default NULL,
  `username` varchar(100) default NULL,
  `password` varchar(100) default NULL,
  `package` tinyint(1) default NULL,
  `expdate` varchar(20) default NULL,
  `phone` varchar(100) default NULL,
  `country` varchar(100) default NULL,
  `code` varchar(150) default NULL,
  `added` tinyint(2) unsigned default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;



#
# Dumping data for table 'users'
#
