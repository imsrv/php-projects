# E-mail Verification Library
# Provided by CGI Connection
# http://www.cgiconnection.com


#####################################
# Error Codes:
# 0 = Valid
# 1 = DNS Timed Out
# 2 = DNS Lookup Failed
# 3 = Verify Timed Out
# 4 = Invalid E-mail Address
# 5, 6, or 7 = Could not connect to SMTP server
# 8 = Unknown User
#####################################

&check_installed_modules("Net::DNS Socket");
use Net::DNS;
use Socket;

$SIG{ALRM} = \&timeout_routine;

sub verify_email
{
my ($email, $TIMEOUT) = @_;
my (@all_temp, $username, $domain, $result, $smtp_server);
$email =~ s/\cM/\n/g;

$TIMEOUT = 10 if $TIMEOUT <= 0;

if ($email ne "" and $email =~ /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/)
 {
 splice(@all_temp, 0);
 @all_temp = split(/\@/, $email);
 $username = @all_temp[0];
 $domain = @all_temp[1];

 eval {
 alarm($TIMEOUT);
 $smtp_server = &get_dns_mx($domain);
 alarm(0); };

 if ($@ =~ /^TIMEOUT/)
  {
  return(1);
  }
  elsif($smtp_server == -1)
  {
  return(2);
  }
  else
  {
  eval {
  alarm($TIMEOUT);
  $result = &verify_email_routine($smtp_server, $email);
  alarm(0); };

  if ($@ =~ /^TIMEOUT/) {
   return(3); }
   else   {
   return("$result"); }
  }
 }
 else
 {
 return(4);
 }
}

sub verify_email_routine  {

    my ($smtp, $email) = @_;
    my ($status);

    $smtp =~ s/^\s+//g; # remove spaces around $smtp
    $smtp =~ s/\s+$//g;

    my($proto) = (getprotobyname('tcp'))[2];
    my($port) = (getservbyname('smtp', 'tcp'))[2];

    my($smtpaddr) = ($smtp =~
		     /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/)
	? pack('C4',$1,$2,$3,$4)
	    : (gethostbyname($smtp))[4];


    if (!defined($smtpaddr))
    {
	return(5);
    }

    if (!socket(MAIL, AF_INET, SOCK_STREAM, $proto))
    {
	return(6);
    }

    if (!connect(MAIL, pack('Sna4x8', AF_INET, $port, $smtpaddr)))
    {
	return(7);
    }

    my($oldfh) = select(MAIL);
    $| = 1;
    select($oldfh);

    $_ = <MAIL>;

    if (/^[45]/)
    {
	close(MAIL);
	return("$_");
    }

    print MAIL "HELO $smtp\r\n";
    while($_ =~ /220/){
    $_ = <MAIL>;
    if (/^[45]/)
    {
	close(MAIL);
	return("$_");
    }}

    print MAIL "MAIL FROM:<>\r\n";
    $_ = <MAIL>;
    if (/^[45]/)
    {
	close(MAIL);
	return("$_");
    }

    print MAIL "RCPT TO: <$email>\r\n";
    $_ = <MAIL>;
    if (/^[45]/)
    {
	close(MAIL);
	return(8);
    }
    else { $status = $_ };

    print MAIL "QUIT\r\n";
    $_ = <MAIL>;
    if (/^[45]/)
    {
	close(MAIL);
	return("$_");
    }

    close(MAIL);
    return(0);
}

sub get_dns_mx
{ 
my($host) = @_[0];
my($query, @mx);
splice(@mx, 0);

$res = Net::DNS::Resolver->new();
$query = $res->search("$host");

if (!$query)
 {
 return(-1);
 }

@mx = mx($res, $host) or return($host);

foreach $record (@mx) 
 {
 return($record->exchange);
 }
}

sub timeout_routine { die "TIMEOUT\n" }; # replacement signal

sub check_installed_modules
{
my ($temp) = @_[0];
my (@modCheck) = split(/ /, $temp);
my ($result) = 0;

for (@modCheck)
 {
 $result = &installed_modules("$_");

 if ($result == 0)
  {
  print "Content-type: text/html\n\n" if ("$ENV{'REQUEST_METHOD'}" ne "");
  print "$_ is not installed\n";
  exit;
  }
 }
}

sub installed_modules {
	my $module = $_;
	my $check = 0;

	eval "use $module";
	if ($@) { $check = 0; }
	else {
		$check = 1; # non-zero equals installed.
		my $version = 0;
		eval "\$version = \$$module\::VERSION";
		$check = $version if (!$@); # Set check to version number if it exists.
	}

	return $check;
}


1;