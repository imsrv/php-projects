
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE></TITLE>
</HEAD>
<BODY>
<CENTER>
Is your site looking ok without violating our rules?&nbsp;
<A TARGET="_top" HREF="add.php?name=<?print $name;?>&email=<?print $email;?>&share=<?print $share;?>&site=<?print $site;?>&language=<?print $language;?>&ref=<?print $ref;?>&sel[1]=<?print $sel[1];?>&sel[2]=<?print $sel[2];?>&sel[3]=<?print $sel[3];?>&sel1[1]=<?print $sel1[1];?>&sel1[2]=<?print $sel1[2];?>&sel1[3]=<?print $sel1[3];?>&pass=<?print $pass;?>&url=<?print $url;?>" SCROLLING='No' NORESIZE NAME='top' BORDER='0'><FRAME MARGINHEIGHT='0' MARGINWIDTH='0' SRC='<?print $url;?>'>Yes</A>
&nbsp;&nbsp;
<A TARGET="_top" HREF="javascript: history.back();">No</A>
</CENTER>
</BODY>
</HTML>
