<?
$subject[1]=" New user regitered ";
$subject[2]=" Your password ";
$subject[3]=" Your password was changed ";
$subject[6]=" Your e-mail was changed ";
$subject[4]=" You are registered ";
$subject[5]=" Confirm your account ";

$body[1]=" New user regitered. Check admin: ";
$body[2]=" Your new password is: ";
$body[3]=" Your Change code is : ";

//Macroses [id],[email],[pass]
$body[4]=" 
+++++++++++++++++++++
Welcome,
Thanks for signup at YOURSITE and please find account
info.

user id : [id]
login   : [email]
pass    : [pass] (this password generated automatically)

Surfbar for getting credit:
http://www.domain.com/hits.php?id=[id]

Referral link:
http://www.domain.com/signup.php?ref=[id]

++++++++++++++++++++++";
//

$msg[1]=" Your password and login was sent on your e-mail ";
$msg[2]=" Login not exist ";
$msg[3]=" 
      Your site will now be checked and verified by 
      our team<BR>Within 1 hours, your site will be included in the site 
      rotation,<BR>if it can be accepted.<BR><BR>You will shortly receive an 
      e-mail<BR>with all the information you need.<BR>Remember to login to 
      member's area and<BR>check your site state by yourself.<BR><BR>Thanks - 
      and welcome to AutoHits.<BR><BR>Yours Truly<BR><BR>Team 
leader<br>
";

$err[1]=" Password or login incorrect ";
$err[2]=" Cannot connect ";
$err[3]=" Fill field ";
$err[4]=" Cannot add ";
$err[5]=" Enter password with chars A-B and/or numbers ";
$err[6]=" Not enough credits ";
$err[7]=" E-mail already registered. ";
$err[8]=" Target 3 categories ";
$err[9]=" Cannot edit ";
$err[10]=" No site to show ";
