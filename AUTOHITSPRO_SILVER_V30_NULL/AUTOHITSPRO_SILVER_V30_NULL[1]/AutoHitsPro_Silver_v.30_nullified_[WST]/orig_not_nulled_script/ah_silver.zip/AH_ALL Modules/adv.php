<?
/***************************************************************************
 *                         AutoHits  PRO                            *
 *                            -------------------
 *    Version          : 2.1                                                  *
 *   Released        : 04.22.2003                                     *
 *   copyright            : (C) 2003 SupaTools.com                           *
 *   email                : info@supatools.com                             *
 *   website              : www.supatools.com                 *
 *   custom work     :http://www.gofreelancers.com      *
 *   support             :http://support.supatools.com        *
 *                                                                         *
 *                                                                         *
 *                                                                         *
 ***************************************************************************/
require('header_inc.php');
?> 
        <table border="0" cellpadding="5" cellspacing="5" width="100%">
          <tr>
               
                <td> <font size="3"><b> Advertisement Rates </b></font> 
                  <p><b>Holiday Special Hits Packages</b> (good until 12/30/02) 
                  </p>
                 <p><br>
                    5,000 credits(hits) on YourCompany.com for $15.00 <br>
                    10,000 credits(hits) on YourCompany.com for $19.00 <br>
                    50,000 credits(hits) on YourCompany.com for $69.00 <br>
                    100,000 credits(hits) on YourCompany.com for $99.00 </p>
                  <p><b>Banner Ads</b> (impressions as low as 25 cents per 1000)
                   <br>
                 </p>
                 <p>50,000 impressions at $20.00 (40 cents per 1000)<br>
                    100,000 impressions at $35.00 (35 cents per 1000) <br>
                    500,000 impressions at $150.00 (30 cents per 1000) <br>
                    1,000,000 impressions at $250.00 (25 cents per 1000) </p>
                  <p>&nbsp;</p></td>
           </tr>
        </table>
<?
require('footer_inc.php');
?>
