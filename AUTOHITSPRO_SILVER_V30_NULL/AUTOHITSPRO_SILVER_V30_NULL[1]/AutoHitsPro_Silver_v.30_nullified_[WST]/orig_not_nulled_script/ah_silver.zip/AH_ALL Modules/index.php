<?
/***************************************************************************
 *                         AutoHits  PRO                            *
 *                            -------------------
 *    Version          : 2.1                                                  *
 *   Released        : 04.22.2003                                     *
 *   copyright            : (C) 2003 SupaTools.com                           *
 *   email                : info@supatools.com                             *
 *   website              : www.supatools.com                 *
 *   custom work     :http://www.gofreelancers.com      *
 *   support             :http://support.supatools.com        *
 *                                                                         *
 *                                                                         *
 *                                                                         *
 ***************************************************************************/
$ref=intval($ref);
if($ref!=0){
	SetCookie("ref",$ref,time()+3600);
} 
include ("header_inc.php");
?> 
      <blockquote> 
        
  <p>Welcome to <font color="#FF0000"><b>YourCompany.com</b></font><font size="1"></font></b>, a FREE automatic traffic generating system.</p>
        
  <p align="left"><br>
    <img src="img/index_r5_c13.gif" width="139" height="126" border="0" align="left">Would 
    you like to receive unlimited FREE traffics to your site without clicking 
    your mouse? When using our system, your site is being shown to thousands of 
    users from around the world, 24 hours a day, 365 days a year and all this 
    is done 100% automatically. </p>
        <p>All you have to do is sign up for FREE and open your browser and let 
          the system do the work. For each 4 sites shown in your browser, you 
          will receive 3 hits in return. We have 20 second timer, so you will 
          receive <b>180 FREE Hits per hour</b> to your site. <b>That's 4320 FREE 
          Hits per day</b>. And we're not stopping here. You also receive credits 
          for your referrals too! A whopping 25% of what your referrals earn. 
          Learn more about referrals in members area.</p>
        
  <p><b>Join for YourCompany.com today and receive 200 credits - It's</b> 
    <font color="#FF0000"><b>FREE</b></font> (after sign up, you will receive 
    200 visitor credits automatically) <br>
        </p>
      </blockquote>
      
<p align="center"><font color="#FF0000"><b><a href="signup.php">YES, SIGN ME UP 
  NOW! CLICK HERE</a></b></font></p>
      <p></p>
<?
include("footer_inc.php");
?>       