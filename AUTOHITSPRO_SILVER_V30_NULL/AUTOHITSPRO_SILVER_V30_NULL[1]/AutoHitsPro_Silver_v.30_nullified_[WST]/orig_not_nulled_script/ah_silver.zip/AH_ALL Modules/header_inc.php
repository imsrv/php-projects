<HTML>
<HEAD>
<TITLE>AutoHits.dk Clone [] run your own traffic site [] traffic system [] AutoHits [] PayPal Advertising System</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="autohits.css" type="text/css">
</HEAD>
<BODY BGCOLOR=#FFFFFF LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
<!-- ImageReady Slices (blank_temp.psd) -->
<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD COLSPAN=6>
			<IMG SRC="images/index_01.gif" WIDTH=780 HEIGHT=54 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=6>
			<IMG SRC="images/index_02.gif" WIDTH=780 HEIGHT=13 ALT=""></TD>
	</TR>
	<TR>
		<TD colspan=6 class=top background="images/index_03.jpg" WIDTH=780 HEIGHT=24>
	<font color="silver" face="tahoma" size="2">	&nbsp; &nbsp; <a href="index.php" class="menu">Home</a> | 	<a href="login.php" class=menu>Members Login</a> | <a href="signup.php" class=menu>Register</a> | <a href="adv.php" class=menu>Advertise</a> | <a href="faq.php" class=menu>FAQ</a> | <a href="contact.php" class=menu>Contact</a></span>

</TD>
	
	</TR>
	<TR>
		<TD COLSPAN=4>
			<IMG SRC="images/index_05.gif" WIDTH=234 HEIGHT=141 ALT=""></TD>
		<TD>
			<IMG SRC="images/index_06.gif" WIDTH=287 HEIGHT=141 ALT=""></TD>
		<TD>
			<IMG SRC="images/index_07.gif" WIDTH=259 HEIGHT=141 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=6>
			<IMG SRC="images/index_08.gif" WIDTH=780 HEIGHT=13 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=2 valign=top align=center>
			<br><br>
<p><img src="img/banner.jpg" width="100" height="100"></p>
<p><img src="img/banner.jpg" width="100" height="100"></p>
</TD>
		<TD background="images/index_10.gif" WIDTH=10 HEIGHT=36>
			</TD>
		<TD COLSPAN=3 bgcolor="white" width="592">
	<!-- BODY STARTS HERE --- HEADER ENDS HERE -->	
