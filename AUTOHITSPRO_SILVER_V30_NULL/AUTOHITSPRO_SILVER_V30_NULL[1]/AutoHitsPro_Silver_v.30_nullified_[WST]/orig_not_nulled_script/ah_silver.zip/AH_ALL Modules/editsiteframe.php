<?$ids=intval($ids);?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE></TITLE>
</HEAD>
<BODY>
<CENTER>
Is your site looking ok without violating our rules?&nbsp;
<A TARGET="_top" HREF="editsite2.php?ids=<?print $ids;?>&site=<?print $site;?>&sel[1]=<?print $sel[1];?>&sel[2]=<?print $sel[2];?>&sel[3]=<?print $sel[3];?>&language=<?print $language;?>&url=<?print $url;?>" SCROLLING='No' NORESIZE NAME='top' BORDER='0'><FRAME MARGINHEIGHT='0' MARGINWIDTH='0' SRC='<?print $url;?>'>Yes</A>
&nbsp;&nbsp;
<A TARGET="_top" HREF="javascript: history.back();">No</A>
</CENTER>
</BODY>
</HTML>
