<?
// your mysql database details
$hostnm = "localhost";
$usernm = "username";
$pwd = "password";
$dbName = "autohits";
// URL Where AutoHits Is Installed 
$path="http://www.domain.com";
$base="http://www.domain.com";
//Same as above but with '/' trailing slash
$url_default="http://supatools.com/software/php/autohits.php";
// your site name
$site_name="YOUR SITE NAME";
// email addresses
$admin_mail="admin@email.net";
$support_email="support@email.net";
// Your paypal account
$email_pay="paypal@youremail.com";
// Referral level credits
$ref_cr[1]=0.25;
$ref_cr[2]=0.0125;
$ref_cr[3]=0.000625;
$ref_cr[4]=0.0000625;
$ref_cr[5]=0.000003125;
// Account Credit Rates
$basic_min=0.75;
$basic_max=1;
$silver_min=1;
$silver_max=1.25;
$gold_min=1.25;
$gold_max=1.5;
// Bonus credits at signup
$bonus_credits=200;
?>