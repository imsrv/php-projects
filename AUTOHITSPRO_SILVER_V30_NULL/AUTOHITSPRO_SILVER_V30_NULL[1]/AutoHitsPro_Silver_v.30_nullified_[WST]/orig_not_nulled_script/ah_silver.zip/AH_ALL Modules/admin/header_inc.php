
<HTML>
<HEAD>
<TITLE><? print $title_adm; ?></TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="expires" content="0">
<meta http-equiv="Cache-Control" content="no-cache">
<style type="text/css">
a {  font-family: Arial, Helvetica, sans-serif; color: navy; TEXT-DECORATION: none}
a:hover {  font-family: Arial, Helvetica, sans-serif; color: navy; TEXT-DECORATION: none}
a.menu {  font-family: Arial, Helvetica, sans-serif; color: #333333; TEXT-DECORATION: none}
a.menu:hover {  font-family: Arial, Helvetica, sans-serif; color: white; TEXT-DECORATION: none}
td {  font-family: Arial, Helvetica, sans-serif; font-size: 11px; COLOR: #555555;}
.bodytext {  font-family: Arial, Helvetica, sans-serif; font-size: 12px;}
.cmn {  font-family: Arial, Helvetica, sans-serif; font-size: 11px;}
.small {  font-family: Arial, Helvetica, sans-serif; font-size: 11px;}
.topic {  font-family: Arial, Helvetica, sans-serif; font-size: 24px; font-weight: bold;}
TEXTAREA {  font-family: Arial, Helvetica, sans-serif; font-size: 11px;BACKGROUND:#1772CB;COLOR: #ffffff;}
SELECT {  font-family: Arial, Helvetica, sans-serif; font-size: 11px;BACKGROUND:#1772CB;COLOR: #ffffff;}
INPUT {  font-family: Arial, Helvetica, sans-serif; FONT-SIZE: 10px;BACKGROUND:#1772CB;COLOR: #ffffff;}

body{
	scrollbar-face-color: #666666;
	scrollbar-track-color: #CCCCCC;
	scrollbar-arrow-color: #66AAEE;

	scrollbar-highlight-color: #DDDDDD;
	scrollbar-3dlight-color: #999999;
	scrollbar-shadow-color: #DDDDDD;
	scrollbar-darkshadow-color: #888888;
}
.std_button {
	background-color: #3678BF;
  color: #99CFC1;
  font-size: 11px;
  font-weight : normal;
  border-style: solid;
  border-width : 1;  
  boder-color : #99CFC1
  font-family: tahoma
}
</style>
</HEAD>
<BODY BGCOLOR=#FFFFFF LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
<TABLE WIDTH=780 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD COLSPAN=9>
			<IMG SRC="images/index_01.gif" WIDTH=611 HEIGHT=32 ALT=""></TD>
		<TD COLSPAN=5>
			<a href="http://www.supatools.com/software/php/autohits.php" target="_blank"><IMG SRC="images/index_02.gif" WIDTH=169 HEIGHT=32 ALT="Powered By : SupaTools.com" border="0"></a></TD>
	</TR>
	<TR>
		<TD COLSPAN=14>
			<IMG SRC="images/index_03.gif" WIDTH=780 HEIGHT=35 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=11>
			<IMG SRC="images/index_04.gif" WIDTH=694 HEIGHT=20 ALT=""></TD>
		<TD COLSPAN=3>
			<a href="change.php"><IMG SRC="images/index_05.gif" WIDTH=86 HEIGHT=20 ALT="Change Your Password" border="0"></a></TD>
	</TR>
	<TR>
		<TD COLSPAN=2>
			<a href="index.php"><IMG SRC="images/index_06.gif" WIDTH=68 HEIGHT=41 ALT="Main Menu" border="0"></a></TD>
		<TD>
			<a href="user.php"><IMG SRC="images/index_07.gif" WIDTH=82 HEIGHT=41 ALT="Manage Members Stats" border="0"></a></TD>
		<TD>
			<a href="mail.php"><IMG SRC="images/index_08.gif" WIDTH=70 HEIGHT=41 ALT="Email All Members" border="0"></a></TD>
		<TD>
			<a href="cat.php"><IMG SRC="images/index_09.gif" WIDTH=96 HEIGHT=41 ALT="Manage Categories" border="0"></a></TD>
		<TD>
			<a href="prices.php"><IMG SRC="images/index_10.gif" WIDTH=81 HEIGHT=41 ALT="Credit And Price Settings" border="0"></a></TD>
		<TD>
			<a href="prices1.php"><IMG SRC="images/index_11.gif" WIDTH=83 HEIGHT=41 ALT="Account Type Settings" border="0"></a></TD>
		<TD>
			<a href="searchu.php"><IMG SRC="images/index_12.gif" WIDTH=77 HEIGHT=41 ALT="Search Users" border="0"></a></TD>
		<TD COLSPAN=2>
			<a href="searchs.php"><IMG SRC="images/index_13.gif" WIDTH=75 HEIGHT=41 ALT="Search Whole Site" border="0"></a></TD>
		<TD COLSPAN=2>
			<a href="statistic.php"><IMG SRC="images/index_14.gif" WIDTH=75 HEIGHT=41 ALT="Users Statistics" border="0"></a></TD>
		<TD COLSPAN=2>
			<a href="dstatistic.php"><IMG SRC="images/index_15.gif" WIDTH=73 HEIGHT=41 ALT="Overall Statistics By Date" border="0"></a></TD>
	</TR>
	<TR>
		<TD COLSPAN=14>
			<IMG SRC="images/index_16.gif" WIDTH=780 HEIGHT=11 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=14>
			<IMG SRC="images/index_17.gif" WIDTH=780 HEIGHT=37 ALT=""></TD>
	</TR>
	
	<TR>
		<TD background="images/index_19.gif" WIDTH=28>
</TD>
		<TD COLSPAN=12 bgcolor="#FFFFFF" WIDTH=728>
<!--- HEADER END ::::: BODY START -->




