<?
$delay_t='20';
$autoplay_t=1; // set to 1 for autoplay, 0 for pause
?>