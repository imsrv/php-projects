<?
$title_adm='Administrator`s panel';
$author_email="support@email.net";

$subject[1]=" Your site was published ";
$subject[2]=" Statistic ";
$subject[3]=" Site was declined ";

$body[1]=" Your site was published ";
$body[2][1]="+++++++++++++++++
Name: [name]
E-mail: [email]
User ID: [id]
Account credits: [credits]";
$body[2][2]="

Site Name [site]	
Site URL [url]	
Total hits [hits]	
From last Mail	[last_mail]
Credits [credits1]	
State   [state]";
$body[2][3]="

Hits Received on this week

Date	   Received
";
$body[2][4]="[date_r]   [receive]
";
$body[2][5]="
Date	   Earned
";
$body[2][6]="[date_e]   [earn]
";
$body[2][7]="++++++++++++++++++++";
$body[3]=" Your site was declined due to not met
in terms and conditions. ";


$msg[1]=" No new sites ";
$msg[2]=" No users ";
$msg[3]=" Mail was sent ";
$msg[4]=" No users Admin ";

$err[1]=" Login or password incorrect ";
$err[2]=" Cannot connect ";
$err[3]=" Fill all fields ";
$err[4]=" Cannot add ";
$err[5]=" Cannot delete ";
$err[6]=" Cannot edit ";
$err[7]=" Cannot publish ";
$err[8]=" Target even one category ";
$err[9]=" User alredy exist please enter new name ";
$err[10]=" Enter current value of field ";
$err[11]=" Cannot send to ";
$err[12]=" Cannot find ";
