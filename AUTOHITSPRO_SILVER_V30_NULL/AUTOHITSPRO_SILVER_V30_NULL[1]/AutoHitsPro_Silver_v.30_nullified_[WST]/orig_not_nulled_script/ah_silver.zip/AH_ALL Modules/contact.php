<?
/***************************************************************************
 *                         AutoHits  PRO                            *
 *                            -------------------
 *    Version          : 2.1                                                  *
 *   Released        : 04.22.2003                                     *
 *   copyright            : (C) 2003 SupaTools.com                           *
 *   email                : info@supatools.com                             *
 *   website              : www.supatools.com                 *
 *   custom work     :http://www.gofreelancers.com      *
 *   support             :http://support.supatools.com        *
 *                                                                         *
 *                                                                         *
 *                                                                         *
 ***************************************************************************/
require('header_inc.php');
?> 
        <table border="0" cellpadding="5" cellspacing="5" width="100%">
          <tr>
                
                <td valign=top> <br><br>
<center>Contact Us anytime on the email provided: <a href=mailto:email@domain.com>email@domain.com</a><br>
</td></tr></table>

<?
require('footer_inc.php');
?>