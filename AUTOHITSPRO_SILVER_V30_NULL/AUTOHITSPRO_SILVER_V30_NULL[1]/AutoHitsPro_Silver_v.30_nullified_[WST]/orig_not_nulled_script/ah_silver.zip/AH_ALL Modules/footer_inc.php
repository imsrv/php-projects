<!-- BODY ENDS HERE --- FOOTER STARTS HERE -->	
</TD>
	</TR>
<TR>
<TD colspan=6 align=center>
<small><hr></small>
</TD></TR>
<TR>
<TD colspan=6 align=center><br><br><br><br><br>
<small>Powered By : <a href="http://www.supatools.com/software/php/autohits.php">AutoHits Pro</a></small><br>
</TD></TR>	
	<TR>
		<TD>
			<IMG SRC="images/spacer.gif" WIDTH=8 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="images/spacer.gif" WIDTH=170 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="images/spacer.gif" WIDTH=10 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="images/spacer.gif" WIDTH=46 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="images/spacer.gif" WIDTH=287 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="images/spacer.gif" WIDTH=259 HEIGHT=1 ALT=""></TD>
	</TR>
</TABLE>
</BODY>
</HTML>