<div align=center>
<a href="user_menu.php"><font color=blue>Main menu</font></a>
:: <a href="hits.php?id=<?print $id;?>"><font color=blue>Autohits</font></a>
:: <a href="ref.php"><font color=blue>Referal</font></a>
:: <a href="del.php"><font color=blue>Delete account</font></a>
:: <a href="buy.php"><font color=blue>Buy Credits</font></a>
:: <a href="type.php"><font color=blue>Upgrade Acount</font></a>
:: <a href="<?print $PHP_SELF;?>?logout=1"><font color=blue>Log Out</font></a>
</div>
<hr noshade size="1">