# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 

package AdReports;
use strict;


sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	return $self;
}



# >> HOUR CHART GENERATOR
sub hour_chart_generator{
	my($self,$master)=@_;
	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	my $hour=$master->{env}->get_hour;

	# input vars
	my $cid=$master->{query}->param('cid');

	#get the ad media
	my(@dailyref)=$master->{db}->select_multi_row_hash("SELECT sum(IMPR) as IMPR, sum(CLICK) as CLICK,LOG_HOUR FROM daily_log where CID='$cid' GROUP BY CID,LOG_DATE,LOG_HOUR ORDER BY LOG_DATE DESC,LOG_HOUR DESC LIMIT 23");
	my $dailytot=@dailyref;

	my $gridref=$master->{db}->select_single_row_hash("SELECT SUM(HOUR_IMPR) as IMPR,SUM(HOUR_CLICK) as CLICK  FROM cp_grouping WHERE CID='$cid'");

	$gridref->{CLICK}*=10+0;
	my $sample_Values="$gridref->{IMPR}";
	my $sample_Values2="$gridref->{CLICK}";
	my $sample_Labels="$hour";
	for(my $k=0;$k<$dailytot;$k++){
		$dailyref[$k]->{CLICK}*=10+0;
		$sample_Values2="$dailyref[$k]->{CLICK},".$sample_Values2;
		$sample_Values="$dailyref[$k]->{IMPR},".$sample_Values;
		$sample_Labels="$dailyref[$k]->{LOG_HOUR},".$sample_Labels;
	}

	print qq~
<!-- Charting capability provided by EasyCharts(c) 2001 an Objectplanet.com Product -->
<applet code="com.objectplanet.chart.BarChartApplet" archive="$images_url/chart.jar" width=585 height=300>
<param name=seriesCount value="2">
<param name=sampleCount value="24">
<param name=sampleValues_0 value="$sample_Values">
<param name=sampleValues_1 value="$sample_Values2">
<param name=sampleLabels value="$sample_Labels">
<param name=seriesLabels value="Impressions,Clicks (x10)">
<param name=sampleAxisLabel value="Hour">
<param name=legendPosition value="bottom">
<param name=barWidth value="0.6">
<param name=graphInsets value="-1,-1,-1,-1">
<param name=sampleColors value="#0066FF,#FFcc00">
<param name=background value="#DDDDCC">
<param name=titleFont value="Arial, bold, 20">
<param name=barLabelsOn value=true>
<param name=autoLabelSpacingOn value=true>
<param name=valueLinesOn value=true>
<param name=multiColorOn value=true>
</applet>
~;

}
# << HOUR CHART GENERATOR







# >> DAY TABLE GENERATOR
sub day_table_generator{
	my($self,$master)=@_;

	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	my $hour=$master->{env}->get_hour;
	my $date=$master->{env}->get_date;

	# input vars
	my $cid=$master->{query}->param('cid');

	#get the ad media
	my(@dailyref)=$master->{db}->select_multi_row_hash("SELECT sum(IMPR) as IMPR, sum(CLICK) as CLICK,LOG_DATE FROM daily_log where CID='$cid' GROUP BY CID,LOG_DATE ORDER BY LOG_DATE DESC");
	my $dailytot=@dailyref;

	my $cidref=$master->{db}->select_single_row_hash("SELECT TODAY_IMPR as IMPR,TODAY_CLICK as CLICK  FROM cp WHERE CID='$cid'");



	# >> accumulate data
	my @impr;
	my @click;
	my @date;
	my $idx=0;
	if($cidref->{IMPR}>0 || $cidref->{CLICK}>0){
		$impr[0]=$cidref->{IMPR};
		$click[0]=$cidref->{CLICK};
		$date[0]=$date;
	}
	for(my $k=0;$k<$dailytot;$k++){
		if($dailyref[$k]->{LOG_DATE} ne $date){
			$idx++;
			$impr[$idx]+=$dailyref[$k]->{IMPR};
			$click[$idx]+=$dailyref[$k]->{CLICK};
			$date[$idx]=$dailyref[$k]->{LOG_DATE};
		}
	}
	my $max=@impr;
	# << accumulate data


	# find max
	for(my $k=0;$k<$max;$k++){
		if($impr[$k]>$master->{IMPR}){
			$master->{IMPR}=$impr[$k];
		}
		if($click[$k]>$master->{CLICK}){
			$master->{CLICK}=$click[$k];
		}
	}
	$master->{WIDTH}=230;



	# first row
	print qq~
	<table cellpadding=3 cellspacing=1 border=0 bgcolor="333333" width="100%">
	<tr class="td2">
	<td align=center><b>Date</td>
	<td align=center><b>Impr</td>
	<td align=center><b>Clicks</td>
	<td align=center><b>CTR</td>
	<td align=center>&nbsp;</td>
	</tr>
	~;
	

	my $impr_sum=0;
	my $click_sum=0;
	for(my $k=0;$k<$max;$k++){
		my $ctp=$master->{tools}->ctp_calculation($impr[$k],$click[$k]);
		$impr_sum+=$impr[$k];
		$click_sum+=$click[$k];
		print qq~
		<tr class="td3">
		<td align=center>$date[$k]</td>
		<td align=center>$impr[$k]</td>
		<td align=center>$click[$k]</td>
		<td align=center>$ctp\%</td>
		<td align=left width="235">~;
		$master->{reports}->bar_table($master,$impr[$k],$click[$k]);				
		print qq~</td>
		</tr>
		~;	
	}

	my $ctp=$master->{tools}->ctp_calculation($impr_sum,$click_sum);
	print qq~
	<tr bgcolor="EEEEEE">
	<td align=right>Total:</td>
	<td align=center>$impr_sum</td>
	<td align=center>$click_sum</td>
	<td align=center>$ctp\%</td>
	<td align=left width="235">&nbsp;</td>
	</tr>
	</table>
	~;

}
# << DAY TABLE GENERATOR









# >> GROUP DAY TABLE GENERATOR
sub group_day_table_generator{
	my($self,$master)=@_;

	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	my $hour=$master->{env}->get_hour;
	my $date=$master->{env}->get_date;

	# input vars
	my $gid=$master->{query}->param('gid');

	#get the ad media
	my(@dailyref)=$master->{db}->select_multi_row_hash("SELECT sum(IMPR) as IMPR, sum(CLICK) as CLICK,LOG_DATE FROM daily_log where GID='$gid' GROUP BY LOG_DATE ORDER BY LOG_DATE DESC");
	my $dailytot=@dailyref;

	my $gridref=$master->{db}->select_single_row_hash("SELECT sum(HOUR_IMPR) as IMPR,sum(HOUR_CLICK) as CLICK  FROM cp_grouping WHERE GID='$gid'");



	# >> accumulate data
	my @impr;
	my @click;
	my @date;
	my $idx=0;
	if($gridref->{IMPR}>0 || $gridref->{CLICK}>0){
		$impr[0]=$gridref->{IMPR};
		$click[0]=$gridref->{CLICK};
		$date[0]=$date;
	}
	for(my $k=0;$k<$dailytot;$k++){
		if($idx==0 && $dailyref[$k]->{LOG_DATE} ne $date){
			$idx++;
		}
		$impr[$idx]+=$dailyref[$k]->{IMPR};
		$click[$idx]+=$dailyref[$k]->{CLICK};
		$date[$idx]=$dailyref[$k]->{LOG_DATE};
		$idx++;
	}
	my $max=@impr;
	# << accumulate data


	# find max
	for(my $k=0;$k<$max;$k++){
		if($impr[$k]>$master->{IMPR}){
			$master->{IMPR}=$impr[$k];
		}
		if($click[$k]>$master->{CLICK}){
			$master->{CLICK}=$click[$k];
		}
	}
	$master->{WIDTH}=230;


	# first row
	print qq~
	<table cellpadding=3 cellspacing=1 border=0 bgcolor="333333" width="100%">
	<tr class="td2">
	<td align=center><b>Date</td>
	<td align=center><b>Impr</td>
	<td align=center><b>Clicks</td>
	<td align=center><b>CTR</td>
	<td align=center>&nbsp;</td>
	</tr>
	~;	

	
	my $impr_sum=0;
	my $click_sum=0;
	for(my $k=0;$k<$max;$k++){
		my $ctp=$master->{tools}->ctp_calculation($impr[$k],$click[$k]);
		$impr_sum+=$impr[$k];
		$click_sum+=$click[$k];
		print qq~
		<tr class="td3">
		<td align=center>$date[$k]</td>
		<td align=center>$impr[$k]</td>
		<td align=center>$click[$k]</td>
		<td align=center>$ctp\%</td>
		<td align=left width="235">~;
		$master->{reports}->bar_table($master,$impr[$k],$click[$k]);				
		print qq~</td>
		</tr>
		~;	
	}

	my $ctp=$master->{tools}->ctp_calculation($impr_sum,$click_sum);
	print qq~
	<tr bgcolor="EEEEEE">
	<td align=right>Total:</td>
	<td align=center>$impr_sum</td>
	<td align=center>$click_sum</td>
	<td align=center>$ctp\%</td>
	<td align=left width="235">&nbsp;</td>
	</tr>
	</table>
	~;

}
# << GROUP DAY TABLE GENERATOR









# >> GROUP HOUR CHART GENERATOR
sub group_hour_chart_generator{
	my($self,$master)=@_;
	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	my $hour=$master->{env}->get_hour;

	# input vars
	my $gid=$master->{query}->param('gid');

	#get the ad media
	my(@dailyref)=$master->{db}->select_multi_row_hash("SELECT sum(IMPR) as IMPR, sum(CLICK) as CLICK,LOG_HOUR FROM daily_log where GID='$gid' GROUP BY LOG_DATE,LOG_HOUR ORDER BY LOG_DATE DESC,LOG_HOUR DESC LIMIT 23");
	my $dailytot=@dailyref;

	my $gridref=$master->{db}->select_single_row_hash("SELECT SUM(HOUR_IMPR) as IMPR,SUM(HOUR_CLICK) as CLICK  FROM cp_grouping WHERE GID='$gid'");

	$gridref->{CLICK}*=10+0;
	my $sample_Values="$gridref->{IMPR}";
	my $sample_Values2="$gridref->{CLICK}";
	my $sample_Labels="$hour";
	for(my $k=0;$k<$dailytot;$k++){
		$dailyref[$k]->{CLICK}*=10+0;
		$sample_Values2="$dailyref[$k]->{CLICK},".$sample_Values2;
		$sample_Values="$dailyref[$k]->{IMPR},".$sample_Values;
		$sample_Labels="$dailyref[$k]->{LOG_HOUR},".$sample_Labels;
	}

	print qq~
<!-- Charting capability provided by EasyCharts(c) 2001 an Objectplanet.com Product -->
<applet code="com.objectplanet.chart.BarChartApplet" archive="$images_url/chart.jar" width=585 height=300>
<param name=seriesCount value="2">
<param name=sampleCount value="24">
<param name=sampleValues_0 value="$sample_Values">
<param name=sampleValues_1 value="$sample_Values2">
<param name=sampleLabels value="$sample_Labels">
<param name=seriesLabels value="Impressions,Clicks (x10)">
<param name=sampleAxisLabel value="Hour">
<param name=legendPosition value="bottom">
<param name=barWidth value="0.6">
<param name=graphInsets value="-1,-1,-1,-1">
<param name=sampleColors value="#0066FF,#FFcc00">
<param name=background value="#DDDDCC">
<param name=titleFont value="Arial, bold, 20">
<param name=barLabelsOn value=true>
<param name=autoLabelSpacingOn value=true>
<param name=valueLinesOn value=true>
<param name=multiColorOn value=true>
</applet>
~;

}
# <<  GROUP HOUR CHART GENERATOR















# >> BAR TABLE
sub bar_table{
	my($self,$master,$impr,$click)=@_;
	my $images_url=$master->{config}->get_images_url;

	my $width_blue=2;
	if($master->{IMPR}>0){
		$width_blue=int(($impr/$master->{IMPR})*$master->{WIDTH})+2;
	}
	my $width_clearb=$master->{WIDTH}-$width_blue;

	my $width_orange=2;
	if($master->{CLICK}>0){
		$width_orange=int(($click/($master->{CLICK}*2))*$master->{WIDTH})+2;
	}
	my $width_clearo=$master->{WIDTH}-$width_orange;



	print qq~
	<img src="$images_url/lt_blue.gif" width=$width_blue height=8><img src="$images_url/clear.gif" width=$width_clearb height=8><br>
	<img src="$images_url/orange.gif" width=$width_orange height=8><img src="$images_url/clear.gif" width=$width_clearo height=8><br>
	~;

}
# << BAR TABLE









# >> GROUP TABLE GENERATOR
sub group_table_generator{
	my($self,$master)=@_;

	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	my $hour=$master->{env}->get_hour;
	my $date=$master->{env}->get_date;

	# input vars
	my $cid=$master->{query}->param('cid');

	#get the ad media
	my(@dailyref)=$master->{db}->select_multi_row_hash("SELECT sum(IMPR) as IMPR, sum(CLICK) as CLICK,GID FROM daily_log where CID='$cid' GROUP BY CID,GID ORDER BY GID");
	my $dailytot=@dailyref;

	my (@gridref)=$master->{db}->select_multi_row_hash("SELECT sum(HOUR_IMPR) as IMPR,sum(HOUR_CLICK) as CLICK,GID  FROM cp_grouping WHERE CID='$cid' GROUP BY GID");
	my $gridtot=@gridref;

	# find max
	$master->{IMPR}=0;
	$master->{CLICK}=0;
	for(my $k=0;$k<$gridtot;$k++){
		my $dailyref=$master->{db}->select_single_row_hash("SELECT sum(IMPR) as IMPR, sum(CLICK) as CLICK FROM daily_log where CID='$cid' AND GID='$gridref[$k]->{GID}'");
		if($dailyref->{IMPR}+$gridref[$k]->{IMPR}>$master->{IMPR}){
			$master->{IMPR}=$dailyref->{IMPR}+$gridref[$k]->{IMPR};
		}
		if($dailyref->{CLICK}+$gridref[$k]->{CLICK}>$master->{CLICK}){
			$master->{CLICK}=$dailyref->{CLICK}+$gridref[$k]->{CLICK};
		}
	}
	$master->{WIDTH}=230;




	# first row
	print qq~
	<table cellpadding=3 cellspacing=1 border=0 bgcolor="333333" width="100%">
	<tr class="td2">
	<td align=center><b>Group</td>
	<td align=center><b>Impr</td>
	<td align=center><b>Clicks</td>
	<td align=center><b>CTR</td>
	<td align=center>&nbsp;</td>
	</tr>
	~;	
	
	
	my $sample_Values="0";
	my $sample_Values2="0";
	my $sample_Labels="0";

	my $impr_sum=0;
	my $click_sum=0;

	for(my $k=0;$k<$gridtot;$k++){

		my $dailyref=$master->{db}->select_single_row_hash("SELECT sum(IMPR) as IMPR, sum(CLICK) as CLICK FROM daily_log where CID='$cid' AND GID='$gridref[$k]->{GID}'");
		my $gidref=$master->{db}->select_single_row_hash("SELECT * FROM groups WHERE GID='$gridref[$k]->{GID}'");
		
		$dailyref->{IMPR}+=$gridref[$k]->{IMPR};
		$dailyref->{CLICK}+=$gridref[$k]->{CLICK};

		$impr_sum+=$dailyref->{IMPR};
		$click_sum+=$dailyref->{CLICK};
		
		my $ctp=$master->{tools}->ctp_calculation($dailyref->{IMPR},$dailyref->{CLICK});
		print qq~
		<tr class="td3">
		<td align=center>$gidref->{GROUP_NAME}</td>
		<td align=center>$dailyref->{IMPR}</td>
		<td align=center>$dailyref->{CLICK}</td>
		<td align=center>$ctp\%</td>
		<td align=left width="235">~;
		$master->{reports}->bar_table($master,$dailyref->{IMPR},$dailyref->{CLICK});				
		print qq~</td>
		</tr>
		~;	
	}

	my $ctp=$master->{tools}->ctp_calculation($impr_sum,$click_sum);
	print qq~
	<tr bgcolor="EEEEEE">
	<td align=right>Total:</td>
	<td align=center>$impr_sum</td>
	<td align=center>$click_sum</td>
	<td align=center>$ctp\%</td>
	<td align=left width="235">&nbsp;</td>
	</tr>
	</table>
	~;

}
# << GROUP TABLE GENERATOR









# >> DAY CHART GENERATOR
sub day_chart_generator{
	my($self,$master)=@_;

	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	my $hour=$master->{env}->get_hour;
	my $date=$master->{env}->get_date;

	# input vars
	my $cid=$master->{query}->param('cid');

	#get the ad media
	my(@dailyref)=$master->{db}->select_multi_row_hash("SELECT sum(IMPR) as IMPR, sum(CLICK) as CLICK,LOG_DATE FROM daily_log where CID='$cid' GROUP BY CID,LOG_DATE ORDER BY LOG_DATE DESC, LIMIT 14");
	my $dailytot=@dailyref;

	my $cidref=$master->{db}->select_single_row_hash("SELECT TODAY_IMPR as IMPR,TODAY_CLICK as CLICK  FROM cp WHERE CID='$cid'");


	$cidref->{CLICK}*=10+0;
	my $sample_Values="$cidref->{IMPR}";
	my $sample_Values2="$cidref->{CLICK}";
	my $sample_Labels="$date";
	for(my $k=0;$k<$dailytot;$k++){
		$dailyref[$k]->{CLICK}*=10+0;
		$sample_Values2="$dailyref[$k]->{CLICK},".$sample_Values2;
		$sample_Values="$dailyref[$k]->{IMPR},".$sample_Values;
		$sample_Labels="$dailyref[$k]->{LOG_DATE},".$sample_Labels;
	}

	my $height=$dailytot*40+85;

print qq~
<!-- Charting capability provided by EasyCharts (c) 2001 an Objectplanet.com Product -->
<applet code="com.objectplanet.chart.BarChartApplet" archive="$images_url/chart.jar" width=475 height=$height>
<param name=seriesCount value="2">
<param name=sampleCount value="1">
<param name=sampleValues_0 value="$sample_Values">
<param name=sampleValues_1 value="$sample_Values2">
<param name=sampleLabels value="$sample_Labels">
<param name=seriesLabels value="Impressions,Clicks (x10)">
<param name=barAlignment value="horizontal">
<param name=barWidth value="0.6">
<param name=graphInsets value="-1,-1,-1,-1">
<param name=sampleColors value="#0066FF,#FFcc00">
<param name=background value="#DDDDCC">
<param name=chartBackground value="#FFFFDD">
<param name=titleFont value="Arial, bold, 20">
<param name=barLabelsOn value=true>
<param name=autoLabelSpacingOn value=true>
<param name=valueLinesOn value=true>
<param name=multiColorOn value=true>
</applet>
~;

}
# << DAY CHART GENERATOR















sub campaigns{
	my($self,$master)=@_;

	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;

	# advertiser info
	my $aidref=$master->{db}->select_single_row_hash("SELECT * FROM ad where LOGIN='$master->{whoami}'");

	# get the campaigns
	my(@cidref)=$master->{db}->select_multi_row_hash("SELECT * FROM cp WHERE AID='$aidref->{AID}'");
	my $cidtot=@cidref;
	
	# print header
	$master->{LINK}="campaigns";
	$master->{html}->header($master,"Advertiser Campaigns");


	print qq~
	<img src="$images_url/clear.gif" width=1 height=20><br>
	<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333" width="100%">
	<tr class="td2">
	<td colspan=7><b>Campaigns for: $aidref->{ADVERTISER_NAME}</td>
	</tr>
	<tr class="td6">
	<td align=center><b>Name</td>
	<td align=center><b>Ad Type</td>
	<td align=center><b>Status</td>
	<td align=center><b>Impr</td>
	<td align=center><b>Clicks</td>
	<td align=center><b>CTP</td>
	<td align=center><b>Functions</td>
	</tr>
	~;


	my $last_class="td3";
	my $counter=0;
	my $old_link_type;
	my $coo;

	for(my $k=0;$k<$cidtot;$k++){

		# money calcs
		my $ctp=$master->{tools}->ctp_calculation($cidref[$k]->{DELIVERED_IMPR},$cidref[$k]->{DELIVERED_CLICK});
		my $earnings=$cidref[$k]->{CPM}*$cidref[$k]->{DELIVERED_IMPR}/1000+$cidref[$k]->{CPC}*$cidref[$k]->{DELIVERED_CLICK};
		my $effcpm=0;
		if($cidref[$k]->{DELIVERED_IMPR}>0){
			$effcpm=$earnings/($cidref[$k]->{DELIVERED_IMPR}/1000);
		}
		$effcpm=sprintf("%.2f",$effcpm);
		$effcpm="\$$effcpm";
		$earnings=sprintf("%.2f",$earnings);
		$earnings="\$$earnings";
		if($cidref[$k]->{CPM}+$cidref[$k]->{CPC}==0){
			$earnings="N/A";
			$effcpm="N/A";
		}

		# link type
		my $link_type="Text";
		if($cidref[$k]->{HEIGHT}>1 && $cidref[$k]->{WIDTH}>1){
			$link_type="$cidref[$k]->{WIDTH}x$cidref[$k]->{HEIGHT}";
		}

		# class control
		if($link_type ne $old_link_type){
			$old_link_type=$link_type;
			$counter++;
			if($counter > 2){$counter=1};
		}
		if($counter==1){$last_class="td3";}
		if($counter==2){$last_class="td4";}

		
		my $color="td3";
		if($coo==1){
			$color="td5";
			$coo=0;
		}else{
			$coo++;	
		}

		my $status="Off";
		if($cidref[$k]->{STATUS}==1){
			$status="Active";
		}

		print qq~
		<tr class="$color">
		<td align=center>$cidref[$k]->{CAMPAIGN_NAME}</td>
		<td align=center>$link_type</td>
		<td align=center>$status</td>
		<td align=center>$cidref[$k]->{DELIVERED_IMPR}</td>
		<td align=center>$cidref[$k]->{DELIVERED_CLICK}</td>
		<td align=center>$ctp\%</td>
		<td align=center><a href="$cgi_bin_url/adcenter.cgi?task=campaign_report&cid=$cidref[$k]->{CID}&cache=$cache">View Report</a></td>
		</tr>
		~;
	}

	print qq~
	</table>
	&nbsp;<br>
	&nbsp;<br>
	~;


	$master->{html}->footer($master);
}
# END VIEW ADVERTISERS






sub campaign_report{
	my($self,$master)=@_;

	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $date=$master->{config}->get_date;
	my $cache=$master->{env}->get_cache;
	
	# input vars
	my $cid=$master->{query}->param('cid');


	# advertiser info
	my $aidref=$master->{db}->select_single_row_hash("SELECT * FROM ad where LOGIN='$master->{whoami}'");


	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid' AND AID='$aidref->{AID}'");


	#get the ad media
	my(@midref)=$master->{db}->select_multi_row_hash("SELECT * FROM cp_media where CID='$cid'");
	my $midtot=@midref;
	
	
	# print header
	$master->{html}->header($master,"Edit: $cidref->{CAMPAIGN_NAME}");


	# start and end dates
	my @MONTH;	my @DAY;	my @MONTH2;	my @DAY2;	my %YEAR;	my %YEAR2;
	my ($smonth,$sday,$syear)=$master->{tools}->date_splice("$cidref->{START_DATE}");
	$DAY[$sday+0]=" selected";
	$MONTH[$smonth+0]=" selected";
	$YEAR{"$syear"}=" selected";
	my ($emonth,$eday,$eyear)=$master->{tools}->date_splice("$cidref->{END_DATE}");
	$DAY2[$eday+0]=" selected";
	$MONTH2[$emonth+0]=" selected";
	$YEAR2{"$eyear"}=" selected";


	# checkboxes
	my %ui; if($cidref->{MAX_IMPR}==0){$ui{1}=" checked ";};
	my %uc; if($cidref->{MAX_CLICK}==0){$uc{1}=" checked ";};
	my %udi;if($cidref->{MAX_DAILY_IMPR}==0){$udi{1}=" checked ";};
	my %udc;if($cidref->{MAX_DAILY_CLICK}==0){$udc{1}=" checked ";};

	# geometry
	my $geometry="$cidref->{WIDTH} x $cidref->{HEIGHT}";
	if($cidref->{WIDTH}==1 && $cidref->{HEIGHT}==1){
		$geometry="Text Link";
	}



	###########################
	########### CAMPAIGN ADS ##
	my $today_ctp=$master->{tools}->ctp_calculation($cidref->{TODAY_IMPR},$cidref->{TODAY_CLICK});
	my $total_ctp=$master->{tools}->ctp_calculation($cidref->{DELIVERED_IMPR},$cidref->{DELIVERED_CLICK});

	my $status=qq~<font color="red"><b>Off</b></font>~;
	if($cidref->{IMPR_BIN}+$cidref->{CLICK_BIN}>0){
		$status=qq~<font color="blue"><b>On</b></font>~;
	}

	#IMPRESSION BIN:$cidref->{IMPR_BIN}<br>
	#CLICK BIN:$cidref->{CLICK_BIN}<br>


	print qq~
	&nbsp;<br>
	<!--  Start Campaign Ads  -->
	<table cellpadding=3 cellspacing=1 border=0 width="100%" bgcolor="333333">
	<tr class="td2">
	<td colspan=2>
	<table cellpadding=0 cellspacing=0 border=0 width="100%">
	<tr>
	<td nowrap><b>Campaign Report</b></td>
	<td width=100% align="right"></td>
	</tr>
	</table>
	</td>
	</tr>

	<tr class="td3">
	<td width=50% valign="top">
	<!-- Start Section 1 -->
	<table cellpadding=2 cellspacing=0 border=0 width="100%">
	<tr>
	<td valign="top">



	<table cellpadding=5 cellspacing=1 border=0 width="100%" bgcolor="000000">
	<tr bgcolor="dddddd">
	<td align=center><strong>&nbsp;</td>
	<td align=center><strong>Impressions</td>
	<td align=center><strong>Clicks</td>
	<td align=center><strong>CTR</td>
	</tr>
	<tr bgcolor="dddddd">
	<td align=center><strong>Today</td>
	<td align=center>$cidref->{TODAY_IMPR}</td>
	<td align=center>$cidref->{TODAY_CLICK}</font></td>
	<td align=center>$today_ctp\%</font></td>
	</tr>
	<tr bgcolor="dddddd">
	<td align=center><strong>Total</td>
	<td align=center>$cidref->{DELIVERED_IMPR}</td>
	<td align=center>$cidref->{DELIVERED_CLICK}</font></td>
	<td align=center>$total_ctp\%</font></td>
	</tr>
	</table>
	<img src="$images_url/clear.gif" width=1 height=5><br>
	<table cellpadding=2 cellspacing=1 border=0 width="100%">
	~;


	#get the ad media
	my(@dailyref)=$master->{db}->select_multi_row_hash("SELECT sum(IMPR) as IMPR, sum(CLICK) as CLICK,LOG_DATE FROM daily_log where CID='$cid' GROUP BY LOG_DATE ORDER BY LOG_DATE DESC");

	my $maxi=0;
	for(my $k=0;$k<7;$k++){
		if($dailyref[$k]->{IMPR}>$maxi){
			$maxi=$dailyref[$k]->{IMPR};
		}
	}
	$maxi++;


	for(my $k=0;$k<7;$k++){
		#my $offset_date=$master->{db}->single_result("SELECT DATE_ADD('$date',INTERVAL -$k DAY)");
		#my $dailyref=$master->{db}->select_single_row_hash("SELECT * FROM daily_log where CID='$cid' AND LOG_DATE='$offset_date'");

		my $impr=$dailyref[$k]->{IMPR}+0;
		my $widthi=(158/$maxi)*$impr+2;
		my $widthi2=160-$widthi;
		my $click=$dailyref[$k]->{CLICK}+0;

		if(!$dailyref[$k]->{LOG_DATE}){
			$dailyref[$k]->{LOG_DATE}="NA";
		}

		print qq~
		<tr class="td3">
		<td align="center">$dailyref[$k]->{LOG_DATE}</td>
		<td align="left"><IMG SRC="$images_url/ltblue.gif" WIDTH=$widthi HEIGHT=12><IMG SRC="$images_url/clear.gif" WIDTH=$widthi2 HEIGHT=12></td>
		<td align="center">$impr</td>
		</tr>
		~;
	}


	print qq~
	</table>

	</td>
	</tr>
	</table>
	<!-- End Section 1 -->
	</td>
	<td width=50% valign="top">
	~;




	my $max_iremaining=$cidref->{MAX_IMPR}-$cidref->{DELIVERED_IMPR};
	my $max_cremaining=$cidref->{MAX_CLICK}-$cidref->{DELIVERED_CLICK};
	my $max_idisplay=$cidref->{MAX_IMPR};
	if($cidref->{MAX_IMPR}==0){
		$max_idisplay="Unlimited";
		$max_iremaining="Unlimited";
	}
	my $max_cdisplay=$cidref->{MAX_CLICK};
	if($cidref->{MAX_CLICK}==0){
		$max_cdisplay="Unlimited";
		$max_cremaining="Unlimited";
	}

	print qq~
	<!-- Start Section 2 -->
	<table cellpadding=2 cellspacing=0 border=0 width="100%">
	<tr>
	<td>
	<table cellpadding=2 cellspacing=1 border=0 bgcolor="000000" width="100%">
	<tr bgcolor="dddddd">
	<td align="right">
	Status:
	</td>
	<td align=left>
	$status
	</td>
	</tr>

	<tr bgcolor="dddddd">
	<td align="right">
	Campaign Name:
	</td>
	<td align=left>
	$cidref->{CAMPAIGN_NAME}
	</td>
	</tr>


	<tr bgcolor="dddddd">
	<td align="right">
	Ad Type:
	</td>
	<td align=left>
	$geometry
	</td>
	</tr>


	<tr bgcolor="dddddd">
	<td align="right">
	Start Date:
	</td>
	<td align=left>
	$cidref->{START_DATE}
	</td>
	</tr>

	<tr bgcolor="dddddd">
	<td align="right">
	End Date:
	</td>
	<td align=left>
	$cidref->{END_DATE}
	</td>
	</tr>


	<tr bgcolor="dddddd">
	<td align="right">
	Impr Target:
	</td>
	<td align=left>
	$max_idisplay
	</td>
	</tr>

	<tr bgcolor="dddddd">
	<td align="right">
	Click Target:
	</td>
	<td align=left>
	$max_cdisplay
	</td>
	</tr>


	<tr bgcolor="dddddd">
	<td align="right">
	Impr Remaining:
	</td>
	<td align=left>
	$max_iremaining
	</td>
	</tr>

	<tr bgcolor="dddddd">
	<td align="right">
	Clicks Remaining:
	</td>
	<td align=left>
	$max_cremaining
	</td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	<!-- End Section 2 -->


	<img src="$images_url/clear.gif" width=1 height=5><br>
  &nbsp;- <a href="$cgi_bin_url/adcenter.cgi?task=view_campaign_history&cid=$cid&cache=$cache">Daily History</a><br>
	<img src="$images_url/clear.gif" width=1 height=5><br>

	
	</td>
	</tr>

	
	</table>
	&nbsp;<br>
	&nbsp;<br>





	<!--  Start Campaign Ads  -->
	<table cellpadding=3 cellspacing=1 border=0 width="100%" bgcolor="333333">

	<tr class="td2">
	<td colspan=6>

	<table cellpadding=0 cellspacing=0 border=0 width="100%">
	<tr>
	<td nowrap><b>Campaign Ad Performance</b></td>
	<td width=100% align="right">&nbsp;</td>
	</tr>
	</table>

	</td>
	</tr>

	<tr bgcolor="dddddd">
	<td align="center"><b>Name</b></td>
	<td align="center"><b>Type</b></td>
	<td align="center"><b>Priority</b></td>
	<td align="center"><b>Impr</b></td>
	<td align="center"><b>Clicks</b></td>
	<td align="center"><b>CTR</b></td>
	</tr>
	~;


	for(my $k=0;$k<$midtot;$k++){
		my $ctp=$master->{tools}->ctp_calculation($midref[$k]->{TOTAL_IMPR},$midref[$k]->{TOTAL_CLICK});

		my $type="GIF";
		if($midref[$k]->{AD_TYPE}==1){
			$type="HTML";
		}

		print qq~
		<tr class="td3">
		<td align="center">$midref[$k]->{NAME}</td>
		<td align="center">$type</td>
		<td align="center">$midref[$k]->{WEIGHT}</td>
		<td align="center">$midref[$k]->{TOTAL_IMPR}</td>
		<td align="center">$midref[$k]->{TOTAL_CLICK}</td>
		<td align="center">$ctp\%</td>
		</tr>
		~;


	#	if($midref[$k]->{AD_TYPE}==0){
	#		print qq~<td align=center><a href="$cgi_bin_url/adcenter.cgi?task=edit_standard&mid=$midref[$k]->{MID}&cache=$cache">Edit</a> | <a href="$cgi_bin_url/adcenter.cgi?task=reset_media&cid=$cid&mid=$midref[$k]->{MID}&cache=$cache">Reset</a> | <a href="$cgi_bin_url/adcenter.cgi?task=delete_media&mid=$midref[$k]->{MID}&cid=$midref[$k]->{CID}&cache=$cache" onclick="return confirm('Are you sure you want to delete $midref[$k]->{NAME}?')">Delete</a></td>~;
	#	}else{
	#		print qq~<td align=center><a href="$cgi_bin_url/adcenter.cgi?task=edit_html&mid=$midref[$k]->{MID}&cache=$cache">Edit</a> | <a href="$cgi_bin_url/adcenter.cgi?task=reset_media&cid=$cid&mid=$midref[$k]->{MID}&cache=$cache">Reset</a> | <a href="$cgi_bin_url/adcenter.cgi?task=delete_media&mid=$midref[$k]->{MID}&cid=$midref[$k]->{CID}&cache=$cache" onclick="return confirm('Are you sure you want to delete $midref[$k]->{NAME}?')">Delete</a></td>~;
	#	}
	#	print qq~
	#	</tr>
	#	~;
	}
	

	
	print qq~
	<!--  End Campaign Ads  -->
	</table>
	&nbsp;<br>
	&nbsp;<br>
	~;
	########### CAMPAIGN ADS ##
	###########################











	###########################
	########### DISPLAY ADS  ##

	print qq~
	<!--  Start Campaign Ads  -->
	<table cellpadding=3 cellspacing=1 border=0 width="100%" bgcolor="333333">

	<tr class="td2">
	<td colspan=7>

	<table cellpadding=0 cellspacing=0 border=0 width="100%">
	<tr>
	<td nowrap><b>Campaign Ads</b></td>
	<td width=100% align="right">
	~;
	
#	<b>[<a href="$cgi_bin_url/adcenter.cgi?task=add_standard&cid=$cid&cache=$cache">Add a New GIF Ad</a>] &nbsp;	[<a href="$cgi_bin_url/adcenter.cgi?task=add_html&cid=$cid&cache=$cache">Add a New HTML Ad</a>]</b>
	
	print qq~
	</td>
	</tr>
	</table>

	</td>
	</tr>


	<tr class="td3">
	<td colspan=7>
	<table cellpadding=4 cellspacing=1 border=0 width="100%" bgcolor="333333">
	~;


	for(my $k=0;$k<$midtot;$k++){
		my $ctp=$master->{tools}->ctp_calculation($midref[$k]->{TOTAL_IMPR},$midref[$k]->{TOTAL_CLICK});

		my $img_url=$midref[$k]->{IMG_URL};
		my $click_url=$midref[$k]->{CLICK_URL};
		my $alt=$midref[$k]->{ALT};
		my $under_text=$midref[$k]->{UNDER_TEXT};	

		$img_url=~s/IDNUMBER+/$cache/g;
		$click_url=~s/IDNUMBER+/$cache/g;
		$alt=~s/IDNUMBER+/$cache/g;
		$under_text=~s/IDNUMBER+/$cache/g;

		if(length($under_text)>0){
			$under_text=qq~<a href="$click_url" target="$midref[$k]->{TARGET}">$under_text</a>~;
		}


		print qq~
		<tr class="td3">
		<td width="100" valign="center" align="right"><b>$midref[$k]->{NAME}</b></td>
		<td width="500">~;
		if($midref[$k]->{AD_TYPE}==0){
			print qq~
			<center>
			<a href="$click_url" target="$midref[$k]->{TARGET}"><img src="$img_url" width=$cidref->{WIDTH} height=$cidref->{HEIGHT} border=$midref[$k]->{BORDER} alt="$alt"></a><br>
			$under_text
			</center>
			~;
		}else{

			my $rich_ad=$midref[$k]->{RICH};
			$rich_ad=~s/IDNUMBER+/$cache/g;
			print qq~
			<center>
			$rich_ad
			</center>
			~;
		}

		print qq~</td></tr>~;

	}
	

	
	print qq~
	</table>
	<!--  End Campaign Ads  -->
	</td>
	</tr>
	</table>
	&nbsp;<br>
	~;
	########### DISPLAY ADS  ##
	###########################



	$master->{html}->footer($master);
}







# >> VIEW CAMPAIGN HISTORY
sub view_campaign_history{
	my($self,$master)=@_;

	$master->{charts}="yes";
	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;

	# input vars
	my $cid=$master->{query}->param('cid');

	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid'");

	#get the campaign ref
	my $aidref=$master->{db}->select_single_row_hash("SELECT * FROM ad where AID='$cidref->{AID}'");
	
	
	# print header
	$master->{LINK}="campaigns";
	$master->{html}->header($master,"View Campaign History");


	print qq~
	<img src="$images_url/clear.gif" width=12 height=12><br>
	<b>24 Hour History for: $cidref->{CAMPAIGN_NAME}</b><br>
	~;

	$master->{reports}->hour_chart_generator($master);
	print qq~
	<table cellpadding=0 cellspacing=0 border=0 width="100%">
	<tr>
	<td align=right>
	<table cellpadding=0 cellspacing=3 border=0>
	<tr>
	<td bgcolor="0066FF">
<img src="$images_url/clear.gif" width=12 height=12>
	</td>
	<td>
	Impressions
	</td>
	</tr>
	<tr>
	<td bgcolor="FFCC00">
<img src="$images_url/clear.gif" width=12 height=12>
	</td>
	<td>
	Clicks (x10)
	</td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	~;



	#print qq~
	#<b>Daily History</b><br>
	#~;
	#$master->{reports}->day_chart_generator($master);



	print qq~
	<br>&nbsp;<br>
	<b>History Table</b><br>
	~;
	$master->{reports}->day_table_generator($master);


	print qq~
	<br>
	~;



	$master->{html}->footer($master);
}
# << VIEW CAMPAIGN HISTORY








# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 
1;

