# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle

# AdLogin.pm - most of the functions for adcenter, a mess

package AdLogin;
use strict;


sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	return $self;
}


sub check_login{
	my($self,$master)=@_;

	# config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	my $remote=$master->{env}->get_remote;
	my $agent=$master->{env}->get_agent;
	my $datestamp=$master->{env}->get_datestamp;
	my $admin_user_name=$master->{config}->{_admin_user_name};
	my $admin_password=$master->{config}->{_admin_password};


	
	
	#get the campaigns
	my $configref=$master->{db}->select_single_row_hash("SELECT * FROM adconfig");	
	if(!$configref || $configref->{TIME_STAMP}==0){
		print "Content-type: text/html\n\n";
		print qq~
		<html>
		<head>
		<title>ADCYCLE CONFIGURATION PROBLEM</title>
		</head>
		<body>
		</b>Looks like you have problems with the AdCycle Installation on your system</b>
		1. Check your web server error_log for any messages. (most important)<br>
		2. Check the build.cgi output closely. Run again.<br>
		3. Check mysql permissions or reset them.<br>
		4. Check the mysql password and user name in AdConfig.pm.<br>
		...
		</body>
		</html>
		~;
	}
	
	
	# input vars
	my $account=$master->{query}->param("account");
	my $password=$master->{query}->param("pwd");
	my $mixer=int(rand(10000000));
	my $ck_id="";
	my $ck_login="";
	my $verify=0;

	$account =~ s/\=|\'|\"|\`|\}|\(//g;
	$password =~ s/\=|\'|\"|\`|\}|\(//g;
	
	if(length($account)>0){
		if($account eq $admin_user_name && $admin_password eq $password){
			$verify=1;
			$ck_id=$mixer;
			$master->{whoami}="ADMIN";
			my $login_cookie=$master->{query}->cookie(-name=>"ADCYCLE_LOGIN",
			    -value=>"$account|$mixer|",
			    -expires=>'+20d',
				  -path=>'/'
					);	
			$login_cookie=$master->{query}->unescape("$login_cookie");
			print "Set-Cookie: $login_cookie\n";
		}
		if($verify==0){
			my $aidref=$master->{db}->select_single_row_hash("SELECT * FROM ad WHERE LOGIN='$account' AND PASSWORD='$password'");	
			if($aidref){
				$verify=1;
				$ck_id=$mixer;
				$master->{whoami}="$account";
				my $login_cookie=$master->{query}->cookie(-name=>"ADCYCLE_LOGIN",
			      -value=>"$account|$mixer|",
				    -expires=>'+20d',
					  -path=>'/'
						);	
				$login_cookie=$master->{query}->unescape("$login_cookie");
				print "Set-Cookie: $login_cookie\n";
			}
		}
	}


	# if not a direct login
	my $login_cookie=$master->{query}->cookie('ADCYCLE_LOGIN');
	$login_cookie =~ s/\=|\'|\"|\`|\}|\(//g;
	if($verify==0 && length($account)==0){
		($ck_login,$ck_id)=split(/\|/,$login_cookie);
		my $lidref=$master->{db}->select_single_row_hash("SELECT * FROM login WHERE COOKIEID='$ck_id' AND AGENT='$agent' ORDER BY LOG_TIME DESC");	
		if($lidref){
			$verify=2;
			$master->{whoami}=$lidref->{ACCOUNT};
			$master->{LOGIN_CHECK_TYPE}="COOKIE";
		}
	}
	if($verify==0 && length($account)==0){
		($ck_login,$ck_id)=split(/\|/,$login_cookie);
		my $lidref=$master->{db}->select_single_row_hash("SELECT * FROM login WHERE REMOTE='$remote' AND AGENT='$agent' ORDER BY LOG_TIME DESC");	
		if($lidref){
			$verify=2;
			$master->{whoami}=$lidref->{ACCOUNT};
			$master->{LOGIN_CHECK_TYPE}="IP";
		}
	}

	if($verify==1){
		# make insert list
		my $insert_list=[
	  ["REMOTE",$remote],
	  ["ACCOUNT",$master->{whoami}],
	  ["AGENT",$agent],
	  ["COOKIEID",$ck_id]
		];
		$master->{db}->insert_row("login",$insert_list);
	}

	return
}#end sub



# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle

1;
