# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 

package AdAdvertiser;
use strict;


sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	return $self;
}


sub view_advertisers{
	my($self,$master)=@_;

	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	
	
	# print header
	$master->{LINK}="advertisers";
	$master->{html}->header($master,"Advertisers");


	#get the campaigns
	my(@aidref)=$master->{db}->select_multi_row_hash("SELECT * FROM ad order by ADVERTISER_NAME");
	my $aidtot=@aidref;



	print qq~
	<img src="$images_url/clear.gif" width=1 height=15><br>
	<img src="$images_url/advertisers.gif" width=250 height=25><br>
	<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333">
	<tr class="td2">
	<td align=center><b>Name</td>
	<td align=center><b>Campaigns</td>
	<td align=center><b>Function</td>
	</tr>
	~;



	my $coo;
	for(my $k=0;$k<$aidtot;$k++){

		my $count=$master->{db}->single_result("SELECT COUNT(*) from cp WHERE AID='$aidref[$k]->{AID}'");	
	

		my $color="td3";
		if($coo==1){
			$color="td5";
			$coo=0;
		}else{
			$coo++;	
		}

		print qq~
		<tr class="$color">	
		<td><b>&nbsp;&nbsp;$aidref[$k]->{ADVERTISER_NAME}</td>
		<td align=center>$count</td>
		<td align=center><a href="$cgi_bin_url/adcenter.cgi?task=edit_advertiser&aid=$aidref[$k]->{AID}&cache=$cache">edit</a> | <a href="$cgi_bin_url/adcenter.cgi?account=$aidref[$k]->{LOGIN}&pwd=$aidref[$k]->{PASSWORD}&cache=$cache">login</a> | <a href="$cgi_bin_url/adcenter.cgi?task=delete_advertiser&aid=$aidref[$k]->{AID}&cache=$cache" onclick="return confirm('Are you sure you want to delete $aidref[$k]->{ADVERTISER_NAME} and all campaigns for this advertiser?')">delete</a></td>
		</tr>
		~;
	}



	print qq~
	</table>
	&nbsp;<br>
	&nbsp;<br>
	&nbsp;<br>
	<table cellpadding=2 cellspacing=1 border=0 bgcolor="999999">
	<tr>
	<td bgcolor="ddddcc">
	<b><a href="$cgi_bin_url/adcenter.cgi?task=add_advertiser_form&cache=$cache">Add a New Advertiser</a>
	</td>
	</tr>
	</table>
	~;



	$master->{html}->footer($master);
}
# END VIEW ADVERTISERS











sub add_advertiser_form{
	my($self,$master)=@_;

	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	
	
	# print header
	$master->{LINK}="advertisers";
	$master->{html}->header($master,"Advertisers");



	# add advertiser form
	print qq~
	&nbsp;<br>
	<form action="$cgi_bin_url/adcenter.cgi" method="post">
	<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333">
	<tr class="td2">
	<td colspan=2><b>Add a New Advertiser</b></td>
	</tr>
	<tr class="td3">
	<td align="right"><b>Advertiser Name:</td>
	<td><input type="text" name="advertiser_name" value="" size=$master->{medium} class="ft1"></td>
	</tr>
	<tr class="td3">
	<td align="right"><b>Advertiser User Name:</td>
	<td><input type="text" name="login" value="" size=$master->{short} class="ft1"></td>
	</tr>
	<tr class="td3">
	<td align="right"><b>Password:</td>
	<td><input type="text" name="password" value="" size=$master->{short} class="ft1"></td>
	</tr>

	<tr class="td3">
	<td colspan=2><input type="submit" name="change" value="ADD" class="ft2"></td>
	</tr>	

	</table>
	<input type="hidden" name="task" value="add_advertiser">
	<input type="hidden" name="cache" value="$cache">
	</form>
	&nbsp;<br>
	&nbsp;<br>
	~;

	$master->{html}->footer($master);
}







sub add_advertiser{
  my($self,$master)=@_;

	# input params
	my $advertiser_name=$master->{query}->param('advertiser_name');
	my $password=$master->{query}->param('password');
	my $login=$master->{query}->param('login');
	my $cache=$master->{env}->get_cache;

	if(length($advertiser_name)==0){
		$master->{error}.=qq~Please enter an advertiser name|~;
	}
	if(length($login)==0){
		$login=$cache;
	}
	my $nameref=$master->{db}->select_single_row_hash("SELECT * FROM ad where LOGIN='$login'");
	if($nameref){
		$master->{error}.=qq~User name is already in use. Please use another.|~;
	}
	
	if(length($master->{error})==0){	
		# get aid
		my $aid=$master->{tools}->get_id($master,"AID");

		# make insert list
		my $insert_list=[
		 ["AID",$aid],
		 ["ADVERTISER_NAME",$advertiser_name],
		 ["LOGIN",$login],
		 ["PASSWORD",$password]
		];

		# insert row
		$master->{db}->insert_row("ad",$insert_list);

		$master->{message}="Advertiser Created";
		$master->{advertiser}->view_advertisers($master);
	
	}else{

		# >> error output
		$master->{LINK}="advertisers";
		$master->{tools}->error_handler($master);
		# << error output

	}

}



# >> edit advertiser
sub edit_advertiser{
	my($self,$master)=@_;

	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	
	# input vars
	my $aid=$master->{query}->param('aid');

	
	# print header
	$master->{LINK}="advertisers";
	$master->{html}->header($master,"Advertisers");


	#get the campaigns
	my $aidref=$master->{db}->select_single_row_hash("SELECT * FROM ad where AID='$aid'");

	print qq~
	&nbsp;<br>
	<form action="$cgi_bin_url/adcenter.cgi" method="post">
	<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333">

	<tr class="td2">
	<td colspan=2><b>Advertiser Info</b></td>
	</tr>


	<tr class="td3">
	<td align="right">&nbsp;<b>Advertiser Name:</td>
	<td><input type="text" name="advertiser_name" value="$aidref->{ADVERTISER_NAME}" size=$master->{medium} class="ft1"></td>
	</tr>

	<tr class="td3">
	<td align="right">&nbsp;&nbsp;<b>Login User Name:</td>
	<td><input type="text" name="login" value="$aidref->{LOGIN}" size=$master->{short} class="ft1"></td>
	</tr>

	<tr class="td3">
	<td align="right"><b>Login Password:</td>
	<td><input type="text" name="password" value="$aidref->{PASSWORD}" size=$master->{short} class="ft1"></td>
	</tr>

	</table>
	<img src="$images_url/clear.gif" width=1 height=5><br>


	<input type="hidden" name="aid" value="$aid">
	<input type="hidden" name="task" value="update_advertiser">
	<input type="submit" name="change" value="UPDATE" class="ft2">
	<input type="hidden" name="cache" value="$cache">
	</form>
	&nbsp;<br>
	~;


	$master->{html}->footer($master);
}
# << edit advertiser




sub update_advertiser{
  my($self,$master)=@_;

	# input params
	my $advertiser_name=$master->{query}->param('advertiser_name');
	my $login=$master->{query}->param('login');
	my $password=$master->{query}->param('password');
	my $aid=$master->{query}->param('aid');

	# generate query list
	my $c;
	$c=$master->{db}->update_cv($c,"ADVERTISER_NAME",$advertiser_name);
	$c=$master->{db}->update_cv($c,"LOGIN",$login);
	$c=$master->{db}->update_cv($c,"PASSWORD",$password);
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE ad SET $c WHERE AID='$aid'");

	$master->{message}="Advertiser Profile Updated";
	$master->{advertiser}->edit_advertiser($master);
}






sub delete_advertiser{
  my($self,$master)=@_;

	# input params
	my $aid=$master->{query}->param('aid');

	# delete advertiser
	$master->{db}->{adcycle}->do("DELETE FROM ad WHERE AID='$aid'");

	# delete campaigns
	$master->{db}->{adcycle}->do("DELETE FROM cp WHERE AID='$aid'");

	# delete media
	$master->{db}->{adcycle}->do("DELETE FROM cp_media WHERE AID='$aid'");

	# delete grouping
	$master->{db}->{adcycle}->do("DELETE FROM cp_grouping WHERE AID='$aid'");

	$master->{message}="Advertiser Deleted";
	$master->{advertiser}->view_advertisers($master);

}



# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 
1;

