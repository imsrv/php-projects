package AdMaster;

# load modules
use strict;
use AdConfig;
use AdCampaign;
use AdCron;
use AdEnv;
use AdReports;
use AdHtml;
use AdTables;
use AdLogin;
use AdAdvertiser;
use AdGroups;
use AdManager;
use AdDb;
use AdTools;
use AdTarget;
use CGI;


# initialize master object
sub new {
	my $this=shift;
	my $exclude=shift;
	my $class= ref($this) || $this;
	my $self= {};
	$self->{config}=AdConfig->new();
	$self->{login}=AdLogin->new();
	$self->{cron}=AdCron->new();
	$self->{campaign}=AdCampaign->new();
	$self->{reports}=AdReports->new();
	$self->{env}=AdEnv->new();
	$self->{html}=AdHtml->new();
	$self->{tables}=AdTables->new();
	$self->{advertiser}=AdAdvertiser->new();
	$self->{manager}=AdManager->new();
	$self->{groups}=AdGroups->new();
	if($exclude ne "query"){
		$self->{query}=CGI->new;
	}
	$self->{db}=AdDb->new;
	$self->{tools}=AdTools->new;
	$self->{target}=AdTarget->new;
	bless $self, $class;
	return $self;
}
1;







