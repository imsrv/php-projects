# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle

# AdHtml.pm - some HTML subs


package AdHtml;
use strict;


sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	return $self;
}


sub header{
	my($self,$master,$title)=@_;
  my $images_url=$master->{config}->get_images_url;
  my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
  my $dhmtl_menu=$master->{config}->get_dhtml_menu;
  my $cid=$master->{query}->param('cid');
  my $task=$master->{query}->param('task');
  my $cache=$master->{env}->get_cache;
  my $agent=$master->{env}->get_agent;
  my $whoami=$master->{env}->get_whoami;
	$master->{header}="yes";


	if($master->{clear_cookie}>0){
		my $impression_cookie = $master->{query}->cookie(-name=>"i$master->{clear_cookie}", #impression list
		                     -value=>"",
			                   -expires=>'+24h',
				                 -path=>'/',
						             );
		$impression_cookie = $master->{query}->unescape("$impression_cookie");
		print "Set-Cookie: $impression_cookie\n";
		my $click_cookie = $master->{query}->cookie(-name=>"c$master->{clear_cookie}", #impression list
		                     -value=>"",
			                   -expires=>'+7d',
				                 -path=>'/',
						             );
		$click_cookie = $master->{query}->unescape("$click_cookie");
		print "Set-Cookie: $click_cookie\n";	
	}




	print "Content-type: text/html\n\n";
	print qq~
	<html>
	<head>
	<title>$title</title>
	<style type="text/css">
	<!--
	body{font-family: Arial,Helvetica, sans-serif;font-size: 12px;color: \#000000;}
	p{font-family: Arial,Helvetica, sans-serif;font-size: 12px;color: \#000000;}
	a:visited{color: \#3300CC;}
	a:active{color: \#3300CC;}
	a:link{color: \#3300CC;}
	td{font-family: Arial, Helvetica;font-size: 12px;color: \#000000;}
	~;

	$master->{shortest}=2;
	$master->{short}=5;
	$master->{medium}=15;
	$master->{long}=25;
	$master->{longest}=30;
	$master->{longest2}=30;
	if(index($agent,"MSIE")!=-1){
		print qq~
		.ft1{font-family: Verdana, Arial, Helvetica; font-size: 12px; font-weight: normal; color: \#000000; background-color: #EEFFFF; border: 1px solid #333300; vertical-align: middle}
		.ft2{font-family: Verdana, Arial, Helvetica; font-size: 10px; font-weight: bold; color: \#000033; background-color: #dddddd; border: 1px solid #000000; vertical-align: middle}
		.ft3{font-family: Verdana, Arial, Helvetica; font-size: 12px; font-weight: normal; color: \#000000; #EEEEEE; vertical-align: middle}
		.font1{font-family: Arial, Helvetica; font-size: 15px; font-weight: bold; color: \#000000;}
		.font2{font-family: Arial, Helvetica; font-size: 10px; font-weight: bold; color: \#000000;}
		.td1{font-family: Verdana, Arial, Helvetica; font-size: 12px;  color: #000000; background-color: #003366;}
		.td2{font-family: Verdana, Arial, Helvetica; font-size: 12px;  color: #000000; background-color: #33CCFF;}
		.td3{font-family: Verdana, Arial, Helvetica; font-size: 12px;  color: #000000; background-color: #FFFFCC;}
		.td4{font-family: Verdana, Arial, Helvetica; font-size: 12px;  color: #000000; background-color: #CCFF99;}
		.td5{font-family: Verdana, Arial, Helvetica; font-size: 12px;  color: #000000; background-color: #FFFFAA;}
		.td6{font-family: Verdana, Arial, Helvetica; font-size: 12px;  color: #000000; background-color: #DDDDCC;}
		~;
		$master->{shortest}=2;
		$master->{short}=8;
		$master->{medium}=25;
		$master->{long}=42;
		$master->{longest}=58;
		$master->{longest2}=87;
	}else{
		print qq~
		.td1{font-family: Verdana, Arial, Helvetica; font-size: 12px;  color: #FF0000; background-color: #003366;}
		.td2{font-family: Verdana, Arial, Helvetica; font-size: 12px;  color: #FF0000; background-color: #88BBEE;}
		.td3{font-family: Verdana, Arial, Helvetica; font-size: 12px;  color: #FF0000; background-color: #FFFFCC;}
		.td4{font-family: Verdana, Arial, Helvetica; font-size: 12px;  color: #FF0000; background-color: #CCFF99;}
		.td5{font-family: Verdana, Arial, Helvetica; font-size: 12px;  color: #FF0000; background-color: #FFFFAA;}
		.td6{font-family: Verdana, Arial, Helvetica; font-size: 12px;  color: #FF0000; background-color: #DDDDCC;}
		~;
	}


	my $onresize=qq~~;
	#my $onresize=qq~onResize="location.reload(true)"~; # un-comment to reload on geometry resize <<<<<<<<<<<----


	print qq~
	//-->
	</style>
	</head>
	<body $onresize bgcolor="ffffff" link="0000ff" vlink="0000ff" leftmargin=20 rightmargin=20 topmargin=10 bottommargin=0 marginheight=10 marginwidth=15>

~;


if($master->{hide_toolbar} ne "yes"){
if($master->{whoami} eq "ADMIN" && $dhmtl_menu ne "no"){
print qq~
<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
<!--
HM_DOM = (document.getElementById) ? true : false;
HM_NS4 = (document.layers) ? true : false;
HM_IE = (document.all) ? true : false;
HM_IE4 = HM_IE && !HM_DOM;
HM_Mac = (navigator.appVersion.indexOf("Mac") != -1);
HM_IE4M = HM_IE4 && HM_Mac;
HM_IsMenu = (HM_DOM || HM_NS4 || (HM_IE4 && !HM_IE4M));
HM_BrowserString = HM_NS4 ? "NS4" : HM_DOM ? "DOM" : "IE4";

if(window.event + "" == "undefined") event = null;
function HM_f_PopUp(){return false};
function HM_f_PopDown(){return false};
popUp = HM_f_PopUp;
popDown = HM_f_PopDown;

var width=700;
IE4 = (document.all);
NS4 = (document.layers);
if(IE4 || NS4){
width=(IE4) ? document.body.clientWidth : window.innerWidth;
height=(IE4) ? document.body.clientHeight : window.innerHeight;
}
width=(width-64)/5;
var button_width = parseInt(width);

HM_PG_MenuWidth = button_width;
HM_PG_FontFamily = "Arial,sans-serif";
HM_PG_FontSize = 10;
HM_PG_FontBold = 0;
HM_PG_FontItalic = 0;
HM_PG_FontColor = "blue";
HM_PG_FontColorOver = "white";
HM_PG_BGColor = "#DDDDDD";
HM_PG_BGColorOver = "#FFCCCC";
HM_PG_ItemPadding = 2;

HM_PG_BorderWidth = 1;
HM_PG_BorderColor = "black";
HM_PG_BorderStyle = "solid";
HM_PG_SeparatorSize = 1;
HM_PG_SeparatorColor = "#000000";
HM_PG_ImageSrc = "$images_url/tri.gif";
HM_PG_ImageSrcLeft = "$images_url/triL.gif";

HM_PG_ImageSize = 5;
HM_PG_ImageHorizSpace = 0;
HM_PG_ImageVertSpace = 2;

HM_PG_KeepHilite = true; 
HM_PG_ClickStart = 0;
HM_PG_ClickKill = false;
HM_PG_ChildOverlap = 20;
HM_PG_ChildOffset = 4;
HM_PG_ChildPerCentOver = null;
HM_PG_TopSecondsVisible = 0.5;
HM_PG_StatusDisplayBuild =0;
HM_PG_StatusDisplayLink = 0;
HM_PG_UponDisplay = null;
HM_PG_UponHide = null;
HM_PG_RightToLeft = false;
//HM_PG_CreateTopOnly = 1;
HM_PG_ShowLinkCursor = 1;
//HM_a_TreesToBuild = [1,2];


HM_Array2 = [
[button_width,		// menu width
35,		// left_position
70,			// top_position
"#FFFFCC",      // font_color
"#003399",   // mouseover_font_color
"#003399",   // background_color
"#FFFFCC",    // mouseover_background_color
"black",     // border_color
"black",    // separator_color
1,			// top_is_permanent
1,          // top_is_horizontal
0,          // tree_is_horizontal
1,          // position_under
0,          // top_more_images_visible
1,          // tree_more_images_visible
"null",     // evaluate_upon_tree_show
"null",     // evaluate_upon_tree_hide
],          //right-to-left
["\&nbsp\;Advertisers","$cgi_bin_url/adcenter.cgi?task=view_advertisers&cache=$cache",1,0,0],
["\&nbsp\;Campaigns","$cgi_bin_url/adcenter.cgi?task=view_campaigns&cache=$cache",1,0,1],
["\&nbsp\;Groups","$cgi_bin_url/adcenter.cgi?task=view_groups&cache=$cache",1,0,1],
["\&nbsp\;Manager","$cgi_bin_url/adcenter.cgi?task=view_manager&cache=$cache",1,0,0],
["\&nbsp\;Logout","$cgi_bin_url/adcenter.cgi?task=logout&cache=$cache",1,0,0]
]
~;




my(@tidref)=$master->{db}->select_multi_row_hash("SELECT * FROM adtype order by TID");
my $tidtot=@tidref;


# >> tids
print qq~
HM_Array2_2 = [
[],
~;
for(my $k=0;$k<$tidtot;$k++){
print qq~["\&nbsp\;$tidref[$k]->{NAME}","$cgi_bin_url/adcenter.cgi?task=view_campaigns&tid=$tidref[$k]->{TID}&cache=$cache",1,0,1]\n~;
if($k!= $tidtot-1){print ",";}
}
print qq~]~;
# << tids


# >> campaigns
for(my $k=0;$k<$tidtot;$k++){

my (@cidref)=$master->{db}->select_multi_row_hash("SELECT CID,CAMPAIGN_NAME FROM cp WHERE TID=$tidref[$k]->{TID} ORDER BY CAMPAIGN_NAME");
my $cidtot=@cidref;

if($cidtot>0){

my $ar=$k+1;
print qq~
HM_Array2_2_$ar = [
[],
~;
for(my $j=0;$j<$cidtot;$j++){
	$cidref[$j]->{CAMPAIGN_NAME}=substr($cidref[$j]->{CAMPAIGN_NAME},0,20);
	if(length($cidref[$j]->{CAMPAIGN_NAME})==20){
		$cidref[$j]->{CAMPAIGN_NAME}.="..";
	}
	print qq~["\&nbsp\;$cidref[$j]->{CAMPAIGN_NAME}","$cgi_bin_url/adcenter.cgi?task=edit_campaign&cid=$cidref[$j]->{CID}&cache=$cache",1,0,0]\n~;
	if($j!= $cidtot-1){print ",";}
}

print qq~]~;

}

}
# << campaigns







# >> tids
print qq~
HM_Array2_3 = [
[],
~;
for(my $k=0;$k<$tidtot;$k++){
print qq~["\&nbsp\;$tidref[$k]->{NAME}","$cgi_bin_url/adcenter.cgi?task=view_groups&tid=$tidref[$k]->{TID}&cache=$cache",1,0,1]\n~;
if($k!= $tidtot-1){print ",";}
}
print qq~]~;
# << tids


# >> campaigns
for(my $k=0;$k<$tidtot;$k++){

my (@gidref)=$master->{db}->select_multi_row_hash("SELECT GID,GROUP_NAME FROM groups WHERE TID=$tidref[$k]->{TID} ORDER BY GROUP_NAME");
my $gidtot=@gidref;

if($gidtot>0){

my $ar=$k+1;
print qq~
HM_Array2_3_$ar = [
[],
~;
for(my $j=0;$j<$gidtot;$j++){
	$gidref[$j]->{GROUP_NAME}=substr($gidref[$j]->{GROUP_NAME},0,20);
	if(length($gidref[$j]->{GROUP_NAME})==20){
		$gidref[$j]->{GROUP_NAME}.="..";
	}
	print qq~["\&nbsp\;$gidref[$j]->{GROUP_NAME}","$cgi_bin_url/adcenter.cgi?task=edit_group&gid=$gidref[$j]->{GID}&cache=$cache",1,0,0]\n~;
	if($j!= $gidtot-1){print ",";}
}

print qq~]~;

}

}
# << campaigns





print qq~
if(HM_IsMenu) {
document.write("<SCR" + "IPT LANGUAGE='JavaScript1.2' SRC='$images_url/HM_Script"+ HM_BrowserString +".js' TYPE='text/javascript'><\/SCR" + "IPT>");
}
//-->
</SCRIPT>
~;

}}




print qq~
	<table cellpadding=0 cellspacing=0 width="100%" border=0 bgcolor="ffffff">
	<tr>
	<td><img src="$images_url/new_account_header.gif" width="152" height="45" border=0></td>
	<td width="100%">

	<table cellpadding=0 cellspacing=0 width="100%" border=0 bgcolor="ffffff">
	<tr><td bgcolor="ffffff" width="100%"><img src="$images_url/clear.gif" width=1 height=38></td></tr>
	<tr><td bgcolor="ffcc00" width="100%"><img src="$images_url/clear.gif" width=1 height=6></td></tr>
	<tr><td bgcolor="000000" width="100%"><img src="$images_url/clear.gif" width=1 height=1></td></tr>
	</tr>
	</table>


	
	</td>
	</tr>
	</table>
	<table cellpadding=4 cellspacing=0 width="100%" border=0 bgcolor="009966">
	<tr>
	<td align="center">
	~;


	print qq~<img src="$images_url/clear.gif" width=1 height=20><br>~;# stick ad in here if you want one





	print qq~
	</td>
	</tr>
	</table>
	<table cellpadding=0 cellspacing=0 width="100%" border=0>
	<tr>
	<td bgcolor="009966" width="20"><img src="$images_url/clear.gif" width=20 height=55></td>
	<td>
	
	
	<table cellpadding=0 cellspacing=0 width="100%" border=0 bgcolor="003399">
	<tr>
	<td nowrap align="right">~;
	

	if($master->{hide_toolbar} ne "yes"){
		if($master->{whoami} eq "ADMIN" && $dhmtl_menu eq "no"){
				$master->{html}->output_toolbar($master);
		}else{
			if($master->{whoami} ne "ADMIN"){
				$master->{html}->output_report_toolbar($master);
			}
		}
	}
	

	print qq~</td>
	</tr>
	</table>
	<table cellpadding=15 cellspacing=0 width="100%" border=0>
	<tr>
	<td bgcolor="ffffff">
	~;
	$master->{html}->message($master);
}



sub footer{
	my($self,$master)=@_;
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;


	my $easycharts;
	if($master->{charts} eq "yes"){
		$easycharts=qq~ and <a href="http://www.objectplanet.com">Easycharts</a> v2.5~;
	}


	print qq~
	</td>
	</tr>
	</table>
	<table cellpadding=0 cellspacing=0 width="100%" border=0 bgcolor="003399">
	<tr>
	<td>
	<img src="$images_url/clear.gif" width=5 height=5><br>
	</td>
	</tr>
	</table>
	</td>
	<td bgcolor="009966" width="20"><img src="$images_url/clear.gif" width=20 height=1><br></td>
	</tr>
	</table>
	<table cellpadding=0 cellspacing=0 width="100%" border=0 bgcolor="009966">
	<tr>
	<td><img src="$images_url/left_footer.gif" width=10 height=20></td>
	<td width="100%">&nbsp;</td>
	<td><img src="$images_url/right_footer.gif" width=10 height=20></td>
	</tr>
	</table>
	<table cellpadding=0 cellspacing=0 width="100%" border=0>
	<tr>
	<td align="right">
	powered by <a href="http://www.adcycle.com">adcycle</a> v1.17 $easycharts<img src="$images_url/clear.gif" width=20 height=1><br>
	</td>
	</tr>
	</table>
	</body>
	</html>
	~;
}



sub question{
	my($self,$question)=@_;
	my $question=qq~[ <b><a title="Get Help" href=\"\#hello\" OnClick=\"window1=window.open('http://www.adcycle.com/help.go?question=$question', 'window1', 'width=525,height=500,scrollbars=yes'); window1.focus();\"><FONT COLOR=\"003366\">?</FONT></a></b> ]~;
	return $question;
}



sub message{
	my($self,$master)=@_;
	my $datestamp=$master->{env}->get_datestamp;
	if(length($master->{message})>2){
		print qq~<font color="FF0000"><b>$master->{message} at $datestamp</b></font><br>~;
	}
	if(length($master->{test})>2){
		print qq~<font color="CC00CC"><b>TEST: $master->{test} at $datestamp</b></font><br>~;
	}
}



sub login{
	my($self,$master)=@_;
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;


	# if not a direct login
	my $login_cookie=$master->{query}->cookie('ADCYCLE_LOGIN');
	my ($ck_login,$ck_id)=split(/\|/,$login_cookie);
	$master->{hide_toolbar}="yes";

	# print header
	$master->{LINK}="campaigns";
	$master->{html}->header($master,"AdCenter Login");

	print qq~
	&nbsp;<BR>
	<form name="form1" action="$cgi_bin_url/adcenter.cgi" method="post">
	<table cellpadding=10 cellspacing=0 border=0>
	<tr>
	<td>
	<table cellpadding=3 cellspacing=0 border=0 bgcolor="000000">
	<tr>
	<td align=left width=95%>
	<font face="verdana,arial" size=2 color="white"><strong>&nbsp;Account Login</strong></font>
	</td>
	</tr>
	<tr>
	<td bgcolor="ffffff">
	<font face="verdana,arial" size=2>
	<img src="$images_url/clear.gif" width=1 height=1><br>
	&nbsp;&nbsp;&nbsp;User Name: <font face="verdana,arial" size=3><input type="text" name="account" value="$ck_login" size=$master->{short} class="ft1"></font>&nbsp;<br>
	<img src="$images_url/clear.gif" width=1 height=5><br>
	<font face="verdana,arial" size=2>
	&nbsp;&nbsp;&nbsp;Password: <font face="verdana,arial" size=3><input type="password" name="pwd" value="" size=$master->{short} class="ft1"></font>&nbsp;<br>
	<font size=2 face="verdana,arial"><b>
	&nbsp;<br>
	<input type="submit" name="change" value="LOGIN" class="ft2">
	</td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	<input type="hidden" name="cache" value="$cache">
	</form>
	&nbsp;<br>
	~;

	$master->{html}->footer($master);
}






sub output_toolbar{
	my($self,$master)=@_;
  my $images_url=$master->{config}->get_images_url;
  my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
  my $cache=$master->{env}->get_cache;

	# start javascript
	print qq~
	<script language="javascript">
	<!--
	tmp = new Image(100,24);
	~;

	my @link_display;
	if($master->{LINK} eq "campaigns"){@link_display=(0,1,0,0,0,0);}
	if($master->{LINK} eq "advertisers"){@link_display=(0,0,1,0,0,0);}
	if($master->{LINK} eq "groups"){@link_display=(0,0,0,1,0,0);}
	if($master->{LINK} eq "manager"){@link_display=(0,0,0,0,1,0);}

	my @link;
	$link[1]=qq~$cgi_bin_url/adcenter.cgi?task=view_campaigns&cache=$cache~;
	$link[2]=qq~$cgi_bin_url/adcenter.cgi?task=view_advertisers&cache=$cache~;
	$link[3]=qq~$cgi_bin_url/adcenter.cgi?task=view_groups&cache=$cache~;
	$link[4]=qq~$cgi_bin_url/adcenter.cgi?task=view_manager&cache=$cache~;
	$link[5]=qq~$cgi_bin_url/adcenter.cgi?task=logout&cache=$cache~;

	my @alt;
	$alt[1]=qq~Campaign Manager~;
	$alt[2]=qq~Advertiser Manager~;
	$alt[3]=qq~Group Manager~;
	$alt[4]=qq~AdCycle Manager~;
	$alt[5]=qq~Logout~;


	# javascript contents
	for(my $k=1;$k<6;$k++){
		if($link_display[$k]==0){
			print qq~b$k=new Image(122,22);\n~;
			print qq~b$k.src="$images_url/tb_b_$k.gif";\n~;
		}
	}

	# end java script
	print qq~
	function Bon(img){
	if(img){
	tmp.src = eval("document.images." + img.name + ".src");
	img.src = eval(img.name + ".src");
	}
	}
	function Boff(img){
	if(img){
	img.src = tmp.src;
	}
	}
	// -->
	</script>
	~;

	#print qq~<img src="$images_url/tb_f_clear.gif" width=122 height=20>~;

	# javascript contents
	for(my $k=1;$k<6;$k++){
		if($link_display[$k]==0){
			print qq~<a href="$link[$k]" onMouseOver="Bon(b$k)" onMouseOut="Boff(b$k)" target="_top"><img src="$images_url/tb_f_$k.gif" width=122 height=20 border=0 name="b$k" ALT="$alt[$k]"></a>~;	
		}else{
			print qq~<a href="$link[$k]" target="_top"><img src="$images_url/tb_b_$k.gif" width=122 height=20 border=0 name="b$k" ALT="RELOAD $alt[$k]"></a>~;	
		}
	}

}










sub output_report_toolbar{
	my($self,$master)=@_;
  my $images_url=$master->{config}->get_images_url;
  my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
  my $cache=$master->{env}->get_cache;

	# start javascript
	print qq~
	<script language="javascript">
	<!--
	tmp = new Image(100,24);
	~;

	my @link_display;
	if($master->{LINK} eq "campaigns"){@link_display=(0,1,0);}


	my @link;
	$link[1]=qq~$cgi_bin_url/adcenter.cgi?task=campaigns&cache=$cache~;
	$link[2]=qq~$cgi_bin_url/adcenter.cgi?task=logout&cache=$cache~;

	my @alt;
	$alt[1]=qq~Campaign Manager~;
	$alt[2]=qq~Logout~;


	# javascript contents
	for(my $k=1;$k<3;$k++){

		my $lb=1;
		if($k==2){
			$lb=5;
		}

		if($link_display[$k]==0){
			print qq~b$k=new Image(122,22);\n~;
			print qq~b$k.src="$images_url/tb_b_$lb\.gif";\n~;
		}
	}

	# end java script
	print qq~
	function Bon(img){
	if(img){
	tmp.src = eval("document.images." + img.name + ".src");
	img.src = eval(img.name + ".src");
	}
	}
	function Boff(img){
	if(img){
	img.src = tmp.src;
	}
	}
	// -->
	</script>
	~;

	#print qq~<img src="$images_url/tb_f_clear.gif" width=122 height=20>~;

	# javascript contents
	for(my $k=1;$k<3;$k++){
		my $lb=1;
		if($k==2){
			$lb=5;
		}
		if($link_display[$k]==0){
			print qq~<a href="$link[$k]" onMouseOver="Bon(b$k)" onMouseOut="Boff(b$k)" target="_top"><img src="$images_url/tb_f_$lb\.gif" width=122 height=20 border=0 name="b$k" ALT="$alt[$k]"></a>~;	
		}else{
			print qq~<a href="$link[$k]" target="_top"><img src="$images_url/tb_b_$lb\.gif" width=122 height=20 border=0 name="b$k" ALT="RELOAD $alt[$k]"></a>~;	
		}
	}

}




sub front_panel{
	my($self,@space)=@_;
	my $master=$space[0];
	my $enum=$space[1];
	my $diff=$space[2];
	my $ems=$space[3];
	if($ems==1){
		my $num=30-$diff;
		$master->{image}=qq~Woops! Something is wrong.... ~;
		$master->{query}->param(-name=>'task',-values=>"view_manager");
	}
	if($ems==2){
		my $num=30-$diff;
		$master->{image}=qq~30 Days have Expired, <a href="http://www.adcycle.com/register.html" target="_blank">Please register AdCycle.</a>~;
    $master->{query}->param(-name=>'task',-values=>'view_manager');
	}
	if($diff<=30 && $ems==3){
		my $num=30-$diff;
		$master->{image}=qq~<b><font color="red">Evaluation Day $diff of 30.</font></b> <a href="http://www.adcycle.com/register.html" target="_blank">Please register AdCycle.</a>~;
	}
	if($enum!=15 && $ems==4){
		$master->{image}=qq~Please enter your registration key again.~;
    $master->{query}->param(-name=>'task',-values=>'view_manager');
	}
	return $master
}


# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle

1;
