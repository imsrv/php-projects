package AdTools;
use strict;


sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	return $self;
}



sub ctp_calculation{
	my ($self,$impr,$clicks) = @_;
	my $ctp=0;
	if($impr != 0 && $clicks!=0){
		$ctp=($clicks/$impr)*100;
	}
	$ctp=sprintf("%.2f",$ctp);
	return $self,$ctp;
}



sub money_chop{
	my ($self,$money) = @_;
	$money=sprintf("%.2f",$money);
	return $self,$money;
}


sub date_splice{
	my ($self,$date)=@_;
	my $month=substr($date,5,2);
	my $year=substr($date,0,4);
	my $day=substr($date,8,2);
	return $month,$day,$year
}


sub date_convert{
	my ($self,$date) = @_;
	my $month=substr($date,5,2);
	my $day=substr($date,8,2);
	my $year=substr($date,2,2);
	$date="$month/$day/$year";
	return $self,$date;
}


sub get_id{
	my ($self,$master,$id_type) = @_;
	my $idref=$master->{db}->select_single_row_hash("SELECT * FROM ids");
	$master->{db}->{adcycle}->do("UPDATE ids SET $id_type=$id_type+1");
	return $self,$idref->{$id_type};
}



sub error_handler{
	my ($self,$master) = @_;
	$master->{html}->header($master,"ERROR");
	print qq~
	&nbsp;<br>
	<b><font size=3>The following errors occurred:</font></b><br>
	&nbsp;<br>
	~;
	
	my @error=split(/\|/,$master->{error});
	my $errortot=@error;

	for(my $k=0;$k<$errortot;$k++){
		my $num=$k+1;
		print qq~<font color="red"><b>$num: $error[$k]</font><br>\n~;
	}


	print qq~&nbsp;<br>&nbsp;<br>Use the "Back" button on your browser to fix the entry.<br>&nbsp;<br>&nbsp;<br>~;

	
	
	$master->{html}->footer($master);
	return
}
sub keyck{
	my ($self,$master) = @_;
	my $date=$master->{env}->get_date;
	my $idref=$master->{db}->select_single_row_hash("SELECT * FROM ids");
	my $configref=$master->{db}->select_single_row_hash("SELECT * FROM adconfig");
	my $coo=$configref->{USER_ENABLED};	my $sum_cron;my $error=0;my $delta=0;
	my $uid=$master->{query}->param('uid'); if(length($uid)>0){$coo=$uid;}
	if(length($coo)==0){
		my $today=$master->{db}->single_result("SELECT TO_DAYS('$date')");
	  my $then=$master->{db}->single_result("SELECT TO_DAYS('$idref->{LOG_DATE}')");
		if($today-$then>31){
			$error=2;
		}
		if($today-$then<=31){
			$error=3;
			$delta=$today-$then;
		}
		if($idref->{LOG_DATE} ne $configref->{LOG_DATE}){
			$error=1;
		}
	}else{
		$error=4;
		$delta=substr($coo,0,1);
		$sum_cron+=substr($coo,4,1);
		$sum_cron+=substr($coo,7,1);
		$sum_cron+=substr($coo,11,1);
	}
	$master->{html}->front_panel($master,$sum_cron,$delta,$error);
}


# if you know a more elegant way of doing this, drop me an email :)
sub comma_insert{
	my ($self,$number) = @_;
	my $length=length($number);

	if($length==4){
		my $str1=substr($number,0,1);
		my $str2=substr($number,1,3);
		$number=$str1.",".$str2;
	}
	if($length==5){
		my $str1=substr($number,0,2);
		my $str2=substr($number,2,3);
		$number=$str1.",".$str2;
	}
	if($length==6){
		my $str1=substr($number,0,3);
		my $str2=substr($number,3,3);
		$number=$str1.",".$str2;
	}
	if($length==7){
		my $str1=substr($number,0,1);
		my $str2=substr($number,1,3);
		my $str3=substr($number,4,3);
		$number=$str1.",".$str2.",".$str3;
	}
	if($length==8){
		my $str1=substr($number,0,2);
		my $str2=substr($number,2,3);
		my $str3=substr($number,5,3);
		$number=$str1.",".$str2.",".$str3;
	}
	if($length==9){
		my $str1=substr($number,0,3);
		my $str2=substr($number,3,3);
		my $str3=substr($number,6,3);
		$number=$str1.",".$str2.",".$str3;
	}
	return $self,$number;
}



sub month_chop{
	my ($self,$month) = @_;
	my $ax_month="";
  if($month eq "January"){$ax_month="Jan.";}
  if($month eq "Febuary"){$ax_month="Feb.";}
  if($month eq "March"){$ax_month="Mar.";}
  if($month eq "April"){$ax_month="Apr.";}
  if($month eq "May"){$ax_month="May";}
  if($month eq "June"){$ax_month="June";}
  if($month eq "July"){$ax_month="July.";}
  if($month eq "August"){$ax_month="Aug.";}
  if($month eq "September"){$ax_month="Sept.";}
  if($month eq "October"){$ax_month="Oct.";}
  if($month eq "November"){$ax_month="Nov.";}
  if($month eq "December"){$ax_month="Dec.";}
	return $self,$ax_month;
}



1;