# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 

package AdCron;
use strict;


sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	return $self;
}



sub hourly_update{
	my($self,$master)=@_;
	my $timestamp=$master->{env}->get_timestamp;
	my $hour=$master->{env}->get_hour;
	my $date=$master->{env}->get_date;
	my $datestamp=$master->{env}->get_datestamp;
	if(length($master->{datestamp})>0){
		$datestamp=$master->{datestamp};
	}
	if(length($master->{hour})>0){
		$hour=$master->{hour};
	}
	if(length($master->{timestamp})>0){
		$timestamp=$master->{timestamp};
	}
	if(length($master->{date})>0){
		$date=$master->{date};
	}


	# date manip
	my $offset_stamp=$master->{db}->single_result("SELECT DATE_ADD('$datestamp',INTERVAL -1 HOUR)");
	my $offset_stamp2=$master->{db}->single_result("SELECT DATE_ADD('$datestamp',INTERVAL -8 HOUR)");
	my $adj_log_date=substr($offset_stamp,0,10);
	my $adj_log_hour=substr($offset_stamp,11,2);



	# >> gridref
	$master->{db}->{adcycle}->do("LOCK TABLES cp WRITE,adconfig WRITE,cp_media WRITE,cp_grouping WRITE,daily_log WRITE");
		my $configref=$master->{db}->select_single_row_hash("SELECT * FROM adconfig");
		my $epoch_seconds=$master->{db}->single_result("SELECT UNIX_TIMESTAMP('$timestamp')");
		my $hour_stamp=int($epoch_seconds/3600);
		my $hour_update="no";
		if($hour_stamp != $configref->{THIS_HOUR}){
			$hour_update="yes";
			my(@gridref)=$master->{db}->select_multi_row_hash("SELECT * FROM cp_grouping WHERE HOUR_IMPR>0 OR HOUR_CLICK>0");
			my $gridtot=@gridref;
			for(my $k=0;$k<$gridtot;$k++){
				my $insert_list=[["CID",$gridref[$k]->{CID}],["GID",$gridref[$k]->{GID}],["MID",$gridref[$k]->{MID}],["IMPR",$gridref[$k]->{HOUR_IMPR}],["CLICK",$gridref[$k]->{HOUR_CLICK}],["LOG_HOUR",$adj_log_hour],["LOG_DATE",$adj_log_date]];
				$master->{db}->insert_row("daily_log",$insert_list);
			}
			$master->{db}->{adcycle}->do("UPDATE cp_grouping SET HOUR_IMPR=0,HOUR_CLICK=0");
		}
		$master->{db}->{adcycle}->do("UPDATE adconfig SET THIS_HOUR=$hour_stamp");

		# >> hour 0
		if($hour==0){
			$master->{db}->{adcycle}->do("UPDATE cp SET TODAY_IMPR=0,TODAY_CLICK=0");
		}
		# << hour 0

	$master->{db}->{adcycle}->do("UNLOCK TABLES");
	# << gridref

	$master->{db}->{adcycle}->do("DELETE FROM live_log");
	$master->{db}->{adcycle}->do("DELETE FROM error_log");
	$master->{db}->{adcycle}->do("DELETE FROM login WHERE LOG_TIME < '$offset_stamp2'");

	if($hour_update eq "yes"){
		my(@cidref)=$master->{db}->select_multi_row_hash("SELECT * FROM cp");
		my $cidtot=@cidref;
		for(my $k=0;$k<$cidtot;$k++){
			$master->{cron}->campaign_bin_update($master,$cidref[$k]->{CID});
		}
	}

}







sub campaign_bin_update{
	my($self,$master,$cid)=@_;

	# env vars
	my $hour=$master->{env}->get_hour;
	my $date=$master->{env}->get_date;
	my $datestamp=$master->{env}->get_datestamp;
	if(length($master->{datestamp})>0){
		$datestamp=$master->{datestamp};
	}
	if(length($master->{hour})>0){
		$hour=$master->{hour};
	}
	if(length($master->{date})>0){
		$date=$master->{date};
	}


	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid'");

	# date to days	
  my $start_days=$master->{db}->single_result("SELECT TO_DAYS('$cidref->{START_DATE}')");
  my $end_days=$master->{db}->single_result("SELECT TO_DAYS('$cidref->{END_DATE}')");
  my $date_days=$master->{db}->single_result("SELECT TO_DAYS('$date')");

	my $status=0;
	my $impr_bin=0;
	my $click_bin=0;
	my $campaign_display="yes";
	
	# media check
  my $media_count=$master->{db}->single_result("SELECT COUNT(*) FROM cp_media WHERE CID='$cid' AND WEIGHT>0 AND ((AD_TYPE=0 AND LENGTH(CLICK_URL)>7) OR (AD_TYPE=1 AND LENGTH(RICH)>0))");
	

	# >> date checks
	my $day_of_week=$master->{db}->single_result("SELECT DAYOFWEEK('$datestamp')");
	# day priority
	my @day_priority=split(/\|/,$cidref->{DAY_PRIORITY});
	my $day_count=0;
	for(my $x=0;$x<7;$x++){
		my $offset=$x+1;
		if($day_of_week==$offset && $day_priority[$x]==0){
			$campaign_display="no";
		}
		if($day_priority[$x]==1){
			$day_count++;
		}
	}
	my $day_fraction=$day_count/7;

	# hour priority
	my @hour_priority=split(/\|/,$cidref->{HOUR_PRIORITY});
	my $hour_count=0;
	my $cid_next_hour=substr($datestamp,11,2)+0;
	for(my $x=0;$x<24;$x++){
		if($cid_next_hour+0==$x && $hour_priority[$x]==0){
			$campaign_display="no";
		}
		if($hour_priority[$x]==1){
			$hour_count++;
		}
	}
	my $hour_fraction=$hour_count/24;
	# << date checks		



	# >> bin set
	if($date_days >= $start_days && $date_days <= $end_days && $media_count>0  && $campaign_display eq "yes"){
		my $max_dimpr=$cidref->{MAX_DAILY_IMPR};
		my $max_dclick=$cidref->{MAX_DAILY_CLICK};
		my $max_impr=$cidref->{MAX_IMPR};
		my $max_click=$cidref->{MAX_CLICK};
		if($max_dimpr==0){$max_dimpr=9999999999;}
		if($max_dclick==0){$max_dclick=9999999999;}
		if($max_impr==0){$max_impr=9999999999;}
		if($max_click==0){$max_click=9999999999;}
		my $today_impr=$cidref->{TODAY_IMPR};
		my $today_click=$cidref->{TODAY_CLICK};
		my $delivered_impr=$cidref->{DELIVERED_IMPR};
		my $delivered_click=$cidref->{DELIVERED_CLICK};
		my $hour_multiple=24*$hour_fraction;
		my $impr_left=$max_impr-$delivered_impr;
		my $click_left=$max_click-$delivered_click;

		if($cidref->{RATE_CONTROL}==1){
			my $delta_impr=($hour*($max_dimpr/$hour_count))-$today_impr;
			my $delta_click=($hour*($max_dclick/$hour_count))-$today_click;
			$impr_bin=$delta_impr+($max_dimpr/$hour_count);
			$click_bin=$delta_click+($max_dclick/$hour_count);
		}else{
			my $start_hours=$start_days*24;
			my $end_hours=($end_days*24)+24;
			my $current_hour=($date_days*24)+$hour;
			my $total_hours=$end_hours-$start_hours;
			my $exp_hours=$current_hour-$start_hours;
			my $hours_left=$total_hours-$exp_hours;
			my $complete_fraction=$exp_hours/$total_hours;
			$impr_bin=($complete_fraction*$hour_fraction*$day_fraction*$max_impr)-$delivered_impr;
			$click_bin=($complete_fraction*$hour_fraction*$day_fraction*$max_click)-$delivered_click;
		}

		if($impr_bin>$impr_left){
			$impr_bin=$impr_left;
		}
		if($click_bin>$click_left){
			$click_bin=$click_left;
		}
	
	}else{
		$impr_bin=0;
		$click_bin=0;
	}
	# << bin set


	if($impr_bin==0 && $click_bin==0){
		$status=0;
	}else{
		$status=1;
	}


	# generate query list
	my $c;
	$c=$master->{db}->update_cv($c,"IMPR_BIN",$impr_bin);
	$c=$master->{db}->update_cv($c,"CLICK_BIN",$click_bin);
	$c=$master->{db}->update_cv($c,"STATUS",$status);
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE cp SET $c WHERE CID='$cid'");

}


# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 

1;

