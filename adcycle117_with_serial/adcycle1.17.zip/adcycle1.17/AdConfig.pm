# http://www.AdCycle.com - AdCycle Version 1.17  Sept 17, 2001
# Copyright (c) 2001 AdCycle.com All rights reserved.


# -- SHAREWARE LICENSE AGREEMENT >>
# This is not free software. You are hereby licensed to use this software for 
# evaluation purposes without charge for a period of 30 days. If you use this 
# software after the 30-day evaluation period you must register.
#
# 1. All copyrights to AdCycle are exclusively owned by the author.
#
# 2. Anyone may use this software during a test period of 30 days. Following 
#    this test period of 30 days or less, if you wish to continue to use 
#    AdCycle, you must register at http://www.adcycle.com/register.html.
#
# 3. Payment of the single copy license fee authorizes one named person 
#    or company to use *one* installation of this Software on one computer 
#    provided this copyright is not violated and provided the rules 
#    outlined herein are observed.
#
# 4. The AdCycle shareware version, may be freely distributed, 
#    provided the distribution package is not modified. No person or company 
#    may charge a fee for the distribution of AdCycle without written 
#    permission from AdCycle.
#
# 5. You may not use, copy, emulate, clone, rent, lease, sell, modify, 
#    disassemble, otherwise reverse engineer, or transfer the licensed 
#    program, or any subset of the licensed program, except as provided for 
#    in this agreement. You can modify the look and feel of AdCycle and make
#    code changes for your own use only, provided that all copyright notices and 
#    links remain intact and each modified installation is regitered. Any 
#    unauthorized use shall result in immediate and automatic termination of 
#    this license and may result in criminal and/or civil prosecution. All rights
#    not expressly granted here are reserved by author.
#
# 6. Charting capability has been provided by ObjectPlanet.com. You may only use 
#    the EasyCharts applet for AdCycle reporting. 
#
# 7. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
#    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
#    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
#    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE
#    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
#    CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
#    SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
#    INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
#    CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
#    ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
#    OF THE POSSIBILITY OF SUCH DAMAGE.
#
# 8. Installing and using AdCycle signifies acceptance of these terms and 
#    conditions of the license. 
#
# 9. If you do not agree with the terms of this license you must remove AdCycle 
#    files from your storage devices and cease to use the product
#
# -- SHAREWARE LICENSE AGREEMENT <<


################################################################
####          AdCycle Configuration (AdConfig.pm)           ####
################################################################

package AdConfig;
use strict;
use vars '$AUTOLOAD';


sub AUTOLOAD{
	my ($self) = @_;
	$AUTOLOAD =~ /.*::get(_\w+)/;
	exists $self->{$1};
	return $self->{$1}	# return attribute
}



sub initialize {
	my $self = shift;

#############################################
# *** OPTIONS 1-7  REQUIRE MODIFICATION *** #
#############################################

 #-- 1. ADCYCLE ADMIN USER NAME
 $self->{_admin_user_name}  ="admin";    #<<<<-- admin user name

 #-- 2. ADCYCLE ADMIN PASSWORD
 $self->{_admin_password}="";    #<<<<-- admin password 

 #-- 3. URL OF ADCYCLE CGI-BIN DIRETORY
 $self->{_cgi_bin_url}="http://www.your_site.com/cgi-bin/adcycle";   #<<<<-- leave out trailing "/"
						
 #-- 4. URL OF ADCYCLE IMAGES DIRECTORY
 $self->{_images_url}="http://www.your_site.com/adimages";     #<<<<-- leave out trailing "/"


###############################
# ----   MySQL Settings   --- #

 #-- 5. MySQL USER NAME (permissions must be set in MySQL for this name)
 $self->{_db_user}->{adcycle}="mysql_user_name";    #<<<<-- MySQL database user

 #-- 6. MySQL PASSWORD (permissions must be set in MySQL for this password)
 $self->{_db_password}->{adcycle}="mysql_password";    #<<<<-- MySQL database user password

 #-- 7. MySQL DATABASE NAME
 $self->{_db_database}->{adcycle}="adcycle"; #<<<<-- MySQL database name (usually leave as-is)

 #-- 8. MySQL IP/Domain Name(necessary in some cases)
 $self->{_db_ip}->{adcycle}="";    #<<<<--optional ip/domain (usually leave as-is)

 #-- 9. Apache DBI Enabled
 $self->{_apache_dbi}->{adcycle}="no";    #<<<<--(yes or no) (usually leave as-is)

 #-- 10. DHTML Navigation Menu
 $self->{_dhtml_menu}="yes";    #<<<<--(yes or no) (usually leave as-is)

# ---- End MySQL Settings --- #
###############################

}
#  - Consult with your ISP for MySQL options
#  - Don't forget to create a mySQL database consistent with item 5,6 & 7
#  - Don't forget set mySQL permissions consistent with 5,6 (may not be required)
#  - No other mods should be required for this file
###################################################################
####                  End Installation Notes                   ####
###################################################################

sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
  $self->initialize();
	return $self;
}

1;
