# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle

package AdEnv;

use strict;
use vars '$AUTOLOAD';

sub AUTOLOAD{
	my ($self) = @_;
	$AUTOLOAD =~ /.*::get(_\w+)/;
	exists $self->{$1};
	return $self->{$1}	# return attribute
}


sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
  $self->initialize();
	return $self;
}


sub initialize {
	my $self = shift;
	my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time());
	$mon++;
	$year=$year+1900;
	my $smon=$mon;
	my $sday=$mday;
	my $shour=$hour;
	my $smin=$min;
	my $ssec=$sec;
	if($mon < 10){$smon="0$mon";}
	if($mday < 10){$sday="0$mday";}
	if($hour < 10){$shour="0$hour";}
	if($min < 10){$smin="0$min";}
	if($sec < 10){$ssec="0$sec";}

	my $date="$year-$smon-$sday";
	my $datestamp="$year-$smon-$sday $shour:$smin:$ssec";
	my $timestamp="$year$smon$sday$shour$smin$ssec";
	my $date_eq=($year*10000)+($mon*100)+$mday;
	my $remote=$ENV{'REMOTE_ADDR'};
	$remote =~ s/\s|\=|\'|\"|\}|\`|\)//g;
	my $remote_host=$ENV{'REMOTE_HOST'};
	$remote_host =~ s/\=|\'|\"|\`|\}|\(//g;
	my $agent=$ENV{'HTTP_USER_AGENT'};
	$agent =~ s/\=|\'|\"|\`|\}|\(//g;
	my $refer=$ENV{'HTTP_REFERER'};
	$refer =~ s/\'//g;

	$self->{'_remote'}= $remote || "111.111.111.111";
	$self->{'_remote_host'}= $remote_host || "111.111.111.111";
	$self->{'_agent'}= $agent || "No Browser";
	$self->{'_cookie'}= $ENV{'HTTP_COOKIE'} || "No Cookie";
	$self->{'_refer'}= $refer || "No Referer";
	$self->{'_query'}= $ENV{'QUERY_STRING'} || "No Query";
	$self->{'_timestamp'}= $timestamp;
	$self->{'_datestamp'}= $datestamp;
	$self->{'_day'}=$mday;
	$self->{'_month'}=$mon;
	$self->{'_year'}=$year;
	$self->{'_date'}= $date;
	$self->{'_date_eq'}= $date_eq;
	$self->{'_hour'}= $hour;
	$self->{'_min'}= $min;
	srand();
	my $cache=int(rand(1000));
	$self->{'_cache'}=$cache;
}



1;

# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle