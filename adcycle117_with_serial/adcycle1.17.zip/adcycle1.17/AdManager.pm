# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 

package AdManager;
use strict;


sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	return $self;
}


sub view_manager{
	my($self,$master)=@_;

	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	

	#get the campaigns
	my $configref=$master->{db}->select_single_row_hash("SELECT * FROM adconfig");	

	# print header
	$master->{LINK}="manager";
	$master->{html}->header($master,"Adcycle Manager");

	if($master->{query}->param('uid')==0){
		print $master->{image}."<br>";
	}


	# checkboxes
	my %cron; if($configref->{CRON_ENABLED}==1){$cron{1}=" checked ";};
	my %earn; if($configref->{DISPLAY_EARNINGS}==1){$earn{1}=" checked ";};
	my %delay; if($configref->{DELAYED_INSERT}==1){$delay{1}=" checked ";};
	my %ad;if($configref->{DISPLAY_ADVERTISER}==1){$ad{1}=" checked ";};
	my %auto;if($configref->{AUTO_ACTIVATE}==1){$auto{1}=" checked ";};


	# add campaign form
	print qq~
	<form action="$cgi_bin_url/adcenter.cgi" method="post">
	<img src="$images_url/manager.gif" width=250 height=25><br>
	<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333">

	<tr class="td3">
	<td align="right"><b>License Key:</td>
	<td><b>$configref->{USER_ENABLED}</b> &nbsp;<a href="http://www.adcycle.com/cgi-bin/reg_update.cgi?bin=$cgi_bin_url/adcenter.cgi">Enter/Update Key</a></td>
	</tr>

	<tr class="td3">
	<td align="right"><b>Cron Enabled:</td>
	<td><input type="checkbox" $cron{1} name="cron" value="1" class="ft3"> Cron activated for background tasks</td>
	</tr>

	<tr class="td3">
	<td align="right"><b>Earnings Display:</td>
	<td><input type="checkbox" $earn{1} name="earn" value="1" class="ft3"> Display earnings on the campaigns page</td>
	</tr>

	<tr class="td3">
	<td align="right"><b>Delayed Insert:</td>
	<td><input type="checkbox" $delay{1} name="delay" value="1" class="ft3"> Use MySQL delayed insert</td>
	</tr>

	<tr class="td3">
	<td align="right"><b>Advertiser Display:</td>
	<td><input type="checkbox" $ad{1} name="ad" value="1" class="ft3"> Display advertisers on the campaigns page</td>
	</tr>

	<tr class="td3">
	<td align="right"><b>Auto-Activate:</td>
	<td><input type="checkbox" $auto{1} name="auto" value="1" class="ft3"> Auto-activate campaigns within a group</td>
	</tr>

	<tr class="td3">
	<td align="right"><b>Ad Folder Path:</td>
	<td><input type="text" name="ad_path" value="$configref->{AD_DIR}" size="$master->{long}" class="ft3"> (optional)</td>
	</tr>

	<tr class="td3">
	<td align="right"><b>Ad Folder URL:</td>
	<td><input type="text" name="ad_url" value="$configref->{AD_URL}" size="$master->{long}" class="ft3"> (optional)</td>
	</tr>


	</table>
	<img src="$images_url/clear.gif" width=1 height=5><br>
	<input type="hidden" name="task" value="update_adcycle_variables">
	<input type="submit" name="change" value="UPDATE" class="ft2">&nbsp;&nbsp;~;print $master->{html}->question("manager");print qq~
	<input type="hidden" name="cache" value="$cache">
	</form>
	&nbsp;<br>
	~;


	# add adtype form
	print qq~
	<form action="$cgi_bin_url/adcenter.cgi" method="post">
	<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333">

	<tr class="td2">
	<td colspan=2><b>Create a New Ad Type</b></td>
	</tr>

	<tr class="td3">
	<td align="right"><b>Description:</td>
	<td><input type="text" name="name" value="" size="$master->{medium}" class="ft3"></td>
	</tr>
		
	<tr class="td3">
	<td align="right"><b>Geometry:</td>
	<td><input type="text" name="width" value="" size="$master->{shortest}" class="ft3"> <b>x</b> <input type="text" $cron{1} name="height" value="" size="$master->{shortest}" class="ft3"> pixels</td>
	</tr>

	</table>
	<img src="$images_url/clear.gif" width=1 height=5><br>
	<input type="hidden" name="task" value="add_adtype">
	<input type="submit" name="change" value="ADD" class="ft2">
	<input type="hidden" name="cache" value="$cache">
	</form>
	~;

	#get the campaigns
	my(@tidref)=$master->{db}->select_multi_row_hash("SELECT * FROM adtype order by TID");
	my $tidtot=@tidref;


	# add group form
	print qq~
	<form action="$cgi_bin_url/adcenter.cgi" method="get">
	<select name="tid" class="ft1">
	~;
	for(my $k=0;$k<$tidtot;$k++){
		print qq~<option value="$tidref[$k]->{TID}">$tidref[$k]->{NAME}</a>~;
	}		
	print qq~
	</select>
	<input type="submit" name="change" value="EDIT" class="ft2">
	<input type="hidden" name="task" value="edit_adtype">
	<input type="hidden" name="cache" value="$cache">
	</form>
	&nbsp;<br>
	&nbsp;<br>
	~;

	$master->{html}->footer($master);
}




# >> add adtype
sub add_adtype{
  my($self,$master)=@_;

	# input params
	my $name=$master->{query}->param('name')."";
	my $width=$master->{query}->param('width')+0;
	my $height=$master->{query}->param('height')+0;



	my $tempref=$master->{db}->select_single_row_hash("SELECT * FROM adtype WHERE WIDTH=$width AND HEIGHT=$height");

	if(!$tempref){
	my $tid=$master->{tools}->get_id($master,"TID");
	# make insert list
	my $insert_list=[
   ["TID",$tid],
   ["NAME",$name],
   ["WIDTH",$width],
   ["HEIGHT",$height]
	];
	# insert row
	$master->{db}->insert_row("adtype",$insert_list);
	}

	$master->{message}="AdType has been added";
	$master->{manager}->view_manager($master);
}
# << add adtype


# >> adcycle variables
sub update_adcycle_variables{
  my($self,$master)=@_;

	# input params
	my $cron=$master->{query}->param('cron')+0;
	my $earn=$master->{query}->param('earn')+0;
	my $delay=$master->{query}->param('delay')+0;
	my $ad=$master->{query}->param('ad')+0;
	my $auto=$master->{query}->param('auto')+0;
	my $clear=$master->{query}->param('clear')+0;
	my $ad_path=$master->{query}->param('ad_path')."";
	my $ad_url=$master->{query}->param('ad_url')."";

	$master->{db}->{adcycle}->do("ALTER TABLE adconfig MODIFY AD_DIR VARCHAR(200) NOT NULL DEFAULT ''");

	# generate query list
	my $c;
	$c=$master->{db}->update_cv($c,"CRON_ENABLED",$cron);
	$c=$master->{db}->update_cv($c,"DELAYED_INSERT",$delay);
	$c=$master->{db}->update_cv($c,"DISPLAY_ADVERTISER",$ad);
	$c=$master->{db}->update_cv($c,"DISPLAY_EARNINGS",$earn);
	$c=$master->{db}->update_cv($c,"AUTO_ACTIVATE",$auto);
	$c=$master->{db}->update_cv($c,"AD_DIR",$ad_path);
	$c=$master->{db}->update_cv($c,"AD_URL",$ad_url);
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE adconfig SET $c");

	$master->{message}="AdCycle Manager has been updated ";
	$master->{manager}->view_manager($master);
}
# << adcycle variables






# >> edit adtype
sub edit_adtype{
	my($self,$master)=@_;

	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	
	# input vars
	my $aid=$master->{query}->param('aid');
	my $tid=$master->{query}->param('tid');

	
	# print header
	$master->{LINK}="manager";
	$master->{html}->header($master,"Manager");


	#get the campaigns
	my $tidref=$master->{db}->select_single_row_hash("SELECT * FROM adtype where TID='$tid'");

	# >> geomtery
	my $geometry=qq~$tidref->{WIDTH} x $tidref->{HEIGHT} pixels~;
	if($tidref->{WIDTH}==1 && $tidref->{HEIGHT}==1){
		$geometry="Text Links";
	}
	if($tidref->{WIDTH}==2 && $tidref->{HEIGHT}==2){
		$geometry="Pop Windows";
	}
	# << geometry


	print qq~
	&nbsp;<br>
	<form action="$cgi_bin_url/adcenter.cgi" method="post">
	<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333">

	<tr class="td2">
	<td colspan=2><b>Ad Type Information</b></td>
	</tr>


	<tr class="td3">
	<td align="right">&nbsp;<b>Description:</td>
	<td><input type="text" name="name" value="$tidref->{NAME}" size=$master->{medium} class="ft1"></td>
	</tr>

	<tr class="td3">
	<td align="right">&nbsp;<b>Geometry:</td>
	<td>$geometry</td>
	</tr>

	</table>
	<img src="$images_url/clear.gif" width=1 height=5><br>


	<input type="hidden" name="tid" value="$tid">
	<input type="hidden" name="task" value="update_adtype">
	<input type="submit" name="change" value="UPDATE" class="ft2">
	<input type="hidden" name="cache" value="$cache">
	</form>
	&nbsp;<br>

	<a href="$cgi_bin_url/adcenter.cgi?task=delete_adtype&tid=$tid&cache=$cache">Delete this ad type</a>
	~;

	$master->{html}->footer($master);
}
# >> edit adtype





# >> delete ad types
sub delete_adtype{
  my($self,$master)=@_;

	# input params
	my $tid=$master->{query}->param('tid');

	

	# insert row
	my $cp_qty=$master->{db}->single_result("SELECT COUNT(*) from cp WHERE TID='$tid'");

	if($cp_qty==0){
		$master->{db}->{adcycle}->do("DELETE FROM adtype WHERE TID='$tid'");
		$master->{message}="AdType has been DELETED";
	}else{
		$master->{message}="NOT DELETED. You must first delete all campaigns that are using this ad type proir to deleting!";
	}

	$master->{manager}->view_manager($master);
}
# << update ad types




# >> update ad types
sub update_adtype{
  my($self,$master)=@_;

	# input params
	my $tid=$master->{query}->param('tid');
	my $name=$master->{query}->param('name');

	# generate query list
	my $c;
	$c=$master->{db}->update_cv($c,"NAME",$name);
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE adtype SET $c WHERE TID='$tid'");

	$master->{message}="AdType has been updated";
	$master->{manager}->edit_adtype($master);
}
# << update ad types







# >> update manager
sub update_manager{
  my($self,$master)=@_;

	# input params
	my $uid=$master->{query}->param('uid');

	# generate query list
	my $c;
	$c=$master->{db}->update_cv($c,"USER_ENABLED",$uid);
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE adconfig SET $c");

	$master->{message}="AdCycle Manager has been updated";
	$master->{manager}->view_manager($master);
}
# << update manager



sub logout{
  my($self,$master)=@_;

	# config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	my $remote=$master->{env}->get_remote;

	# get cookie info
	my $login_cookie=$master->{query}->cookie('ADCYCLE_LOGIN');
	my ($ck_login,$ck_id)=split(/\|/,$login_cookie);

	# delete grouping
	$master->{db}->{adcycle}->do("DELETE FROM login WHERE ACCOUNT='$ck_login' OR REMOTE='$remote'");
	$master->{hide_toolbar}="yes";

	$master->{html}->login($master);
}


# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 

1;

