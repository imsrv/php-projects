# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 

package AdCampaign;
use strict;


sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	return $self;
}





# >> VIEW CAMPAIGNS
sub view_campaigns{
	my($self,$master)=@_;

	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	my $gid=$master->{query}->param('gid');
	my $tid=$master->{query}->param('tid');
	
	
	# print header
	$master->{LINK}="campaigns";
	$master->{html}->header($master,"Welcome to AdCenter");


	#get the adconfig
	my $configref=$master->{db}->select_single_row_hash("SELECT * FROM adconfig");

	#get the groups
	my(@gidref)=$master->{db}->select_multi_row_hash("SELECT * FROM groups order by GID");
	my $gidtot=@gidref;


	#get the campaigns
	my @gridref;
	my $gridtot;
	my @cidref;
	my $cidtot;
	if($gid ne "all" && length($gid)!=0){
		(@gridref)=$master->{db}->select_multi_row_hash("SELECT SUM(TOTAL_IMPR) as IMPR, SUM(TOTAL_CLICK) as CLICK,CID FROM cp_grouping where GID='$gid' GROUP BY CID ORDER BY CID");
		$gridtot=@gridref;
	}else{
		if($tid==0){
			(@cidref)=$master->{db}->select_multi_row_hash("SELECT * FROM cp ORDER BY WIDTH DESC,HEIGHT DESC,CAMPAIGN_NAME");
			$cidtot=@cidref;
		}else{
			(@cidref)=$master->{db}->select_multi_row_hash("SELECT * FROM cp WHERE TID=$tid ORDER BY WIDTH DESC,HEIGHT DESC,CAMPAIGN_NAME");
			$cidtot=@cidref;
		}
	}



	print qq~
	<form action="$cgi_bin_url/adcenter.cgi" method="get">
	<table cellpadding=0 cellspacing=0 border=0 width="100%">
	<tr>
	<td valign="top">$master->{image}</td>
	<td align="right">
	<select name="gid" class="ft1" onChange="this.form.submit()">
	<option value="all">All Groups
	~;


	for(my $k=0;$k<$gidtot;$k++){
		my $link_type="Text";
		if($gidref[$k]->{HEIGHT}>1 && $gidref[$k]->{WIDTH}>1){
			$link_type="$gidref[$k]->{WIDTH}x$gidref[$k]->{HEIGHT}";
		}
		my $checked="";
		if($gid==$gidref[$k]->{GID}){
			$checked=" SELECTED ";
		}
		$gidref[$k]->{GROUP_NAME}=substr($gidref[$k]->{GROUP_NAME},0,15);
		if(length($gidref[$k]->{GROUP_NAME})==15){
			$gidref[$k]->{GROUP_NAME}.="...";
		}


		print qq~<option$checked value="$gidref[$k]->{GID}">$gidref[$k]->{GROUP_NAME}\[$link_type]~;
	}

	print qq~
	</select>
	</form></td>
	</tr>
	</table>
	~;






	if($gid ne "all" && length($gid)!=0){
		# >>-- start group table
		print qq~
		<img src="$images_url/campaigns.gif" width=250 height=25><br>
		<table cellpadding=3 cellspacing=1 border=0 bgcolor="333333" width="100%">
		<tr class="td2">
		~;
		if($configref->{DISPLAY_ADVERTISER}==1){
		print qq~
		<td align="center"><b>Advertiser</td>
		~;
		}
		print qq~
		<td align="center"><b>Campaign Name</td>
		<td align="center"><b>Ad Type</td>
		<td align="center"><b>Status</td>
		<td align="center"><b>Impr</td>
		<td align="center"><b>Clicks</td>
		<td align="center"><b>CTR</td>
		~;

		if($configref->{DISPLAY_EARNINGS}==1){
		print qq~
		<td align="center"><b>Eff. CPM</td>
		<td align="center"><b>Earnings</td>
		~;
		}

		print qq~
		<td align="center"><b>Functions  ~;print $master->{html}->question("campaign_table");print qq~</td>
		</tr>
		~;

		my $last_class="td3";
		my $counter=0;
		my $old_link_type;
		my $coo;
		my $sum_click=0;
		my $sum_impr=0;
		my $sum_earnings=0;


		for(my $k=0;$k<$gridtot;$k++){
			my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$gridref[$k]->{CID}'");

			# >> money calcs
			my $ctp=$master->{tools}->ctp_calculation($gridref[$k]->{IMPR},$gridref[$k]->{CLICK});
			my $earnings=$cidref->{CPM}*$gridref[$k]->{IMPR}/1000+$cidref->{CPC}*$gridref[$k]->{CLICK};
			my $effcpm=0;
			if($gridref[$k]->{IMPR}>0){
				$effcpm=$earnings/($gridref[$k]->{IMPR}/1000);
			}
			$effcpm=sprintf("%.2f",$effcpm);
			$effcpm="\$$effcpm";
			$earnings=sprintf("%.2f",$earnings);

			# sum
			$sum_earnings+=$earnings;
			$sum_impr+=$gridref[$k]->{IMPR};
			$sum_click+=$gridref[$k]->{CLICK};

			$earnings="\$$earnings";
			if($cidref->{CPM}+$cidref->{CPC}==0){
				$earnings="N/A";
				$effcpm="N/A";
			}
			# <<

			# >> link type
			my $link_type="Text";
			if($cidref->{HEIGHT}>2 && $cidref->{WIDTH}>2){
				$link_type="$cidref->{WIDTH}x$cidref->{HEIGHT}";
			}
			if($cidref->{HEIGHT}==2 && $cidref->{WIDTH}==2){
				$link_type="Pop";
			}
			# << link type

			# >> class control
			if($link_type ne $old_link_type){
				$old_link_type=$link_type;
				$counter++;
				if($counter > 2){$counter=1};
			}
			if($counter==1){$last_class="td3";}
			if($counter==2){$last_class="td4";}
			my $color="td3";
			if($coo==1){
				$color="td5";
				$coo=0;
			}else{
				$coo++;	
			}
			# << class control

			my $status=qq~Off~;
			if($cidref->{IMPR_BIN}+$cidref->{CLICK_BIN}>0){
				$status=qq~On~;
			}

			print qq~
			<tr class="$color">
			~;
			my $aidref=$master->{db}->select_single_row_hash("SELECT * FROM ad WHERE AID='$cidref->{AID}'");
			if($configref->{DISPLAY_ADVERTISER}==1){
			print qq~
			<td><b>&nbsp;&nbsp;$aidref->{ADVERTISER_NAME}</td>
			~;
			}

			$gridref[$k]->{IMPR}=$master->{tools}->comma_insert($gridref[$k]->{IMPR});
			$gridref[$k]->{CLICK}=$master->{tools}->comma_insert($gridref[$k]->{CLICK});

			print qq~
			<td align="left"><b>&nbsp;&nbsp;$cidref->{CAMPAIGN_NAME}</td>
			<td align="center">$link_type</td>
			<td align="center">$status</td>
			<td align="right">$gridref[$k]->{IMPR}&nbsp;</td>
			<td align="right">$gridref[$k]->{CLICK}&nbsp;</td>
			<td align="center">$ctp\%</td>
			~;

			if($configref->{DISPLAY_EARNINGS}==1){
			print qq~
			<td align="center">$effcpm</td>
			<td align="center">$earnings</td>
			~;
			}
			print qq~
			
			<td align="center"><a title="Edit $cidref->{CAMPAIGN_NAME}" href="$cgi_bin_url/adcenter.cgi?task=edit_campaign&cid=$cidref->{CID}&cache=$cache">Edit</a> | <a href="$cgi_bin_url/adcenter.cgi?task=delete_campaign&cid=$cidref->{CID}&cache=$cache" onclick="return confirm('Are you sure you want to delete $cidref->{CAMPAIGN_NAME}?')">Delete</a></td>
			</tr>
			~;
		}

		my $ctp=$master->{tools}->ctp_calculation($sum_impr,$sum_click);
		my $colspan=3;
		my $colspan2=4;
		my $effcpm=0.00;
		if($configref->{DISPLAY_EARNINGS}==1){
			$colspan2+=2;
		}
		if($configref->{DISPLAY_ADVERTISER}==1){
			$colspan++;
		}

		if($sum_impr>0){
			$effcpm=$sum_earnings/($sum_impr/1000);
		}
		$effcpm=sprintf("%.2f",$effcpm);
		$effcpm="\$$effcpm";
		$sum_earnings="\$$sum_earnings";


		$sum_impr=$master->{tools}->comma_insert($sum_impr);
		$sum_click=$master->{tools}->comma_insert($sum_click);

		print qq~
		<tr class="td2">
		<td align=right colspan=$colspan><b>Total:</b></td>
		<td align="center"><b>$sum_impr</td>
		<td align="center"><b>$sum_click</td>
		<td align="center"><b>$ctp\%</td>
		~;
		if($configref->{DISPLAY_EARNINGS}==1){
			print qq~
			<td align="center"><b>$effcpm</td>
			<td align="center"><b>$sum_earnings</td>
			~;
		}
		print qq~
		<td colspan=$colspan2>&nbsp;</td>	
		</tr>
		</table>
		~;
		# <<-- end table


	}else{

		# >>-- start campaign table
		print qq~
		<img src="$images_url/campaigns.gif" width=250 height=25><br>
		<table cellpadding=3 cellspacing=1 border=0 bgcolor="333333" width="100%">
		<tr class="td2">
		~;
		if($configref->{DISPLAY_ADVERTISER}==1){
		print qq~
		<td align="center"><b>Advertiser</td>
		~;
		}
		print qq~
		<td align="center"><b>Campaign Name</td>
		<td align="center"><b>Ad Type</td>
		<td align="center"><b>Status</td>
		<td align="center"><b>Impr</td>
		<td align="center"><b>Clicks</td>
		<td align="center"><b>CTR</td>
		~;

		if($configref->{DISPLAY_EARNINGS}==1){
		print qq~
		<td align="center"><b>Eff. CPM</td>
		<td align="center"><b>Earnings</td>
		~;
		}

		print qq~
		<td align="center"><b>Functions  ~;print $master->{html}->question("campaign_table");print qq~</td>
		</tr>
		~;

		my $last_class="td3";
		my $counter=0;
		my $old_link_type;
		my $coo;

		for(my $k=0;$k<$cidtot;$k++){
			# >> money calcs
			my $ctp=$master->{tools}->ctp_calculation($cidref[$k]->{DELIVERED_IMPR},$cidref[$k]->{DELIVERED_CLICK});
			my $earnings=$cidref[$k]->{CPM}*$cidref[$k]->{DELIVERED_IMPR}/1000+$cidref[$k]->{CPC}*$cidref[$k]->{DELIVERED_CLICK};
			my $effcpm=0;
			if($cidref[$k]->{DELIVERED_IMPR}>0){
				$effcpm=$earnings/($cidref[$k]->{DELIVERED_IMPR}/1000);
			}
			$effcpm=sprintf("%.2f",$effcpm);
			$effcpm="\$$effcpm";
			$earnings=sprintf("%.2f",$earnings);
			$earnings="\$$earnings";
			if($cidref[$k]->{CPM}+$cidref[$k]->{CPC}==0){
				$earnings="N/A";
				$effcpm="N/A";
			}
			# <<

			# >> link type
			my $link_type="Text";
			if($cidref[$k]->{HEIGHT}>2 && $cidref[$k]->{WIDTH}>2){
				$link_type="$cidref[$k]->{WIDTH}x$cidref[$k]->{HEIGHT}";
			}
			if($cidref[$k]->{HEIGHT}==2 && $cidref[$k]->{WIDTH}==2){
				$link_type="Pop";
			}
			# << link type

			# >> class control
			if($link_type ne $old_link_type){
				$old_link_type=$link_type;
				$counter++;
				if($counter > 2){$counter=1};
			}
			if($counter==1){$last_class="td3";}
			if($counter==2){$last_class="td4";}
			my $color="td3";
			if($coo==1){
				$color="td5";
				$coo=0;
			}else{
				$coo++;	
			}
			# << class control

			my $status=qq~Off~;
			if($cidref[$k]->{IMPR_BIN}+$cidref[$k]->{CLICK_BIN}>0){
				$status=qq~On~;
			}

			print qq~
			<tr class="$color">
			~;
			my $aidref=$master->{db}->select_single_row_hash("SELECT * FROM ad WHERE AID='$cidref[$k]->{AID}'");
			if($configref->{DISPLAY_ADVERTISER}==1){
			print qq~
			<td><b>&nbsp;&nbsp;$aidref->{ADVERTISER_NAME}</td>
			~;
			}


			$cidref[$k]->{DELIVERED_IMPR}=$master->{tools}->comma_insert($cidref[$k]->{DELIVERED_IMPR});
			$cidref[$k]->{DELIVERED_CLICK}=$master->{tools}->comma_insert($cidref[$k]->{DELIVERED_CLICK});

			print qq~
			<td><b>&nbsp;&nbsp;$cidref[$k]->{CAMPAIGN_NAME}</td>
			<td align="center">$link_type</td>
			<td align="center">$status</td>
			<td align="right">$cidref[$k]->{DELIVERED_IMPR}&nbsp;</td>
			<td align="right">$cidref[$k]->{DELIVERED_CLICK}</td>
			<td align="center">$ctp\%</td>
			~;

			if($configref->{DISPLAY_EARNINGS}==1){
			print qq~
			<td align="center">$effcpm</td>
			<td align="center">$earnings</td>
			~;
			}
			print qq~
			
			<td align="center"><a title="Edit $cidref[$k]->{CAMPAIGN_NAME}" href="$cgi_bin_url/adcenter.cgi?task=edit_campaign&cid=$cidref[$k]->{CID}&cache=$cache">Edit</a> | <a href="$cgi_bin_url/adcenter.cgi?task=delete_campaign&cid=$cidref[$k]->{CID}&cache=$cache" onclick="return confirm('Are you sure you want to delete $cidref[$k]->{CAMPAIGN_NAME}?')">Delete</a></td>
			</tr>
			~;
		}

		print qq~
		</table>
		~;
		# <<-- end table
	}



	print qq~
	&nbsp;<br>
	&nbsp;<br>
	&nbsp;<br>

	<table cellpadding=2 cellspacing=1 border=0 bgcolor="333333">
	<tr>
	<td bgcolor="ddddcc">
	<b><a href="$cgi_bin_url/adcenter.cgi?task=add_campaign_form&cache=$cache">Add a New Campaign</a>
	</td>
	</tr>
	</table>
	~;

	$master->{html}->footer($master);
}
# << VIEW CAMPAIGNS



















# >> VIEW CAMPAIGN HISTORY
sub view_campaign_history{
	my($self,$master)=@_;


	$master->{charts}="yes";
	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;

	# input vars
	my $cid=$master->{query}->param('cid');

	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid'");

	#get the campaign ref
	my $aidref=$master->{db}->select_single_row_hash("SELECT * FROM ad where AID='$cidref->{AID}'");
	
	
	# print header
	$master->{LINK}="campaigns";
	$master->{html}->header($master,"View Campaign History");


	# >> top menu
	print qq~
	<div class="font1">
	<a href="$cgi_bin_url/adcenter.cgi?task=view_campaigns&cache=$cache">Campaign Manager</a> : 
	<a href="$cgi_bin_url/adcenter.cgi?task=edit_campaign&cid=$cid&cache=$cache">$cidref->{CAMPAIGN_NAME}</a> : 
	Daily History
	</div>
	~;
	# << top menu	


	print qq~
	&nbsp;<br>
	<table cellpadding=0 cellspacing=0 border=0>
	<tr>
	<td align=right>
	<img src="$images_url/24hour.gif" width=120 height=25>
	</td><td valign="bottom">
	&nbsp;for: $cidref->{CAMPAIGN_NAME}<br>
	<img src="$images_url/clear.gif" width=1 height=3><br>
	</td>
	</tr>
	</table>
	~;

	$master->{reports}->hour_chart_generator($master);
	print qq~
	<table cellpadding=0 cellspacing=0 border=0 width="100%">
	<tr>
	<td align=right>
	<table cellpadding=0 cellspacing=3 border=0>
	<tr>
	<td bgcolor="0066FF">
<img src="$images_url/clear.gif" width=12 height=12>
	</td>
	<td>
	Impressions
	</td>
	</tr>
	<tr>
	<td bgcolor="FFCC00">
<img src="$images_url/clear.gif" width=12 height=12>
	</td>
	<td>
	Clicks (x10)
	</td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	~;

	print qq~
	<img src="$images_url/clear.gif" width=12 height=5><br>
	<img src="$images_url/daily.gif" width=120 height=25><br>
	~;
	$master->{reports}->day_table_generator($master);




	print qq~
	<br>&nbsp;<br>
	<img src="$images_url/group_performance.gif" width=160 height=25><br>
	~;
	$master->{reports}->group_table_generator($master);


	print qq~
	<br>
	&nbsp;<br>
	~;



	$master->{html}->footer($master);
}
# << VIEW CAMPAIGN HISTORY














# >> ADD A CAMPAIGN FORM
sub add_campaign_form{
	my($self,$master)=@_;


	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;


	#get the campaigns
	my(@aidref)=$master->{db}->select_multi_row_hash("SELECT * FROM ad order by AID");
	my $aidtot=@aidref;
	
	#get the campaigns
	my(@tidref)=$master->{db}->select_multi_row_hash("SELECT * FROM adtype order by TID");
	my $tidtot=@tidref;



	if($aidtot!=0){

		# print header
		$master->{LINK}="campaigns";
		$master->{html}->header($master,"Add a New Campaign");

		# add campaign form
		print qq~
		<form action="$cgi_bin_url/adcenter.cgi" method="post">
		&nbsp;<br>
		<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333">
		<tr class="td2">
		<td colspan=2><b>Add a New Campaign</b></td>
		</tr>
		<tr class="td3">
		<td align="right"><b>Campaign Name:</td>
		<td><input type="text" name="campaign_name" value="" size=$master->{medium} class="ft1"></td>
		</tr>
		<tr class="td3">
		<td align="right"><b>Advertiser:</td>
		<td><select name="aid" class="ft1">~;
	
		for(my $k=0;$k<$aidtot;$k++){
			print qq~<option value="$aidref[$k]->{AID}">$aidref[$k]->{ADVERTISER_NAME}</a>~;
		}

		print qq~</select></td>
		</tr>

		<tr class="td3">
		<td align="right" valign="top"><img src="$images_url/clear.gif" width=1 height=2><br><b>Ad Type<b></td>
		<td><select name="type" class="ft1">
		~;

		for(my $k=0;$k<$tidtot;$k++){
			print qq~<option value="$tidref[$k]->{TID}">$tidref[$k]->{NAME}</a>~;
		}		

		print qq~
		</select>
		</td>
		</tr>

		<tr class="td3">
		<td colspan=2><input type="submit" name="change" value="ADD" class="ft2"></td>
		</tr>	
	
		</table>
		<input type="hidden" name="task" value="add_campaign">
		<input type="hidden" name="cache" value="$cache">
		</form>
		&nbsp;<br>
		&nbsp;<br>
		~;
		$master->{html}->footer($master);

	}else{
		$master->{message}="PLEASE ADD AN ADVERTISER BEFORE ADDING CAMPAIGNS. Message at";
		$master->{advertiser}->add_advertiser_form($master);
	}


}
# << ADD A CAMPAIGN FORM








sub add_campaign{
  my($self,$master)=@_;

	# input params
	my $aid=$master->{query}->param('aid');
	my $campaign_name=$master->{query}->param('campaign_name');
	my $width=$master->{query}->param('width');
	my $height=$master->{query}->param('height');
	my $type=$master->{query}->param('type');
	my $date=$master->{env}->get_date;


	#figure out start date
	my $start_date=$master->{db}->single_result("SELECT DATE_ADD('$date',INTERVAL 0 DAY)");

	#figure out end date
	my $end_date=$master->{db}->single_result("SELECT DATE_ADD('$date',INTERVAL 30 DAY)");

	# get cid
	my $cid=$master->{tools}->get_id($master,"CID");

	# get typeref
	my $typeref=$master->{db}->select_single_row_hash("SELECT * FROM adtype WHERE TID='$type'");

	# make insert list
	my $insert_list=[
   ["CID",$cid],
   ["AID",$aid],
   ["CAMPAIGN_NAME",$campaign_name],
   ["TID",$type],
   ["WIDTH",$typeref->{WIDTH}],
   ["HEIGHT",$typeref->{HEIGHT}],
   ["START_DATE",$start_date],
   ["END_DATE",$end_date]
	];
	# insert row
	$master->{db}->insert_row("cp",$insert_list);


	# get mid
	my $mid=$master->{tools}->get_id($master,"MID");

	# make insert list
	my $insert_list=[
   ["NAME","Ad \#1"],
   ["AID",$aid],
   ["CID",$cid],
   ["MID",$mid]
	];
	# insert row
	$master->{db}->insert_row("cp_media",$insert_list);



	#get the campaigns
	my(@gidref)=$master->{db}->select_multi_row_hash("SELECT * FROM groups WHERE WIDTH='$typeref->{WIDTH}' AND HEIGHT='$typeref->{HEIGHT}'");
	my $gidtot=@gidref;

	
	#get the adconfig
	my $configref=$master->{db}->select_single_row_hash("SELECT * FROM adconfig");
	my $status=$configref->{AUTO_ACTIVATE};



	for(my $k=0;$k<$gidtot;$k++){
		# make insert list
		my $insert_list=[
	  ["GID",$gidref[$k]->{GID}],
	  ["AID",$aid],
	  ["CID",$cid],
	  ["MID",$mid],
	  ["STATUS",$status],
	  ["WEIGHT","100"]
		];
		# insert row
		$master->{db}->insert_row("cp_grouping",$insert_list);
	}


	# check campaign status
	$master->{campaign}->media_status($master);

	# update bin
	$master->{cron}->campaign_bin_update($master,$cid);

	$master->{message}="Campaign has been created";
	$master->{campaign}->view_campaigns($master);

}










sub edit_campaign{
	my($self,$master)=@_;

	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $date=$master->{env}->get_date;
	my $cache=$master->{env}->get_cache;
	
	# input vars
	my $cid=$master->{query}->param('cid');


	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid'");

	
	#get the campaign ref
	my $aidref=$master->{db}->select_single_row_hash("SELECT * FROM ad where AID='$cidref->{AID}'");

	#get the ad media
	my(@midref)=$master->{db}->select_multi_row_hash("SELECT * FROM cp_media where CID='$cid'");
	my $midtot=@midref;
	
	
	# print header
	$master->{LINK}="campaigns";
	$master->{html}->header($master,"Edit: $cidref->{CAMPAIGN_NAME}");


	# start and end dates
	my @MONTH;	my @DAY;	my @MONTH2;	my @DAY2;	my %YEAR;	my %YEAR2;
	my ($smonth,$sday,$syear)=$master->{tools}->date_splice("$cidref->{START_DATE}");
	$DAY[$sday+0]=" selected";
	$MONTH[$smonth+0]=" selected";
	$YEAR{"$syear"}=" selected";
	my ($emonth,$eday,$eyear)=$master->{tools}->date_splice("$cidref->{END_DATE}");
	$DAY2[$eday+0]=" selected";
	$MONTH2[$emonth+0]=" selected";
	$YEAR2{"$eyear"}=" selected";


	# checkboxes
	my %ui; if($cidref->{MAX_IMPR}==0){$ui{1}=" checked ";};
	my %uc; if($cidref->{MAX_CLICK}==0){$uc{1}=" checked ";};
	my %udi;if($cidref->{MAX_DAILY_IMPR}==0){$udi{1}=" checked ";};
	my %udc;if($cidref->{MAX_DAILY_CLICK}==0){$udc{1}=" checked ";};

	# geometry
	my $geometry="$cidref->{WIDTH} x $cidref->{HEIGHT}";
	if($cidref->{WIDTH}==1 && $cidref->{HEIGHT}==1){
		$geometry="Text Link";
	}
	if($cidref->{WIDTH}==2 && $cidref->{HEIGHT}==2){
		$geometry="Pop Windows";
	}



	###########################
	########### CAMPAIGN ADS ##
	my $today_ctp=$master->{tools}->ctp_calculation($cidref->{TODAY_IMPR},$cidref->{TODAY_CLICK});
	my $total_ctp=$master->{tools}->ctp_calculation($cidref->{DELIVERED_IMPR},$cidref->{DELIVERED_CLICK});

	my $status=qq~<font color="red"><b>Off</b></font>~;
	if($cidref->{IMPR_BIN}+$cidref->{CLICK_BIN}>0){
		$status=qq~<font color="blue"><b>On</b></font>~;
	}

	#print qq~IMPRESSION BIN:$cidref->{IMPR_BIN}<br>~;
	#print qq~CLICK BIN:$cidref->{CLICK_BIN}<br>~;




	# >> top menu
	print qq~
	<div class="font1">
	<a href="$cgi_bin_url/adcenter.cgi?task=view_campaigns&cache=$cache">Campaign Manager</a> : $cidref->{CAMPAIGN_NAME}
	</div>
	&nbsp;<br>
	~;
	# << top menu	




	print qq~
	<!--  Start Campaign Ads  -->
	<table cellpadding=3 cellspacing=1 border=0 width="100%" bgcolor="333333">
	<tr class="td2">
	<td colspan=2>
	<table cellpadding=0 cellspacing=0 border=0 width="100%">
	<tr>
	<td nowrap><b>Campaign Profile</b></td>
	<td width=100% align="right"></td>
	</tr>
	</table>
	</td>
	</tr>

	<tr class="td3">
	<td width=50% valign="top">
	<!-- Start Section 1 -->
	<table cellpadding=2 cellspacing=0 border=0 width="100%">
	<tr>
	<td valign="top">



	<table cellpadding=5 cellspacing=1 border=0 width="100%" bgcolor="000000">
	<tr bgcolor="dddddd">
	<td align="center"><strong>&nbsp;</td>
	<td align="center"><strong>Impressions</td>
	<td align="center"><strong>Clicks</td>
	<td align="center"><strong>CTR</td>
	</tr>
	<tr bgcolor="dddddd">
	<td align="center"><strong>Today</td>
	<td align="center">$cidref->{TODAY_IMPR}</td>
	<td align="center">$cidref->{TODAY_CLICK}</font></td>
	<td align="center">$today_ctp\%</font></td>
	</tr>
	<tr bgcolor="dddddd">
	<td align="center"><strong>Total</td>
	<td align="center">$cidref->{DELIVERED_IMPR}</td>
	<td align="center">$cidref->{DELIVERED_CLICK}</font></td>
	<td align="center">$total_ctp\%</font></td>
	</tr>
	</table>
	<img src="$images_url/clear.gif" width=1 height=5><br>
	<table cellpadding=2 cellspacing=1 border=0 width="100%">
	~;


	#get the ad media
	my(@dailyref)=$master->{db}->select_multi_row_hash("SELECT sum(IMPR) as IMPR, sum(CLICK) as CLICK,LOG_DATE FROM daily_log where CID='$cid' GROUP BY CID,LOG_DATE ORDER BY LOG_DATE DESC");

	my $maxi=0;
	for(my $k=0;$k<7;$k++){
		if($dailyref[$k]->{IMPR}>$maxi){
			$maxi=$dailyref[$k]->{IMPR};
		}
	}
	$maxi++;


	for(my $k=0;$k<7;$k++){
		my $impr=$dailyref[$k]->{IMPR}+0;
		my $widthi=(158/$maxi)*$impr+2;
		my $widthi2=160-$widthi;
		my $click=$dailyref[$k]->{CLICK}+0;

		if(!$dailyref[$k]->{LOG_DATE}){
			$dailyref[$k]->{LOG_DATE}="NA";
		}


		
		if($dailyref[$k]->{LOG_DATE} eq $date){
			$impr=$cidref->{TODAY_IMPR};
		}

		print qq~
		<tr class="td3">
		<td align="center">$dailyref[$k]->{LOG_DATE}</td>
		<td align="left"><IMG SRC="$images_url/ltblue.gif" WIDTH=$widthi HEIGHT=12><IMG SRC="$images_url/clear.gif" WIDTH=$widthi2 HEIGHT=12></td>
		<td align="center">$impr</td>
		</tr>
		~;
	}


	print qq~
	</table>

	</td>
	</tr>
	</table>
	<!-- End Section 1 -->
	</td>
	<td width=50% valign="top">
	~;




	my $max_iremaining=$cidref->{MAX_IMPR}-$cidref->{DELIVERED_IMPR};
	my $max_cremaining=$cidref->{MAX_CLICK}-$cidref->{DELIVERED_CLICK};
	my $max_idisplay=$cidref->{MAX_IMPR};
	if($cidref->{MAX_IMPR}==0){
		$max_idisplay="Unlimited";
		$max_iremaining="Unlimited";
	}
	my $max_cdisplay=$cidref->{MAX_CLICK};
	if($cidref->{MAX_CLICK}==0){
		$max_cdisplay="Unlimited";
		$max_cremaining="Unlimited";
	}

	print qq~
	<!-- Start Section 2 -->
	<table cellpadding=2 cellspacing=0 border=0 width="100%">
	<tr>
	<td>
	<table cellpadding=2 cellspacing=1 border=0 bgcolor="000000" width="100%">
	<tr bgcolor="dddddd">
	<td align="right">
	Status:
	</td>
	<td align=left>
	$status
	</td>
	</tr>

	<tr bgcolor="dddddd">
	<td align="right">
	Start Date:
	</td>
	<td align=left>
	$cidref->{START_DATE}
	</td>
	</tr>

	<tr bgcolor="dddddd">
	<td align="right">
	End Date:
	</td>
	<td align=left>
	$cidref->{END_DATE}
	</td>
	</tr>


	<tr bgcolor="dddddd">
	<td align="right">
	Impression Target:
	</td>
	<td align=left>
	$max_idisplay
	</td>
	</tr>

	<tr bgcolor="dddddd">
	<td align="right">
	Click Target:
	</td>
	<td align=left>
	$max_cdisplay
	</td>
	</tr>


	<tr bgcolor="dddddd">
	<td align="right">
	Impressions Remaining:
	</td>
	<td align=left>
	$max_iremaining
	</td>
	</tr>

	<tr bgcolor="dddddd">
	<td align="right">
	Clicks Remaining:
	</td>
	<td align=left>
	$max_cremaining
	</td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	<!-- End Section 2 -->

	<img src="$images_url/clear.gif" width=1 height=5><br>
  &nbsp;- <a href="$cgi_bin_url/adcenter.cgi?task=view_campaign_history&cid=$cid&cache=$cache">Daily History</a><br>
	<img src="$images_url/clear.gif" width=1 height=5><br>
	&nbsp;- <a href="$cgi_bin_url/adcenter.cgi?task=reset_campaign_data&cid=$cid&cache=$cache" onclick="return confirm('Are you sure you want to reset all data for $cidref->{CAMPAIGN_NAME}?')">Reset Campaign Data</a>
	
	</td>
	</tr>

	
	</table>
	&nbsp;<br>
	&nbsp;<br>
	~;


	my $link_head=qq~[<a href="$cgi_bin_url/adcenter.cgi?task=add_standard&cid=$cid&cache=$cache">Add a New GIF/JPEG Ad</a>] &nbsp;	[<a href="$cgi_bin_url/adcenter.cgi?task=add_html&cid=$cid&cache=$cache">Add a New HTML Ad</a>]~;
	if($cidref->{WIDTH}==1 && $cidref->{HEIGHT}==1){
		$link_head=qq~[<a href="$cgi_bin_url/adcenter.cgi?task=add_standard&cid=$cid&cache=$cache">Add a New Text Link</a>]~;
	}
	if($cidref->{WIDTH}==2 && $cidref->{HEIGHT}==2){
		$link_head=qq~[<a href="$cgi_bin_url/adcenter.cgi?task=add_standard&cid=$cid&cache=$cache">Add a New Pop-Window Link</a>]~;
	}


	print qq~
	<!--  Start Campaign Ads  -->
	<table cellpadding=3 cellspacing=1 border=0 width="100%" bgcolor="333333">

	<tr class="td2">
	<td colspan=7>

	<table cellpadding=0 cellspacing=0 border=0 width="100%">
	<tr>
	<td nowrap><b>Campaign Ads</b></td>
	<td width=100% align="right"><b>$link_head</b></td>
	</tr>
	</table>

	</td>
	</tr>

	<tr bgcolor="dddddd">
	<td align="center"><b>Name</b></td>
	<td align="center"><b>Type</b></td>
	<td align="center"><b>Weight</b></td>
	<td align="center"><b>Impr</b></td>
	<td align="center"><b>Clicks</b></td>
	<td align="center"><b>CTR</b></td>
	<td align="center"><b>Action</b></td>
	</tr>
	~;


	for(my $k=0;$k<$midtot;$k++){
		my $ctp=$master->{tools}->ctp_calculation($midref[$k]->{TOTAL_IMPR},$midref[$k]->{TOTAL_CLICK});

		my $type="GIF";
		if($midref[$k]->{AD_TYPE}==1){
			$type="HTML";
		}
		if($cidref->{WIDTH}==1 && $cidref->{HEIGHT}==1){
			$type="Text";
		}
		if($cidref->{WIDTH}==2 && $cidref->{HEIGHT}==2){
			$type="Pop";
		}

		my $color=qq~class="td3"~;
		if($midref[$k]->{WEIGHT}==0){
			$color=qq~bgcolor="ffff99"~;
		}
		

		print qq~
		<tr $color>
		<td align="center"><b>$midref[$k]->{NAME}</b></td>
		<td align="center">$type</td>
		<td align="center">$midref[$k]->{WEIGHT}</td>
		<td align="center">$midref[$k]->{TOTAL_IMPR}</td>
		<td align="center">$midref[$k]->{TOTAL_CLICK}</td>
		<td align="center">$ctp\%</td>
		~;


		if($midref[$k]->{AD_TYPE}==0){
			print qq~<td align="center"><a href="$cgi_bin_url/adcenter.cgi?task=edit_standard&mid=$midref[$k]->{MID}&cache=$cache">Edit</a> | <a href="$cgi_bin_url/adcenter.cgi?task=reset_media&cid=$cid&mid=$midref[$k]->{MID}&cache=$cache">Reset</a> | <a href="$cgi_bin_url/adcenter.cgi?task=delete_media&mid=$midref[$k]->{MID}&cid=$midref[$k]->{CID}&cache=$cache" onclick="return confirm('Are you sure you want to delete $midref[$k]->{NAME}?')">Delete</a></td>~;
		}else{
			print qq~<td align="center"><a href="$cgi_bin_url/adcenter.cgi?task=edit_html&mid=$midref[$k]->{MID}&cache=$cache">Edit</a> | <a href="$cgi_bin_url/adcenter.cgi?task=reset_media&cid=$cid&mid=$midref[$k]->{MID}&cache=$cache">Reset</a> | <a href="$cgi_bin_url/adcenter.cgi?task=delete_media&mid=$midref[$k]->{MID}&cid=$midref[$k]->{CID}&cache=$cache" onclick="return confirm('Are you sure you want to delete $midref[$k]->{NAME}?')">Delete</a></td>~;
		}
		print qq~
		</tr>
		~;
	}
	

	
	print qq~
	<!--  End Campaign Ads  -->
	</table>
	&nbsp;<br>
	~;
	########### CAMPAIGN ADS ##
	###########################



	#delivery rate control
	my $dr_control=qq~Controlled by <b>Date</b> or <b><a href="$cgi_bin_url/adcenter.cgi?task=delivery_rate&val=1&cid=$cid&cache=$cache">Daily Maximums</a></b>~;
	if($cidref->{RATE_CONTROL}==1){
		$dr_control=qq~Controlled by <b><a href="$cgi_bin_url/adcenter.cgi?task=delivery_rate&val=0&cid=$cid&cache=$cache">Date</a></b> or <b>Daily Maximums</b>~;
	}




	###############################
	########### CAMPAIGN OPTIONS ##
	print qq~
	<!--  Start Campaign Options  -->
	<form action="$cgi_bin_url/adcenter.cgi" method="post">


	<table cellpadding=3 cellspacing=1 border=0 width="100%" bgcolor="333333">

	<tr class="td2">
	<td colspan=2><b>Campaign Options ~;print $master->{html}->question("campaign_options");print qq~</b></td>
	</tr>
	
	<tr class="td3">
	<td align="right" nowrap><b>Advertiser:</b></td>
	<td width="100%">$aidref->{ADVERTISER_NAME}</td>
	</tr>

	<tr class="td3">
	<td align="right" nowrap><b>Campaign Name:</b></td>
	<td width="100%"><input type="text" name="campaign_name" value="$cidref->{CAMPAIGN_NAME}" size=$master->{medium} class="ft1"></td>
	</tr>

	<tr class="td3">
	<td align="right" valign="top"><b>Ad Type:</b></td>
	<td>$geometry</td>
	</td>
	</tr>

	<tr class="td3">
	<td align="right" valign="top"><b>Groups:</b></td>
	<td><b><a href="$cgi_bin_url/adcenter.cgi?task=select_campaign_groups&cid=$cidref->{CID}&cache=$cache">Edit Grouping</a></b></td>
	</td>
	</tr>


	<tr class="td3">
	<td align="right" nowrap><b>Delivery Rate:</b></td>
	<td width="100%">$dr_control</td>
	</tr>

	<tr class="td3">
	<td align="right" nowrap><b>Start Date:</b></td>
	<td width="100%">
	<SELECT name="start_month" class="ft1">
	<option value=1$MONTH[1]>January
	<option value=2$MONTH[2]>February
	<option value=3$MONTH[3]>March
	<option value=4$MONTH[4]>April
	<option value=5$MONTH[5]>May
	<option value=6$MONTH[6]>June
	<option value=7$MONTH[7]>July
	<option value=8$MONTH[8]>August
	<option value=9$MONTH[9]>September
	<option value=10$MONTH[10]>October
	<option value=11$MONTH[11]>November
	<option value=12$MONTH[12]>December
	</SELECT>
	<SELECT name="start_day" class="ft1">
	<option$DAY[1]>01
	<option$DAY[2]>02
	<option$DAY[3]>03
	<option$DAY[4]>04
	<option$DAY[5]>05
	<option$DAY[6]>06
	<option$DAY[7]>07
	<option$DAY[8]>08
	<option$DAY[9]>09
	<option$DAY[10]>10
	<option$DAY[11]>11
	<option$DAY[12]>12
	<option$DAY[13]>13
	<option$DAY[14]>14
	<option$DAY[15]>15
	<option$DAY[16]>16
	<option$DAY[17]>17
	<option$DAY[18]>18
	<option$DAY[19]>19
	<option$DAY[20]>20
	<option$DAY[21]>21
	<option$DAY[22]>22
	<option$DAY[23]>23
	<option$DAY[24]>24
	<option$DAY[25]>25
	<option$DAY[26]>26
	<option$DAY[27]>27
	<option$DAY[28]>28
	<option$DAY[29]>29
	<option$DAY[30]>30
	<option$DAY[31]>31
	</SELECT>
	<SELECT name="start_year" class="ft1">
	<option $YEAR{'2000'} value=2000>2000
	<option $YEAR{'2001'} value=2001>2001
	<option $YEAR{'2002'} value=2002>2002
	<option $YEAR{'2003'} value=2003>2003
	<option $YEAR{'2004'} value=2004>2004
	<option $YEAR{'2005'} value=2005>2005
	<option $YEAR{'2006'} value=2006>2006
	<option $YEAR{'2007'} value=2007>2007
	<option $YEAR{'2008'} value=2008>2008
	<option $YEAR{'2009'} value=2009>2009
	<option $YEAR{'2010'} value=2010>2010
	</SELECT>
	</td>
	</tr>

	<tr class="td3">
	<td align="right" nowrap><b>End Date:</b></td>
	<td width="100%">
	<SELECT name="end_month" class="ft1">
	<option value=1$MONTH2[1]>January
	<option value=2$MONTH2[2]>February
	<option value=3$MONTH2[3]>March
	<option value=4$MONTH2[4]>April
	<option value=5$MONTH2[5]>May
	<option value=6$MONTH2[6]>June
	<option value=7$MONTH2[7]>July
	<option value=8$MONTH2[8]>August
	<option value=9$MONTH2[9]>September
	<option value=10$MONTH2[10]>October
	<option value=11$MONTH2[11]>November
	<option value=12$MONTH2[12]>December
	</SELECT>
	<SELECT name="end_day" class="ft1">
	<option$DAY2[1]>01
	<option$DAY2[2]>02
	<option$DAY2[3]>03
	<option$DAY2[4]>04
	<option$DAY2[5]>05
	<option$DAY2[6]>06
	<option$DAY2[7]>07
	<option$DAY2[8]>08
	<option$DAY2[9]>09
	<option$DAY2[10]>10
	<option$DAY2[11]>11
	<option$DAY2[12]>12
	<option$DAY2[13]>13
	<option$DAY2[14]>14
	<option$DAY2[15]>15
	<option$DAY2[16]>16
	<option$DAY2[17]>17
	<option$DAY2[18]>18
	<option$DAY2[19]>19
	<option$DAY2[20]>20
	<option$DAY2[21]>21
	<option$DAY2[22]>22
	<option$DAY2[23]>23
	<option$DAY2[24]>24
	<option$DAY2[25]>25
	<option$DAY2[26]>26
	<option$DAY2[27]>27
	<option$DAY2[28]>28
	<option$DAY2[29]>29
	<option$DAY2[30]>30
	<option$DAY2[31]>31
	</SELECT>
	<SELECT name="end_year" class="ft1">
	<option $YEAR2{'2000'} value=2000>2000
	<option $YEAR2{'2001'} value=2001>2001
	<option $YEAR2{'2002'} value=2002>2002
	<option $YEAR2{'2003'} value=2003>2003
	<option $YEAR2{'2004'} value=2004>2004
	<option $YEAR2{'2005'} value=2005>2005
	<option $YEAR2{'2006'} value=2006>2006
	<option $YEAR2{'2007'} value=2007>2007
	<option $YEAR2{'2008'} value=2008>2008
	<option $YEAR2{'2009'} value=2009>2009
	<option $YEAR2{'2010'} value=2010>2010
	</SELECT>
	</td>
	</tr>


	<tr class="td3">
	<td align="right" nowrap><b>Maximum Impressions:</b></td>
	<td width="100%"><input type="text" name="max_impr" value="$cidref->{MAX_IMPR}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" $ui{1} name="unlimited_impr" value="1" class="ft3">Unlimited Impressions]</td>
	</tr>


	<tr class="td3">
	<td align="right" nowrap><b>Maximum Clicks:</b></td>
	<td width="100%"><input type="text" name="max_click" value="$cidref->{MAX_CLICK}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" $uc{1} name="unlimited_click" value="1" class="ft3">Unlimited Clicks]</td>
	</tr>
	~;



	if($cidref->{RATE_CONTROL}==1){
	print qq~
	<tr class="td3">
	<td align="right" nowrap><b>Maximum Daily Impressions:</b></td>
	<td width="100%"><input type="text" name="max_daily_impr" value="$cidref->{MAX_DAILY_IMPR}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" $udi{1} name="unlimited_daily_impr" value="1" class="ft3">Unlimited Daily Impressions]</td>
	</tr>


	<tr class="td3">
	<td align="right" nowrap><b>Maximum Daily Clicks:</b></td>
	<td width="100%"><input type="text" name="max_daily_click" value="$cidref->{MAX_DAILY_CLICK}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" $udc{1} name="unlimited_daily_click" value="1" class="ft3">Unlimited Daily Clicks]</td>
	</tr>
	~;
	}




	print qq~
	<tr class="td3">
	<td align="right" nowrap><b>Delivered Impressions:</b></td>
	<td width="100%"><input type="text" name="delivered_impr" value="$cidref->{DELIVERED_IMPR}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" name="delivered_impr_verify" value="1" class="ft3" onclick="return confirm('Changing this value will create a discrepancy in the historical log. Are you sure you want to do this? It is recommended that you reset all campaign data.')">Update]</td>
	</tr>


	<tr class="td3">
	<td align="right" nowrap><b>Delivered Clicks:</b></td>
	<td width="100%"><input type="text" name="delivered_click" value="$cidref->{DELIVERED_CLICK}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" name="delivered_click_verify" value="1" class="ft3" onclick="return confirm('Changing this value will create a discrepancy in the historical log. Are you sure you want to do this? It is recommended that you reset all campaign data.')">Update]</td>
	</tr>

	<tr class="td3">
	<td align="right" nowrap><b>CPM:</b></td>
	<td width="100%"><input type="text" name="cpm" value="$cidref->{CPM}" size=$master->{short} class="ft1"></td>
	</tr>



	<tr class="td3">
	<td align="right" nowrap><b>CPC:</b></td>
	<td width="100%"><input type="text" name="cpc" value="$cidref->{CPC}" size=$master->{short} class="ft1"></td>
	</tr>



	</table>

	<img src="$images_url/clear.gif" width=1 height=5><br>
	<input type="hidden" name="cid" value="$cid">
	<input type="hidden" name="task" value="update_campaign">
	<input type="submit" name="change" value="UPDATE" class="ft2">
	<input type="hidden" name="cache" value="$cache">
	</form>
	<!--  End Campaign Options  -->
	~;
	########### END CAMPAIGN OPTIONS ##
	###################################






	my %dow;
	my @day_priority=split(/\|/,$cidref->{DAY_PRIORITY});
	for(my $k=0;$k<7;$k++){
		if($day_priority[$k]==1){
			$dow{$k}=" checked ";			
		}
	}
	my %hour;
	my @hour_priority=split(/\|/,$cidref->{HOUR_PRIORITY});
	for(my $k=0;$k<24;$k++){
		if($hour_priority[$k]==1){
			$hour{$k}=" checked ";			
		}
	}



	my %uicap;if($cidref->{IMPR_DELAY}==0 || $cidref->{IMPR_LIMIT}==0){$uicap{1}=" checked ";};
	my %uccap;if($cidref->{CLICK_DELAY}==0 || $cidref->{CLICK_LIMIT}==0){$uccap{1}=" checked ";};


	########################################
	########### ADVANCED CAMPAIGN OPTIONS ##
	print qq~
	&nbsp;<br>
	<!--  Start Advanced Campaign Options  -->
	<form action="$cgi_bin_url/adcenter.cgi" method="post">


	<table cellpadding=3 cellspacing=1 border=0 width="100%" bgcolor="333333">

	<tr class="td2">
	<td colspan=2><b>Advanced Campaign Options ~;print $master->{html}->question("advanced_campaign_options");print qq~</b></td>
	</tr>
	
	<tr class="td3">
	<td align="right" nowrap><b>Impression Frequency Cap:</b></td>
	<td width="100%"><input type="text" name="impr_limit" value="$cidref->{IMPR_LIMIT}" size=$master->{shortest} class="ft1"> Impressions per <input type="text" name="impr_delay" value="$cidref->{IMPR_DELAY}" size=$master->{shortest} class="ft1"> Hours &nbsp;[<input type="checkbox" $uicap{1} name="no_impr_cap" value="1" class="ft3">Unlimited]</td>
	</tr>

	<tr class="td3">
	<td align="right" nowrap><b>Click Frequency Cap:</b></td>
	<td width="100%"><input type="text" name="click_limit" value="$cidref->{CLICK_LIMIT}" size=$master->{shortest} class="ft1"> Clicks per <input type="text" name="click_delay" value="$cidref->{CLICK_DELAY}" size=$master->{shortest} class="ft1"> Hours &nbsp;[<input type="checkbox" $uccap{1} name="no_click_cap" value="1" class="ft3">Unlimited]</td>
	</tr>



	<tr class="td3">
	<td align="right" nowrap><b>Day of Week Targeting:</b></td>
	<td width="100%">

	<table cellpadding=0 cellspacing=0 border=0 width="95%">
	<tr>
	<td width="15%"><input type="checkbox" $dow{0} name="d|0|" value="1" class="ft3">Sun</td>
	<td width="15%"><input type="checkbox" $dow{1} name="d|1|" value="1" class="ft3">Mon</td>
	<td width="15%"><input type="checkbox" $dow{2} name="d|2|" value="1" class="ft3">Tue</td>
	<td width="15%"><input type="checkbox" $dow{3} name="d|3|" value="1" class="ft3">Wed</td>
	<td width="15%"><input type="checkbox" $dow{4} name="d|4|" value="1" class="ft3">Thu</td>
	<td width="15%"><input type="checkbox" $dow{5} name="d|5|" value="1" class="ft3">Fri</td>
	<td width="14%"><input type="checkbox" $dow{6} name="d|6|" value="1" class="ft3">Sat</td>
	</tr>
	</table>

	</td>
	</tr>


	<tr class="td3">
	<td align="right" nowrap valign="top">
	<img src="$images_url/clear.gif" width=1 height=3><br>
	<b>Hour of Day Targeting:</b></td>
	<td width="100%">

	<table cellpadding=0 cellspacing=0 border=0 width="98%">
	<tr>
	<td width="13%"><input type="checkbox" $hour{0} name="h|0|" value="1" class="ft3">12PM</td>
	<td width="13%"><input type="checkbox" $hour{1} name="h|1|" value="1" class="ft3">1AM</td>
	<td width="13%"><input type="checkbox" $hour{2} name="h|2|" value="1" class="ft3">2AM</td>
	<td width="12%"><input type="checkbox" $hour{3} name="h|3|" value="1" class="ft3">3AM</td>
	<td width="13%"><input type="checkbox" $hour{4} name="h|4|" value="1" class="ft3">4AM</td>
	<td width="13%"><input type="checkbox" $hour{5} name="h|5|" value="1" class="ft3">5AM</td>
	<td width="13%"><input type="checkbox" $hour{6} name="h|6|" value="1" class="ft3">6AM</td>
	<td width="12%"><input type="checkbox" $hour{7} name="h|7|" value="1" class="ft3">7AM</td>
	</tr>
	<tr>
	<td width="13%"><input type="checkbox" $hour{8} name="h|8|" value="1" class="ft3">8AM</td>
	<td width="13%"><input type="checkbox" $hour{9} name="h|9|" value="1" class="ft3">9AM</td>
	<td width="13%"><input type="checkbox" $hour{10} name="h|10|" value="1" class="ft3">10AM</td>
	<td width="12%"><input type="checkbox" $hour{11} name="h|11|" value="1" class="ft3">11AM</td>
	<td width="13%"><input type="checkbox" $hour{12} name="h|12|" value="1" class="ft3">12AM</td>
	<td width="13%"><input type="checkbox" $hour{13} name="h|13|" value="1" class="ft3">1PM</td>
	<td width="13%"><input type="checkbox" $hour{14} name="h|14|" value="1" class="ft3">2PM</td>
	<td width="12%"><input type="checkbox" $hour{15} name="h|15|" value="1" class="ft3">3PM</td>
	</tr>
	<tr>
	<td width="13%"><input type="checkbox" $hour{16} name="h|16|" value="1" class="ft3">4PM</td>
	<td width="13%"><input type="checkbox" $hour{17} name="h|17|" value="1" class="ft3">5PM</td>
	<td width="13%"><input type="checkbox" $hour{18} name="h|18|" value="1" class="ft3">6PM</td>
	<td width="12%"><input type="checkbox" $hour{19} name="h|19|" value="1" class="ft3">7PM</td>
	<td width="13%"><input type="checkbox" $hour{20} name="h|20|" value="1" class="ft3">8PM</td>
	<td width="13%"><input type="checkbox" $hour{21} name="h|21|" value="1" class="ft3">9PM</td>
	<td width="13%"><input type="checkbox" $hour{22} name="h|22|" value="1" class="ft3">10PM</td>
	<td width="12%"><input type="checkbox" $hour{23} name="h|23|" value="1" class="ft3">11PM</td>
	</tr>
	</table>

	</td>
	</tr>





	<tr class="td3">
	<td align="right" valign="top"><b>Other Targeting:</b></td>
	<td>
	~;

	if($cidref->{TARGET}==1){
			
		#get the values
		my(@targetref)=$master->{db}->select_multi_row_hash("SELECT * FROM target WHERE CID='$cid' AND STATUS=1 ORDER BY TARGET_ID");
		my $targettot=@targetref;

		print qq~
		<table cellpadding=1 cellspacing=1 border=0 bgcolor="333333" width=250>
		~;

		for(my $k=0;$k<$targettot;$k++){
			my $num=$k+1;
			my $select;
			if($targetref[$k]->{STATUS}==1){
				$select=" checked ";
			}
			
			print qq~
			<tr class="td4">
			<td align=right><b>$targetref[$k]->{NAME}</b>:&nbsp;</td>
			<td>&nbsp;&nbsp;$targetref[$k]->{VALUE}</td>
			</tr>
			~;
		}
		print qq~
		</table>
		<img src="$images_url/clear.gif" width=1 height=2><br>
		~;
	}
	
	print qq~
	<b><a href="$cgi_bin_url/adcenter.cgi?task=edit_targeting&cid=$cidref->{CID}&cache=$cache">Add/Modify Criteria</a></b>
	</td>
	</td>
	</tr>





	</table>

	<img src="$images_url/clear.gif" width=1 height=5><br>
	<input type="hidden" name="cid" value="$cid">
	<input type="hidden" name="task" value="update_advanced_campaign">
	<input type="submit" name="change" value="UPDATE" class="ft2">
	<input type="hidden" name="cache" value="$cache">
	</form>
	<!--  Start Advanced Campaign Options  -->
	~;
	########### END ADVANCED CAMPAIGN OPTIONS ##
	############################################


	print qq~
	&nbsp;<br>
	~;


	$master->{html}->footer($master);
}










# >> Update Advanced Campaign
sub update_advanced_campaign{
  my($self,$master)=@_;

	# input params
	my $cid=$master->{query}->param('cid');
	my $impr_limit=$master->{query}->param('impr_limit');
	my $impr_delay=$master->{query}->param('impr_delay');
	my $click_limit=$master->{query}->param('click_limit');
	my $click_delay=$master->{query}->param('click_delay');
	my $no_impr_cap=$master->{query}->param('no_impr_cap');
	my $no_click_cap=$master->{query}->param('no_click_cap');

	if($no_impr_cap==1){
		$impr_limit=0;
		$impr_delay=0;
	}
	if($no_click_cap==1){
		$click_limit=0;
		$click_delay=0;
	}


	my $hour_string;
	for(my $k=0;$k<24;$k++){
		my $hv=$master->{query}->param("h|$k|")+0;
		$hour_string.="$hv|";
	}
	my $day_string;
	for(my $k=0;$k<7;$k++){
		my $dv=$master->{query}->param("d|$k|")+0;
		$day_string.="$dv|";
	}


	# generate query list
	my $c;
	$c=$master->{db}->update_cv($c,"IMPR_DELAY",$impr_delay);
	$c=$master->{db}->update_cv($c,"IMPR_LIMIT",$impr_limit);
	$c=$master->{db}->update_cv($c,"DAY_PRIORITY",$day_string);
	$c=$master->{db}->update_cv($c,"HOUR_PRIORITY",$hour_string);
	$c=$master->{db}->update_cv($c,"CLICK_DELAY",$click_delay);
	$c=$master->{db}->update_cv($c,"CLICK_LIMIT",$click_limit);
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE cp SET $c WHERE CID='$cid'");



	$master->{cron}->campaign_bin_update($master,$cid);
	$master->{message}="Campaign has been updated";
	$master->{campaign}->edit_campaign($master);
}









# >> Update Campaign
sub update_campaign{
  my($self,$master)=@_;

	# input params
	my $cid=$master->{query}->param('cid');
	my $month_start=$master->{query}->param('start_month');
	my $day_start=$master->{query}->param('start_day');
	my $year_start=$master->{query}->param('start_year');
	my $month_end=$master->{query}->param('end_month');
	my $day_end=$master->{query}->param('end_day');
	my $year_end=$master->{query}->param('end_year');
	my $mi=$master->{query}->param('max_impr');
	my $mc=$master->{query}->param('max_click');
	my $mdi=$master->{query}->param('max_daily_impr');
	my $mdc=$master->{query}->param('max_daily_click');
	my $ui=$master->{query}->param('unlimited_impr');
	my $uc=$master->{query}->param('unlimited_click');
	my $udi=$master->{query}->param('unlimited_daily_impr');
	my $udc=$master->{query}->param('unlimited_daily_click');
	my $click_verify=$master->{query}->param('delivered_click_verify');
	my $impr_verify=$master->{query}->param('delivered_impr_verify');


	# create dates
	my $start_date="$year_start\-$month_start\-$day_start";
	my $end_date="$year_end\-$month_end\-$day_end";


	# handle unlimited
	if($ui==1){$mi=0};
	if($uc==1){$mc=0};
	if($udi==1){$mdi=0};
	if($udc==1){$mdc=0};


	# generate query list
	my $c;
	$c=$master->{db}->update_cv($c,"CAMPAIGN_NAME",$master->{query}->param('campaign_name'));
	$c=$master->{db}->update_cv($c,"START_DATE",$start_date);
	$c=$master->{db}->update_cv($c,"END_DATE",$end_date);
	$c=$master->{db}->update_cv($c,"MAX_IMPR",$mi);
	$c=$master->{db}->update_cv($c,"MAX_CLICK",$mc);
	$c=$master->{db}->update_cv($c,"MAX_DAILY_CLICK",$mdc);
	$c=$master->{db}->update_cv($c,"MAX_DAILY_IMPR",$mdi);
	$c=$master->{db}->update_cv($c,"CPM",$master->{query}->param('cpm'));
	$c=$master->{db}->update_cv($c,"CPC",$master->{query}->param('cpc'));
	if($click_verify==1){
		$c=$master->{db}->update_cv($c,"DELIVERED_CLICK",$master->{query}->param('delivered_click'));
	}
	if($impr_verify==1){
		$c=$master->{db}->update_cv($c,"DELIVERED_IMPR",$master->{query}->param('delivered_impr'));
	}
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE cp SET $c WHERE CID='$cid'");


	$master->{cron}->campaign_bin_update($master,$cid);


	$master->{message}="Campaign has been updated";
	$master->{campaign}->edit_campaign($master);
}









sub select_campaign_groups{
	my($self,$master)=@_;

	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	
	# input vars
	my $cid=$master->{query}->param('cid');

	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid'");
	

	#get the groupings for cid
	my(@gridref)=$master->{db}->select_multi_row_hash("SELECT GID,WEIGHT,STATUS,SUM(TOTAL_IMPR) as TOTAL_IMPR, SUM(TOTAL_CLICK) as TOTAL_CLICK FROM cp_grouping where CID='$cid' GROUP BY GID");
	my $gridtot=@gridref;


	# print header
	$master->{LINK}="campaigns";
	$master->{html}->header($master,"Select Groups: $cidref->{CAMPAIGN_NAME}");



	# >> top menu
	print qq~
	<div class="font1">
	<a href="$cgi_bin_url/adcenter.cgi?task=view_campaigns&cache=$cache">Campaign Manager</a> : 
	<a href="$cgi_bin_url/adcenter.cgi?task=edit_campaign&cid=$cid&cache=$cache">$cidref->{CAMPAIGN_NAME}</a> : 
	Group Selections
	</div>
	~;
	# << top menu	



	print qq~
	&nbsp;<br>
	<form action="$cgi_bin_url/adcenter.cgi" method="post">
	<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333">


	<tr class="td2">
	<td colspan=6><b>Group Selections for $cidref->{CAMPAIGN_NAME}</b></td>
	</tr>
	<tr class="td6">
	<td align="center">
	<b>On/Off</b>
	</td>
	<td align="center">
	<b>Group</b>
	</td>
	<td align="center">
	<b>Weight</b>
	</td>
	<td align="center">
	<b>Impr</b>
	</td>
	<td align="center">
	<b>Clicks</b>
	</td>
	<td align="center">
	<b>CTR</b>
	</td>
	</tr>

	~;

	for(my $g=0;$g<$gridtot;$g++){
		my $gidref=$master->{db}->select_single_row_hash("SELECT * FROM groups WHERE GID='$gridref[$g]->{GID}'");
		my $checked="";
		if($gridref[$g]->{STATUS}==1){
			$checked="CHECKED";
		}
		my $ctr=$master->{tools}->ctp_calculation($gridref[$g]->{TOTAL_IMPR},$gridref[$g]->{TOTAL_CLICK});
		print qq~
		<tr class="td3">
		<td>
		<input type="checkbox" $checked name="G|$gridref[$g]->{GID}|" value="1" class="ft3">
		</td>
		<td>
		<a href="$cgi_bin_url/adcenter.cgi?task=edit_group&gid=$gridref[$g]->{GID}&cache=$cache">$gidref->{GROUP_NAME}</a>
		</td>
		<td align="center">
		$gridref[$g]->{WEIGHT}
		</td>
		<td align="center">
		$gridref[$g]->{TOTAL_IMPR}
		</td>
		<td align="center">
		$gridref[$g]->{TOTAL_CLICK}
		</td>
		<td align="center">
		$ctr\%
		</td>
		</tr>
		~;
	}


	print qq~
	</table>

	<img src="$images_url/clear.gif" width=1 height=5><br>
	<input type="hidden" name="cid" value="$cid">
	<input type="hidden" name="task" value="update_campaign_grouping">
	<input type="submit" name="change" value="UPDATE" class="ft2">
	<input type="hidden" name="cache" value="$cache">
	</form>
	&nbsp;<br>
	<img src="$images_url/clear.gif" width=1 height=3><br>
	~;

	$master->{html}->footer($master);
}







sub update_campaign_grouping{
  my($self,$master)=@_;

	# input params
	my $cid=$master->{query}->param('cid');

	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid'");
	
	#get the groups
	my(@gidref)=$master->{db}->select_multi_row_hash("SELECT * FROM groups where WIDTH='$cidref->{WIDTH}' AND HEIGHT='$cidref->{HEIGHT}'");
	my $gidtot=@gidref;

	#get the groupings for cid
	my(@gridref)=$master->{db}->select_multi_row_hash("SELECT GID,WEIGHT,STATUS,SUM(TOTAL_IMPR) as TOTAL_IMPR, SUM(TOTAL_CLICK) as TOTAL_CLICK FROM cp_grouping where CID='$cid' GROUP BY GID");
	my $gridtot=@gridref;

	for(my $k=0;$k<$gidtot;$k++){
		my $gid=$gidref[$k]->{GID};
		my $temp=$master->{query}->param("G|$gid|")+0;
		$master->{db}->{adcycle}->do("UPDATE cp_grouping SET STATUS=$temp WHERE CID='$cid' AND GID='$gid'");
	}


	$master->{message}="Campaign grouping has been updated";
	$master->{campaign}->select_campaign_groups($master);
}






sub add_standard{
  my($self,$master)=@_;

	# input params
	my $cid=$master->{query}->param('cid');


	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid'");	
		
	# ad qty
	my $ad_qty=$master->{db}->single_result("SELECT COUNT(*) from cp_media WHERE CID='$cid' and AD_TYPE=0");	
	$ad_qty++;

	# get mid
	my $mid=$master->{tools}->get_id($master,"MID");

	# make insert list
	my $insert_list=[
   ["NAME","Ad \#$ad_qty"],
   ["AID",$cidref->{AID}],
   ["CID",$cid],
   ["WEIGHT","0"],
   ["MID",$mid]
	];

	# insert row
	$master->{db}->insert_row("cp_media",$insert_list);


	#get the campaigns
	my(@gidref)=$master->{db}->select_multi_row_hash("SELECT * FROM groups WHERE WIDTH='$cidref->{WIDTH}' AND HEIGHT='$cidref->{HEIGHT}'");
	my $gidtot=@gidref;

	
	#get the campaigns
	my(@gidref)=$master->{db}->select_multi_row_hash("SELECT * FROM groups WHERE WIDTH='$cidref->{WIDTH}' AND HEIGHT='$cidref->{HEIGHT}'");
	my $gidtot=@gidref;

	
	#get the adconfig
	my $configref=$master->{db}->select_single_row_hash("SELECT * FROM adconfig");

	for(my $k=0;$k<$gidtot;$k++){
		my $gridref=$master->{db}->select_single_row_hash("SELECT * FROM cp_grouping WHERE CID='$cid' AND GID='$gidref[$k]->{GID} LIMIT 1'");
		my $status=$gridref->{STATUS}+0;
		my $weight=$gridref->{WEIGHT}+0;
		# make insert list
		my $insert_list=[
	  ["GID",$gidref[$k]->{GID}],
	  ["AID",$cidref->{AID}],
	  ["CID",$cidref->{CID}],
	  ["MID",$mid],
	  ["STATUS",$status],
	  ["WEIGHT",$weight]
		];
		# insert row
		$master->{db}->insert_row("cp_grouping",$insert_list);
	}


	# check campaign status
	$master->{campaign}->media_status($master);

	# update bin
	$master->{cron}->campaign_bin_update($master,$cid);

	$master->{message}="Standard Media Element has been created";
	$master->{campaign}->edit_campaign($master);

}




sub add_html{
  my($self,$master)=@_;

	# input params
	my $cid=$master->{query}->param('cid');
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;


	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid'");	
		
	# rich ad qty
	my $ad_qty=$master->{db}->single_result("SELECT COUNT(*) from cp_media WHERE CID='$cid' and AD_TYPE=1");	
	$ad_qty++;

	# get mid
	my $mid=$master->{tools}->get_id($master,"MID");


	my $rich=qq~<a href="$cgi_bin_url/adclick.cgi?cid=$cid&gid=GID&mid=$mid&id=1" target="_top"><img src="$images_url/banner1.gif" width=$cidref->{WIDTH} height=$cidref->{HEIGHT} border=0 alt="Click to Visit"></a>~;
	

	# make insert list
	my $insert_list=[
   ["NAME","HTML Ad \#$ad_qty"],
   ["AID",$cidref->{AID}],
   ["CID",$cid],
   ["MID",$mid],
   ["RICH",$rich],
   ["WEIGHT","0"],
   ["AD_TYPE","1"],
	];

	# insert row
	$master->{db}->insert_row("cp_media",$insert_list);



	#get the campaigns
	my(@gidref)=$master->{db}->select_multi_row_hash("SELECT * FROM groups WHERE WIDTH='$cidref->{WIDTH}' AND HEIGHT='$cidref->{HEIGHT}'");
	my $gidtot=@gidref;

	
	#get the adconfig
	my $configref=$master->{db}->select_single_row_hash("SELECT * FROM adconfig");

	for(my $k=0;$k<$gidtot;$k++){
		my $gridref=$master->{db}->select_single_row_hash("SELECT * FROM cp_grouping WHERE CID='$cid' AND GID='$gidref[$k]->{GID} LIMIT 1'");
		my $status=$gridref->{STATUS}+0;
		my $weight=$gridref->{WEIGHT}+0;
		# make insert list
		my $insert_list=[
	  ["GID",$gidref[$k]->{GID}],
	  ["AID",$cidref->{AID}],
	  ["CID",$cidref->{CID}],
	  ["MID",$mid],
	  ["STATUS",$status],
	  ["WEIGHT",$weight]
		];
		# insert row
		$master->{db}->insert_row("cp_grouping",$insert_list);
	}




	# check campaign status
	$master->{campaign}->media_status($master);

	# update bin
	$master->{cron}->campaign_bin_update($master,$cid);

	$master->{message}="HTML Element has been created";
	$master->{campaign}->edit_campaign($master);

}



sub delete_campaign{
  my($self,$master)=@_;

	# input params
	my $cid=$master->{query}->param('cid');

	# delete advertiser
	$master->{db}->{adcycle}->do("DELETE FROM cp WHERE CID='$cid'");

	# delete media
	$master->{db}->{adcycle}->do("DELETE FROM cp_media WHERE CID='$cid'");

	# delete grouping
	$master->{db}->{adcycle}->do("DELETE FROM cp_grouping WHERE CID='$cid'");

	# delete grouping
	$master->{db}->{adcycle}->do("DELETE FROM daily_log WHERE CID='$cid'");

	# update bin
	$master->{cron}->campaign_bin_update($master,$cid);

	$master->{message}="Campaign has been deleted";
	$master->{campaign}->view_campaigns($master);

}



sub reset_campaign_data{
  my($self,$master)=@_;

	# input params
	my $cid=$master->{query}->param('cid');

	# delete campaign data
	$master->{db}->{adcycle}->do("UPDATE cp SET 
	IMPR_BIN=99999999,
	CLICK_BIN=99999999,
	ACTION_BIN=99999999,
	MAX_IMPR=0,
	MAX_CLICK=0,
	MAX_ACTION=0,
	MAX_DAILY_IMPR=0,
	MAX_DAILY_CLICK=0,
	MAX_DAILY_ACTION=0,
	TODAY_IMPR=0,
	TODAY_CLICK=0,
	TODAY_ACTION=0,
	DELIVERED_IMPR=0,
	DELIVERED_CLICK=0,
	DELIVERED_ACTION=0
	WHERE CID='$cid'");

	# delete media
	$master->{db}->{adcycle}->do("UPDATE cp_media SET 
	TOTAL_IMPR=0,
	TOTAL_CLICK=0,
	TOTAL_ACTION=0		
	WHERE CID='$cid'");

	# delete grouping
	$master->{db}->{adcycle}->do("UPDATE cp_grouping SET
	HOUR_IMPR=0,
	HOUR_CLICK=0,
	HOUR_ACTION=0,
	TOTAL_IMPR=0,
	TOTAL_CLICK=0,
	TOTAL_ACTION=0
  WHERE CID='$cid'");

	# delete grouping
	$master->{db}->{adcycle}->do("DELETE FROM daily_log WHERE CID='$cid'");

	# delete grouping
	$master->{db}->{adcycle}->do("DELETE FROM raw_log WHERE CID='$cid'");

	# update bin
	$master->{cron}->campaign_bin_update($master,$cid);

	$master->{message}="Data has been reset";
	$master->{campaign}->edit_campaign($master);

}




sub delete_media{
  my($self,$master)=@_;

	# input params
	my $mid=$master->{query}->param('mid');
	my $cid=$master->{query}->param('cid');

	# delete media
	$master->{db}->{adcycle}->do("DELETE FROM cp_media WHERE MID='$mid'");

	# check campaign status
	$master->{campaign}->media_status($master);

	# update bin
	$master->{cron}->campaign_bin_update($master,$cid);

	$master->{message}="Media has been deleted";
	$master->{campaign}->edit_campaign($master);

}





sub media_status{
  my($self,$master)=@_;

	# input params
	my $mid=$master->{query}->param('mid');
	my $cid=$master->{query}->param('cid');

	# get counts
	my $count_standard=$master->{db}->single_result("SELECT COUNT(*) from cp_media WHERE CID='$cid' and AD_TYPE=0 AND WEIGHT > 0");
	my $total_count=$master->{db}->single_result("SELECT COUNT(*) from cp_media WHERE CID='$cid' AND WEIGHT > 0");

	# generate query list
	my $c;
	if($count_standard==0){
		$c=$master->{db}->update_cv($c,"RICH_ONLY","1");
	}else{
		$c=$master->{db}->update_cv($c,"RICH_ONLY","0");
	}
	if($total_count==0){
		$c=$master->{db}->update_cv($c,"STATUS","0");
	}
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE cp SET $c WHERE CID='$cid'");	

	return $master
}






sub edit_standard{
  my($self,$master)=@_;

	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;

	# input params
	my $mid=$master->{query}->param('mid');


	#get the mediaref
	my $midref=$master->{db}->select_single_row_hash("SELECT * FROM cp_media where MID='$mid'");	
	my $cid=$midref->{CID};
	
	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid'");	
	my $width=$cidref->{WIDTH};
	my $height=$cidref->{HEIGHT};


	#get the adconfig
	my $configref=$master->{db}->select_single_row_hash("SELECT * FROM adconfig");


	# print header
	$master->{LINK}="campaigns";
	$master->{html}->header($master,"Edit: $midref->{NAME}");

	my @border;$border[$midref->{BORDER}]=" SELECTED ";
	my %target;$target{$midref->{TARGET}}=" SELECTED ";
	my @und;$und[$midref->{WEIGHT}]=" SELECTED ";
	my %def;$def{$midref->{USE_AS_HTML_DEFAULT}}=" CHECKED ";
	

	my $under_text="";
	if(length($midref->{UNDER_TEXT})>0){
		$under_text=qq~<a href="$midref->{CLICK_URL}" target="$midref->{TARGET}">$midref->{UNDER_TEXT}</a>~;
	}

	
	my $img_url=$midref->{IMG_URL};
	my $click_url=$midref->{CLICK_URL};
	my $alt=$midref->{ALT};
	my $under_text=$midref->{UNDER_TEXT};	
		
	# convert under text
	$midref->{UNDER_TEXT}=~s/\</\&lt\;/g;
	$midref->{UNDER_TEXT}=~s/\>/\&gt\;/g;
	$midref->{UNDER_TEXT}=~s/\"/\&quot\;/g;

	# convert alt
	$midref->{ALT}=~s/\</\&lt\;/g;
	$midref->{ALT}=~s/\>/\&gt\;/g;
	$midref->{ALT}=~s/\"/\&quot\;/g;
	
	$img_url=~s/IDNUMBER+/$cache/g;
	$click_url=~s/IDNUMBER+/$cache/g;
	$alt=~s/IDNUMBER+/$cache/g;
	$under_text=~s/IDNUMBER+/$cache/g;

	if(length($under_text)>0){
		$under_text=qq~<a href="$click_url" target="$midref->{TARGET}">$under_text</a>~;
	}


	my $direct_code=qq~[<a href="$cgi_bin_url/adcenter.cgi?task=direct_adcode&cid=$cid&mid=$mid&cache=$cache">Direct Ad Code</a>]~;


	my $single_pixel="";
	if(index($midref->{SINGLE_PIXEL_URL},"http:")!=-1){
		$single_pixel=qq~<img src="$midref->{SINGLE_PIXEL_URL}" width=1 height=1 border=0>~;
	}





	# >> top menu
	print qq~
	<div class="font1">
	<a href="$cgi_bin_url/adcenter.cgi?task=view_campaigns&cache=$cache">Campaign Manager</a> : 
	<a href="$cgi_bin_url/adcenter.cgi?task=edit_campaign&cid=$cid&cache=$cache">$cidref->{CAMPAIGN_NAME}</a> : 
	$midref->{NAME}
	</div>
	&nbsp;<br>
	~;
	# << top menu	




	if($width > 2 && $height > 2){
		print qq~
		<form action="$cgi_bin_url/adcenter.cgi" enctype="multipart/form-data" method="post">
		<center>
		<a href="$click_url" target="$midref->{TARGET}"><img src="$img_url" width=$width height=$height border=$midref->{BORDER} alt="$alt"></a>$single_pixel<br>
		$under_text
		</center>
		&nbsp;<br>
		&nbsp;<br>
		~;

		print qq~
		<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333" width="100%">
		<tr class="td2">
		<td colspan=2>
		
		<table cellpadding=0 cellspacing=0 border=0 width="100%">
		<tr>
		<td nowrap><b>Standard Ad Manager ~;print $master->{html}->question("edit_standard");print qq~</b></td>
		<td width=100% align="right"><b>$direct_code</b></td>
		</tr>
		</table>	
	
		</td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Name:</td>
		<td><input type="text" name="name" value="$midref->{NAME}" size=$master->{medium} class="ft1"></td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Image URL:</td>
		<td><input type="text" name="image" value="$midref->{IMG_URL}" size=$master->{longest} class="ft1"></td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Click URL:</td>
		<td><input type="text" name="click" value="$midref->{CLICK_URL}" size=$master->{longest} class="ft1"></td>
		</tr>
		~;


		if(length($configref->{AD_DIR})>7 && length($configref->{AD_URL})>7){
			print qq~
			<tr class="td3">
			<td align="right" nowrap><b>Image on Harddrive:</td>
			<td>
			<INPUT TYPE="file" SIZE=$master->{long} NAME="upname" class="ft1">
			</td>
			</tr>
			~;
		}

		print qq~
		<tr class="td3">
		<td align="right"><b>Affiliate Tracking URL:</td>
		<td><input type="text" name="single" value="$midref->{SINGLE_PIXEL_URL}" size=$master->{longest} class="ft1"></td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Weighting:</td>
		<td><select name="weight" class="ft1"><option value=100>100 - High Priority
		<option$und[95] value=95>95
		<option$und[90] value=90>90
		<option$und[85] value=85>85
		<option$und[80] value=80>80
		<option$und[75] value=75>75
		<option$und[70] value=70>70
		<option$und[65] value=65>65
		<option$und[60] value=60>60
		<option$und[55] value=55>55
		<option$und[50] value=50>50- Medium Priority
		<option$und[45] value=45>45
		<option$und[40] value=40>40
		<option$und[35] value=35>35
		<option$und[30] value=30>30
		<option$und[25] value=25>25
		<option$und[20] value=20>20
		<option$und[15] value=15>15
		<option$und[10] value=10>10
		<option$und[5] value=5>5- Low Priority
		<option$und[0] value=0>0- OFF
		</select></td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Border Thickness:</td>
		<td><select name="border" class="ft1">
		<option value=0$border[0]>0
		<option value=1$border[1]>1
		<option value=2$border[2]>2
		<option value=3$border[3]>3
		<option value=4$border[4]>4
		<option value=5$border[5]>5
		<option value=6$border[6]>6
		<option value=7$border[7]>7
		<option value=8$border[8]>8
		<option value=9$border[9]>9
		<option value=10$border[10]>10
		</select>(SSI only)
		</td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Target Attribute:</td>
		<td><select name="target" class="ft1">
		<option value="none" $target{'none'}>Controlled by Ad Code
		<option value="_blank" $target{'_blank'}>_blank: New Window
		<option value="_self" $target{'_self'}>_self
		<option value=" _parent" $target{'_parent'}>_parent
		<option value="_top" $target{'_top'}>_top: Same Window
		</select>[SSI and Rich Media]</td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Alt Text:</td>
		<td><input type="text" name="alt" value="$midref->{ALT}" size=$master->{long} class="ft1"></td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Under Ad Text:</td>
		<td><input type=text name="btext" value="$midref->{UNDER_TEXT}" size=$master->{longest} class="ft1"> [SSI only]</td>
		</tr>

		<tr class="td3">
		<td align="right" nowrap><b>Delivered Impressions:</b></td>
		<td width="100%"><input type="text" name="delivered_impr" value="$midref->{TOTAL_IMPR}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" name="delivered_impr_verify" value="1" class="ft3">Update]</td>
		</tr>

		<tr class="td3">
		<td align="right" nowrap><b>Delivered Clicks:</b></td>
		<td width="100%"><input type="text" name="delivered_click" value="$midref->{TOTAL_CLICK}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" name="delivered_click_verify" value="1" class="ft3">Update]</td>
		</tr>

		<tr class="td3">
		<td align="right"><b>HTML Default:</td>
		<td><input type="checkbox" $def{1} name="default" value=1 class="ft3"> Use this only as a default to HTML ads.</td>
		</tr>


		</table>
		~;
	}
	
	

	# >> text link
	if($width==1 && $height==1){
		print qq~
		<form action="$cgi_bin_url/adcenter.cgi" method="post">
		&nbsp;<br>
		<b>Text Link:</b> $under_text$single_pixel<br>
		&nbsp;<br>
		&nbsp;<br>
		~;

		print qq~
		<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333" width="100%">

		<tr class="td2">
		<td colspan=2>
		<table cellpadding=0 cellspacing=0 border=0 width="100%">
		<tr>
		<td nowrap><b>Link Manager</b></td>
		<td width=100% align="right"><b>$direct_code</b></td>
		</tr>
		</table>	
		</td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Link Name:</td>
		<td><input type="text" name="name" value="$midref->{NAME}" size=$master->{medium} class="ft1"></td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Link Text:</td>
		<td><input type=text name="btext" value="$midref->{UNDER_TEXT}" size=$master->{long} class="ft1"></td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Click URL:</td>
		<td><input type="text" name="click" value="$midref->{CLICK_URL}" size=$master->{longest} class="ft1"></td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Affiliate Tracking URL:</td>
		<td><input type="text" name="single" value="$midref->{SINGLE_PIXEL_URL}" size=$master->{longest} class="ft1"></td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Weighting:</td>
		<td><select name="weight" class="ft1"><option value=100>100 - High Priority
		<option$und[95] value=95>95
		<option$und[90] value=90>90
		<option$und[85] value=85>85
		<option$und[80] value=80>80
		<option$und[75] value=75>75
		<option$und[70] value=70>70
		<option$und[65] value=65>65
		<option$und[60] value=60>60
		<option$und[55] value=55>55
		<option$und[50] value=50>50- Medium Priority
		<option$und[45] value=45>45
		<option$und[40] value=40>40
		<option$und[35] value=35>35
		<option$und[30] value=30>30
		<option$und[25] value=25>25
		<option$und[20] value=20>20
		<option$und[15] value=15>15
		<option$und[10] value=10>10
		<option$und[5] value=5>5- Low Priority
		<option$und[0] value=0>0- OFF
		</select></td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Target Attribute:</td>
		<td><select name="target" class="ft1">
		<option value="none" $target{'none'}>None
		<option value="_blank" $target{'_blank'}>_blank: New Window
		<option value="_self" $target{'_self'}>_self
		<option value=" _parent" $target{'_parent'}>_parent
		<option value="_top" $target{'_top'}>_top: Same Window
		</select></td>
		</tr>

		<tr class="td3">
		<td align="right" nowrap><b>Delivered Impressions:</b></td>
		<td width="100%"><input type="text" name="delivered_impr" value="$midref->{TOTAL_IMPR}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" name="delivered_impr_verify" value="1" class="ft3">Update]</td>
		</tr>

		<tr class="td3">
		<td align="right" nowrap><b>Delivered Clicks:</b></td>
		<td width="100%"><input type="text" name="delivered_click" value="$midref->{TOTAL_CLICK}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" name="delivered_click_verify" value="1" class="ft3">Update]</td>
		</tr>

		</table>
		~;
	}
	# << text link



	# >> pop window
	if($width==2 && $height==2){
		print qq~
		<form action="$cgi_bin_url/adcenter.cgi" method="post">
		&nbsp;<br>
		<b>Pop-Window Link:</b> <a href="$click_url" target="_blank"><b>Test</b></a><br>
		&nbsp;<br>
		&nbsp;<br>
		~;

		print qq~
		<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333" width="100%">

		<tr class="td2">
		<td colspan=2>
		<table cellpadding=0 cellspacing=0 border=0 width="100%">
		<tr>
		<td nowrap><b>Pop-Window Manager</b></td>
		<td width=100% align="right"><b>$direct_code</b></td>
		</tr>
		</table>	
		</td>
		</tr>

		<tr class="td3">
		<td align="right" nowrap><b>Pop-Window Name:</td>
		<td><input type="text" name="name" value="$midref->{NAME}" size=$master->{medium} class="ft1"></td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Redirect URL:</td>
		<td><input type="text" name="click" value="$midref->{CLICK_URL}" size=$master->{longest} class="ft1"></td>
		</tr>

		<tr class="td3">
		<td align="right"><b>Weighting:</td>
		<td><select name="weight" class="ft1"><option value=100>100 - High Priority
		<option$und[95] value=95>95
		<option$und[90] value=90>90
		<option$und[85] value=85>85
		<option$und[80] value=80>80
		<option$und[75] value=75>75
		<option$und[70] value=70>70
		<option$und[65] value=65>65
		<option$und[60] value=60>60
		<option$und[55] value=55>55
		<option$und[50] value=50>50- Medium Priority
		<option$und[45] value=45>45
		<option$und[40] value=40>40
		<option$und[35] value=35>35
		<option$und[30] value=30>30
		<option$und[25] value=25>25
		<option$und[20] value=20>20
		<option$und[15] value=15>15
		<option$und[10] value=10>10
		<option$und[5] value=5>5- Low Priority
		<option$und[0] value=0>0- OFF
		</select></td>
		</tr>

		<tr class="td3">
		<td align="right" nowrap><b>Delivered Pops:</b></td>
		<td width="100%"><input type="text" name="delivered_impr" value="$midref->{TOTAL_IMPR}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" name="delivered_impr_verify" value="1" class="ft3">Update]</td>
		</tr>

		</table>
		~;
	}
	# << pop window
	
	
		
	print qq~
	<img src="$images_url/clear.gif" width=1 height=7><br>
	<input type="hidden" name="cid" value="$cid">
	<input type="hidden" name="mid" value="$mid">
	<input type="hidden" name="task" value="update_standard">
	<input type="submit" name="change" value="UPDATE" class="ft2">
	<input type="hidden" name="cache" value="$cache">
	</form>
	&nbsp;<br>
	~;
	$master->{html}->footer($master);
}






sub update_standard{
  my($self,$master)=@_;

	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;

	# input params
	my $mid=$master->{query}->param('mid');
	my $cid=$master->{query}->param('cid');
	my $click_verify=$master->{query}->param('delivered_click_verify');
	my $impr_verify=$master->{query}->param('delivered_impr_verify');
	my $file=$master->{query}->param('upname');
	my $configref=$master->{db}->select_single_row_hash("SELECT * FROM adconfig");
	my $ad_dir=$configref->{AD_DIR};
	my $fn = $file;
	my $img_url=$master->{query}->param('image');

	$fn =~ s,^.*(\\|/)(.+)$,$2,;	
	if ($fn =~ /^([-\@\w.]+)$/) { 
	   $fn = $1;
	} else {
	   if($fn ne undef) {
	       die "'$fn' is an illegal filename.";
	    }
	}

	# >> upload file
	{
		no strict;
		my $buffer;
		my $bytesread;
		if(length($fn)>0){
			open(OUTFILE,">$ad_dir/$fn");
			binmode OUTFILE;
			while($bytesread=read($file,$buffer,1024)){
				print OUTFILE $buffer;
			}
			close(OUTFILE);
			$img_url="$configref->{AD_URL}/$fn";
		}
	}
	# << upload file


	# generate query list
	my $c;

	if($impr_verify==1){
		$c=$master->{db}->update_cv($c,"TOTAL_IMPR",$master->{query}->param('delivered_impr'));
	}
	if($click_verify==1){
		$c=$master->{db}->update_cv($c,"TOTAL_CLICK",$master->{query}->param('delivered_click'));
	}
	$c=$master->{db}->update_cv($c,"SINGLE_PIXEL_URL",$master->{query}->param('single'));
	$c=$master->{db}->update_cv($c,"IMG_URL",$img_url);
	$c=$master->{db}->update_cv($c,"NAME",$master->{query}->param('name'));
	$c=$master->{db}->update_cv($c,"CLICK_URL",$master->{query}->param('click'));
	$c=$master->{db}->update_cv($c,"WEIGHT",$master->{query}->param('weight'));
	$c=$master->{db}->update_cv($c,"BORDER",$master->{query}->param('border'));
	$c=$master->{db}->update_cv($c,"TARGET",$master->{query}->param('target'));
	$c=$master->{db}->update_cv($c,"ALT",$master->{query}->param('alt'));
	$c=$master->{db}->update_cv($c,"UNDER_TEXT",$master->{query}->param('btext'));
	$c=$master->{db}->update_cv($c,"USE_AS_HTML_DEFAULT",$master->{query}->param('default'));
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE cp_media SET $c WHERE MID='$mid'");

	# update bin
	$master->{cron}->campaign_bin_update($master,$cid);

	# check campaign status
	$master->{campaign}->media_status($master);


	$master->{message}="Standard media has been updated ";
	$master->{campaign}->edit_standard($master);
}








sub edit_html{
  my($self,$master)=@_;

	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;

	# input params
	my $mid=$master->{query}->param('mid');


	#get the mediaref
	my $midref=$master->{db}->select_single_row_hash("SELECT * FROM cp_media where MID='$mid'");	
	my $cid=$midref->{CID};
	
	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid'");	
	my $width=$cidref->{WIDTH};
	my $height=$cidref->{HEIGHT};

	# print header
	$master->{LINK}="campaigns";
	$master->{html}->header($master,"Edit: $midref->{NAME}");


	my @und;$und[$midref->{WEIGHT}]=" SELECTED ";


	my $rich_ad=$midref->{RICH};
	$rich_ad=~s/IDNUMBER+/$cache/g;



	# >> top menu
	print qq~
	<div class="font1">
	<a href="$cgi_bin_url/adcenter.cgi?task=view_campaigns&cache=$cache">Campaign Manager</a> : 
	<a href="$cgi_bin_url/adcenter.cgi?task=edit_campaign&cid=$cid&cache=$cache">$cidref->{CAMPAIGN_NAME}</a> : 
	$midref->{NAME}
	</div>
	~;
	# << top menu	


	print qq~
	&nbsp;<br>
	<center>
	$rich_ad
	</center>
	<form action="$cgi_bin_url/adcenter.cgi" method="post">
	~;


	# convert alt
	$midref->{RICH}=~s/\</\&lt\;/g;
	$midref->{RICH}=~s/\>/\&gt\;/g;
	$midref->{RICH}=~s/\"/\&quot\;/g;

	print qq~
	&nbsp;<br>
	<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333" width="100%">
	<tr class="td2">
	<td colspan=2><b>HTML Ad Manager ~;print $master->{html}->question("edit_html");print qq~</b></td>
	</tr>

	<tr class="td3">
	<td colspan="2"><textarea name="html" rows="16" cols="100" class="ft1">$midref->{RICH}</textarea></td>
	</tr>

	<tr class="td3">
	<td align="right"><b>Name:</td>
	<td><input type="text" name="name" value="$midref->{NAME}" size=$master->{medium} class="ft1"></td>
	</tr>

	<tr class="td3">
	<td align="right"><b>Click URL:</td>
	<td><input type="text" name="click" value="$midref->{CLICK_URL}" size=$master->{longest} class="ft1"></td>
	</tr>

	<tr class="td3">
	<td align="right" nowrap><b>Weighting:</td>
	<td width="100%"><select name="weight" class="ft1"><option value=100>100 - high priority
	<option$und[95] value=95>95
	<option$und[90] value=90>90
	<option$und[85] value=85>85
	<option$und[80] value=80>80
	<option$und[75] value=75>75
	<option$und[70] value=70>70
	<option$und[65] value=65>65
	<option$und[60] value=60>60
	<option$und[55] value=55>55
	<option$und[50] value=50>50- medium priority
	<option$und[45] value=45>45
	<option$und[40] value=40>40
	<option$und[35] value=35>35
	<option$und[30] value=30>30
	<option$und[25] value=25>25
	<option$und[20] value=20>20
	<option$und[15] value=15>15
	<option$und[10] value=10>10
	<option$und[5] value=5>5- low priority
	<option$und[0] value=0>0- off
	</select></td>
	</tr>


	<tr class="td3">
	<td align="right" nowrap><b>Delivered Impressions:</b></td>
	<td width="100%"><input type="text" name="delivered_impr" value="$midref->{TOTAL_IMPR}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" name="delivered_impr_verify" value="1" class="ft3">Update]</td>
	</tr>

	<tr class="td3">
	<td align="right" nowrap><b>Delivered Clicks:</b></td>
	<td width="100%"><input type="text" name="delivered_click" value="$midref->{TOTAL_CLICK}" size=$master->{short} class="ft1"> &nbsp;[<input type="checkbox" name="delivered_click_verify" value="1" class="ft3">Update]</td>
	</tr>


	</table>



	<img src="$images_url/clear.gif" width=1 height=7><br>

	<input type="hidden" name="cid" value="$cid">
	<input type="hidden" name="mid" value="$mid">
	<input type="hidden" name="task" value="update_html">
	<input type="submit" name="change" value="UPDATE" class="ft2">
	<input type="hidden" name="cache" value="$cache">
	</form>
	&nbsp;<br>


<table cellpadding=0 cellspacing=1 border=0 width="100%" bgcolor="000000">
<tr>
<td>
<table cellpadding=10 cellspacing=0 border=0 width="100%">
<tr>
<td bgcolor="eeeedd">
<li>To enable AdCycle click tracking insert <input type="text" name="null" value="&lt;a href=&quot;$cgi_bin_url/adclick.cgi?manager=adcycle.com&cid=$cid&gid=GID&mid=$mid&id=IDNUMBER&quot; target=&quot;_top&quot;&gt;" size=$master->{long} class="ft1"> into your HTML.<br>
<img src="$images_url/clear.gif" width=1 height=5><br>
<li>If the code you insert has IFRAME or Javascript tags, adcycle may not be able to track clicks since the final ad code to the end user is being dynamically generated by a third party.<br>
<img src="$images_url/clear.gif" width=1 height=5><br>
<li>If you need the adcode id passed to the HTML above, insert the word "IDNUMBER" (without the quotes) in the HTML code in one or more places.<br>
<li>All links in your html should have a target attribute of "_top" or "_blank" to force the page to open within the complete browser window when the ad is clicked on.<br>
</td>
</tr>
</table>
</td>
</tr>
</table>	
&nbsp;<br>
&nbsp;<br>
	~;


	$master->{html}->footer($master);

}







sub update_html{
  my($self,$master)=@_;

	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;

	# input params
	my $cid=$master->{query}->param('cid');
	my $mid=$master->{query}->param('mid');
	my $click_verify=$master->{query}->param('delivered_click_verify');
	my $impr_verify=$master->{query}->param('delivered_impr_verify');

	# generate query list
	my $c;
	if($impr_verify==1){
		$c=$master->{db}->update_cv($c,"TOTAL_IMPR",$master->{query}->param('delivered_impr'));
	}
	if($click_verify==1){
		$c=$master->{db}->update_cv($c,"TOTAL_CLICK",$master->{query}->param('delivered_click'));
	}
	$c=$master->{db}->update_cv($c,"NAME",$master->{query}->param('name'));
	$c=$master->{db}->update_cv($c,"CLICK_URL",$master->{query}->param('click'));
	$c=$master->{db}->update_cv($c,"RICH",$master->{query}->param('html'));
	$c=$master->{db}->update_cv($c,"WEIGHT",$master->{query}->param('weight'));
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE cp_media SET $c WHERE MID='$mid'");

	# update bin
	$master->{cron}->campaign_bin_update($master,$cid);

	# check campaign status
	$master->{campaign}->media_status($master);

	$master->{message}="Standard media has been updated";
	$master->{campaign}->edit_html($master);
}




sub reset_media{
  my($self,$master)=@_;

	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;

	# input params
	my $mid=$master->{query}->param('mid');

	# generate query list
	my $c;
	$c=$master->{db}->update_cv($c,"TOTAL_IMPR","0");
	$c=$master->{db}->update_cv($c,"TOTAL_CLICK","0");
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE cp_media SET $c WHERE MID='$mid'");	


	$master->{message}="Counters have been reset";
	$master->{campaign}->edit_campaign($master);
}





sub delivery_rate{
  my($self,$master)=@_;

	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;

	# input params
	my $cid=$master->{query}->param('cid');
	my $val=$master->{query}->param('val');

	# generate query list
	my $c;
	$c=$master->{db}->update_cv($c,"RATE_CONTROL","$val");
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE cp SET $c WHERE CID='$cid'");	

	$master->{cron}->campaign_bin_update($master,$cid);

	$master->{message}="Delivery rate controller has been changed";
	$master->{campaign}->edit_campaign($master);
}







# >> DIRECT AD CODE
sub direct_adcode{
  my($self,$master)=@_;

	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;

	# input params
	my $cid=$master->{query}->param('cid');
	my $gid=$master->{query}->param('gid');
	my $mid=$master->{query}->param('mid');


	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid'");
	my $midref=$master->{db}->select_single_row_hash("SELECT * FROM cp_media where MID='$mid'");
	my $width=$cidref->{WIDTH};
	my $height=$cidref->{HEIGHT};


	#get the campaigns
	my(@gidref)=$master->{db}->select_multi_row_hash("SELECT * FROM groups WHERE WIDTH='$width' AND HEIGHT='$height' order by GID");
	my $gidtot=@gidref;


	# print header
	$master->{LINK}="campaigns";
	$master->{html}->header($master,"Get a Direct Ad Code for Link: ");

	
	if($gidtot==0){
		print "Woops! There are no groups for this ad type. Please create a group, and try again.\n";
	}else{
		if($gid==0){
			$gid=$gidref[0]->{GID};
		}

		my $gidref=$master->{db}->select_single_row_hash("SELECT * FROM groups where GID='$gid'");


		print qq~
		&nbsp;<br>
		<font face="verdana" size=2><b>Direct Ad Code</b><br>
		The ad codes in this page will directly display the ad you have selected. No ads will rotate using these ad codes. This ad code will effectively force an impression. For banner, button, and text ads, click capping will still be enforced. Stats will be generated for the group you select above. For ad rotation, use the ad codes from the "Groups" page.
		~;


		print qq~
		<form action="$cgi_bin_url/adcenter.cgi" method="get">
		<b>Ad Code for Group:</b> <select name="gid" class="ft1">
		~;
		for(my $k=0;$k<$gidtot;$k++){
			my $ck="";
			if($gidref[$k]->{GID}==$gid){
				$ck=" selected";
			}
			print qq~<option $ck value="$gidref[$k]->{GID}">$gidref[$k]->{GROUP_NAME}</a>~;
		}
		print qq~
		</select>
		<input type="submit" name="change" value="UPDATE" class="ft2">
		<input type="hidden" name="cid" value="$cid">
		<input type="hidden" name="mid" value="$mid">
		<input type="hidden" name="task" value="direct_adcode">
		<input type="hidden" name="cache" value="$cache">
		</form>
		~;



	my $single_pixel="";
	if(index($midref->{SINGLE_PIXEL_URL},"http:")!=-1){
		$single_pixel=qq~<img src="$midref->{SINGLE_PIXEL_URL}" width=1 height=1 border=0>~;
	}

	my $under_text="";
	if(length($midref->{UNDER_TEXT})>0){
		$under_text=qq~<br><a href="$cgi_bin_url/adclick.cgi?manager=adcycle.com&gid=$gid&cid=$cid&mid=$mid&id=$cache" target="$midref->{TARGET}">$midref->{UNDER_TEXT}</a><br>~;
	}





# >> standard ad
if($width>2 && $height>2){
my $adcode=qq~
<!-- START ADCYCLE DIRECT BANNER CODE -->
<!-- Group:$gidref->{GROUP_NAME}  Campaign:$cidref->{CAMPAIGN_NAME}  Link:$midref->{NAME}-->
<a href="$cgi_bin_url/adclick.cgi?manager=adcycle.com&gid=$gid&cid=$cid&mid=$mid&id=$cache" target="$midref->{TARGET}"><img src="$cgi_bin_url/adcycle.cgi?gid=$gid&cid=$cid&mid=$mid&id=$cache" width=$width height=$height border=$midref->{BORDER} ALT="$midref->{ALT}"></a>$under_text$single_pixel
<!-- END ADCYCLE DIRECT BANNER CODE -->~;
$adcode=~s/\</\&lt\;/g;
$adcode=~s/\>/\&gt\;/g;
$adcode=~s/\"/\&quot\;/g;

print qq~
<FORM>
<FONT FACE="VERDANA,ARIAL" SIZE=2>
<table cellpadding=5 cellspacing=0 border=0 width=400 bgcolor="cccccc">
<tr>
<td>
<textarea rows="12" cols="$master->{longest2}" wrap=on class="ft1">$adcode</textarea><br>
</td>
</tr>
</table>
</FORM>
&nbsp;<br>
~;
}
# << standard ad





# >> text
if($width==1 && $height==1){
my $adcode=qq~
<!-- START ADCYCLE DIRECT TEXT CODE -->
<!-- Group:$gidref->{GROUP_NAME}  Campaign:$cidref->{CAMPAIGN_NAME}  Link:$midref->{NAME}-->
<a href="$cgi_bin_url/adclick.cgi?manager=adcycle.com&gid=$gid&cid=$cid&mid=$mid&id=$cache" target="$midref->{TARGET}">$midref->{UNDER_TEXT}</a><img src="$cgi_bin_url/adcycle.cgi?gid=$gid&cid=$cid&mid=$mid&id=$cache" width=1 height=1 border=0>$single_pixel
<!-- END ADCYCLE DIRECT TEXT CODE -->~;
$adcode=~s/\</\&lt\;/g;
$adcode=~s/\>/\&gt\;/g;
$adcode=~s/\"/\&quot\;/g;

print qq~
<FORM>
<FONT FACE="VERDANA,ARIAL" SIZE=2>
<b>Impression + Click Accounting Code<br></b>
<table cellpadding=5 cellspacing=0 border=0 width=400 bgcolor="cccccc">
<tr>
<td>
<textarea rows="8" cols="$master->{longest2}" wrap=on class="ft1">$adcode</textarea><br>
</td>
</tr>
</table>
</FORM>
&nbsp;<br>
~;




my $adcode=qq~
<!-- START ADCYCLE DIRECT TEXT CODE [click counting only]-->
<!-- Group:$gidref->{GROUP_NAME}  Campaign:$cidref->{CAMPAIGN_NAME}  Link:$midref->{NAME}-->
<a href="$cgi_bin_url/adclick.cgi?manager=adcycle.com&gid=$gid&cid=$cid&mid=$mid&id=$cache" target="$midref->{TARGET}">$midref->{UNDER_TEXT}</a>$single_pixel
<!-- END ADCYCLE DIRECT TEXT CODE -->~;
$adcode=~s/\</\&lt\;/g;
$adcode=~s/\>/\&gt\;/g;
$adcode=~s/\"/\&quot\;/g;

print qq~
<FORM>
<FONT FACE="VERDANA,ARIAL" SIZE=2>
<b>Click Counting Only</b><br>
<table cellpadding=5 cellspacing=0 border=0 width=400 bgcolor="cccccc">
<tr>
<td>
<textarea rows="8" cols="$master->{longest2}" wrap=on class="ft1">$adcode</textarea><br>
</td>
</tr>
</table>
</FORM>
&nbsp;<br>
~;



}
# << text




# >> pop under window
if($width==2 && $height==2){



my $adcode=qq~
<!-- START ADCYCLE DIRECT POP-UP CODE -->
<!-- Group:$gidref->{GROUP_NAME}  Campaign:$cidref->{CAMPAIGN_NAME}  Link:$midref->{NAME}-->
<script language=javascript><!--
/* Copyright 2001, AdCycle */
var myURL='$cgi_bin_url/adcycle.cgi?gid=$gid&cid=$cid&mid=$mid&id=$cache';
var myWidth='720';
var myHeight='300';
popWindow();
function popWindow(){
pop='width='+myWidth+',height='+myHeight+',titlebar=1,toolbar=1,location=1,';
pop+='menubar=1,scrollbars=1,resizable=1,channelmode=0,directories=0,status=1'; 
var xwin=window.open("",'cool', pop, true);
xwin.location=myURL;
} 
// -->
</script>
<!-- END ADCYCLE DIRECT POP-UP CODE -->
~;
$adcode=~s/\</\&lt\;/g;
$adcode=~s/\>/\&gt\;/g;
$adcode=~s/\"/\&quot\;/g;




print qq~
<FORM>
<FONT FACE="VERDANA,ARIAL" SIZE=2>
<b>Pop-Up Ad Code</b>
<table cellpadding=5 cellspacing=0 border=0 width=400 bgcolor="cccccc">
<tr>
<td>
<textarea rows="20" cols="$master->{longest2}" wrap=on class="ft1">$adcode</textarea><br>
</td>
</tr>
</table>
</FORM>
&nbsp;<br>
~;




my $adcode=qq~
<!-- START ADCYCLE DIRECT POP-UNDER CODE -->
<!-- Group:$gidref->{GROUP_NAME}  Campaign:$cidref->{CAMPAIGN_NAME}  Link:$midref->{NAME}-->
<script language=javascript><!--
/* Copyright 2001, AdCycle */
var myURL='$cgi_bin_url/adcycle.cgi?gid=$gid&cid=$cid&mid=$mid&id=$cache';
var myWidth='720';
var myHeight='300';
popWindow();
function popWindow(){
pop='width='+myWidth+',height='+myHeight+',titlebar=1,toolbar=1,location=1,';
pop+='menubar=1,scrollbars=1,resizable=1,channelmode=0,directories=0,status=1'; 
var xwin=window.open("",'cool', pop, true);
xwin.blur();
xwin.location=myURL;
xwin.blur();
} 
// -->
</script>
<!-- END ADCYCLE DIRECT POP-UNDER CODE -->
~;
$adcode=~s/\</\&lt\;/g;
$adcode=~s/\>/\&gt\;/g;
$adcode=~s/\"/\&quot\;/g;

print qq~
<FORM>
<FONT FACE="VERDANA,ARIAL" SIZE=2>
<b>Pop-Under Ad Code</b>
<table cellpadding=5 cellspacing=0 border=0 width=400 bgcolor="cccccc">
<tr>
<td>
<textarea rows="20" cols="$master->{longest2}" wrap=on class="ft1">$adcode</textarea><br>
</td>
</tr>
</table>
</FORM>
&nbsp;<br>
~;


}
# >> pop under window

	}

	$master->{html}->footer($master);
}
# << DIRECT AD CODE






# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 

1;
