# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle

# AdTables.pm- controls the table creation and destruction process

package AdTables;
use strict;

sub new {
	my $this=shift;
	my $class=ref($this) || $this;
	my $self={};
	bless $self, $class;
	return $self;
}

sub create_tables{
	my($self,$master)=@_;

	# get env and config vars
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $images_url=$master->{config}->get_images_url;
	my $cache=$master->{config}->get_cache;
	my $date=$master->{env}->get_date;
	my $hour=$master->{env}->get_hour;


	# >> ids
	my $sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE ids(
	AID                  INT UNSIGNED NOT NULL DEFAULT 1,
	CID                  INT UNSIGNED NOT NULL DEFAULT 1,
	GID                  INT UNSIGNED NOT NULL DEFAULT 1,
	MID                  INT UNSIGNED NOT NULL DEFAULT 1,
	TID                  INT UNSIGNED NOT NULL DEFAULT 1,
	IDX                  INT UNSIGNED NOT NULL DEFAULT 1,
	LOG_DATE             DATE NOT NULL DEFAULT '$date'
	)");
	$sth->execute;
	$master->{db}->{adcycle}->do("INSERT INTO ids SET AID=1");
	# << ids



	# >> ad type
	my $sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE adtype(
	TID                  SMALLINT UNSIGNED NOT NULL DEFAULT 1 PRIMARY KEY,
	WIDTH                SMALLINT UNSIGNED NOT NULL DEFAULT 468,
	HEIGHT               SMALLINT UNSIGNED NOT NULL DEFAULT 60,
	NAME	               VARCHAR(250) NOT NULL DEFAULT ''
	)");
	$sth->execute;
	# >> ad type



	# >> ad cache
	my $sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE adcache(
	REMOTE               CHAR(15) NOT NULL DEFAULT '',
	TID                  TINYINT UNSIGNED NOT NULL DEFAULT 1,
	SLOT	               CHAR(30) NOT NULL DEFAULT '',
	LOG_TIME             INT UNSIGNED NOT NULL DEFAULT 0
	)");
	$sth->execute;
	$master->{db}->{adcycle}->do("CREATE INDEX remote_idx on adcache(REMOTE)");
	# >> ad cache




	# >> advertiser table
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE ad(
	AID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0 PRIMARY KEY,
	ADVERTISER_NAME       CHAR(200) NOT NULL DEFAULT '',
	EMAIL_ADDRESS         CHAR(200) NOT NULL DEFAULT '',
	SITE_URL              CHAR(200) NOT NULL DEFAULT '',
	LOGIN                 CHAR(20) NOT NULL DEFAULT '',
	PASSWORD              CHAR(20) NOT NULL DEFAULT '',
	TIMEZONE              TINYINT UNSIGNED NOT NULL DEFAULT 0,
	SHOW_HISTORY          TINYINT NOT NULL DEFAULT 1, 
	RAW_HISTORY           TINYINT NOT NULL DEFAULT 1, 
	EDIT_BANNER           TINYINT NOT NULL DEFAULT 0, 
	UPDATE_BANNER_PROFILE TINYINT NOT NULL DEFAULT 0, 
	RESET_BANNER_COUNTER  TINYINT NOT NULL DEFAULT 0, 
	ACTIVATE_BANNER       TINYINT NOT NULL DEFAULT 1, 
	HELP_MENUS            TINYINT NOT NULL DEFAULT 1 
	)");
	$sth->execute;
	# << advertiser table



	# >> live_log
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE live_log(
	REMOTE                CHAR(15) NOT NULL DEFAULT '',
	GID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	CID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	MID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	ACTION                TINYINT UNSIGNED NOT NULL DEFAULT 0, #0 for impression, 1 for click
	PAGE_URL              VARCHAR(100) NOT NULL DEFAULT '',
	AGENT                 VARCHAR(100) NOT NULL DEFAULT '',
	CACHE                 VARCHAR(50) NOT NULL DEFAULT '',
	LOG_TIME              DATETIME NOT NULL DEFAULT '1999-01-01 00:00:00'
	)");
	$sth->execute;
	$master->{db}->{adcycle}->do("CREATE INDEX time_idx on live_log(LOG_TIME)");
	# << live_log



	# >> raw_log
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE raw_log(
	REMOTE                CHAR(15) NOT NULL DEFAULT '',
	GID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	CID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	MID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	ACTION                TINYINT UNSIGNED NOT NULL DEFAULT 0, #0 for impression, 1 for click
	PAGE_URL              VARCHAR(100) NOT NULL DEFAULT '',
	AGENT                 VARCHAR(100) NOT NULL DEFAULT '',
	CACHE                 VARCHAR(50) NOT NULL DEFAULT '',
	LOG_TIME              DATETIME NOT NULL DEFAULT '1999-01-01 00:00:00'
	)");
	$sth->execute;
	$master->{db}->{adcycle}->do("CREATE INDEX time_idx on raw_log(LOG_TIME)");
	# << raw_log



	# >> config
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE adconfig(
	THIS_HOUR             INT UNSIGNED NOT NULL DEFAULT 0,
	HELP_ACTIVE           TINYINT UNSIGNED NOT NULL DEFAULT 1,
	CRON_ENABLED          TINYINT UNSIGNED NOT NULL DEFAULT 0,
	DELAYED_INSERT        TINYINT UNSIGNED NOT NULL DEFAULT 0,
	DISPLAY_EARNINGS      TINYINT UNSIGNED NOT NULL DEFAULT 0,
	DISPLAY_ADVERTISER    TINYINT UNSIGNED NOT NULL DEFAULT 0,
	AUTO_ACTIVATE         TINYINT UNSIGNED NOT NULL DEFAULT 1,
	DEAD_IMAGE            CHAR(100) NOT NULL DEFAULT '',
	DEAD_LINK             CHAR(100) NOT NULL DEFAULT '',
	USER_ENABLED          CHAR(30) NOT NULL DEFAULT '',
	LOG_DATE              DATE NOT NULL DEFAULT '$date',
	AD_URL                VARCHAR(200) NOT NULL DEFAULT '',#
	AD_DIR                VARCHAR(200) NOT NULL DEFAULT '',#
	TIME_STAMP            TIMESTAMP
	)");
	$sth->execute;
	$master->{db}->{adcycle}->do("INSERT INTO adconfig (THIS_HOUR) VALUES ('$hour')");
	# << config



	# >> error_log
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE error_log(
	REMOTE                CHAR(15) NOT NULL DEFAULT '',
	GID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	ACTION                TINYINT UNSIGNED NOT NULL DEFAULT 0, #0 for impression, 1 for click
	PAGE_URL              VARCHAR(100) NOT NULL DEFAULT '',
	AGENT                 VARCHAR(100) NOT NULL DEFAULT '',
	MESSAGE               VARCHAR(50) NOT NULL DEFAULT '',
	LOG_TIME              DATETIME NOT NULL DEFAULT '1999-01-01 00:00:00'
	)");
	$sth->execute;
	# << error_log



	# >> login
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE login(
	REMOTE                CHAR(15) NOT NULL DEFAULT '',
	ACCOUNT               CHAR(20) NOT NULL DEFAULT '',
	COOKIEID	            INT UNSIGNED NOT NULL DEFAULT 0,
	AGENT                 CHAR(100) NOT NULL DEFAULT '',
	LOG_TIME              TIMESTAMP
	)");
	$sth->execute;
	# << login


	# >> target
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE target(
	IDX                   MEDIUMINT UNSIGNED NOT NULL DEFAULT 0 PRIMARY KEY,
	CID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	NAME                  CHAR(20) NOT NULL DEFAULT '',
	TARGET_ID             TINYINT UNSIGNED NOT NULL DEFAULT 0,
	VALUE                 CHAR(50) NOT NULL DEFAULT '',
	IMPR                  INT UNSIGNED NOT NULL DEFAULT 0,
	CLICK                 INT UNSIGNED NOT NULL DEFAULT 0,
	STATUS                TINYINT UNSIGNED NOT NULL DEFAULT 0
	)");
	$sth->execute;
	$master->{db}->{adcycle}->do("CREATE INDEX CID_idx on target(CID,STATUS)");
	# << target


	# >> mid_target
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE mid_target(
	IDX                   SMALLINT UNSIGNED NOT NULL DEFAULT 0 PRIMARY KEY,
	MID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	NAME                  CHAR(20) NOT NULL DEFAULT '',
	TARGET_ID             TINYINT UNSIGNED NOT NULL DEFAULT 0,
	VALUE                 CHAR(50) NOT NULL DEFAULT '',
	IMPR                  INT UNSIGNED NOT NULL DEFAULT 0,
	CLICK                 INT UNSIGNED NOT NULL DEFAULT 0,
	STATUS                TINYINT UNSIGNED NOT NULL DEFAULT 0
	)");
	$sth->execute;
	$master->{db}->{adcycle}->do("CREATE INDEX MID_idx on mid_target(MID,STATUS)");
	# << mid_target

	
	# >> daily log
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE daily_log(
	GID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	CID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	MID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	IMPR                  INT UNSIGNED NOT NULL DEFAULT 0,
	CLICK                 MEDIUMINT UNSIGNED NOT NULL DEFAULT 0,
	ACTION                SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	LOG_HOUR              TINYINT UNSIGNED NOT NULL DEFAULT 0,
	LOG_DATE              DATE NOT NULL DEFAULT '1900-01-01'
	)");
	$sth->execute;
	$master->{db}->{adcycle}->do("CREATE UNIQUE INDEX daily_idx on daily_log(GID,CID,MID,LOG_DATE,LOG_HOUR)");
	# << daily log

	

	# >> cp_grouping
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE cp_grouping(
	GID                  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	CID                  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	MID                  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	AID                  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	WEIGHT               TINYINT UNSIGNED NOT NULL DEFAULT 100,
	MAX_IMPR             INT UNSIGNED NOT NULL DEFAULT 0,
	MAX_CLICK            INT UNSIGNED NOT NULL DEFAULT 0,
	MAX_ACTION           INT UNSIGNED NOT NULL DEFAULT 0,
	HOUR_IMPR            INT UNSIGNED NOT NULL DEFAULT 0,
	HOUR_CLICK           INT UNSIGNED NOT NULL DEFAULT 0,
	HOUR_ACTION          INT UNSIGNED NOT NULL DEFAULT 0,
	TOTAL_IMPR           INT UNSIGNED NOT NULL DEFAULT 0,
	TOTAL_CLICK          INT UNSIGNED NOT NULL DEFAULT 0,
	TOTAL_ACTION         INT UNSIGNED NOT NULL DEFAULT 0,
	STATUS               TINYINT UNSIGNED NOT NULL DEFAULT 0
	)");
	$sth->execute;
	$master->{db}->{adcycle}->do("CREATE UNIQUE INDEX grid_idx on cp_grouping(GID,CID,MID)");
	# << cp_grouping



	# >> groups
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE groups(
	GID                  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	GROUP_NAME           CHAR(50) NOT NULL DEFAULT 'Campaign',
	ROTATION_FLAVOR      TINYINT UNSIGNED NOT NULL DEFAULT 0, # 0 rotation controlled by cookies, 1 cookie+order by weight, 2 random
	TID                  TINYINT UNSIGNED NOT NULL DEFAULT 1,
	TIMEZONE             TINYINT UNSIGNED NOT NULL DEFAULT 0,
	WIDTH                SMALLINT UNSIGNED NOT NULL DEFAULT 468,
	HEIGHT               SMALLINT UNSIGNED NOT NULL DEFAULT 60
	)");
	$sth->execute;
	$master->{db}->{adcycle}->do("CREATE UNIQUE INDEX gid_idx on groups(GID)");
	# << groups



	# >> cp_media
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE cp_media(
	MID                  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	CID                  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	AID                  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	AD_TYPE              TINYINT UNSIGNED NOT NULL DEFAULT 0, # 0 for standard, 1 for rich media
	USE_AS_HTML_DEFAULT  TINYINT UNSIGNED NOT NULL DEFAULT 0, # 0 for no, 1 for yes [use gif as default for html ads]
	NAME	               VARCHAR(250) NOT NULL DEFAULT '',
	SOURCE               TINYINT UNSIGNED NOT NULL DEFAULT 0, # 0 by URL, 1 for in dir on machine
	WEIGHT               TINYINT UNSIGNED NOT NULL DEFAULT 100,
	IMG_URL              VARCHAR(250) NOT NULL DEFAULT '$images_url/banner1.gif',
	CLICK_URL            VARCHAR(250) NOT NULL DEFAULT 'http://www.adcycle.com',
	SINGLE_PIXEL_URL     VARCHAR(250) NOT NULL DEFAULT '',
	BORDER               TINYINT UNSIGNED NOT NULL DEFAULT 0,
	TARGET               CHAR(10) NOT NULL DEFAULT '_top',
	ALT                  VARCHAR(150) NOT NULL DEFAULT 'Click to Visit',
	UNDER_TEXT           VARCHAR(250) NOT NULL DEFAULT '',
	RICH                 BLOB NOT NULL,
	TOTAL_IMPR           INT UNSIGNED NOT NULL DEFAULT 0,
	TOTAL_CLICK          INT UNSIGNED NOT NULL DEFAULT 0,
	TOTAL_ACTION         MEDIUMINT UNSIGNED NOT NULL DEFAULT 0
	)");
	$sth->execute;
	$master->{db}->{adcycle}->do("CREATE UNIQUE INDEX mid_idx on cp_media(MID)");
	# << cp_media



	# >> cp
	$sth=$master->{db}->{adcycle}->prepare("
	CREATE TABLE cp(
	CID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	AID                   SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  CAMPAIGN_NAME         CHAR(50) NOT NULL DEFAULT 'Campaign',
	STATUS                TINYINT NOT NULL DEFAULT 0,
	PASSWORD              CHAR(15) NOT NULL DEFAULT '',
	START_DATE            DATE NOT NULL DEFAULT '2001-01-01',	
	END_DATE              DATE NOT NULL DEFAULT '2004-01-01',
	CPC                   FLOAT(10,6) NOT NULL DEFAULT 0.00,
	CPM                   FLOAT(10,6) NOT NULL DEFAULT 0.00,
	CPA                   FLOAT(10,6) NOT NULL DEFAULT 0.00,
	TIMEZONE              TINYINT UNSIGNED NOT NULL DEFAULT 0,


	RICH_ONLY             TINYINT NOT NULL DEFAULT 0, # 0 for no, 1 for yes
	TID                   TINYINT UNSIGNED NOT NULL DEFAULT 1,
	WIDTH                 SMALLINT UNSIGNED NOT NULL DEFAULT 468,
	HEIGHT                SMALLINT UNSIGNED NOT NULL DEFAULT 60,
	IMPR_DELAY            SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	IMPR_LIMIT            SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	CLICK_DELAY           SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	CLICK_LIMIT           SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	RATE_CONTROL          TINYINT NOT NULL DEFAULT 1, #0 for by date, 1 for by daily maximums
	TARGET                TINYINT NOT NULL DEFAULT 0, #0 for off 1 for on

	IMPR_LOG              SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	CLICK_LOG             SMALLINT UNSIGNED NOT NULL DEFAULT 0,
	ACTION_LOG            SMALLINT UNSIGNED NOT NULL DEFAULT 0,

	IMPR_BIN              INT UNSIGNED NOT NULL DEFAULT 99999999,
	CLICK_BIN             INT UNSIGNED NOT NULL DEFAULT 99999999,
	ACTION_BIN            INT UNSIGNED NOT NULL DEFAULT 99999999,
	MAX_IMPR              INT UNSIGNED NOT NULL DEFAULT 0,
	MAX_CLICK             INT UNSIGNED NOT NULL DEFAULT 0,
	MAX_ACTION            INT UNSIGNED NOT NULL DEFAULT 0,
	MAX_DAILY_IMPR        INT UNSIGNED NOT NULL DEFAULT 0,
	MAX_DAILY_CLICK       INT UNSIGNED NOT NULL DEFAULT 0,
	MAX_DAILY_ACTION      INT UNSIGNED NOT NULL DEFAULT 0,
	TODAY_IMPR            INT UNSIGNED NOT NULL DEFAULT 0,
	TODAY_CLICK           INT UNSIGNED NOT NULL DEFAULT 0,
	TODAY_ACTION          INT UNSIGNED NOT NULL DEFAULT 0,
	DELIVERED_IMPR        INT UNSIGNED NOT NULL DEFAULT 0,
	DELIVERED_CLICK       INT UNSIGNED NOT NULL DEFAULT 0,
	DELIVERED_ACTION      INT UNSIGNED NOT NULL DEFAULT 0,
	DAY_PRIORITY          CHAR(15) NOT NULL DEFAULT '1|1|1|1|1|1|1|',
	HOUR_PRIORITY         CHAR(50) NOT NULL DEFAULT '1|1|1|1|1|1|1|1|1|1|1|1|1|1|1|1|1|1|1|1|1|1|1|1|'
	)");
	$sth->execute;
	$master->{db}->{adcycle}->do("CREATE UNIQUE INDEX cid_idx on cp(CID)");
	# << cp



	# >> advertisers
	my $aid=$master->{tools}->get_id($master,"AID");
	my $insert_list=[
	 ["AID","$aid"],
	 ["ADVERTISER_NAME",'AdCycle'],
	 ["LOGIN",'pop'],
	 ["PASSWORD",'123']
	];
	$master->{db}->insert_row("ad",$insert_list);
	my $aid=$master->{tools}->get_id($master,"AID");
	my $insert_list=[
	 ["AID","$aid"],
	 ["ADVERTISER_NAME",'Metagopher'],
	 ["LOGIN",'cool'],
	 ["PASSWORD",'456']
	];
	$master->{db}->insert_row("ad",$insert_list);
	my $aid=$master->{tools}->get_id($master,"AID");
	my $insert_list=[
	 ["AID","$aid"],
	 ["ADVERTISER_NAME",'Fastclick'],
	 ["LOGIN",'fun'],
	 ["PASSWORD",'789']
	];
	$master->{db}->insert_row("ad",$insert_list);
	# << advertisers




	# >> campaigns
	my $cid=$master->{tools}->get_id($master,"CID");
	my $insert_list=[
   ["CID",$cid],
   ["AID","1"],
   ["CAMPAIGN_NAME","AdCycle Charity"],
   ["WIDTH","468"],
   ["HEIGHT","60"],
   ["START_DATE","2001-01-01"],
   ["END_DATE","2001-12-25"]
	];
	$master->{db}->insert_row("cp",$insert_list);
	my $cid=$master->{tools}->get_id($master,"CID");
	my $insert_list=[
   ["CID",$cid],
   ["AID","2"],
   ["CAMPAIGN_NAME","Metagopher \#1"],
   ["WIDTH","468"],
   ["HEIGHT","60"],
   ["START_DATE","2001-01-01"],
   ["END_DATE","2001-12-25"]
	];
	$master->{db}->insert_row("cp",$insert_list);
	my $cid=$master->{tools}->get_id($master,"CID");
	my $insert_list=[
   ["CID",$cid],
   ["AID","3"],
   ["CAMPAIGN_NAME","Fastclick Referral"],
   ["WIDTH","468"],
   ["HEIGHT","60"],
   ["START_DATE","2001-01-01"],
   ["END_DATE","2001-12-25"]
	];
	$master->{db}->insert_row("cp",$insert_list);
	# << campaigns




	# >> media
	my $mid=$master->{tools}->get_id($master,"MID");
	my $insert_list=[
   ["NAME","Ad \#1"],
   ["AID","1"],
   ["CID","1"],
   ["IMG_URL","$images_url/demoad1.gif"],
   ["CLICK_URL","http://www.adcycle.com"],
   ["MID",$mid]
	];
	$master->{db}->insert_row("cp_media",$insert_list);
	my $mid=$master->{tools}->get_id($master,"MID");
	my $insert_list=[
   ["NAME","Ad \#1"],
   ["AID","2"],
   ["CID","2"],
   ["IMG_URL","$images_url/demoad2.gif"],
   ["CLICK_URL","http://www.metagopher.com"],
   ["MID",$mid]
	];
	$master->{db}->insert_row("cp_media",$insert_list);
	my $mid=$master->{tools}->get_id($master,"MID");
	my $insert_list=[
   ["NAME","Fastclick Ad \#1"],
   ["AID","3"],
   ["CID","3"],
   ["IMG_URL","$images_url/fast1.gif"],
   ["CLICK_URL","http://www.fastclick.com/re.f?2"],
   ["MID",$mid]
	];
	$master->{db}->insert_row("cp_media",$insert_list);
	my $mid=$master->{tools}->get_id($master,"MID");
	my $insert_list=[
   ["NAME","Fastclick Ad \#2"],
   ["AID","3"],
   ["CID","3"],
   ["IMG_URL","$images_url/fast2.gif"],
   ["CLICK_URL","http://www.fastclick.com/re.f?2"],
   ["MID",$mid]
	];
	$master->{db}->insert_row("cp_media",$insert_list);
	# << media



	# >> groups
	my $gid=$master->{tools}->get_id($master,"GID");
	my $insert_list=[
   ["GID",$gid],
   ["GROUP_NAME","Top of Member Pages"],
   ["WIDTH","468"],
   ["HEIGHT","60"]
	];
	$master->{db}->insert_row("groups",$insert_list);
	my $gid=$master->{tools}->get_id($master,"GID");
	my $insert_list=[
   ["GID",$gid],
   ["GROUP_NAME","Bottom of Homepage"],
   ["WIDTH","468"],
   ["HEIGHT","60"]
	];
	$master->{db}->insert_row("groups",$insert_list);
	# << groups



	# >> grouping
	my $insert_list=[
  ["GID","1"],
  ["AID","1"],
  ["CID","1"],
  ["MID","1"],
  ["STATUS","1"],
  ["WEIGHT","100"]
	];
	$master->{db}->insert_row("cp_grouping",$insert_list);
	my $insert_list=[
  ["GID","1"],
  ["AID","2"],
  ["CID","2"],
  ["MID","2"],
  ["STATUS","0"],
  ["WEIGHT","100"]
	];
	$master->{db}->insert_row("cp_grouping",$insert_list);
	my $insert_list=[
  ["GID","1"],
  ["AID","3"],
  ["CID","3"],
  ["MID","3"],
  ["STATUS","1"],
  ["WEIGHT","100"]
	];
	$master->{db}->insert_row("cp_grouping",$insert_list);
	my $insert_list=[
  ["GID","1"],
  ["AID","3"],
  ["CID","3"],
  ["MID","4"],
  ["STATUS","1"],
  ["WEIGHT","100"]
	];
	$master->{db}->insert_row("cp_grouping",$insert_list);

	my $insert_list=[
  ["GID","2"],
  ["AID","1"],
  ["CID","1"],
  ["MID","1"],
  ["STATUS","1"],
  ["WEIGHT","100"]
	];
	$master->{db}->insert_row("cp_grouping",$insert_list);
	my $insert_list=[
  ["GID","2"],
  ["AID","2"],
  ["CID","2"],
  ["MID","2"],
  ["STATUS","1"],
  ["WEIGHT","100"]
	];
	$master->{db}->insert_row("cp_grouping",$insert_list);
	my $insert_list=[
  ["GID","2"],
  ["AID","3"],
  ["CID","3"],
  ["MID","3"],
  ["STATUS","1"],
  ["WEIGHT","100"]
	];
	$master->{db}->insert_row("cp_grouping",$insert_list);
	my $insert_list=[
  ["GID","2"],
  ["AID","3"],
  ["CID","3"],
  ["MID","4"],
  ["STATUS","1"],
  ["WEIGHT","100"]
	];
	$master->{db}->insert_row("cp_grouping",$insert_list);
	# << grouping



	# >> adtypes
	my $tid=$master->{tools}->get_id($master,"TID");
	my $insert_list=[
  ["TID","$tid"],
  ["WIDTH","468"],
  ["HEIGHT","60"],
  ["NAME","468x60"],
	];
	$master->{db}->insert_row("adtype",$insert_list);
	my $tid=$master->{tools}->get_id($master,"TID");
	my $insert_list=[
  ["TID","$tid"],
  ["WIDTH","1"],
  ["HEIGHT","1"],
  ["NAME","Text Link"],
	];
	$master->{db}->insert_row("adtype",$insert_list);
	my $tid=$master->{tools}->get_id($master,"TID");
	my $insert_list=[
  ["TID","$tid"],
  ["WIDTH","2"],
  ["HEIGHT","2"],
  ["NAME","Pop-Window"],
	];
	$master->{db}->insert_row("adtype",$insert_list);
	# << adtypes

}


# >> ERASE TABLES
sub erase_tables{
	my($self,$master)=@_;
	$master->{db}->{adcycle}->do("DROP TABLE ad");
	$master->{db}->{adcycle}->do("DROP TABLE adconfig");
	$master->{db}->{adcycle}->do("DROP TABLE adcache");
	$master->{db}->{adcycle}->do("DROP TABLE live_log");
	$master->{db}->{adcycle}->do("DROP TABLE raw_log");
	$master->{db}->{adcycle}->do("DROP TABLE error_log");
	$master->{db}->{adcycle}->do("DROP TABLE login");
	$master->{db}->{adcycle}->do("DROP TABLE cp_grouping");
	$master->{db}->{adcycle}->do("DROP TABLE groups");
	$master->{db}->{adcycle}->do("DROP TABLE cp_media");
	$master->{db}->{adcycle}->do("DROP TABLE daily_log");
	$master->{db}->{adcycle}->do("DROP TABLE target");
	$master->{db}->{adcycle}->do("DROP TABLE mid_target");
	$master->{db}->{adcycle}->do("DROP TABLE adtype");
	$master->{db}->{adcycle}->do("DROP TABLE ids");
	$master->{db}->{adcycle}->do("DROP TABLE cp");
}
# << ERASE TABLES


1;


# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle