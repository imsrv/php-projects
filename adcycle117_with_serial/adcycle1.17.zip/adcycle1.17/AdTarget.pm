# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 

package AdTarget;
use strict;


sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	return $self;
}


sub edit_targeting{
	my($self,$master)=@_;

	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	my $cid=$master->{query}->param('cid');
	
	# print header
	$master->{LINK}="campaigns";
	$master->{html}->header($master,"Edit Targeting");

	#get the campaign ref
	my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp where CID='$cid'");

	#get the values
	my(@targetref)=$master->{db}->select_multi_row_hash("SELECT * FROM target WHERE CID='$cid' ORDER BY STATUS DESC,TARGET_ID");
	my $targettot=@targetref;


	# >> top menu
	print qq~
	<div class="font1">
	<a href="$cgi_bin_url/adcenter.cgi?task=view_campaigns&cache=$cache">Campaign Manager</a> : 
	<a href="$cgi_bin_url/adcenter.cgi?task=edit_campaign&cid=$cid&cache=$cache">$cidref->{CAMPAIGN_NAME}</a> : 
	Targeting
	</div>
	&nbsp;<br>
	~;
	# << top menu	



	print qq~
	<form action="$cgi_bin_url/adcenter.cgi" method="post">
	<table cellpadding=2 cellspacing=1 border=0 bgcolor="333333" width="400">
	<tr class="td2" height=24>
	<td colspan=5>&nbsp;<b>Campaign Targeting for: $cidref->{CAMPAIGN_NAME}</td>
	</tr>
	<tr class="td3">
	<td align="center">&nbsp;</td>
	<td align="center"><b>Type</td>
	<td align="center"><b>Value</td>
	<td align="center"><b>On/Off</td>
	<td align="center"><b>Functions</td>
	</tr>
	~;

	for(my $k=0;$k<$targettot;$k++){
		my $num=$k+1;
		my $select;
		if($targetref[$k]->{STATUS}==1){
			$select=" checked ";
		}
		
		print qq~
		<tr class="td3">
		<td align="center">$num</td>
		<td align="center">$targetref[$k]->{NAME}</td>
		<td>&nbsp;&nbsp;$targetref[$k]->{VALUE}</td>
		<td align="center"><input type="checkbox" $select name="S|$targetref[$k]->{IDX}|" value="1" class="ft3"></td>
		<td align="center"><a href="$cgi_bin_url/adcenter.cgi?task=delete_targeting&idx=$targetref[$k]->{IDX}&cid=$cidref->{CID}&cache=$cache" onclick="return confirm('Are you sure you want to delete this?')">Delete</a></td>
		</tr>
		~;
	}
	print qq~
	<tr class="td3">
	<td colspan=5><input type="submit" name="change" value="UPDATE" class="ft2"></td>
	</tr>
	</table>
	<img src="$images_url/clear.gif" width=1 height=5><br>
	<input type="hidden" name="cid" value="$cid">
	<input type="hidden" name="task" value="update_targeting">
	<input type="hidden" name="cache" value="$cache">
	</form>			
	~;

	print qq~
	&nbsp;<br>
	&nbsp;<br>
	<form action="$cgi_bin_url/adcenter.cgi" method="post">
	<table cellpadding=3 cellspacing=1 border=0 bgcolor="333333">

	<tr class="td2">
	<td colspan=2><b>Add a new Targeting Criteria</b> ~;print $master->{html}->question("targeting");print qq~</td>
	</tr>
	<tr class="td3">
	<td align="right"><b>Type:</td>
	<td>
	<select name="type" class="ft1">
	<option value="Keyword Target|1|">Keyword Target
	<option value="Exact Keyword Target|6|">Exact Keyword Target
	<option value="IP Target|2|">IP Target
	<option value="IP Block|3|">IP Block
	<option value="Page Target|4|">Page Target
	<option value="Page Block|5|">Page Block
	<option value="Hostname Target|7|">Hostname Target
	<option value="Hostname Block|8|">Hostname Block
	</select>
	</td>
	</tr>

	<tr class="td3">
	<td align="right">&nbsp;&nbsp;<b>Value:</td>
	<td><input type="text" name="val" value="" size="$master->{medium}" class="ft3"></td>
	</tr>

	<tr class="td3">
	<td colspan=2><input type="submit" name="change" value="ADD" class="ft2"></td>
	</tr>

	</table>
	<img src="$images_url/clear.gif" width=1 height=5><br>
	<input type="hidden" name="cid" value="$cid">
	<input type="hidden" name="task" value="add_target">
	<input type="hidden" name="cache" value="$cache">
	</form>
	<img src="$images_url/clear.gif" width=1 height=3><br>
	~;

	$master->{html}->footer($master);
}



sub add_target{
  my($self,$master)=@_;

	# input params
	my $cid=$master->{query}->param('cid');
	my $type=$master->{query}->param('type');
	my $val=$master->{query}->param('val');

	my $idx=$master->{tools}->get_id($master,"IDX");

	my ($name,$id)=split(/\|/,$type);

	# make insert list
	my $insert_list=[
   ["IDX","$idx"],
   ["CID","$cid"],
   ["NAME","$name"],
   ["TARGET_ID",$id],
   ["VALUE",$val],
   ["STATUS","1"]
	];

	# insert row
	$master->{db}->insert_row("target",$insert_list);
	$master->{db}->{adcycle}->do("UPDATE cp SET TARGET=1 WHERE CID='$cid'");

	$master->{db}->{adcycle}->do("alter table ids modify IDX MEDIUMINT UNSIGNED NOT NULL DEFAULT 0");
	$master->{db}->{adcycle}->do("alter table target modify IDX MEDIUMINT UNSIGNED NOT NULL DEFAULT 0");

	$master->{message}="Targeting Criteria Added";
	$master->{target}->edit_targeting($master);
}




sub update_targeting{
  my($self,$master)=@_;

	# input params
	my $cid=$master->{query}->param('cid');


	#get the values
	my(@targetref)=$master->{db}->select_multi_row_hash("SELECT * FROM target WHERE CID='$cid' ORDER BY STATUS DESC,TARGET_ID");
	my $targettot=@targetref;

	
	for(my $k=0;$k<$targettot;$k++){
		my $idx=$targetref[$k]->{IDX};
		my $temp=$master->{query}->param("S|$idx|");
		$temp+=0;
		$master->{db}->{adcycle}->do("UPDATE target SET STATUS='$temp' WHERE IDX='$idx'");
	}


	#get the campaign ref
	my $sumref=$master->{db}->select_single_row_hash("SELECT SUM(STATUS) as STATUS FROM target where CID='$cid'");
	if($sumref->{STATUS}>0){
		$master->{db}->{adcycle}->do("UPDATE cp SET TARGET=1 WHERE CID='$cid'");
	}else{
		$master->{db}->{adcycle}->do("UPDATE cp SET TARGET=0 WHERE CID='$cid'");
	}


	$master->{message}="Targeting has been updated";
	$master->{target}->edit_targeting($master);
}



sub delete_targeting{
  my($self,$master)=@_;

	# input params
	my $cid=$master->{query}->param('cid');
	my $idx=$master->{query}->param('idx');

	# delete advertiser
	$master->{db}->{adcycle}->do("DELETE FROM target WHERE IDX='$idx'");

	$master->{message}="Item has been deleted";
	$master->{target}->edit_targeting($master);

}

# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 

1;

