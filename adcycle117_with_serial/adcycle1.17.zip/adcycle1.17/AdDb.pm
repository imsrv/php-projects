package AdDb;
	use strict;
	use DBI;
	my $counter=0;
	my @dbconnect;


sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	return $self;
}


sub connect{   
	my ($self,$master,$dbconfig,$database,$descriptor) = @_;
	if(!$database){$database=$master->{config}->{_db_database}->{$dbconfig};}
	if(!$descriptor){$descriptor=$dbconfig;}
	my $db_ip=$master->{config}->{_db_ip}->{$dbconfig};
	my $db_name=$database;
	my $db_user=$master->{config}->{_db_user}->{$dbconfig};
	my $db_password=$master->{config}->{_db_password}->{$dbconfig};
	my $ip_attach=":$db_ip"; if($master->{machine_ip} eq $db_ip || $db_ip eq ""){$ip_attach="";}
	my $dbh ||=DBI->connect("DBI:mysql:$database$ip_attach",$db_user,$db_password);
	$self->{"$descriptor"}=$dbh;
	$dbconnect[$counter]=$descriptor;
	$counter++;
	return $self,$dbh;
}


sub set_lock{
	my ($self,$lock_name,$delay)=@_;
	my $sth = $self->{adcycle}->do("SELECT GET_LOCK('$lock_name',$delay)");
	return $self
}


sub release_lock{
	my ($self,$lock_name)=@_;
	my $sth = $self->{adcycle}->do("SELECT RELEASE_LOCK('$lock_name')");
	return $self,$sth
}


sub update_cv{
	my ($self,$c,$column_name,$column_value)=@_;
	$c.="$column_name=".$self->{adcycle}->quote($column_value).",";
	return $self,$c
}


sub select_single_row_hash{
	my ($self,$query)=@_;
	my $sth=$self->{adcycle}->prepare("$query");
	$sth->execute;
	my $hashref = $sth->fetchrow_hashref();
	$sth->finish();
	return $hashref
}


sub single_result{
	my ($self,$query)=@_;
	my $sth = $self->{adcycle}->prepare("$query");
  $sth->execute;
	my $result=$sth->fetchrow_array;
	$sth->finish();
	return $result
}


sub insert_row{
	my ($self,$table,$insert_list,$delayed)=@_;
	my $row_entry;
	my $columns;
	my $values;
	foreach $row_entry(@{$insert_list}){
    $columns.=$row_entry->[0].",";
    $values.=$self->{adcycle}->quote($row_entry->[1]).",";
  }
	chop($columns);
	chop($values);

	$self->{adcycle}->do("INSERT $delayed INTO $table ($columns) VALUES ($values)");
	return $self
}


sub select_multi_row_hash{
	my ($self,$query)=@_;
	my $sth = $self->{adcycle}->prepare("$query");
	$sth->execute;
	my $refer;
	my $rowqty=0;
	my @hashref;
	while($refer = $sth->fetchrow_hashref()){
		$hashref[$rowqty]=$refer;
		$rowqty++;
	}
	$sth->finish();
	return @hashref
}



sub clean_up{
	my ($self,$master) = @_;
	my $apache_dbi=$master->{config}->get_apache_dbi;
	if($apache_dbi ne "yes"){
		for(my $k=0;$k<$counter;$k++){
		 $self->{"$dbconnect[$k]"}->disconnect;
		}
	}
	return $self
}




1;