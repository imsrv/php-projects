# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 

package AdGroups;
use strict;


sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {};
	bless $self, $class;
	return $self;
}


sub view_groups{
	my($self,$master)=@_;

	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	my $tid=$master->{query}->param('tid')+0;
	
	
	# print header
	$master->{LINK}="groups";
	$master->{html}->header($master,"Ad Groups");


	#get the groups
	my @gidref;

	if($tid==0){
		(@gidref)=$master->{db}->select_multi_row_hash("SELECT * FROM groups order by WIDTH DESC,GROUP_NAME");
	}else{
		(@gidref)=$master->{db}->select_multi_row_hash("SELECT * FROM groups WHERE TID=$tid order by WIDTH DESC,GROUP_NAME");
	}
	my $gidtot=@gidref;


	print qq~
	<img src="$images_url/clear.gif" width=1 height=15><br>
	<img src="$images_url/groups.gif" width=250 height=25><br>
	<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333">
	<tr class="td2">
	<td align="center"><b>Group Name</td>
	<td align="center"><b>Ad Type</td>
	<td align="center"><b>Impr</td>
	<td align="center"><b>Clicks</td>
	<td align="center"><b>CTR</td>
	<td align="center"><b>Functions</td>
	</tr>
	~;

	my $coo;

	for(my $k=0;$k<$gidtot;$k++){

		my $geometry=qq~$gidref[$k]->{WIDTH} x $gidref[$k]->{HEIGHT}~;
		if($gidref[$k]->{WIDTH}==1 && $gidref[$k]->{HEIGHT}==1){
			$geometry="Text";
		}
		if($gidref[$k]->{WIDTH}==2 && $gidref[$k]->{HEIGHT}==2){
			$geometry="Pop";
		}
		
		my $rotation="By Cookie";
		if($gidref[$k]->{ROTATION_FLAVOR}==1){
			$rotation="Random";
		}

		my $cpgref=$master->{db}->select_single_row_hash("SELECT sum(TOTAL_IMPR) as IMPR,sum(TOTAL_CLICK) as CLICK FROM cp_grouping where GID='$gidref[$k]->{GID}'");
		$cpgref->{IMPR}+=0;
		$cpgref->{CLICK}+=0;

		my $color="td3";
		if($coo==1){
			$color="td5";
			$coo=0;
		}else{
			$coo++;	
		}

		my $ctp=$master->{tools}->ctp_calculation($cpgref->{IMPR},$cpgref->{CLICK});
		$cpgref->{IMPR}=$master->{tools}->comma_insert($cpgref->{IMPR});
		$cpgref->{CLICK}=$master->{tools}->comma_insert($cpgref->{CLICK});

		print qq~
		<tr class="$color">
		<td><b>&nbsp;$gidref[$k]->{GROUP_NAME}</td>
		<td align="center">$geometry</td>
		<td align="right">$cpgref->{IMPR}</td>
		<td align="right">$cpgref->{CLICK}</td>
		<td align="center">$ctp%</td>
		<td align="center"><a href="$cgi_bin_url/adcenter.cgi?task=edit_group&gid=$gidref[$k]->{GID}&cache=$cache">Edit</a> | 
		<a href="$cgi_bin_url/adcenter.cgi?task=view_group_history&gid=$gidref[$k]->{GID}&cache=$cache">Stats</a> | 
		<a href="$cgi_bin_url/adcenter.cgi?task=get_adcodes&gid=$gidref[$k]->{GID}&cache=$cache">Ad Code</a> | 
		<a href="$cgi_bin_url/adcenter.cgi?task=delete_group&gid=$gidref[$k]->{GID}&cache=$cache" onclick="return confirm('Are you sure you want to delete $gidref[$k]->{GROUP_NAME}?')">Delete</a>
		</td>
		</tr>
		~;
	}


	print qq~

	</table>
	&nbsp;<br>
	&nbsp;<br>
	&nbsp;<br>
	<table cellpadding=2 cellspacing=1 border=0 bgcolor="999999">
	<tr>
	<td bgcolor="ddddcc">
	<b><a href="$cgi_bin_url/adcenter.cgi?task=add_group_form&cache=$cache">Add a New Group</a>
	</td>
	</tr>
	</table>
	~;

	$master->{html}->footer($master);
}








sub add_group_form{
	my($self,$master)=@_;
	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
	
	
	# print header
	$master->{LINK}="groups";
	$master->{html}->header($master,"Add a New Group");


	#get the campaigns
	my(@tidref)=$master->{db}->select_multi_row_hash("SELECT * FROM adtype order by TID");
	my $tidtot=@tidref;


	# add group form
	print qq~
	<form action="$cgi_bin_url/adcenter.cgi" method="post">
	&nbsp;
	<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333">
	<tr class="td2">
	<td colspan=2><b>Add a New Group</b></td>
	</tr>
	<tr class="td3">
	<td align="right"><b>Group Name:</td>
	<td><input type="text" name="group_name" value="" size=$master->{medium} class="ft1"></td>
	</tr>
	
		<tr class="td3">
		<td align="right" valign="top"><img src="$images_url/clear.gif" width=1 height=2><br><b>Ad Type<b></td>
		<td><select name="type" class="ft1">
		~;

		for(my $k=0;$k<$tidtot;$k++){
			print qq~<option value="$tidref[$k]->{TID}">$tidref[$k]->{NAME}</a>~;
		}		

		print qq~
		</select>
		</td>
		</tr>

	
	<tr class="td3">
	<td colspan=2><input type="submit" name="change" value="ADD" class="ft2"></td>
	</tr>	
	
		
	</table>
	<input type="hidden" name="task" value="add_group">
	<input type="hidden" name="cache" value="$cache">
	</form>
	&nbsp;<br>
	&nbsp;<br>
	~;

	$master->{html}->footer($master);
}




# >> VIEW GROUP HISTORY
sub view_group_history{
	my($self,$master)=@_;


	$master->{charts}="yes";
	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;

	# input vars
	my $gid=$master->{query}->param('gid');

	#get the campaign ref
	my $gidref=$master->{db}->select_single_row_hash("SELECT * FROM groups where GID='$gid'");

	
	
	# print header
	$master->{LINK}="groups";
	$master->{html}->header($master,"View Group History");


	# >> top menu
	print qq~
	<div class="font1">
	<a href="$cgi_bin_url/adcenter.cgi?task=view_groups&cache=$cache">Group Manager</a> : 
	$gidref->{GROUP_NAME}
	</div>
	~;
	# << top menu	



	print qq~
	&nbsp;<br>
	<table cellpadding=0 cellspacing=0 border=0>
	<tr>
	<td align=right>
	<img src="$images_url/24hour.gif" width=120 height=25>
	</td><td valign="bottom">
	&nbsp;for: $gidref->{GROUP_NAME}<br>
	<img src="$images_url/clear.gif" width=1 height=3><br>
	</td>
	</tr>
	</table>
	~;

	$master->{reports}->group_hour_chart_generator($master);
	print qq~
	<table cellpadding=0 cellspacing=0 border=0 width="100%">
	<tr>
	<td align=right>
	<table cellpadding=0 cellspacing=3 border=0>
	<tr>
	<td bgcolor="0066FF">
<img src="$images_url/clear.gif" width=12 height=12>
	</td>
	<td>
	Impressions
	</td>
	</tr>
	<tr>
	<td bgcolor="FFCC00">
<img src="$images_url/clear.gif" width=12 height=12>
	</td>
	<td>
	Clicks (x10)
	</td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	~;

	print qq~
	<img src="$images_url/clear.gif" width=12 height=5><br>
	<img src="$images_url/daily.gif" width=120 height=25><br>
	~;
	$master->{reports}->group_day_table_generator($master);



	print qq~
	<br>
	&nbsp;<br>
	&nbsp;<br>
	<li><a href="$cgi_bin_url/adcenter.cgi?task=edit_group&gid=$gidref->{GID}&cache=$cache"><b>Back to Group: $gidref->{GROUP_NAME}</b></a><br>
	<img src="$images_url/clear.gif" width=1 height=7><br>
	<li><a href="$cgi_bin_url/adcenter.cgi?task=view_groups&cache=$cache"><b>Back to Group Manager</b></a><br>
	~;



	$master->{html}->footer($master);
}
# << VIEW GROUP HISTORY
























sub add_group{
  my($self,$master)=@_;

	# input params
	my $group_name=$master->{query}->param('group_name');
	my $width=$master->{query}->param('width');
	my $height=$master->{query}->param('height');
	my $type=$master->{query}->param('type');


	# get new gid
	my $gid=$master->{tools}->get_id($master,"GID");

	# get typeref
	my $typeref=$master->{db}->select_single_row_hash("SELECT * FROM adtype WHERE TID='$type'");

	# make insert list
	my $insert_list=[
   ["GID",$gid],
   ["GROUP_NAME",$group_name],
   ["TID",$type],
   ["WIDTH",$typeref->{WIDTH}],
   ["HEIGHT",$typeref->{HEIGHT}]
	];

	# insert row
	$master->{db}->insert_row("groups",$insert_list);


	#get the campaigns
	my(@cidref)=$master->{db}->select_multi_row_hash("SELECT * FROM cp WHERE WIDTH='$typeref->{WIDTH}' AND HEIGHT='$typeref->{HEIGHT}'");
	my $cidtot=@cidref;

	#get the adconfig
	my $configref=$master->{db}->select_single_row_hash("SELECT * FROM adconfig");
	my $status=$configref->{AUTO_ACTIVATE};


	for(my $k=0;$k<$cidtot;$k++){
		my(@midref)=$master->{db}->select_multi_row_hash("SELECT * FROM cp_media WHERE CID='$cidref[$k]->{CID}'");
		my $midtot=@midref;
		for(my $t=0;$t<$midtot;$t++){
			# make insert list
			my $insert_list=[
		  ["GID",$gid],
		  ["AID",$cidref[$k]->{AID}],
		  ["CID",$cidref[$k]->{CID}],
		  ["MID",$midref[$t]->{MID}],
		  ["WEIGHT","100"],
		  ["STATUS","$status"]
			];
			# insert row
			$master->{db}->insert_row("cp_grouping",$insert_list);
		}
	}

	$master->{message}="Group Created";
	$master->{groups}->view_groups($master);

}





sub edit_group{
	my($self,$master)=@_;
	
	# get config and env vars
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;
		
	# input vars
	my $gid=$master->{query}->param('gid');

	#get the group ref
	my $gidref=$master->{db}->select_single_row_hash("SELECT * FROM groups where GID='$gid'");

	#get the campaigns
	my(@cidref)=$master->{db}->select_multi_row_hash("SELECT * FROM cp WHERE WIDTH='$gidref->{WIDTH}' AND HEIGHT='$gidref->{HEIGHT}'");
	my $cidtot=@cidref;

	#get the campaigns
	my(@gridref)=$master->{db}->select_multi_row_hash("SELECT GID,CID,WEIGHT,STATUS,SUM(TOTAL_IMPR) as TOTAL_IMPR, SUM(TOTAL_CLICK) as TOTAL_CLICK FROM cp_grouping where GID='$gid' GROUP BY CID ORDER BY STATUS DESC,WEIGHT DESC,CID");
	my $gridtot=@gridref;

	# print header
	$master->{LINK}="groups";
	$master->{html}->header($master,"Edit Group: $gidref->{GROUP_NAME}");

	my %rotation;
	$rotation{$gidref->{ROTATION_FLAVOR}}=" checked ";

	# >> geomtery
	my $geometry=qq~$gidref->{WIDTH} x $gidref->{HEIGHT}~;
	if($gidref->{WIDTH}==1 && $gidref->{HEIGHT}==1){
		$geometry="Text Links";
	}
	if($gidref->{WIDTH}==2 && $gidref->{HEIGHT}==2){
		$geometry="Pop Windows";
	}
	# << geometry


	# >> top menu
	print qq~
	<div class="font1">
	<a href="$cgi_bin_url/adcenter.cgi?task=view_groups&cache=$cache">Group Manager</a> : 
	$gidref->{GROUP_NAME}
	</div>
	~;
	# << top menu	

	print qq~
	<img src="$images_url/clear.gif" width=1 height=15><br>
	<form action="$cgi_bin_url/adcenter.cgi" method="post">
	<table cellpadding=4 cellspacing=1 border=0 bgcolor="333333">

	<tr class="td2">
	<td colspan=2><b>Group: <font color="000033">$gidref->{GROUP_NAME}</font> ~;print $master->{html}->question("group_table");print qq~</b></td>
	</tr>


	<tr class="td3">
	<td align="right"><b>Name</b>:</td>
	<td><input type="text" name="group_name" size=$master->{medium} value="$gidref->{GROUP_NAME}" class="ft1"></td>
	</tr>

	<tr class="td3">
	<td align="right"><b>Ad Type</b>:</td>
	<td>$geometry <b> &nbsp;[<a href="$cgi_bin_url/adcenter.cgi?task=get_adcodes&gid=$gidref->{GID}&cache=$cache">Get Ad Codes</a>]</td>
	</tr>

	<tr class="td3">
	<td align="right" valign="top">
	<img src="$images_url/clear.gif" width=1 height=5><br>
	<b>Campaigns</b>:</td>
	<td>


	<table cellpadding=3 cellspacing=1 border=0 bgcolor="333333" width="100%">
	<tr bgcolor="eeeedd">
	<td>&nbsp;</td>
	<td align="center"><b>Name</b></td>
	<td align="center"><b>Weight</b></td>
	<td align="center"><b>Status</b></td>
	<td align="center"><b>Impr</b></td>
	<td align="center"><b>Clicks</b></td>
	<td align="center"><b>CTR</b></td>
	</tr>

	~;

	my $need_default="yes";

	for(my $k=0;$k<$gridtot;$k++){

		#get gridref
		my $cidref=$master->{db}->select_single_row_hash("SELECT * FROM cp WHERE CID='$gridref[$k]->{CID}'");

		#select and check
		my $checked="";
		my @UND;
		if($gridref[$k]->{STATUS}==1){$checked=" CHECKED ";}	
		$UND[$gridref[$k]->{WEIGHT}]=" SELECTED ";
		
		my $color="eeeedd";
		if($gridref[$k]->{STATUS}==0){
			$color="dddddd";
		}

		my $status=qq~<font color="red"><b>Off</b></font>~;
		if($cidref->{IMPR_BIN}+$cidref->{CLICK_BIN}>0){
			$status=qq~<font color="blue"><b>On</b></font>~;
		}

		my $ctr=$master->{tools}->ctp_calculation($gridref[$k]->{TOTAL_IMPR},$gridref[$k]->{TOTAL_CLICK});

		$gridref[$k]->{TOTAL_IMPR}=$master->{tools}->comma_insert($gridref[$k]->{TOTAL_IMPR});
		$gridref[$k]->{TOTAL_CLICK}=$master->{tools}->comma_insert($gridref[$k]->{TOTAL_CLICK});

		print qq~
		<tr bgcolor="$color">
		<td>
		<input type="checkbox" $checked name="C|$cidref->{CID}|" value="1">
		</td>
		<td>
		<a href="$cgi_bin_url/adcenter.cgi?task=edit_campaign&cid=$cidref->{CID}&cache=$cache">$cidref->{CAMPAIGN_NAME}</a>
		</td>
		<td>
		<SELECT name="WEIGHT|$cidref->{CID}|"><option $UND[100] value=100>100 - High
		<option $UND[95] value=95>95
		<option $UND[90] value=90>90
		<option $UND[85] value=85>85
		<option $UND[80] value=80>80
		<option $UND[75] value=75>75
		<option $UND[70] value=70>70
		<option $UND[65] value=65>65
		<option $UND[60] value=60>60
		<option $UND[55] value=55>55
		<option $UND[50] value=50>50- Medium
		<option $UND[45] value=45>45
		<option $UND[40] value=40>40
		<option $UND[35] value=35>35
		<option $UND[30] value=30>30
		<option $UND[25] value=25>25
		<option $UND[20] value=20>20
		<option $UND[15] value=15>15
		<option $UND[10] value=10>10
		<option $UND[5] value=5>5- Low
		<option $UND[0] value=0>0- Default
		</select><BR>
		</td>
		<td align="center">
		$status
		</td>
		<td align="right">
		$gridref[$k]->{TOTAL_IMPR}
		</td>
		<td align="right">
		$gridref[$k]->{TOTAL_CLICK}
		</td>
		<td align="center">
		$ctr\%
		</td>
		</tr>
		~;


		my $black_banner="no";
		#>> black adcycle banner
		if($cidref->{RATE_CONTROL}==0){
			$black_banner="yes";
		}
		if($cidref->{IMPR_DELAY}+$cidref->{CLICK_DELAY}+$cidref->{IMPR_LIMIT}+$cidref->{CLICK_LIMIT}>0){
			$black_banner="yes";
		}
		if($cidref->{MAX_IMPR}+$cidref->{MAX_CLICK}+$cidref->{MAX_DAILY_IMPR}+$cidref->{MAX_DAILY_CLICK}>0){
			$black_banner="yes";
		}
		if($cidref->{TARGET}==1){
			$black_banner="yes";
		}
		if($cidref->{IMPR_BIN}+$cidref->{CLICK_BIN}==0){
			$black_banner="yes";
		}
		if($gridref[$k]->{STATUS}==0){
			$black_banner="yes";
		}
		if($black_banner eq "no" || ($gridref[$k]->{WEIGHT}==0 && $gridref[$k]->{STATUS}==1)){
			$need_default="no";
		}
		#<< black adcycle banner

	}


	print qq~
	</table>
	</td>
	</tr>


	<tr class="td3">
	<td align="right" valign="top">
	<img src="$images_url/clear.gif" width=1 height=5><br>
	<b>Rotation</b>:
	</td>
	<td>
	<input type=radio $rotation{0} name="rotation" value="0">Cookie Controlled Random Weighted Rotation<br>
	<input type=radio $rotation{1} name="rotation" value="1">Cookie Controlled Rotation Ordered by Weighting<br>
	<input type=radio $rotation{2} name="rotation" value="2">Random Weighted Rotation<br>
	</td>
	</tr>


	</table>
	<img src="$images_url/clear.gif" width=1 height=5><br>

	<input type="hidden" name="gid" value="$gid">
	<input type="hidden" name="task" value="update_group">
	<input type="submit" name="change" value="UPDATE" class="ft2">
	<input type="hidden" name="cache" value="$cache">
	</form>
	&nbsp;<br>
	~;


	#>> black adcycle banner
	if($need_default eq "yes"){
		print qq~
		<img src="$images_url/clear.gif" width=1 height=20><br>
		<table cellpadding=7 cellspacing=1 border=0 bgcolor="333333" width="350">
		<tr bgcolor="FFCCCC">
		<td>		
		<b>[ALERT] This group has the potential to generate black adcycle default ads. To eliminate this possibility add an active campaign to the group and set the weight as "0-Default"<br>

		</td>
		</tr>
		</table>
		~;
	}
	#<< black adcycle banner

	$master->{html}->footer($master);
}





sub update_group{
  my($self,$master)=@_;

	# input params
	my $group_name=$master->{query}->param('group_name');
	my $rotation=$master->{query}->param('rotation');
	my $gid=$master->{query}->param('gid');

	# get the group ref
	my $gidref=$master->{db}->select_single_row_hash("SELECT * FROM groups where GID='$gid'");
	#$master->{clear_cookie}=$gidref->{TID};
	
	#get the campaigns
	my(@cidref)=$master->{db}->select_multi_row_hash("SELECT * FROM cp WHERE WIDTH='$gidref->{WIDTH}' AND HEIGHT='$gidref->{HEIGHT}'");
	my $cidtot=@cidref;

	#get the campaigns
	my(@gridref)=$master->{db}->select_multi_row_hash("SELECT GID,CID,WEIGHT,STATUS,SUM(TOTAL_IMPR) as TOTAL_IMPR, SUM(TOTAL_CLICK) as TOTAL_CLICK FROM cp_grouping where GID='$gid' GROUP BY CID ORDER BY STATUS DESC,WEIGHT DESC");
	my $gridtot=@gridref;


	my %already_inc;
	my @already_inc;
	my $count=0;
	for(my $k=0;$k<$cidtot;$k++){
		my $checked="";
		for(my $g=0;$g<$gridtot;$g++){
			if($gridref[$g]->{CID}==$cidref[$k]->{CID}){
				$already_inc{$cidref[$k]->{CID}}=1;
				$already_inc[$count]=$cidref[$k]->{CID};
				$count++;
			}
		}
	}

	for(my $k=0;$k<$cidtot;$k++){
		my $cid=$cidref[$k]->{CID};
		my $temp=$master->{query}->param("C|$cid|");
		my $weight=$master->{query}->param("WEIGHT|$cid|");

		# add a row
		if($temp==1 && $already_inc{$cid}!=1){
			$master->{db}->{adcycle}->do("INSERT INTO cp_grouping (GID,AID,CID,WEIGHT,STATUS) VALUES ($gid,$cidref[$k]->{AID},$cid,$weight,'1')");
		}

		# update a row
		if($temp==1 && $already_inc{$cid}==1){
			$master->{db}->{adcycle}->do("UPDATE cp_grouping SET WEIGHT='$weight',STATUS='1' WHERE GID='$gid' AND CID='$cid'");
		}

		# update a row
		if($temp==0){
			$master->{db}->{adcycle}->do("UPDATE cp_grouping SET WEIGHT='$weight',STATUS='0' WHERE GID='$gid' AND CID='$cid'");
		}

	}

	# generate query list
	my $c;
	$c=$master->{db}->update_cv($c,"GROUP_NAME",$group_name);
	$c=$master->{db}->update_cv($c,"ROTATION_FLAVOR",$rotation);
	chop($c);

	# insert row
	$master->{db}->{adcycle}->do("UPDATE groups SET $c WHERE GID='$gid'");	

	$master->{message}="Group has been updated";
	$master->{groups}->edit_group($master);
}




sub delete_group{
  my($self,$master)=@_;

	# input params
	my $gid=$master->{query}->param('gid');

	# delete advertiser
	$master->{db}->{adcycle}->do("DELETE FROM groups WHERE GID='$gid'");

	# delete grouping
	$master->{db}->{adcycle}->do("DELETE FROM cp_grouping WHERE GID='$gid'");

	$master->{message}="Group has been deleted";
	$master->{groups}->view_groups($master);

}










sub get_adcodes{
  my($self,$master)=@_;

	# input params
	my $gid=$master->{query}->param('gid');
	my $target=$master->{query}->param('target');
	my $keywords=$master->{query}->param('keywords');
	my $placement=$master->{query}->param('placement');
	my $images_url=$master->{config}->get_images_url;
	my $cgi_bin_url=$master->{config}->get_cgi_bin_url;
	my $cache=$master->{env}->get_cache;

	# get the group ref
	my $gidref=$master->{db}->select_single_row_hash("SELECT * FROM groups where GID='$gid'");
	my $width=$gidref->{WIDTH};
	my $height=$gidref->{HEIGHT};

	# print header
	$master->{LINK}="groups";
	$master->{html}->header($master,"Ad codes for $gidref->{GROUP_NAME}");

	# relative url construction
	my $ul=length($cgi_bin_url);
	my $idx=index($cgi_bin_url,"\/",8);
	my $relative=substr($cgi_bin_url,$idx,$ul-$idx);

	if(length($target)==0){
		$target="_top";
	}


	my %placement;
	my %target;
	my %keywords;

	$placement{$placement}=" selected ";
	$target{$target}=" selected ";
	$keywords{$keywords}=" selected ";


	my $page_layout="";
	my $add_on="";
	if($placement eq "multi"){
		$page_layout=qq~&layout=multi~;
		$add_on="[MULTI-AD]";
	}

	my $kw="";
	if($keywords eq "on"){
		$kw=qq~&keywords=ENTER+KEYWORD+LIST~;
		$add_on.=" [KEYWORD]";
	}



	# add advertiser form
	print qq~
	<img src="$images_url/clear.gif" width=1 height=4><br>
	<form action="$cgi_bin_url/adcenter.cgi" method="get">
	<table cellpadding=3 cellspacing=1 border=0 bgcolor="333333">
	<tr class="td2">
	<td colspan=2><b>Code Options</b> ~;print $master->{html}->question("adcode_page");print qq~</td>
	</tr>
	<tr class="td3">
	<td align="right"><b>Page Target:</b></td>
	<td><select name="target" class="ft1">
	<option $target{_top} value="_top">Target "_top"
	<option $target{_blank} value="_blank">Target "_blank"
	<option $target{_self} value="_self">Target "_self"
	<option $target{_parent} value="_parent">Target "_parent"
	</select>
	</td>
	</tr>
	<tr class="td3">
	<td align="right">
	<b>Page Layout:</b>
	</td>
	<td>
	<select name="placement" class="ft1">
	<option $placement{single} value="single">Single ad in page
	<option $placement{multi} value="multi">Multiple ads in page
	</select>
	</td>
	</tr>
	<tr class="td3">
	<td align="right">
	<b>Keywords:</b>
	</td>
	<td>
	<select name="keywords" class="ft1">
	<option $keywords{off} value="off">No Keyword Targeting
	<option $keywords{on} value="on">Keyword Targeting Code
	</select>
	</td>
	</tr>
	</table>
	<img src="$images_url/clear.gif" width=1 height=4><br>
	<input type="submit" name="change" value="CHANGE" class="ft2">
	<input type="hidden" name="task" value="get_adcodes">
	<input type="hidden" name="gid" value="$gid">
	</form>
	&nbsp;<br>
	&nbsp;<br>
	~;
	

if($width>2 && $height>2){

#IFRAME CACHE BUST
my $adcode=qq~
<!-- START ADCYCLE.COM IFRAME RICH MEDIA CACHE-BUST CODE for $gidref->{GROUP_NAME} -->
<script language="javascript">
<!-- /* � 2001 AdCycle.com All Rights Reserved.*/ 
var id=$cache;
var jar=new Date();var s=jar.getSeconds();var m=jar.getMinutes();
var flash=s*m+id;var cgi='$cgi_bin_url';
var p='<iframe src="'+cgi+'/adcycle.cgi?gid=$gid$page_layout&t=$target&id='+flash+'&type=iframe$kw" ';
p+='height=$height width=$width border=0 marginwidth=0 marginheight=0 hspace=0 ';
p+='vspace=0 frameborder=0 scrolling=no>';
p+='<a href="'+cgi+'/adclick.cgi?manager=adcycle.com&gid=$gid$page_layout&id='+flash+'" target="$target">';
p+='<img src="'+cgi+'/adcycle.cgi?gid=$gid$page_layout&id='+flash+'$kw" width=$width height=$height ';
p+='border=1 alt="Click to Visit"></a></iframe>'; document.write(p); // -->
</script>
<noscript>
<a href="$cgi_bin_url/adclick.cgi?manager=adcycle.com&gid=$gid$page_layout&id=$cache" target="$target"><img src="$cgi_bin_url/adcycle.cgi?gid=$gid$page_layout&id=$cache$kw" width=$width height=$height border=1 ALT="Click to Visit"></a>
</noscript>
<!-- END ADCYCLE.COM IFRAME RICH MEDIA CODE -->~;

$adcode=~s/\</\&lt\;/g;
$adcode=~s/\>/\&gt\;/g;
$adcode=~s/\"/\&quot\;/g;

print qq~
<FORM>
<table cellpadding=5 cellspacing=1 border=0 width=400 bgcolor="333333">
<tr bgcolor="cccccc">
<td>
<b>IFRAME Cache-bust Code [Rich Media Enabled] for <font color="3333CC">$gidref->{GROUP_NAME}</font> $add_on<BR></b>
</td>
</tr>
<tr bgcolor="cccccc">
<td>
<textarea rows="23" cols="$master->{longest2}" wrap=on class="ft1">$adcode</textarea>
This version is recommended.
</td>
</tr>
</table>
</FORM>
&nbsp;<br>
~;


#SSI Code
my $adcode=qq~<!-- START ADCYCLE SSI MEDIA CODE for $gidref->{GROUP_NAME} -->
<!--#include virtual="$relative/adcycle.cgi?gid=$gid$page_layout&type=ssi&id=$cache$kw"-->
<!-- END ADCYCLE CODE -->~;

$adcode=~s/\</\&lt\;/g;
$adcode=~s/\>/\&gt\;/g;
$adcode=~s/\"/\&quot\;/g;

print qq~
<FORM>
<table cellpadding=5 cellspacing=1 border=0 width=400 bgcolor="333333">
<tr bgcolor="cccccc">
<td>
<b>SSI Media Code [Rich Media Enabled] for <font color="3333CC">$gidref->{GROUP_NAME}</font> $add_on<BR></b>
</td>
</tr>
<tr bgcolor="cccccc">
<td>
<textarea rows="3" cols="$master->{longest2}" wrap=on class="ft1">$adcode</textarea>
Your web server needs to have Server Side Includes (SSI) enabled for this ad code to work. This code is not recommended for novices. Please consult with your ISP if you have any problems.
</td>
</tr>
</table>
</FORM>
&nbsp;<br>
~;


# STANDARD CACHE BUST
my $adcode=qq~
<!-- START ADCYCLE STANDARD CACHE-BUST CODE for $gidref->{GROUP_NAME}-->
<script language="javascript">
<!-- /* � 2001 AdCycle.com All Rights Reserved.*/ 
var id=$cache;
var jar=new Date();var s=jar.getSeconds();var m=jar.getMinutes();
var flash=s*m+id;var cgi='$cgi_bin_url';
var p='<a href="'+cgi+'/adclick.cgi?manager=adcycle.com&gid=$gid$page_layout&id='+flash+'" target="$target">';
p+='<img src="'+cgi+'/adcycle.cgi?gid=$gid$page_layout&id='+flash+'$kw" width=$width height=$height ';
p+='border=1 alt="Click to Visit"></a>'; document.write(p); // -->
</script>
<noscript>
<a href="$cgi_bin_url/adclick.cgi?manager=adcycle.com&gid=$gid$page_layout&id=$cache" target="$target"><img src="$cgi_bin_url/adcycle.cgi?gid=$gid$page_layout&id=$cache$kw" width=$width height=$height border=1 ALT="Click to Visit"></a>
</noscript>
<!-- END ADCYCLE CODE -->~;

$adcode=~s/\</\&lt\;/g;
$adcode=~s/\>/\&gt\;/g;
$adcode=~s/\"/\&quot\;/g;

print qq~
<FORM>
<table cellpadding=5 cellspacing=1 border=0 width=400 bgcolor="333333">
<tr bgcolor="cccccc">
<td>
<b>Standard Cache-bust Code for <font color="3333CC">$gidref->{GROUP_NAME}</font> $add_on<BR></b>
</td>
</tr>
<tr bgcolor="cccccc">
<td>
<textarea rows="18" cols="$master->{longest2}" wrap=on class="ft1">$adcode</textarea>
</td>
</tr>
</table>
</FORM>
&nbsp;<br>
~;


# STANDARD
my $adcode=qq~
<!-- START ADCYCLE STANDARD CODE for $gidref->{GROUP_NAME}-->
<a href="$cgi_bin_url/adclick.cgi?manager=adcycle.com&gid=$gid$page_layout&id=$cache" target="$target"><img src="$cgi_bin_url/adcycle.cgi?gid=$gid$page_layout&id=$cache$kw" width=$width height=$height border=1 ALT="Click to Visit"></a>
<!-- END ADCYCLE CODE -->~;

$adcode=~s/\</\&lt\;/g;
$adcode=~s/\>/\&gt\;/g;
$adcode=~s/\"/\&quot\;/g;

print qq~
<FORM>
<table cellpadding=5 cellspacing=1 border=0 width=400 bgcolor="333333">
<tr bgcolor="cccccc">
<td>
<b>Standard Code for <font color="3333CC">$gidref->{GROUP_NAME}</font> $add_on<BR></b>
</td>
</tr>
<tr bgcolor="cccccc">
<td>
<textarea rows="6" cols="$master->{longest2}" wrap=on class="ft1">$adcode</textarea><br>
Use this code if you do not want rich media support, and no cache-busting.
</td>
</tr>
</table>
</FORM>
&nbsp;<br>
~;







print qq~
&nbsp;<br>
<table cellpadding=7 cellspacing=1 border=0 width=400 bgcolor="333333">
<tr bgcolor="33CCFF">
<td>
<b>If you have more than one ad in a single page, select "Multiple Ads in a Page" from the pulldown menu at the top of this page, and change the "id=\#" to a unique number for each ad code. Creating unique numbers for the ad code id can be accomplished by reloading this page.
</td>
</tr>
</table>
&nbsp;<br>
~;




}else{

print qq~Rotation functionality for text links and pop-windows is still under development. In the meantime, please use the direct ad codes provided in the campaign creative pages.~;



}






	$master->{html}->footer($master);
}











# Copyright (c) 2001 AdCycle.com All rights reserved.
# http://www.adcycle.com - download the lastest version of adcycle 

1;

