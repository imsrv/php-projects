<!-- beginning of footer -->

<P>
<TABLE WIDTH=100% BGCOLOR=#aaaaaa CELLSPACING=0 CELLPADDING=3
 BORDER=0>
 <TR>
 <TD BGCOLOR=#ffffff>&nbsp;</TD>
 <TD BGCOLOR=#eeeeee>&nbsp;</TD>
 <TD BGCOLOR=#d5d5d5>&nbsp;</TD>
 <TD BGCOLOR=#cccccc>&nbsp;</TD>
 <TD BGCOLOR=#bbbbbb>&nbsp;</TD>
 <TD ALIGN=CENTER VALIGN=MIDDLE>
  <CENTER>
   <FONT SIZE=-1 FACE="Arial, Verdana" COLOR=#555555>
    &copy; 2000 under the GNU Public License, v2
   </FONT>
  </CENTER>
 </TD>
 <TD BGCOLOR=#bbbbbb>&nbsp;</TD>
 <TD BGCOLOR=#cccccc>&nbsp;</TD>
 <TD BGCOLOR=#d5d5d5>&nbsp;</TD>
 <TD BGCOLOR=#eeeeee>&nbsp;</TD>
 <TD BGCOLOR=#ffffff>&nbsp;</TD>
 </TR>
</TABLE>
<P>

</BODY>
</HTML>
