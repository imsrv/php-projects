<?php
$bottom=<<<BOTTOM
<table width=975 border=0 cellspacing=0 cellpadding=0 align=center>
<tr>
<td bgcolor="#CCCCCC"><img src="%%RF%%style/%%STYLE%%/image/0.gif" width="1" height="1"></td>
</tr>
<tr>
<td>
<table width="100%" border=0 cellspacing=0 cellpadding=0 align=center>
<tr valign=top>
<td><div class=bottom><b>&nbsp;</b></div></td>
<td align=right><div class=bottom>&nbsp;</div></td>
</tr>
</table>
</td>
</tr>
</table>
</form>
</body>
</html>

BOTTOM;
?>
