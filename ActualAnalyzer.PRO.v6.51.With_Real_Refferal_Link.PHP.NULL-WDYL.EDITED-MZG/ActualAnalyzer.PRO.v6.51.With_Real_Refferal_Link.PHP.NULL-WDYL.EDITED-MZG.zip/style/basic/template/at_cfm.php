<?php

$cmess=<<<CMESS
<DIV class=bor750>
<table width=750 border=0 cellspacing=0 cellpadding=0 align=center>
<tr height=20><td background="%%RF%%style/%%STYLE%%/image/bg.gif"><font color="#FFFFFF"><SPAN class=f12>&nbsp;&nbsp;<b>%%HEADER%%</b></SPAN></font></td></tr>
<tr bgcolor="#EEEEEE" height=20><td align=center><SPAN class=f11>%%CONFIRM%%</SPAN></td></tr>
<tr height=20><td align=center background="%%RF%%style/%%STYLE%%/image/bg2.gif"><table width="100%" border=0 cellspacing=0 cellpadding=0><tr>
<td align=right width="47%"><a href="admin.php" onclick="return false"><img TABINDEX=7 width=20 height=20 src="%%RF%%style/%%STYLE%%/image/back.gif" title="%%BACK%%" border=0 onclick='FormIdExtParam(admin,"%%PGID%%","back","%%ACT%%")'></a></td>
<td width="6%">&nbsp;</td><td align=left width="47%"><a href="admin.php" onclick="return false"><img TABINDEX=8 width=20 height=20 src="%%RF%%style/%%STYLE%%/image/go.gif" title="%%NEXT%%" border=0 onclick='FormIdExtParam(admin,"%%PGID%%","confirm","%%PARAM%%")'></a></td>
</tr></table></td></tr></table></DIV><br>

CMESS;

$topg=<<<TOPG
<DIV class=bor750>
<table width=750 border=0 cellspacing=0 cellpadding=0 align=center>
<tr height=20><td background="%%RF%%style/%%STYLE%%/image/bg.gif"><font color="#FFFFFF"><SPAN class=f12>&nbsp;&nbsp;<b>%%HEADER%%</b></SPAN></font></td></tr>
<tr bgcolor="#EEEEEE" height=20><td align=center><SPAN class=f11>%%CONFIRM%%&nbsp;&nbsp;'<i>%%GROUP%%</i>'&nbsp;?</SPAN></td></tr>
<tr height=20><td align=center background="%%RF%%style/%%STYLE%%/image/bg2.gif"><table width="100%" border=0 cellspacing=0 cellpadding=0><tr>
<td align=right width="47%"><a href="admin.php" onclick="return false"><img TABINDEX=7 width=20 height=20 src="%%RF%%style/%%STYLE%%/image/back.gif" title="%%BACK%%" border=0 onclick='FormIdExtParam(admin,"%%PGID%%","back","%%ACT%%")'></a></td>
<td width="6%">&nbsp;</td><td align=left width="47%"><a href="admin.php" onclick="return false"><img TABINDEX=8 width=20 height=20 src="%%RF%%style/%%STYLE%%/image/go.gif" title="%%NEXT%%" border=0 onclick='FormIdExtParam(admin,"%%PGID%%","confirm","%%PARAM%%")'></a></td>
</tr></table></td></tr></table></DIV><br>

TOPG;

$topp=<<<TOPP
<DIV class=bor750>
<table width=750 border=0 cellspacing=0 cellpadding=0 align=center>
<tr height=20><td background="%%RF%%style/%%STYLE%%/image/bg.gif"><font color="#FFFFFF"><SPAN class=f12>&nbsp;&nbsp;<b>%%HEADER%%</b></SPAN></font></td></tr>
<tr bgcolor="#EEEEEE" height=20>
<td align=center><div class=tabl><SPAN class=f11>%%CONFIRM%%&nbsp;&nbsp;'</SPAN><a href="%%URL%%" style="color:#000000" title="%%PAGE%%" target=_blank><code class=f9><i>%%PAGESHORT%%</i></code></a><SPAN class=f11>'&nbsp;?</SPAN></div></td></tr>
<tr height=20><td align=center background="%%RF%%style/%%STYLE%%/image/bg2.gif"><table width="100%" border=0 cellspacing=0 cellpadding=0><tr>
<td align=right width="47%"><a href="admin.php" onclick="return false"><img TABINDEX=7 width=20 height=20 src="%%RF%%style/%%STYLE%%/image/back.gif" title="%%BACK%%" border=0 onclick='FormIdExtParam(admin,"%%PGID%%","back","%%ACT%%")'></a></td>
<td width="6%">&nbsp;</td><td align=left width="47%"><a href="admin.php" onclick="return false"><img TABINDEX=8 width=20 height=20 src="%%RF%%style/%%STYLE%%/image/go.gif" title="%%NEXT%%" border=0 onclick='FormIdExtParam(admin,"%%PGID%%","confirm","%%PARAM%%")'></a></td>
</tr></table></td></tr></table></DIV><br>

TOPP;

?>