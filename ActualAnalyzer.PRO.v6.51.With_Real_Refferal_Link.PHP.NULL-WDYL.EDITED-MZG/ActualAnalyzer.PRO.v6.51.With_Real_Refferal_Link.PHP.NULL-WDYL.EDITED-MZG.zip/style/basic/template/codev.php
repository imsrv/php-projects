<?php
$begin=<<<BEGIN
<DIV class=bor750><table width=750 border=0 cellspacing=0 cellpadding=0 align=center><tr height=20>
<td class=linkw background="%%RF%%style/%%STYLE%%/image/bg.gif"><font color="#FFFFFF"><SPAN class=f12>&nbsp;&nbsp;<b>%%HEADER%%</b></SPAN></font></td>
</tr><tr><td bgcolor="#EEEEEE"><textarea rows=10 cols=91 class=tarea750>

BEGIN;

$end=<<<END
</textarea></td></tr><tr height=20><td background="%%RF%%style/%%STYLE%%/image/bg2.gif" align=right><SPAN class=f10>&nbsp;</SPAN></td></tr></table></DIV><br>

END;
?>