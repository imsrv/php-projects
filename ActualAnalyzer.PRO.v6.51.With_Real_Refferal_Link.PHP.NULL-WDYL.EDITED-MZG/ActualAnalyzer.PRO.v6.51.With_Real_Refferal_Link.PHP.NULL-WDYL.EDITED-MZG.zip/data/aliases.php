<?php

/*------------------------------------------------------------------------------
Add below this block the aliases of your domain
For example:

$alias[]='babelfish.altavista.com';
$alias[]='actualscripts.org';

ActualAnalyzer will store the statistics also for actualscripts.net and
actualscripts.org
------------------------------------------------------------------------------*/
$alias[]='babelfish.altavista.com';
$alias[]='translate.ru';
$alias[]='translate.google.com';

?>