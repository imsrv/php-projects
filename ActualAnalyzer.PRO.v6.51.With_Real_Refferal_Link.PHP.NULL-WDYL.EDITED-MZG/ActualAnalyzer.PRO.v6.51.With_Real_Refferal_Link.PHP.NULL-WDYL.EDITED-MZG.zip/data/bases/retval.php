<?php

$retval[1]=3;
$retval[2]=10;
$retval[3]=30;
$retval[4]=60;
$retval[5]=180;
$retval[6]=600;
$retval[7]=1800;
$retval[8]=3600;
$retval[9]=10800;
$retval[10]=36000;
$retval[11]=86400;
$retval[12]=259200;
$retval[13]=864000;
$retval[14]=26280000;
$retval[15]=78840000;
$retval[16]=315360000;
$retval[17]=946080000;
$retval[18]=0;

?>