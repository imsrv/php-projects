<?php

$exthost[]='com';
$exthost[]='net';
$exthost[]='org';
$exthost[]='edu';
$exthost[]='int';
$exthost[]='gov';
$exthost[]='mil';
$exthost[]='biz';
$exthost[]='pro';
$exthost[]='coop';
$exthost[]='arpa';
$exthost[]='info';
$exthost[]='aero';
$exthost[]='nato';
$exthost[]='museum';

?>