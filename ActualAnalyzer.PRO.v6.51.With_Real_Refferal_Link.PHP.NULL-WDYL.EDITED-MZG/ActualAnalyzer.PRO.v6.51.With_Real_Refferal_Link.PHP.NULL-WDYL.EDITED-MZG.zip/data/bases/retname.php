<?php

$rettime[1]=_LESSTHAN.' 3 '._SEC;
$rettime[2]='3 '._SEC.' - 10 '._SEC;
$rettime[3]='10 '._SEC.' - 30 '._SEC;
$rettime[4]='30 '._SEC.' - 1 '._MIN;
$rettime[5]='1 '._MIN.' - 3 '._MIN;
$rettime[6]='3 '._MIN.' - 10 '._MIN;
$rettime[7]='10 '._MIN.' - 30 '._MIN;
$rettime[8]='30 '._MIN.' - 1 '._HOUR_S;
$rettime[9]='1 '._HOUR_S.' - 3 '._HOUR_S;
$rettime[10]='3 '._HOUR_S.' - 10 '._HOUR_S;
$rettime[11]='10 '._HOUR_S.' - 1 '._DAY_S;
$rettime[12]='1 '._DAY_S.' - 3 '._DAY_S;
$rettime[13]='3 '._DAY_S.' - 10 '._DAY_S;
$rettime[14]='10 '._DAY_S.' - 1 '._MONTH_S;
$rettime[15]='1 '._MONTH_S.' - 3 '._MONTH_S;
$rettime[16]='3 '._MONTH_S.' - 1 '._YEAR_S;
$rettime[17]='1 '._YEAR_S.' - 3 '._YEAR_S;
$rettime[18]=_MORETHAN.' 3 '._YEAR_S;

?>