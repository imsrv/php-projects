<?php

$tzones[1]='(GMT -12:00 hours) Eniwetok, Kwajalein';
$tzones[2]='(GMT -11:00 hours) Midway Island, Samoa';
$tzones[3]='(GMT -10:00 hours) Hawaii';
$tzones[4]='(GMT -9:00 hours) Alaska';
$tzones[5]='(GMT -8:00 hours) Pacific Time';
$tzones[6]='(GMT -7:00 hours) Mountain Time, Arizona';
$tzones[7]='(GMT -6:00 hours) Central Time, Mexico City';
$tzones[8]='(GMT -5:00 hours) Eastern Time, Bogota, Lima';
$tzones[9]='(GMT -4:00 hours) Atlantic Time, Caracas';
$tzones[10]='(GMT -3:00 hours) Brassila, Buenos Aires';
$tzones[11]='(GMT -2:00 hours) Mid-Atlantic, Ascension Is.';
$tzones[12]='(GMT -1:00 hour) Azores, Cape Verde Islands';
$tzones[13]='(GMT) Casablanca, Edinburgh, London, Lisbon';
$tzones[14]='(GMT +1:00 hour) Berlin, Paris, Rome';
$tzones[15]='(GMT +2:00 hours) Cairo, Helsinki, Kaliningrad';
$tzones[16]='(GMT +3:00 hours) Baghdad, Moscow, Nairobi';
$tzones[17]='(GMT +4:00 hours) Abu Dhabi, Baku, Tbilisi';
$tzones[18]='(GMT +5:00 hours) Ekaterinburg, Islamabad';
$tzones[19]='(GMT +6:00 hours) Almaty, Colombo, Dhaka';
$tzones[20]='(GMT +7:00 hours) Bangkok, Hanoi, Jakarta';
$tzones[21]='(GMT +8:00 hours) Hong Kong, Singapore';
$tzones[22]='(GMT +9:00 hours) Osaka, Seoul, Tokyo';
$tzones[23]='(GMT +10:00 hours) Canberra, Melbourne, Sydney';
$tzones[24]='(GMT +11:00 hours) Magadan, Solomon Islands';
$tzones[25]='(GMT +12:00 hours) Auckland, Marshall Island';
$tzones[26]='(GMT +13:00 hours) Nukualofa';

?>