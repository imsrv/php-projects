<?php
// ATTENTION: add new records to end
$os['winlong']='Windows Codename Longhorn';
$os['win2003']='Windows 2003';
$os['winxp']='Windows XP';
$os['winme']='Windows Me';
$os['win2000']='Windows 2000';
$os['winnt']='Windows NT';
$os['win98']='Windows 98';
$os['win95']='Windows 95';
$os['win16']='Windows 3.xx';
$os['wince']='Windows CE';
$os['macosx']='Mac OS X';
$os['mac']='Mac OS';
$os['linux']='Linux';
$os['aix']='Aix';
$os['sunos']='Sun Solaris';
$os['irix']='Irix';
$os['osf']='OSF Unix';
$os['hpux']='HP Unix';
$os['netbsd']='NetBSD';
$os['bsdi']='BSDi';
$os['freebsd']='FreeBSD';
$os['openbsd']='OpenBSD';
$os['gnu']='GNU';
$os['unix']='Unknown Unix system';
$os['beos']='BeOS';
$os['os2']='OS/2';
$os['amigaos']='AmigaOS';
$os['atari']='Atari';
$os['vms']='VMS';
$os['cpm']='CPM';
$os['dcast']='Dreamcast';
$os['riscos']='RISC OS';
$os['webtv']='WebTV';

?>