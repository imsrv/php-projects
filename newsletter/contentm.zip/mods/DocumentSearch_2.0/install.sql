CREATE TABLE mod_docsearch_config (  result_perpage int(4) default '10',  result_previewlength int(4) default '150');
INSERT INTO mod_docsearch_config VALUES("5", "100");