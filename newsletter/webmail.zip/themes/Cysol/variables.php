<?php
$tableAttributes = "cellspacing='0'";
?>
