<?php
$tableAttributes = "cellspacing='1'";
?>
