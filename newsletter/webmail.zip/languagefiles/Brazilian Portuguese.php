<?php
$l1 = "Ocorreu um erro";
$l2 = "&lt;&lt;&lt; Voltar";
$l3 = "O programa n�o conseguiu estabelecer conex�o com o servidor de POP3. Esta foi a mensagem de erro:";
$l4 = "O programa nao conseguiu autenticar-se no servidor de POP3. Provavelmente o seu usu�rio ou senha est�o errados.";
$l5 = "OK";
$l6 = "Log in";
$l7 = "Senha (Password) do servidor POP:";
$l8 = "Usu�rio do servidor POP:";
$l9 = "Endere�o do servidor POP:";
$l10 = "Nome do servidor POP:";
$l11 = "N�o existem mensagens na sua caixa de entrada.";
$l12 = "Este programa n�o conseguiu executar o comando TOP.";
$l13 = "[Sem assunto]";
$l15 = "O programa falhou ao obter a mensagem #$id.";
$l16 = "Remetente:";
$l17 = "Destinat�rio:";
$l18 = "Data:";
$l19 = "Organiza��o:";
$l20 = "Cliente de Mail:";
$l21 = "Responder a:";
$l22 = "Cabe�alhos";
$l23 = "C�pia oculta:";
$l24 = "Responder";
$l25 = "Encaminhar";
$l26 = "Apagar";
$l27 = "Responder a todos";
$l28 = "Imprimir";
$l29 = "Ver mensagem";
$l30 = "Lingua:";
$l31 = "Tem certeza que deseja apagar a mensagem selecionada?";
$l32 = "A Messagem #$id n�o pode ser removida.";
$l33 = "Nova mensagem";
$l34 = "Atualizar";
$l35 = "[Nome de arquivo desconhecido]";
$l36 = "Assunto:";
$l37 = "De:";
$l38 = "Para:";
$l39 = "C�pia:";
$l40 = "BCC:";
$l41 = "Anexar:";
$l42 = "Enviar como HTML";
$l43 = "Enviar";
$l44 = "Tem certeza que deseja enviar a mensagem agora?";
# Do not translate [date] and [sender]. Think of them as variables. The
# string will be transformed into e.g. "On 08-08-2001 12:42, John Doe
# <doe@example.com> wrote":
$l45 = "Em [date], [sender] escreveu:";
$l46 = "Mensagem reenviada";
$l47 = "voc�";
$l48 = "N�o esque�a de colocar um endere�o v�lido de envio.";
$l49 = "N�o esque�a de colocar um endere�o v�lido de recep��o.";
# The character set corresponding to your language:
$l50 = "ISO-8859-1";
$l51 = "Este programa n�o foi capaz de ler um dos arquivos em anexo. Isto deve-se provavelmente a permiss�es erradas no diret�rio de upload. Contate o administrador de sistema.";
$l52 = "Log out";
$l53 = "Licen�a: <a href='license.txt' target='_blank'>GNU General Public License</a>";
$l54 = "Sobre";
$l55 = "Servidor POP pr�-definido:";
$l56 = "Endere�o de servidor POP pr�-definido:";
$l57 = "Usu�rio de servidor POP pr�-definido:";
$l58 = "Dividir frames";
$l59 = "Verticalmente";
$l60 = "Horizontalmente";
$l61 = "Defini��es";
$l62 = "Salvar defini��es";
$l63 = "Percentagem no frame de caixa de mensagens:";
$l64 = "Percentagem no frame de mensagens:";
$l65 = "Rodap� (todas as p�ginas):";
$l66 = "Cabecalho da p�gina de login:";
$l67 = "Rodap� da p�gina de login:";
$l68 = "Titulo visivel no nome da janela:";
$l69 = "O programa n�o tem permiss�es de escrita no arquivo settingssaved.php. Este arquivo necessita de permiss�es de escrita, altere as permiss�es para 666.";
$l70 = "As defini��es foram gravadas.";
$l71 = "Manter senha (password) antiga";
$l72 = "Nova senha (password):";
$l73 = "Senha (Password) de administrador:";
$l74 = "Administrador:";
$l75 = "Acesso negado.";
$l76 = "%s verifica��o autom�tica";
$l77 = "Ativar";
$l78 = "Desativar";
$l79 = "Numero de minutos entre cada verifica��o:";
$l80 = "Tem certeza que deseja sair?";
$l81 = "Tema:";
$l82 = "<a href='readme.html' target='_blank'>Ver o arquivo readme</a>";
$l83 = "Mensagem de texto formatado:";
$l84 = "Sim";
$l85 = "N�o";
$l86 = "Confirmar recebimento";
$l87 = "Prioridade:";
$l88 = "Alta";
$l89 = "Normal";
$l90 = "Baixa";
$l91 = "Mais Alta";
$l92 = "Mais Baixa";
$l93 = "Esta sele��o ativa/desativa a formata��o do texto. Se voc� selecionar esta op��o, textos de mensagens ser�o formatados de forma que *bold* ser� convertido para <b>bold</b>, /italic/ ser� convertido para <i>italic</i>, e _underlined_ ser� convertido para <u>underlined</u>.";
$l94 = "Ajuda";
$l95 = "Fechar";
$l96 = "Se voc� desejar limitar os usu�rios deste programa para apenas um servidor POP, ou para um pequeno n�mero de servidores POP pr�-definidos, escreva uma lista destes servidores separados por v�rgula e um espa�o: <i>mail1.example.com, mail2.example.com, mail3.example.com</i>";
$l97 = "Entre com um ou mais n�meros de portas separados por v�gula e um espa�o, ex.: <i>110, 111</i>.";
$l98 = "Entre com um ou mais usu�rios POP separados por v�gula e um espa�o, ex.: <i>user1, user2</i>.";
$l99 = "Seu endere�o de e-mail:";
$l100 = "Vo�� n�o selecionou nenhuma mensagem para ser apagada.";
$l101 = "Voc� tem certeza que quer apagar as mensagens selecionadas ?";
$l102 = "(Des)Selecionar todas";
$l103 = "Re-digite a senha";
$l104 = "As senhas n�o conferem. N�o s�o iguais.";



function l14($timeStamp) {
	return date("d/m/Y H:i", $timeStamp);
}
?>