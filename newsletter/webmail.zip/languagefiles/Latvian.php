<?php
$l1 = "Radusies k��da";
$l2 = "&lt;&lt;&lt; Atpaka�";
$l3 = "Nav iesp�jams savienoties ar POP serveri, m��iniet v�lreiz. ��di izskat�s k��da:";
$l4 = "Nav iesp�jams savienoties ar POP serveri, m��iniet v�lreiz. Iesp�jamais iemesls - nepareizs lietot�ja v�rds vai parole.";
$l5 = "Turpin�t";
$l6 = "Ielogoties";
$l7 = "Parole:";
$l8 = "Lietot�js:";
$l9 = "Servera ports:";
$l10 = "Servera nosaukums:";
$l11 = "Pastkast�t� nav v�stu�u.";
$l12 = "Programma nevar palaist TOP komandu.";
$l13 = "[Bez virsraksts]";
$l15 = "Nav izdevies atv�rt v�stuli nr #$id.";
$l16 = "S�t�t�js:";
$l17 = "Sa��m�js:";
$l18 = "Datums:";
$l19 = "Organiz�cija:";
$l20 = "S�t�t�ja pasta programma:";
$l21 = "Atbild�t uz:";
$l22 = "Virsraksti";
$l23 = "CC:";
$l24 = "Atbild�t";
$l25 = "P�rs�t�t";
$l26 = "Dz�st";
$l27 = "Atbild�t uz vis�m";
$l28 = "Izdruk�t";
$l29 = "Par�d�t kodu";
$l30 = "Valoda:";
$l31 = "Vai tie��m v�laties dz�st izv�l�to v�stuli?";
$l32 = "V�stuli #$id nevar izdz�st.";
$l33 = "Jauna v�stule";
$l34 = "P�rlas�t";
$l35 = "[Nezin�ms faila v�rds]";
$l36 = "T�ma:";
$l37 = "No:";
$l38 = "Kam:";
$l39 = "CC:";
$l40 = "BCC:";
$l41 = "Pievienot failu:";
$l42 = "S�t�t k� HTML";
$l43 = "S�t�t";
$l44 = "Vai v�laties nos�t�t t�l�t?";
# Do not translate [date] and [sender]. Think of them as variables. The
# string will be transformed into e.g. "On 08-08-2001 12:42, John Doe
# <doe@example.com> wrote":
$l45 = "Datum� [date], [sender] rakst�ja:";
$l46 = "P�rs�t�ta v�stule";
$l47 = "tu";
$l48 = "Neaizmirstiet ierakst�t pareizu s�t�t�ja adresi.";
$l49 = "Neaizmirstiet ierakst�t pareizu sa��m�ja adresi.";
# The character set corresponding to your language:
$l50 = "Windows-1257";
$l51 = "Nav iesp�jams nolas�t k�du no pievienotajiem failiem. L�dzu sazinieties ar admnistratoru";
$l52 = "Beigt darbu";
$l53 = "Licenze: <a href='license.txt' target='_blank'>GNU General Public License</a>";
$l54 = "Par";
$l55 = "POP serveris:";
$l56 = "POP servera ports:";
$l57 = "POP servera lietot�js:";
$l58 = "Sadal�t freimus";
$l59 = "Vertik�li";
$l60 = "Horizont�li";
$l61 = "Opcijas";
$l62 = "Saglab�t opcijas";
$l63 = "Virsrakstu da�as procentu�l� da�a:";
$l64 = "V�stules da�as procentu�l� da�a:";
$l65 = "Pak�je (visas lapas)):";
$l66 = "Ielogojam�s lapas galvene:";
$l67 = "Ielogojam�s lapas pak�je:";
$l68 = "Virsraksts p�rl�k�:";
$l69 = "�ai programmai nav teis�bas ierakst�t fail� settingssaved.php. �o faiam vajag uzlikt tiesibas uz 666.";
$l70 = "Opcijas noglab�tas.";
$l71 = "Saglab�t iepriek��jo paroli";
$l72 = "Jauna parole:";
$l73 = "Administr��anas lapas parole:";
$l74 = "Admnistr��anas lapas lietot�js:";
$l75 = "Pieeja aizliegta.";
$l76 = "%s autom�tisko p�rbaudi";
$l77 = "At�aut";
$l78 = "Aizliegt";
$l79 = "Cik min�tes gaid�t l�dz n�ko�ai p�rbaudei?";
$l80 = "Vai tie��m v�laties beigt darbu?";
$l81 = "T�ma:";
$l82 = "<a href='readme.html' target='_blank'>Apskat�t pal�dz�bas failu</a>";
$l83 = "Format�ts v�stules teksts:";
$l84 = "J�";
$l85 = "N�";
$l86 = "Jaut�t par sa�em�anu";
$l87 = "Priorit�te:";
$l88 = "Augsta";
$l89 = "Norm�la";
$l90 = "Zema";
$l91 = "Augst�k�";
$l92 = "Zem�k�";
$l93 = "�� opcija iesl�dz/izsl�dz format�tu v�stules tekstu. Ja opciju iesl�gsiet, tad parast� teksta v�stules tiks format�tas.";
$l94 = "Pal�dz�ba";
$l95 = "Aizv�rt";
$l96 = "Ja v�laties ierobe�ot lietot�jam serveru izv�li, tad sarakstiet tos rind� atdalot ar kommatu un atstarpi: <i>mail1.example.com, mail2.example.com, mail3.example.com</i>";
$l97 = "Ierakstiet vienu vai vair�kus portus atdalot ar kommatu un atstarpi, piem�ram,. <i>110, 111</i>.";
$l98 = "Ierakstiet vienu vai vair�kus lietot�ju v�rdus atdalot ar kommatu un atstarpi, piem�ram, <i>user1, user2</i>.";
$l99 = "E-pasta adrese:";
$l100 = "J�s neesat izv�l�jies nevienu v�stuli, ko dz�st.";
$l101 = "Vai tie��m v�laties dz�st izv�l�t�s v�stules?";
$l102 = "(Ne)Atz�m�t visus";
$l103 = "Atk�rtojiet paroli";
$l104 = "J�sus ievad�t�s paroles nav vien�das.";



function l14($timeStamp) {
	return date("m-d-Y h:i a", $timeStamp);
}
?>