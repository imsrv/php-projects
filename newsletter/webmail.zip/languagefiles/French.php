<?php
// Version:0.6

$l1 = "Une erreur est survenue";
$l2 = "&lt;&lt;&lt; Pr&eacute;c&eacute;dent";
$l3 = "Le programme ne peut se connecter au serveur POP . Message d'erreur::";
$l4 = "Le programme ne peut ouvrir de session sur le serveur POP. Ceci est probablement du &agrave; un nom d'utilisateur ou un mot de passe incorrect";
$l5 = "OK";
$l6 = "Connexion";
$l7 = "Mot de passe:";
$l8 = "Utilisateur: ";
$l9 = "Port du serveur POP:";
$l10 = "Nom du serveur POP:";
$l11 = "Vous n'avez pas de nouveaus message.";
$l12 = "Le programme ne peut exc&eacute;ter la commande TOP.";
$l13 = "[Pas d'objet]";
$l15 = "Erreur lors de la r&eacute;ception du message: #$id.";
$l16 = "Exp&eacute;diteur:";
$l17 = "Destinataire";
$l18 = "Date:";
$l19 = "Soci&eacute;t&eacute;:";
$l20 = "Client de messagerie:";
$l21 = "R&eacute;pondre &agrave; ";
$l22 = "En-t&ecirc;tes";
$l23 = "Cc:";
$l24 = "R&eacute;pondre";
$l25 = "Transf&eacute;rer";
$l26 = "Supprimer";
$l27 = "R&eacute;pondre &agrave; tous";
$l28 = "Imprimer";
$l29 = "Afficher la source";
$l30 = "Langue";
$l31 = "Etes vous sure de vouloir supprimer le message s&eacute;lectionn&eacute;?";
$l32 = "Le message #$id ne peut &ecirc;tre supprim&eacute;.";
$l33 = "Nouveau message";
$l34 = "Rafra&icirc;chir";
$l35 = "[Nom de fichier inconnu]";
$l36 = "Objet";
$l37 = "De:";
$l38 = "A:";
$l39 = "Cc:";
$l40 = "BCc:";
$l41 = "Fichier joint:";
$l42 = "Envoyer au format HTML";
$l43 = "Envoyer";
$l44 = "Etes vous certain de vouloir envoyer le message maintenant?";
# Do not translate [date] and [sender]. Think of them as variables. The
# string will be transformed into e.g. "On 08-08-2001 12:42, John Doe
# <doe@example.com> wrote":
$l45 = "Le [date], [sender] wrote:";
$l46 = "Message transf&eacute;r&eacute;";
$l47 = "Vous";
$l48 = "N'oubliez pas de saisir une adresse d'exp&eacute;diteur correcte.";
$l49 = "N'oubliez pas de saisir une adresse de destinataire correcte.";
# The character set corresponding to your language:
$l50 = "ISO-8859-1";
$l51 = "Le programme n'a pu lire l'un des fichier joints. Ceci est probablement du &agrave; des permission insuffisante sur le r&eacute;pertoire de t&eacute;l&eacute;chargement. Merci de contacter l'administrateur du syst&egrave;me.";
$l52 = "D&eacute;connexion";
$l53 = "Licence: <a href='license.txt' target='_blank'>GNU General Public License</a>";
$l54 = "A propos";
$l55 = "Serveur POP pr&eacute;d&eacute;fini:";
$l56 = "Port du serveur POP predefini:";
$l57 = "Compte POP pr&eacute;d&eacute;fini:";
$l58 = "Split frames";
$l59 = "Verticallement";
$l60 = "Horizontallement";
$l61 = "Param&egrave;tres";
$l62 = "Sauver les param&egrave;tres";
$l63 = "Pourcentage de la frame d'ent&ecirc;te:";
$l64 = "Pourcentage de la frame de message:";
$l65 = "Pied de page (toutes les pages):";
$l66 = "En-t&ecirc;te de la la page de login:";
$l67 = "pied de page de la page de login:";
$l68 = "Le titre vu dans la barre de titre:";
$l69 = "Le programme n'a pas l'autorisation d'&eacute;crire dans le fichier settingssaved.php. Ce fichier doit avoir les permissions 666.";
$l70 = "Les param&egrave;tres on &eacute;t&eacute; sauv&eacute;s.";
$l71 = "Conserver l'ancien mot de passe";
$l72 = "Nouveau mot de passe";
$l73 = "mot de passe de la page d'administration:";
$l74 = "Utilisateur de la page d'administration:";
$l75 = "Acc&eacute;s refus&eacute;";
$l76 = "%s le v&eacute;rification automatique";
$l77 = "Activer";
$l78 = "D&eacute;sactiver";
$l79 = "Interval entre chaque v�rification (en minute):";
$l80 = "Etes vous sure de vouloir d�connecter?";
$l81 = "Th&egrave;me:";
$l82 = "<a href='readme.html' target='_blank'>Voir le fichier readme</a>";
$l83 = "Formatted message text:";
$l84 = "Oui";
$l85 = "Non";
$l86 = "Demander un r&eacute;ponse";
$l87 = "Priorit&eacute;:";
$l88 = "Haute";
$l89 = "Normale";
$l90 = "Faible";
$l91 = "La plus haute";
$l92 = "La plus faible";
$l93 = "Cette option active ou d&eacute;sactive l'envoie des messages au format texte. si vous l'activez, les messages en texte brut seront format&eacute; de la fa&ccedil;on suivante: *bold* sera converti en <b>bold</b>, /italic/ en <i>italic</i>, et _underlined_ en <u>underlined</u>.";
$l94 = "Aide";
$l95 = "Fermer";
$l96 = "si vous souha&icirc;tez limiter les utilisateur de ce programme &agrave; un seul serveur POP ou &agrave; un nombre de serveurs pr&eacute;d&eacute;finies, entrez la liste de ces serveurs s&eacute;par&eacute;e par une virgule et un espace, ex: <i>mail1.example.com, mail2.example.com, mail3.example.com</i>";
$l97 = "Entrez un ou plusieurs num&eacute;ro de ports s&eacute;par&eacute;s par une virgule et un espace. ex: <i>110, 111</i>.";
$l98 = "Entrez un ou plusieurs noms d'utilisateurs s&eacute;par&eacute;s par une virgule et un espace. ex <i>user1, user2</i>.";
$l99 = "Votre adresse email:";
$l100 = "You did not select any messages to be deleted.";
$l101 = "Are you sure that you want to delete the selected messages?";
$l102 = "(De)select all";
$l103 = "Repeat the password";
$l104 = "The two passwords you entered are not the same.";



function l14($timeStamp) {
	return date("d-m-Y H:i ", $timeStamp);
}
?>